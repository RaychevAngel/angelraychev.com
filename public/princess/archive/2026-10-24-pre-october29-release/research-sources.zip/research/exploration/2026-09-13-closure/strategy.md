# Strategy normal forms: exploration and rejection tests

13 September 2026, bounded exploration beginning at 17:06 UTC. This note records research directions, applicability conditions, and small rejection tests. It adds no accepted classification theorem. No manuscript, Lean, or website changes belong to this exploration.

The leading global direction is a **joint forward/reverse calibration of the actual middle intersection**, with **two-history central-threshold domination** as its focused odd-area target. Causal, budget-preserving exchange remains a possible proof mechanism, but the fixed-matching clearance-time route is substantially downgraded: the accepted $25\times26$, $k=13$, 188-day optimal solo witness admits no such matching and also fails two-day physical survivor nesting. This does not rule out a different optimal monotone strategy. Ordinary lattice uncrossing, ordinary discrete-convex resource allocation, and an unqualified flow relaxation each miss an essential condition. The tests below identify those conditions explicitly.

## 1. What a successful result must contain

Current scope was checked against `CURRENT_CHECKPOINT.md`, `HANDOFF.md`, and `research/RECTANGLE_GAPS.md`. A global result must include optimal strategies from the actual full-board start, with the same inspection quota on every day. Classifying arbitrary partial beliefs is unnecessary; proving an assertion only for synthetic scalar states is insufficient.

There are two separate targets:

1. A structural theorem decides the optimal strategy/value, including the remaining shared-budget middle day and the shape-changing even-area cases.
2. A numerical theorem evaluates the resulting clocks and endpoint tests with a number of permitted operations independent of width, length, and budget. A polynomial optimizer, a width-sized state graph, or a recurrence with one operation per root band does not meet this second target.

The existing exact boundary-port representation already covers arbitrary rectangles after parameter-dependent preprocessing. A proposed universal optimization formulation must improve that boundary, rather than rename the same computation.

Four live counterexamples constrain any normal form:

* On the genuine $11\times11$, $k=7$ full-start solo orbit, capacities go $(0,0)\to(4,4)\to(8,7)\to(10,11)\to(14,12)$. The inverse-profile facts “nondecreasing, 1-Lipschitz, phase difference at most one” do not preserve a solo difference at most one. See `research/bridge-odd-clock-bottom-orientation.md`.
* On $21\times21$, $k=12$, an actual quota history reaches a mixed state $(1,55)$ when solo capacities are $(55,56)$. Its total exceeds the slower solo capacity. Mixed exceptions are real even before the upper collar; a proof cannot discard all of them.
* On $16\times n$, $k=56$, $n\equiv22\pmod{12}$, the accepted optimal construction uses the physical transition $127\to79\to28$, changing boundary shape and corner. The corresponding fixed-anchor continuation leaves 29. A universal fixed-anchor strategy is therefore the wrong target. See `research/bridge-quadratic-edge-exception.md`.
* For the accepted $25\times26$, $k=13$, 188-day optimal solo witness, the allowed matching graph has maximum matching 182, below the required 325, with a Hall witness of 212 vertices having only 69 neighbors. The witness also fails two-day physical survivor nesting on 20 days, first at day 12 and last at day 172. A fixed matching cannot encode this witness as a nested history; existence of an alternative optimal nested history remains open.

## 2. Route A, downgraded mechanism: causal balanced exchange of whole histories

**Scope and payoff.** A causal exchange theorem could support a joint calibration for odd and even area. The fixed-matching implementation below is no longer a leading normal-form candidate: a known optimal 25-row witness fails its defining representation. To continue through that route, one must produce an alternative optimal nested strategy or explicitly allow matching changes/recontamination. Neither modification currently has a uniform proof or a constant-size endpoint formula.

The lower exploration lane has the useful daily inequality for union/intersection of survivor histories, but it controls the sum of their daily costs. It does not keep each new history under its own daily quota. Its two-vertex example is decisive: two histories with costs $(1,1)$ can uncross to costs $(0,2)$ and $(2,0)$. A total-cost argument cannot repair this.

There is an unusually close external mechanism. Antoniadis, Hüffner, Lenzner, Moldenhauer, and Souza prove that a collection of intervals admits a coloring whose color loads differ by at most one at every point, with a constructive algorithm. Thus independently recolorable unit intervals of aggregate load at most $2k$ can be divided into two loads at most $k$. Their higher-dimensional and online results also warn against discarding the interval hypothesis. [Balanced Interval Coloring, STACS 2011](https://drops.dagstuhl.de/entities/document/10.4230/LIPIcs.STACS.2011.531).

**The required bridge is causal, not merely algebraic.** One would need to decompose the difference between two legal histories into packets such that:

1. Each packet has a specified daily inspection load.
2. Recoloring packets preserves legal survivor transitions, not only cardinalities.
3. The resulting two histories retain the endpoint property needed by the central splice, or improve its capped union.
4. The packet recoloring theorem respects every daily capacity, including the first and final days.

The lower lane's matching-normal-form candidate supplies a conditional interval representation. Identify opposite colors by a fixed perfect matching. Movement alternates two directed relations $K,K^T$, each containing loops. If some time-optimal full-start strategy has nested matched survivor sets, each matched vertex has a last surviving time $\ell(v)$. Its required inspections occur after $\ell(v)$ while a predecessor still survives. On either time parity the predecessor relation is fixed, giving an arithmetic-progression interval of inspections. A vertex therefore produces up to two parity intervals, tied to the same clearance time.

This is weaker than ordinary hunter monotonicity and allows boundary shapes to change. The lower lane reports exact tiny comparisons supporting matched nesting on $2\times4$, $2\times6$, and $4\times4$ at the tested feasible quotas; those are finite evidence, not a proof. The 25-row matching and two-day-nesting failures above are substantially stronger negative evidence against using the representation unqualified. They refute its applicability to that accepted optimal witness, not the existence of another optimal nested witness. The additional unmatched vertex on odd-area boards also needs an explicit terminal rule; a perfect matching cannot simply be assumed there.

**Why changing the time coordinate does not finish the argument.** Separate parity clocks turn each column into two interval blocks, not one common interval. Stacking the two clocks or imposing adjacent-slot daily constraints can destroy integrality. The abstract three-packet system

$$A=\{1,3\},\qquad B=\{1,2\},\qquad C=\{2,3\}$$

has aggregate load two at every time, but cannot be colored into two loads at most one. Each packet is an interval on each parity and permits a shared clearance start. Its $3\times3$ incidence determinant has absolute value two, unchanged by reordering time. This is an abstract obstruction; no claim is made that these three packets alone arise from a physical grid history.

Causality may be precisely what repairs it. If a vertex cleared before day 1 needs another inspection on day 3, a predecessor must remain alive sufficiently late. That predecessor has its own mandatory clearance load. These future-witness loads are absent from the bare triangle. They can change the actual half-rounding problem even though adding columns cannot remove an existing non-unimodular submatrix. This suggests a narrower **causal half-rounding lemma**, allowing exchanges to move the witness packets too.

**Exact sufficient matrix condition.** Suppose $N_{tj}\in\{0,1\}$ is the daily load matrix of independently recolorable packets and $d=N\mathbf1$. If $N$ is totally unimodular, then

$$\lfloor d/2\rfloor\le Nz\le\lceil d/2\rceil,\qquad 0\le z\le1$$

has an integral solution: $z=\tfrac12\mathbf1$ is feasible, and the augmented constraint matrix is totally unimodular. Consecutive ones in a single common row order is a sufficient special case. This is a precise applicability criterion, not a claim that the game's matrix satisfies it. Fixed packet colors or asymmetric residual capacities need their own feasible fractional point; the unforced half-vector argument does not cover them.

**Decisive next test.** Extract packet columns from already reconstructed matched optimal histories. Search triples of days for columns restricting to $110,101,011$. A hit rejects blanket total unimodularity in those coordinates. Then retain all causal witness columns and test actual half-roundability and legal reconstruction. This is a structural test on small witnesses, not a broad board scan. A failed rounded reconstruction should report the exact violated movement edge or terminal constraint. A successful diagnostic only justifies attacking the corresponding causal lemma.

**Failure criterion.** If an exact small-board comparison shows that every matched-nested strategy takes longer than the optimum, stop trying to prove the existential normal form universally. Failure of one optimal witness, including the 25-row witness, is not that comparison. Preserve such witnesses and consider a bounded number of matching changes or recontamination episodes. If packet exchange requires arbitrarily many correlated branches, an interval-coloring reduction is unlikely to be the right global framework.

**A safe packet definition, and its executed rejection test.** There is a conservative way to make independent recolorability precise. Use a variable for each spacetime position belonging to exactly one of the two survivor histories. For each local transition/inspection factor at $(v,t)$, connect all singleton variables among $(v,t)$ and its predecessor neighbors $(u,t-1)$. Swapping every label in a connected component swaps the two local costs at each affected factor and preserves legality. Positions belonging to both or neither history are invariant. Components therefore define safe flips, with signed daily cost vectors; these vectors need not be unit intervals. The union and intersection of the two histories at every layer stay fixed, so this alone does not uncross them.

The requested cheap screen was executed on saved witnesses, including literal verification of every component generator:

| Paired histories | Singleton variables | Component sizes | What the flips do |
|---|---:|---|---|
| $6\times6$, $k=5$, full 14-day path and its horizontal reflection | 252 | 126, 126 | Move whole cohort service between histories; separate flips exceed the quota |
| The same path and its $180^\circ$ rotation | 132 | 66, 66 | Exchange whole cohort sweeps with zero daily cost difference |
| $16\times22$, $k=56$, four-day solo path and its $180^\circ$ rotation | 300 | 300 | Only global history relabeling |

CPU time was 0.016 seconds. In the first row the two signed vectors are opposites of

```text
(5,5,5,5,5,5,4,-5,-5,-5,-5,-5,-5,-4).
```

The other rows have zero signed vectors. Thus this safe factor-component exchange is too coarse on these examples; it does not reveal the desired unit interval packets. A useful refinement would need to split a component while changing its causal witnesses, rather than merely recolor connected components.

The lower lane's independent receipt, `clearance-witness-gate.json`, contains all 36 cohort/matched-pair incidence columns of the $6\times6$ 14-day path. All 364 triples of days avoid the triangle minor. This finite positive test is much weaker than total unimodularity or safe independent packet recoloring. The same lane reports that a local eight-cycle matching repair accommodates the accepted 16-row shape change, whereas the two stripe matchings do not. That repair does not overcome the 25-row obstruction: even allowing an arbitrary fixed perfect matching cannot encode the accepted 188-day witness.

## 3. Leading route B: paired calibration and the odd central threshold

**Scope and payoff.** This targets the remaining odd shared-budget decision without proving an unnecessarily strong normal form for every partial state. It could settle all odd-area values at the structural level, while the clock-evaluation problem remains separate.

Write the odd color-class sizes as $E=M+1$. At the last layer $L=\tau-1$ before solo capture, let $\mathcal R_L$ be the actual attainable deficit frontier and let $D_0,D_1$ be the pure solo capacities. The exact central objective is

$$C_L=\min_{(x,y),(u,v)\in\mathcal R_L}
\bigl[(E-x-u)_+ +(M-y-v)_+\bigr].$$

The useful theorem is only

$$C_L\le k\quad\Longrightarrow\quad E+M-D_0-D_1\le k.$$

The reverse implication is supplied by the pure histories. This implication is weaker than an exact formula for $C_L$, weaker than orienting every attainable point, and weaker than saying every intermediate split can be improved immediately. A sufficient stronger envelope would be

$$\min(E,x+u)+\min(M,y+v)\le\max(E,D_0+D_1)$$

for the relevant pairs: in the nontrivial region $k<M$, a contribution capped at $E$ cannot achieve the central threshold $E+M-k$. The existing `src/uniform_rectangle_central_pair_attack.py` investigates that stronger envelope; it is not an accepted theorem.

The most credible exchange acts on both quota histories together and preserves their daily totals. It should be allowed to exchange a whole interval of decisions, then compare only the final capped objective. Immediate scalar improvement need not hold, and a synthetic state need not possess the ancestry needed for the exchange.

The accepted inverse-target elimination in `research/bridge-odd-clock-orientation-targets.md` supplies a useful local oracle: an inverse output $u$ has the full input interval $[g_p(u),g_p(u+1)-1]$. Both endpoints matter. Replacing it by minimum required ammunition loses necessary conditions because inverse plateaus can absorb additional quota. A block-exchange argument can use those intervals as exact constraints without assuming the disputed orientation conclusion.

**Scheduling analogy and its limit.** Nain, Tsoucas, and Walrand use interchange arguments to derive priority policies for specified queueing models. This suggests proving a sample-path exchange invariant, but their stochastic service/feedback hypotheses do not hold for deterministic root-profile regrowth. No priority index transfers automatically. [Interchange arguments in stochastic scheduling, 1989](https://doi.org/10.2307/3214386).

**Decisive next test.** On the actual $11\times11$, $k=7$ and $21\times21$, $k=12$ traces, enumerate only the existing exceptional frontier histories and their prospective central partners. Ask whether every threshold-improving pair has a legal finite-block exchange toward a pure partner while preserving each day's quota. Save the shortest obstruction to a chosen exchange rule. Do not test only arbitrary oriented source pairs: the existing synthetic $11\times11$ trace already defeats that closure claim.

**Success criterion.** A full-start induction or two-history exchange theorem proves the threshold implication for all widths, lengths, and feasible budgets in the remaining odd region. A theorem restricted to actual full-start paths is sufficient; an arbitrary-partial-state classification is not required.

### Refinement: a joint forward/reverse calibration

The root exploration suggests a stronger synthesis that also applies to even area. Let $A_l$ be the set reachable before a middle inspection after $l$ preceding rounds. Let $B_r$ be the corresponding set from the reversed final $r$ rounds, starting from the full board. Undirected movement gives the exact middle-cover condition

$$|A_l\cap B_r|\le k.$$

Together with the two actual quota-feasible histories, this is equivalent to a strategy of length $l+r+1$. The two histories are otherwise independent. Their anchor relation must be derived from the intersection geometry; it cannot be imposed as if the histories shared an earlier ancestry.

A precise calibration target is a joint potential $\Phi(A,B)$ such that:

* $\Phi(V,V)\ge T_* -1$;
* $\Phi(A,B)\le0$ when $|A\cap B|\le k$;
* either legal update $A\mapsto N(A\setminus S)$ or $B\mapsto N(B\setminus S)$, with $|S|\le k$, decreases $\Phi$ by at most one.

These conditions would prove $T\ge T_*$. One can restrict the domain to pairs attainable from the actual full start. A useful $\Phi$ would contain a relative-position/overlap correction, so a weak entrance estimate on one side can be offset by the other side's geometry. A sum of two independent solo clocks would merely reproduce the existing method.

Defining $\Phi$ through the exact remaining paired-state optimization would be circular as a closure strategy. The substantive target is an explicit calibration in a bounded list of geometric quantities, or a telescoping history identity whose endpoint can be evaluated without reconstructing the paired frontier.

This differs materially from the current unilateral CHARGE/radius program: it need not prove that every solo transition or solo continuation is optimally calibrated. It must instead control both update directions and the joint middle-cover boundary. In odd area the symmetric specialization $l=r=\tau-1$ gives the threshold target above. On $24\times24$, $k=13$, a concrete test would exclude a pair with $l=102$, $r=103$ and middle intersection at most 13, thereby excluding a 206-day full strategy.

**Cheapest falsification test.** For any proposed small set of pair features, take already reachable prefix/reversed-prefix states and their board symmetries. Look for two pairs with identical features but different central-cover feasibility, or a legal update violating either Bellman direction. Such a collision rejects the proposed feature compression unless its worst-case overlap bound still suffices. In particular, individual sizes, radii, and corner counts omit relative anchor information. This paired calibration is now the most direct global synthesis; the matching/causal exchange proposal could provide its geometric proof mechanism.

## 4. Screens for Monge, majorization, and discrete-convex approaches

Murota's framework gives simultaneous multiple exchanges and closure under suitable convolution and network transformations. Those results require genuine $M^{\natural}$-concavity/exchange hypotheses; a network transformation uses flow conservation and concave arc weights. Frank and Murota's fair-flow work similarly begins with an integral submodular-flow polyhedron. Neither result says that a nonlinear neighborhood evolution has such a representation. [Murota, Discrete Convex Analysis](https://arxiv.org/html/2212.03598), [Frank–Murota, Fair Integral Submodular Flows](https://arxiv.org/abs/2012.07325).

**Executed toy rejection: the current deficit domain is not $M^{\natural}$-convex.** On the actual first day of $11\times11$, $k=7$, all quota splits give

```text
p = 0..7:
(4,0), (4,0), (3,0), (2,1), (1,2), (1,2), (0,3), (0,4).
Pareto maxima: (4,0), (2,1), (1,2), (0,4).
```

Take the downward closure, which also allows weaker guaranteed deficits. For $X=(4,0)$, $Y=(0,4)$, exchange of the first coordinate would require either both $(3,0),(1,4)$, or both $(3,1),(1,3)$. Neither choice is available. This is an actual first-day failure, not a synthetic later state. Consequently a standard discrete-convex lift whose permitted projection necessarily preserves $M^{\natural}$-convexity cannot project to this exact domain. A successful lift must use a different object, a weaker paired-objective property, or additional non-convex constraints.

The inverse profile also has oscillating increments. For $I_0(z)$, $z=0,\ldots,15$, the values are

```text
0,0,1,1,2,3,4,4,5,6,7,8,9,9,10,11
```

so its increments are neither nondecreasing nor nonincreasing. Separable concave allocation and a greedy marginal-return rule cannot be assumed. The pattern does not refute every possible Monge Bellman representation, but it rejects the simplest one-dimensional convexity premise.

Topkis provides conditions for monotone optimizing choices on lattices. That can motivate a phase-aware increasing-differences test for the Bellman objective, but monotone choices do not imply pure quotas or a bounded number of switches. The terminal objective, feasible action domain, and backward preservation of the required inequalities must all be established. [Topkis, Minimizing a Submodular Function on a Lattice](https://pubsonline.informs.org/doi/10.1287/opre.26.2.305).

The lower-priority surviving idea is therefore a **history-lifted block exchange**, not raw majorization of the two deficit coordinates. Root-band endpoints are natural exchange blocks, because their interior maps are affine. But one exchange per root band still leaves a width-dependent construction/evaluation. To close the numerical box, a second argument must aggregate the blocks without processing them individually.

## 5. Why ordinary time-expanded flow and monotone search do not close the box

**Fractional path cover is already too weak at a feasible budget.** On $4\times4$, $k=3$, take a six-day time-expanded graph. Give every room at every day fractional shot weight $1/6$. Every six-vertex rabbit walk has total weight one, and each day's total weight is $16/6\le3$. Thus the usual fractional “hit every temporal path” relaxation is feasible. The accepted exact value is $T_3(4\times4)=12$, from `paper/sections/four-rows.tex`. An ordinary path-cover LP plus daily capacity rows is not integral and cannot be treated as a min-cut solution. This example is an algebraic relaxation witness, not a randomized physical strategy.

Ordinary monotone hunter search is also too restrictive as a generic theorem. Dissaux, Fioravantes, Gahlawat, and Nisse prove $\operatorname{pw}(G)\le mh(G)\le\operatorname{pw}(G)+1$ and exhibit trees with hunter number two but arbitrarily large monotone hunter number. Their game is the same forced-neighbor-move game, so the warning is directly relevant. It does not refute rectangle-specific matched nesting, which is a different property. [Further results on the Hunters and Rabbit game through monotonicity](https://arxiv.org/abs/2309.16533).

The useful pathwidth connection is a possible **clearance-time layout with alternating directed boundary loads** after the matching normal form is proved. The task is then to optimize both its peak daily load and its duration. An existing pathwidth theorem alone addresses neither the alternating relation nor the time-optimal budget tradeoff.

## 6. What would remain after each structural success

| Structural result | What it settles | Additional numerical/constructive obligation |
|---|---|---|
| Odd two-history threshold domination | The $2\tau-1$ versus $2\tau$ decision from the full start | Evaluate the solo clocks and final deficits uniformly; provide the already suggested pure/central strategy rule |
| Matched clearance-time normal form | A common exact strategy class, potentially for even area and odd area with an unmatched-vertex rule | Optimize the clearance field without a board-sized or width-sized search; preserve the $127\to79\to28$ shape change |
| Causal balanced exchange | Repairs the per-day quota defect of history uncrossing | Show the chosen uncrossed endpoints produce a finite canonical family, then derive its endpoint formula |
| Monge or submodular-flow representation only | A potentially faster exact optimizer | This alone is not a uniform fixed-operation numerical result |
| Bounded number of geometric switches | A smaller family of physical constructions | The switch positions and root-band passage times must themselves have a uniformly bounded evaluation |

A credible full-box program combines an explicit full-start structural bound with the numerical lane's independent root-band/overshoot work. Neither side should be reported as completing the other. At this checkpoint the joint forward/reverse calibration is the leading global target, while the central-threshold implication is the smallest useful odd-area theorem. Matching/clearance methods remain conditional supporting ideas, substantially downgraded by the 25-row witness.

## 7. Reproducibility and stopping boundary

The first new numerical diagnostic in this lane enumerated the eight first-day quota splits on $11\times11$, $k=7$, and checked the displayed exchange failure. It used exact integer roots and the profiles in `src/bridge_odd_clock_orientation_probe.cpp`. The second formed the factor components of the three saved witness pairs listed above and literally checked each safe flip. No broad parameter scan was run. The abstract triangle obstruction and fractional path-cover witness are direct finite algebraic checks.

The first-day test can be reproduced with:

```python
from math import isqrt
b, E, M, k = 5, 61, 60, 7
def R(z):
    r = isqrt(z)
    return r + (r*r < z)
def rho(z):
    r = isqrt(z)
    return r + (r*(r+1) < z)
def I(p, z):
    if z >= (M if p == 0 else E):
        return E if p == 0 else M
    if p == 0:
        return z - min(rho(z), b, rho(M-z))
    return z - min(R(z), b+1, 1+R(E-z))
points = [(I(0, k-p), I(1, p)) for p in range(k+1)]
domain = {(x,y) for a,c in points
          for x in range(a+1) for y in range(c+1)}
assert (4,0) in domain and (0,4) in domain
assert not ((3,0) in domain and (1,4) in domain)
assert not ((3,1) in domain and (1,3) in domain)
print(points)
```

Source SHA-256 at the time of the test:

```text
f6ff46bcdbd7a7f0700f2a4220732597ddd605d9cf913256757a77e3ebe44c96  src/bridge_odd_clock_orientation_probe.cpp
18ca4670f66d382ac08b73c95d906f303671ab11f1876e68b93da05eb7738aa7  research/bridge-odd-clock-bottom-orientation.md
f7acdb220b9b84c9775072bc17ad2667b276404d4bbae11b200730ec994b376c  research/bridge-quadratic-edge-exception.md
```

No route in this note is promoted to an accepted global theorem. The next authorized effort should begin with the paired calibration or central exchange obstruction. Further matching/clearance work first needs a concrete response to the accepted 25-row witness, rather than another broad sweep of already matching scalar values.

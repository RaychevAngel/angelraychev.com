# Exploration: an absolute-operation expression for rectangle clocks

13 September 2026. Numerical lane, authorized exploration window only.
No manuscript, Lean, website, or accepted theorem was changed. The algebra
below is an exploratory representation of existing clocks, not a new
rectangle classification or an impossibility claim.

## Assessment

The most concrete new lead is a **Josephus remainder recurrence inside the
actual alternating minimum-budget clock**. It survives pairing the square
and pronic phases. The accumulated clock also contains a weighted moment
of those remainders in the direct summation formula; no identity recovering
that moment from a fixed number of endpoint expressions was found.
This suggests targeting a summation identity for the whole remainder
history, or an independent global action/dual potential. Another useful
compression is an explicit two-candidate formula for every paired root-band
endpoint, including the lower bands where the two roots differ by several.
Neither compression yet evaluates the accumulated passage in fixed work.

No reviewed general-purpose result supplies the missing absolute bound.
Euclidean algorithms, continued-fraction normal forms, finite automata with
input-dependent reading length, and polynomial-time lattice-point counting
would all remain intermediate algorithms. Naming a Josephus, Abel, or
Dedekind-sum function does not satisfy the numerical criterion.

## Exact starting obligation

Current sources read: `HANDOFF.md`, `CURRENT_CHECKPOINT.md`,
`research/CLASSIFICATION_SCOPE.md`, `research/RECTANGLE_GAPS.md` §3,
`paper/sections/odd-minimum-budget.tex`,
`paper/sections/uniform-odd-time.tex` (solo bands), and
`paper/sections/bounded-odd-frontier.tex` (corner ammunition).

For width `w=2b+1`, odd `n>=w`, and minimum budget `m=b+1`, the already
proved value is

```
T = 2wn - (8b² - 4b - 4L_b + 4).
```

With `q(z)=min{r>=0:z<=r(r+1)}` and `R(z)=ceil(sqrt(z))`, the width clock is

```
A0=B0=0,
A' = B+m-min(q(B+m),b),
B' = A+m-min(R(A+m),b+1),
L_b = first t with B_t=b(b-1).
```

Equivalently, `L_b+1` is the greedy solo clearing duration of the minority
prefix of size `b²+1` on the width-w square. This forward version is useful
below. All longer-side affine work has already been cancelled in the value
formula. The remaining `4L_b` term has a positive coefficient; no further
upper/lower bulk cancellation removes it automatically.

## 1. The actual paired tail contains Josephus arithmetic

Use the uncapped lower-corner maps, with
`Q(z)=min{r>=1:z<=r(r-1)}`. At a phase-1 step let `y` be the number of
survivors after the inspection. A complete pair, when both intermediate
survivors are positive, acts by

```
P_m(y)=y-2m+Q(y)+R(y+Q(y)-m).
```

For the minimum-budget tail the starting survivor is exactly
`y=b(b-1)` and `m=b+1`. Put `r=Q(y)`, `d=m-r`, and suppose
`r>=ceil((m+2)/2)`. Throughout this pronic band the second root is `r`
or `r-1`. From top to bottom there are two translation bands:

| Pair decrement | Integer band width |
| --- | --- |
| `D=2d` | `2r-m-1 = b-D` |
| `D+1` | `m-1 = b` |

If a band's upper endpoint is U, write entry `y=U-e`. Its number of
pair steps is `c=ceil((width-e)/D)`, with zero allowed for a skipped band.
The next band's overshoot is `e'=e+cD-width`. In both rows this reduces to

```
e_D = (e_(D-1)-b) mod D,       e_1=0.
```

The moduli run consecutively from 2 through
`N=b-1+[b odd]`. This is the standard Josephus remainder recurrence with
negative step `-b`, restricted to a special diagonal range. Negative step
is an algebraic direction convention; it is not an appeal to a positive
fixed-step theorem. Crucially, **the step itself varies with the input b**.
The familiar fixed-step-two binary formula therefore does not apply.
More precisely, if `J(1,k)=0` and
`J(D,k)=(J(D-1,k)+k) mod D` is the zero-based positive-step Josephus
function, then

```
e_D = D-1-J(D,b+1).
```

Thus the last residue belongs to the diagonal family `J(N,N+1)` or
`J(N,N+2)`. The special relation between population and step is real,
but none of the reviewed formulas collapses this family uniformly.

The derivation needs no assumption that every root band is visited: the
entry overshoot is smaller than the preceding modulus, so the displayed
ceiling is nonnegative, and a skipped band's zero count preserves the same
remainder equation. Below the stated root range the two roots can differ
by two or more; the simple constant-step recurrence has not been extended
through that part of the clock.

### Small diagnostic and the accumulated invariant

`numerical-diagnostics.json` checks the actual pair map, not a surrogate,
on two fixed inputs only:

| b | Consecutive moduli | Pair steps | Final survivor | Final overshoot |
| --- | --- | --- | --- | --- |
| 12 | 2..11 | 20 | 38 | 4 |
| 64 | 2..63 | 210 | 1004 | 52 |

Every constituent pair agrees with the direct square/pronic update. The
two checks took under 0.001 CPU second. No width catalogue was generated.
An earlier direct-clock check gave `L_12=46`, `L_64=445`, `L_256=2472`;
these are orientation checks only, not a fitted formula.

Let `H_N=sum_{d=1}^N 1/d`. The paired duration P of this segment obeys the
following exact rearrangement of its quotient sum:

```
P = b(H_N-1) - floor(N/2)
    + e_N/N + sum_{D=2}^{N-1} e_D/[D(D+1)].
```

Indeed each band count is
`(b+e_D-e_(D-1))/D - [D even]`; summation by parts gives the identity.
The final weighted sum has positive coefficients. It does not telescope
to the final residue by this rearrangement. At b=12 its value is
`919/2310`, with terminal correction `4/11`; at b=64 it is about 1.5656,
with terminal correction `52/63`. Counting each band independently with
zero entry overshoot gives 23 instead of 20, and 241 instead of 210.

This is a precise obstacle to the naive sum of independent root-band
ceilings. It is **not** a lower bound on the arithmetic complexity of L_b.
The unexamined lower tail might combine with this moment in a new identity.
This is an embedded arithmetic component, not a complexity reduction from
the general Josephus problem to evaluation of L_b.

There is already a simpler conservation law. With `h=floor(N/2)`,

```
sum_{D=2}^N D*c_D = b(N-1)+e_N-h(h+1).
```

This is total loss of survivor volume: each pair in band D removes D.
It illustrates why a global conserved statistic alone is insufficient.
The clock is the unweighted sum of the same counts.

**Decisive next test:** seek a closed cocycle whose difference along
`e_D=(e_(D-1)-b) mod D` equals the local band count, including the lower
tail, and whose endpoints depend on only a fixed number of elementary
expressions in b. A formula only for `e_N`, or a variable Josephus
recursion evaluated faster, would not suffice.

## 2. All paired band endpoints have a two-candidate expression

For the uncapped phase-1 pair define the cumulative threshold

```
H_m(S) = max{y>=0: Q(y)+R((y+Q(y)-m)_+) <= S},   S>=1.
```

One may assign upper root bounds r and s with r+s=S. The two conditions
are `y<=r(r-1)` and `y<=s²-r+m`. Hence

```
H_m(S) = max_(1<=r<=S) min(r(r-1),(S-r)²-r+m).
```

The first quadratic increases in r and the second decreases. They cross
at `r*=(S²+m)/(2S)`. Thus the maximum requires only the floor and ceiling
of r*, each clipped to `[1,S]`. This removes root-band sorting and a
parameter-sized optimization from the definition of a single endpoint.
For m=13 all S=1..24 were checked against direct integer enumeration;
all matched. This is a diagnostic of the algebraic identity, not an
evaluation of the whole clock.

For a positive paired decrement D use `S=2m-D`; the band's width is
`H_m(S)-H_m(S-1)`. Passage still carries an entry residue modulo D. In
the upper region the endpoint formula specializes to the Josephus bands
above. Below it, the varying quotient `m/S` changes the optimal root
difference. Capped and reflected branches in finite rectangles require
additional endpoint cases before this could be a universal clock language.

**Decisive next test:** symbolically simplify the endpoint difference
modulo D on all root-difference branches. A fixed number of branch types
with a common telescoping clock coordinate would be useful. Merely grouping
the quotients `floor(m/S)` into O(sqrt(m)) or O(log(m)) ranges would still
miss the goal.

## 3. Beatty, Sturmian, and complementarity routes

A fixed rotation gives a mechanical binary word whose equal-length factors
differ in their number of ones by at most one. This could collapse passage
counts to a floor if the clock's carry word were such a word.

The natural candidate already fails on one actual trace. At b=64, for the
constant quotient range D=33..63, put
`a_D=ceil((b-e_(D-1))/D)` and `u_D=a_D-floor(b/D)`. Its word is

```
1111101101010100100010000001000
```

It contains both `00` and `11`. Thus this candidate is not balanced, even
at factor length two, and cannot itself be one fixed-slope mechanical
word. This excludes only that direct encoding. A new coordinate, finite
combination of words, or self-similar substitution remains possible.

Inverse/complementary sequence theorems are relevant because our root maps
are inverses of quadratic capacities. But they complement a known rank
sequence; they do not automatically eliminate repeated iteration at a
variable budget.

**Decisive next test:** construct the claimed transformed rank or carry
word explicitly and prove a bounded balance/rotation law. Testing a few
L_b values for a Beatty fit is much weaker than testing the actual word.

## 4. Abel coordinates and a global action bypass

For a positive paired map P, an exact clock coordinate would satisfy
`Phi(P(y))=Phi(y)-1` with a suitable terminal normalization. A closed Phi
and inverse would solve the iteration without stepping through bands.
However, a construction that defines Phi by the orbit or by interpolating
successive fundamental intervals merely renames the missing calculation.
The inverse-deficit maps merge adjacent integer inputs. The positive
forward paired map displayed above is strictly increasing; its truncation
at capture is absorbing. These distinctions matter: a globally invertible
conjugacy for the terminated clock is not automatic. An orbit-specific
rank or a lift with a separate boundary coordinate would be appropriate.

There is a simple diagnostic for overly rigid guesses: on a long
translation band with decrement D, a fixed-degree polynomial satisfying
`Phi(y)-Phi(y-D)=1` at sufficiently many consecutive integers must be
affine with slope 1/D. Two long bands with different D contradict a single
such polynomial. Floors or a nonpolynomial coordinate evade this argument;
it is not an obstruction to the allowed expression class.

An alternative is a global optimal-control/action formula or Bellman dual
derived directly from the space-time geometry. The existing minimum-quota
theorem already proves greedy optimality, so another proof of optimality
alone would not evaluate L_b. A useful dual must have a fixed-operation
initial value and attain equality along the full-start optimum. It need
not be sharp for every arbitrary partial state. A bounded-complexity
space-time shape family might provide such a dual and cause the remainder
moment to cancel against a boundary term.

**Decisive next test:** find a candidate with a one-step telescoping charge
verified on every state of the two sample optimal orbits, then identify
the symbolic family of endpoint identities it requires. Reject candidates
whose initial value is another hitting time, a sum over all shells, or a
parameter-length coefficient extraction.

## 5. Lattice counting, Euclidean reciprocity, and asymptotics

An encoding of all carries as the lattice points of a fixed-dimensional
region could be a useful representation. Generic rational-polygon
formulas, however, introduce Dedekind-Rademacher sums; fixed-dimensional
Barvinok methods are polynomial in the bit length, not a fixed number of
standard operations. Their descriptions also do not turn the orbit-defined
remainders into a fixed-dimensional polytope for free.

The actual threshold intersection has the factorization
`(r-s)(r+s)=m`, suggesting hyperbolic quotient geometry rather than one
fixed-slope triangle. A successful lattice representation would need a
special bounded-denominator or unimodular structure, or a reciprocity law
that cancels the variable sum completely.

A uniform elementary asymptotic with an error smaller than one could
reduce the clock to a fixed number of integer candidates. That only closes
the problem if a fixed-operation condition selects the candidate, or a
rounding theorem excludes all dangerous fractional parts. A bounded or
logarithmic error estimate, a numerical value of a width-dependent limit
constant, and O(log b) refinement do not meet the stated endpoint.

**Decisive next tests:** (i) exhibit a fixed-dimensional region with a
uniformly bounded explicit decomposition, rather than invoke counting as
an oracle; or (ii) prove an absolute error bound plus a uniform rounding
gap for a specified elementary clock approximation. The exact remainder
moment above is a useful quantity against which to test either claim.

## 6. Rowmotion, homomesy, and abelian least action

Johnson–Liu express birational rowmotion on products of chains through
the octahedron recurrence and generalized chain-weight words that rotate.
This supplies a model for finding an accumulated statistic. Their
iterates involve lattice-path/minor expressions with dimensions depending
on the rectangle. A connection alone would not make those expressions
constant in size. [Primary source](https://arxiv.org/abs/2204.04255).

Our finite clock terminates at capture, whereas rowmotion is invertible
and periodic on the corresponding finite combinatorial setting. There
is therefore no direct conjugacy on these original state spaces. A lift
could retain discarded boundary information, but would need a special
full-start factorization to produce an elementary endpoint. An average
over a whole orbit also does not determine a first-passage segment unless
the boundary correction has an explicit form. This is an assessment of
the proposed connection, not a theorem excluding such a lift.

Bond–Levine's local abelianness axioms imply order independence and a
least-action characterization of firing counts. This suggests a second
route: encode the corner-ammunition computation as a stabilizing processor
network, then solve its count of local updates directly.
[Primary source](https://arxiv.org/abs/1309.3445).

For this problem the missing hypotheses would be local commutation,
correct physical clipping, and preservation of the phase and per-day
budget. Order independence of a virtual height-lowering model does not
by itself establish these properties for physical inspections. Even if
the encoding worked, a variable-size least-action integer program would
still be an algorithm. The useful endpoint would be a stable update-count
profile with a fixed number of explicitly located pieces and a total
count evaluable without traversing the board.

**Decisive next test:** look for a charge `Psi_m(S,e,phase)` whose change
across every paired band equals its number of pairs minus a simple
reference increment, including skipped bands and root-difference changes.
Its value at both full-start and capture must have a fixed-operation
formula. Alternatively, exhibit the explicit stable update-count profile
of a physically faithful abelian encoding. The weighted volume identity
above is a baseline check; reproducing only that identity is not enough.

## A caution against treating root bands as an impossibility argument

The simpler increasing recurrence `a'=a+floor(sqrt(a))`, started at 1,
shows how an exact reset law can collapse a variable number of bands.
On entry to `[k²,(k+1)²-1]` along this orbit, write `a=k²+e`; these
entries satisfy `0<=e<k`. Entry `e=0` takes three
steps and sends the next entry offset to `k-1`; an entry `e>0` takes
two steps and sends the offset to `e-1`. Starting from k=1, zero offsets
occur precisely at powers of two. Consequently entry into band k takes
`2(k-1)+ceil(log_2(k))` steps. This is a direct algebraic comparison,
not a formula for the rectangle recurrence.

The analogous useful discovery here would be a reset or rotation law for
the *whole* square/pronic clock that survives the changing modulus. The
Josephus representation identifies the required arithmetic; it does not
prove that such a law cannot exist.

## Primary literature and how it bears on this problem

- A. M. Odlyzko and H. S. Wilf, *Functional iteration and the Josephus
  problem*, Glasgow Math. J. 33 (1991), 235–240.
  [Author-hosted paper](https://www-users.cse.umn.edu/~odlyzko/doc/arch/josephus.problem.pdf),
  [publisher record](https://doi.org/10.1017/S0017089500008272).
  Studies ceiling iteration and its use in Josephus evaluation. Relevant
  to a clock conjugacy and controlled rounding; it is not a supplied
  uniform formula for our input-dependent step.
- L. Halbeisen and N. Hungerbühler, *The Josephus problem*, J. Théor.
  Nombres Bordeaux 9 (1997), 303–318.
  [Author-hosted text](https://people.math.ethz.ch/~halorenz/publications/pdf/jos.pdf),
  [published scan](https://math.ch/norbert.hungerbuehler/publications/The_Josephus_problem.pdf).
  Their explicit-function definition allows exp, log, floor, arithmetic
  and composition, but explicitly distinguishes being explicit in one
  variable while fixing the others. Their fixed-step formulas and
  width-dependent limiting constants therefore need a separate uniformity
  audit here. The article also gives general bounds and an algorithm.
- *Analytical Study and Efficient Evaluation of the Josephus Function*,
  [arXiv:2303.15457](https://arxiv.org/abs/2303.15457),
  [JIS article](https://cs.uwaterloo.ca/journals/JIS/VOL27/Cruz/cruz4.pdf).
  Derives recurrences for extremal points and uses the intervening linear
  pieces for fast evaluation. This suggests acceleration, not an absolute
  bound on the number of pieces for variable step.
- A. S. Fraenkel, *Iterates of Beatty sequences* (2020),
  [author-hosted paper](https://www.wisdom.weizmann.ac.il/~fraenkel/Papers/Graham1973.pdf).
  Studies iterated/complementary Beatty families. Relevant to a potential
  fixed-rotation rank representation; our natural correction word fails
  that first test.
- M. Angel, *Partitions of the natural numbers*, Canad. Math. Bull. 7
  (1964), 219ff.,
  [publisher paper](https://doi.org/10.4153/CMB-1964-020-1).
  Generalizes the inverse/complementary sequence framework of Lambek and
  Moser. This is a possible language for quadratic capacity ranks, not a
  theorem about iterating the present budget-shifted maps.
- *Group iteration for Abel's functional equation*, Nonlinear Analysis:
  Hybrid Systems 1 (2007), 95–102,
  [publisher article](https://doi.org/10.1016/j.nahs.2006.04.002).
  Gives iterative constructions of monotone Abel solutions. Existence of
  that coordinate does not provide a finite elementary evaluation.
- M. Beck and S. Robins, *Explicit and efficient formulas for the lattice
  point count in rational polygons using Dedekind-Rademacher sums*,
  Discrete Comput. Geom. 27 (2002), 443–459,
  [author preprint](https://arxiv.org/abs/math/0111329).
  The formulas use polynomial-time computable finite Fourier sums and
  reciprocity. The word “explicit” here is weaker than this project's
  absolute-operation goal unless those sums cancel in the special family.
- A. Barvinok, *A Polynomial Time Algorithm for Counting Integral Points
  in Polyhedra When the Dimension is Fixed*, Math. Oper. Res. 19 (1994),
  769–779, [publisher article](https://doi.org/10.1287/moor.19.4.769).
  Fixed dimension gives polynomial-time counting. It does not make the
  arithmetic count independent of input size.
- J. Johnson and R. I. Liu, *Birational Rowmotion and the Octahedron
  Recurrence* (2022), [author preprint](https://arxiv.org/abs/2204.04255).
  Chain-weight shifts and generalized rotating words suggest a global
  statistic; the required factorization for our absorbing clock is absent.
- B. Bond and L. Levine, *Abelian networks I. Foundations and examples*,
  [author preprint](https://arxiv.org/abs/1309.3445).
  A possible language for an order-independent update-count certificate,
  provided its local axioms and the physical budget constraints are proved.

## What would count as real closure

The best immediate target is a uniform formula for the **total** Josephus
quotient cocycle together with the remaining lower tail, or a geometric
dual whose endpoint cancels that cocycle. The paired endpoint formula is
a useful intermediate normal form. A named special function, a new
width-dependent table, faster band traversal, or another parameter
threshold would not answer the requested global numerical question.

The suggested order of further investigation is: first a clock coordinate
for the two-candidate paired endpoint normal form; second a full-start
geometric action or stable update-count formula that bypasses the clock;
third a uniform elementary approximation with a proved exact-rounding
rule. Direct fixed-rotation words fail the recorded test. Euclidean or
lattice-counting acceleration remains useful computation but does not
establish the absolute-operation endpoint.

No proof that the desired standard-operation expression exists, or that
it cannot exist, has been obtained in this exploration.

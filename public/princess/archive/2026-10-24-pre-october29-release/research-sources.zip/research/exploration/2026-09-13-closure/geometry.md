# Geometry and whole-history closure routes

13 September 2026, bounded exploration during the 17:06–17:25 UTC window.
This is an assessment and a set of structural tests, not a new rectangle
classification. No manuscript, Lean, or website source was changed.

## Assessment

The most useful change of viewpoint is to compress **whole physical
histories**, retaining their local dependencies, before projecting to room
counts or corner flags. The existing radius/lens theory is valuable evidence
about what a successful compression must preserve. Adding further isolated
flags does not by itself suggest an all-width/all-budget theorem.

Two concrete routes emerged:

1. A clearance-time normal form after a fixed matching, followed by spatial
   height compression. It has an exact mathematical formulation and cheap
   falsification tests. Small examples and the sixteen-row shape change fit,
   after a nontrivial local matching repair. However, the existing optimal
   25-by-26 witness fits neither this form nor the weaker same-color two-day
   nesting form. This substantially downgrades the route. It remains an
   existential hypothesis about *another* optimum, not an established normal
   form and not an invitation to search more widths.
2. A causal, budget-preserving rearrangement of two entire histories. Its
   starting local inequalities are exact, and interval discrepancy supplies
   a plausible endpoint if geometry yields suitable independent packets.
   Generic submodularity, independent parity intervals, and scalar budgets
   all fail to supply the needed integer exchange. The missing theorem is
   a structural one about actual rectangular histories.

Neither route currently closes all even-area values. Even a successful
normal-form theorem would still need a bounded spatial description and
evaluation of its changing root bands before meeting the absolute O(1)
numerical objective. That distinction must remain explicit.

## Existing barriers that the proposed replacement must respect

The current checkpoint and `research/RECTANGLE_GAPS.md` are the source of
the mathematical scope. In particular:

- Static neighborhood minimizers cannot simply be chained: the known
  6-by-6, budget-5 scalar relaxation predicts 13 rather than the exact 14.
- `paper/sections/compression.tex` proves whole-strategy comparison only for
  monotone, cardinality-preserving, neighborhood-subcommuting maps. It also
  proves that parity-preserving even-path maps in this class are identities.
- `research/unequal-diagonal-time-small-counterexample.json` gives a
  4-by-5 partial support whose diagonal compression increases its budget-2
  capture time from 2 to 3.
- `research/even-bridge-two-round-path.md` already excludes the natural
  two-step even-path product compressions on 2-by-4. Suppressing the
  intermediate inspection is not a legitimate two-day reduction.
- `research/even-bridge-full-board-prefix-failure-6x6.json` excludes the
  all-corner-prefix normal form for a particular *varying-budget* full-start
  history. It does not refute constant-budget full-start optimality.
- The accepted sixteen-row quadratic-edge improvement changes shape and
  beats both original anchored-prefix bounds. A putative universal family
  must include that possibility; an exclusively lower-bound repair is not
  justified.

## Route A: a fixed-matching clearance labeling

Choose a perfect domino matching M of an even-area rectangle. Identify each
color class with its h matched pairs. If B is the bipartite adjacency matrix
in these coordinates, each diagonal entry is one. A cohort alternates the
Boolean neighborhood maps K=B and K^transpose. Its matched survivors after
day t will be denoted R_t, with R_0 the full pair set.

The precise candidate is:

> For every full rectangle and constant feasible k, there is a time-optimal
> strategy and one fixed perfect matching M such that each initial-color
> cohort satisfies R_t subseteq R_(t-1) on every day.

The matching may be chosen once with the strategy. Allowing it to change
arbitrarily during the history would evade the question by placing the
history in the changing coordinate system. No such moving-matching claim
is proposed.

If the displayed nesting holds, define ell(v) as the last day on which a
matched pair survives. Then R_t={v:ell(v)>=t}. Let K_(t-1) be the motion
map between the previous survivor and the day-t belief. For t>=2 the exact
inspection load of this cohort is

    c_t = #{v: ell(v)<t <= 1+max{ell(u): u in Pred_(K_(t-1))(v)}}.

The first load is c_1=#{v:ell(v)=0}. This formula retains the intermediate
physical move. The predecessor set is fixed on each time parity, so each
vertex's inspection occurrences form at most one interval on odd days and
one on even days. Their starts are coupled by the same ell(v).

Conversely any such finite labeling supplies an actual strategy with these
loads: R_t subseteq R_(t-1) subseteq K_(t-1)(R_(t-1)), because K has loops,
so inspecting K_(t-1)(R_(t-1)) minus R_t gives exactly the stated survivors.
This is an exact representation of the **restricted** model. It does not
prove that unrestricted optimal strategies belong to it.

### Relation to known monotonicity

The matching condition is not full-game monotone hunting. A room shot for
one cohort can remain available later to the other cohort. Thus the general
lower bound on monotone hunter number in terms of pathwidth does not directly
contradict it. Within one cohort it implies same-physical-color two-day
survivor nesting and forbids an already-shot room from surviving again.
This is closely related to the red-variant monotonicity studied by Dissaux
et al.; their definition also handles clearing through inspection of all
contaminated neighbors. Their unbounded monotonicity gaps on trees warn that
a theorem must exploit rectangles, not merely bipartiteness. Their theorem
is about hunter counts, not minimum capture time at a fixed budget.
[Primary paper, definitions in Section 3 and red variant in Section 5](https://arxiv.org/html/2309.16533).

Minimum-length path decompositions are a useful analogous problem: width
and length must be optimized together. Their known general-graph complexity
does not settle our alternating directed maps, but it cautions against
treating a width theorem as an optimal-time theorem.
[Dereniowski, Kubiak and Zwols](https://arxiv.org/abs/1302.2788).

### Finite gates and their actual scope

The tiny exact full-board solver `matched_monotone_gate.cpp` compares
unrestricted capture with the fixed short-axis stripe-matching restriction.
The latter retains every unused-quota choice: deleting extra vertices early
need not preserve a later nesting-constrained strategy.

| Rectangle | k | Unrestricted | Nested |
|---|---:|---:|---:|
| 2 by 4 | 2 | 6 | 6 |
| 2 by 6 | 2 | 10 | 10 |
| 4 by 4 | 3 | 12 | 12 |
| 4 by 4 | 4 | 6 | 6 |

The final comparison run used about 0.216 CPU seconds. A preliminary
4-by-6 unrestricted attempt stopped at its 1.5 CPU-second cap; it supplied
no exact comparison and is not used. These are structural gates, not new
coverage results.

For the troublesome 6-by-6, k=5 case, a literal color-one-first greedy
prefix solo followed by the other cohort captures in 14 days. Both stripe
matching axes make this history nested. The already established lower 14
therefore makes it a nested optimum. Color-zero-first takes 15: orientation
cannot be discarded. Its 36 pair/cohort inspection columns have no
110/101/011 minor on any of the 364 triples of its 14 days. This is neither
a proof of total unimodularity nor a statement about all optimal histories.

The accepted sixteen-row k=56 witnesses at lengths 22 and 34 are all
downward pyramids. Each violates stripe nesting once, at the shape-change
start: room (14,8) reappears while its preceding stripe mate is absent.
Blacklisting every edge that violates predecessor containment on any day
and finding a perfect matching gives an **exact test for a fixed matching
for that entire given history**. Both witnesses pass. In fact the same
eight-cycle flip repairs them: in the patch x=12..15, y=8..9, replace four
short-axis stripe dominoes by

    (12,8)--(12,9),   (13,9)--(14,9),
    (14,8)--(13,8),   (15,9)--(15,8).

All other stripe dominoes remain. This is a concrete fixed, local geometric
repair, not a matching changed during the strategy. The matching and replay
receipt is `clearance-witness-gate.json`; it includes the original witness
hash and a full matching. The final witness gate used about 0.009 CPU seconds.

There is a substantial negative screen: the existing 188-day optimal solo
witness in `research/bridge-upper-transport-25x26-prefix.json` admits no
such fixed perfect matching. Its allowed-edge graph has maximum matching
182 rather than 325. The saved Hall set has 212 vertices and only 69 allowed
neighbors. See `clearance-25-witness-gate.json`. The same history also fails
the weaker two-day, same-physical-color survivor nesting on 20 days, first
on day 12; see `parity-nesting-witness-gate.json`. The sixteen-row witnesses
pass this weaker check. These failures concern those witnesses; they do not
prove that every optimum fails. No alternate 188-day history was searched.

### What would make this an all-parameter route

A successful replacement lemma would have to transform an arbitrary
*full-start constant-budget optimum* into a jointly admissible history with
the chosen lifetime structure, preserving every daily budget. A possible
proof setup is to minimize a reentry statistic among all optimal histories
and use a minimal Hall-deficient region of the allowed-matching graph to
identify the necessary history exchange. The sixteen-row eight-cycle
exhibits the scale of a local matching repair; it does not establish that
such repairs always suffice. The 25-row failure is the first serious test
that any proposed replacement must address.

Even proving that statement is not parameter compression: M and ell have
O(wn) entries. A separate spatial theorem must allow a bounded description
of the optimal lifetime field—e.g. a bounded number of explicitly shaped
fronts and shape changes—and preserve the known sixteen-row improvement.
Downward pyramids allow that improvement, whereas one anchored prefix does
not. No theorem bounding their number of extrema, changes, or root-band
events was found. A finite-dimensional optimizer with dimension depending
on w or n does not meet the numerical objective.

For all-odd rectangles a natural **hypothesis**, not a result, is to remove
one majority corner, fix a near-perfect domino matching, and retain one
extra lifetime sampled only on majority-color days. A formal ghost index
makes the maps square, but the matching loop at this index is missing and
the coordinate is forced empty on minority days. It must be exempt from
one-step nesting. This fixed defect is preferable to a freely moving
unmatched vertex, whose trajectory could conceal unbounded extra state.
Its interaction with the shared central budget is still an open obligation.

## Route B: causal whole-history rearrangement

For survivor envelopes use the exact day cost

    c_t(R)=|N(R_(t-1)) minus R_t|,

with the full initial belief and empty final survivor handled separately.
For two histories R,S, coordinatewise union and intersection obey

    c_t(R union S)+c_t(R intersection S) <= c_t(R)+c_t(S)

for every t. To check it, use N(A union B)=N(A) union N(B),
N(A intersection B) subseteq N(A) intersection N(B), and the two-bit
directed-cut inequality at each output vertex. The first-day cost is
modular. This elementary identity is independent of compression or anchors.

It is not the needed budget theorem. Already on one edge P2, with two
days and k=1, the intermediate envelopes {left} and {right} both cost
(1,1). Their union costs (0,2) and intersection (2,0). Neither uncrossed
history respects k=1. Thus ordinary submodular minimization or an averaged
cost bound cannot be substituted for a simultaneous daily guarantee.

There is a genuinely relevant discrepancy result: unit intervals can be
colored so the load difference at every time is at most one, constructively.
If legal exchanges really separated into independently assignable intervals,
a combined load at most 2k could be divided into two loads at most k.
[Antoniadis et al., Balanced Interval Coloring](https://drops.dagstuhl.de/entities/document/10.4230/LIPIcs.STACS.2011.531).

Our lifetime packets are two coupled parity intervals, so that theorem is
not directly applicable. The upper lane's abstract packets {1,3}, {1,2},
{2,3} have total load two at every time but cannot be split into two
unit-load classes: they form a triangle. This is not a physical-grid
counterexample. Actual reappearances require predecessors surviving long
enough, and those predecessors create their own future inspection loads.
The desired lemma must include these causal witness jobs. Adding witness
columns does not erase a forbidden matrix minor; “causal roundability” is
a separate property from total unimodularity.

One safe exact exchange unit is available. In two histories, make vertices
for differing spacetime memberships; join all differences appearing in one
local cost factor, namely the output membership and its previous-neighbor
memberships. Swapping a whole connected component between histories swaps
the two values of every affected local factor and preserves legality.
Different components can be swapped independently. Their signed daily
load vectors need not be intervals, unit weights, or small. The geometric
question is whether a relevant optimal rectangular pair can be replaced
so these vectors have a balanced, causally closed decomposition while the
required terminal allocation is preserved. See the strategy lane's note
for the exact exchange and its additional endpoint obligation.

This is a route to all budgets only if that replacement theorem is
unbounded and works for the true full-start optimum. Proving it for
near-square events alone, or checking another terminal width, does not
close the task. The strategy lane completed the structural screen on saved
histories during this exploration. The safe components were whole cohort
sweeps on the 6-by-6 examples and one giant component on the 16-by-22 solo
example. Thus this exact exchange rule is too coarse to supply independent
interval jobs. Any useful replacement must change causal witnesses rather
than merely recolor these components; see `strategy.md` for the receipt.

## Why off-the-shelf rearrangement or topology does not finish it

Hajaiej, Han and Hua prove a lattice rearrangement inequality for decreasing
distance kernels, and show that a single total order cannot give the
Pólya–Szegő inequality for every nonnegative function on Z^2. Their iterated
rearrangement is therefore a useful reminder to seek a richer order, but
its theorem does not apply directly to our kernel 1[distance=1], which
jumps upward from distance zero to one. Moreover, standard rearrangement
of surviving domains tends to increase path counts; preserving a successful
search would require that zero surviving paths remain zero. Finite board
boundaries and intervening inspections are additional obligations.
[Primary theorem and hypotheses](https://arxiv.org/html/2209.01003).

Isoperimetric nesting can determine hunter numbers in favorable graphs,
as in [Bolkema and Groothuis](https://arxiv.org/abs/1701.08726). It does not
by itself give minimum time at every fixed budget when minimizing shapes
cannot be chained. Likewise planar topology can constrain exchange regions
or Hall sets, but planarity alone does not supply the daily balance or an
absolute bound on the number of geometric changes. The root lane separately
examines space-time cut/min-max formulations; this note makes no new cut
integrality claim.

## Recommendation after screening

Do not promote strict matching nesting, two-day nesting, generic convexity,
or generic interval coloring to an accepted framework. Keep the exact
clearance representation and the small eight-cycle repair as useful leads,
and use the 25-row witness as a required negative control. The strongest
common target after screening is the **joint forward/reverse calibration
of the actual middle intersection** in `ASSESSMENT.md`. It retains the
physical meeting condition without imposing an unsupported monotone normal
form. A causal whole-history replacement controlling spatial shape and all
daily costs remains a possible proof mechanism for that calibration, not
an established reduction. Neither route yet supplies a sharp potential,
a direct optimal family for every parameter, or the separate bounded
numerical evaluation theorem.

The final assessment's matching and nesting summary agrees with these
receipts, with the qualification that the two 16-row repairs concern the
complete solo histories at lengths 22 and 34. The stated paired-potential
conditions imply the advertised lower bound by summing the two Bellman
inequalities. Their applicability to both update directions and the actual
middle-cover boundary is the central unproved task; no existing screening
result establishes those inequalities for a proposed sharp expression.

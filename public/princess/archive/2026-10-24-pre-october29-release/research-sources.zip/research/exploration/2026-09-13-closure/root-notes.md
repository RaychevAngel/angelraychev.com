# Exploratory notebook: routes to full closure

13 September 2026. Start17:06UTC; requested20–30minute exploration only.
No accepted theorem changes, formalization, manuscript changes, or deployment.
The numerical criterion remains an absolute fixed-size expression in standard
operations. A new exact algorithm would not itself satisfy it.

## Exact space-time cut formulation; first obstruction to generic min-cut

For a proposed horizon T, make vertices(v,t),1<=t<=T, and arcs from(u,t)
to(v,t+1) whenever u~v. A schedule wins exactly when its deleted vertices
hit every full layer1-to-layerT path, with at most k deletions per layer.
This preserves both original parity cohorts and all physical geometry.
It reframes the original problem; it is not a simplification by itself.

Let y(v,t) be binary post-inspection survivor-envelope labels, y(v,T)=0.
Linear variables x satisfy x(v,1)>=1-y(v,1), and for t>=2,
x(v,t)>=y(u,t-1)-y(v,t) for each neighbor u of v. Layer sums of x are <=k.
With binary variables this is exactly the existing survivor-envelope semantics.
Fractional relaxation admits y(v,t)=1-t/T and x(v,t)=1/T, giving k=N/T.
On a graph with a perfect matching, N vertex-disjoint alternating time paths
force total deletion weight>=N, so the fractional optimum is exactly N/T.
Thus the most natural ordinary flow/LP dual loses all geometric expansion:
it cannot distinguish infeasible budgets from slow capture on even rectangles.
This is a diagnostic against generic max-flow/min-cut, not a hardness theorem.
Useful duality would need integral geometric or time-interval constraints.

## Existing framework lessons used as filters

- Pointwise minimum neighborhoods need not compose:6x6,k5.
- Counts plus a current corner bit do not retain previous anchors.
- Minimizing phase clocks can switch preferred orientation illegally.
- A prefix-palindrome upper is sometimes genuinely too long:16-row edge,
  and minimum-budget width25 saves a central day.
- Ordinary union/intersection of entire survivor histories preserves a sum
  of daily costs but not the separate k caps. Lower lane gives P2,T2,k1:
  two(1,1)-cost histories uncross to(0,2) and(2,0).
- The unresolved O(1) width clock already arises in the solved odd minimum-
  budget family. Eliminating search/optimization does not eliminate it.

## End-of-exploration synthesis review

The leading geometric target changed after screening. Fixed-matching
clearance histories initially looked promising; the existing16-row solo
shape change fits after one local eight-cycle matching repair. The accepted
25-by-26 solo witness instead has an exact allowed-edge maximum matching
182 rather than325, with a Hall set212 versus69 neighbors, and fails
same-color two-day nesting on20days. These are witness obstructions, not
proof that no alternate optimal normal form exists. They downgrade the
monotone proposal without triggering a new capture search.

The root synthesis therefore prioritizes a paired forward/reverse overlap
calibration, with the exact terminal condition |A intersect B|<=k. The
strategy lane independently checked its time indices and Bellman directions.
The numerical lane independently reviewed the reflected Josephus formula,
the harmonic/remainder identity, and their hypotheses. Root independently
recomputed the identity at r12 and64 and the simpler power-of-two reset
comparison through64bands. The latter is an analogy, not our rectangle clock.

ASSESSMENT.md records the ranked program, negative gates, primary literature,
and unchanged O(1) criterion. All tracked project sources remain unchanged;
only this exploratory directory was added. No main theorem or formalization
coverage is promoted on the basis of these diagnostics.

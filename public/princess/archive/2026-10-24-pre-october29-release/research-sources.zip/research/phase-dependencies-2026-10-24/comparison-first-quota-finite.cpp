// Complete arithmetic base for the first-quota ordinary orbit.
// Scope: k=13..9900, c=0..k, u>=1, root 4..min(99,k-2).
// W_0=(c-rho(c),c-ceil_sqrt(c)); W_{u+1}=(G_k(W_u[1]),F_k(W_u[0])).
// No board widths or lengths are sampled.
#include <algorithm>
#include <cmath>
#include <iostream>
#include <vector>
using I=long long;
I root(I x){I z=sqrtl(x);while(z*z<x)++z;while(z>0&&(z-1)*(z-1)>=x)--z;return z;}
I rho(I x){I z=(sqrtl(1+4*x)-1)/2;while(z*(z+1)<x)++z;while(z>0&&(z-1)*z>=x)--z;return z;}
I triangular_inverse(I x){I z=(sqrtl(1+8*x)-1)/2;while((z+1)*(z+2)/2<=x)++z;while(z*(z+1)/2>x)--z;return z;}
struct Pair{I a,b;};
Pair next(Pair x,I k){return{x.b+k-rho(x.b+k),x.a+k-root(x.a+k)};}
I minimum(Pair x){return std::min(x.a,x.b);}
I bad(I x,I k){return x+k-1-rho(x+k-1);}
int main(){I seeds=0,bad_steps=0,min_margin=10000,orbits=0,times=0,pruned_c=0;
 std::cout<<"{\"per_budget\":[";
 for(I k=13;k<=9900;++k){I cap=std::min<I>(9801,(k-2)*(k-2)),count=0,orbit_count=0;
  for(I c=0;c<=k;++c){Pair x=next({c-rho(c),c-root(c)},k);
   // Both initial coordinates and the update are monotone in c. All later
   // coordinates are nondecreasing in time. Thus every omitted c/u is vacuous.
   if(minimum(x)>=cap){pruned_c+=k-c+1;break;}
   ++orbits;++orbit_count;
   for(I u=1;minimum(x)<cap;++u){++times;
    for(I p=0;p<2;++p){I own=p?x.b:x.a,other=p?x.a:x.b;
     for(I q=other+1;q<=std::min(own,cap);++q){I r=root(q);
      if(r<4||r>99||r>k-2||q>r*(r-p))continue;
      I core=2*r-2-p-2*triangular_inverse(r*(r-p)-q);
      if(p==0&&q==(r-1)*(r-1)+1)core=std::min(core,2*r-4);
      Pair future=x;I z=q,j=0;
      while(z>minimum(future)&&j<core){z=bad(z,k);future=next(future,k);++j;++bad_steps;}
      if(j>=core){std::cerr<<"FAIL k="<<k<<" c="<<c<<" u="<<u<<" p="<<p<<" q="<<q<<" r="<<r<<" core="<<core<<" mix="<<j<<"\n";return 1;}
      ++count;++seeds;min_margin=std::min(min_margin,core-1-j);
     }
    }
    Pair y=next(x,k);if(y.a<x.a||y.b<x.b){std::cerr<<"temporal monotonicity failed\n";return 2;}x=y;
   }
  }
  if(k>13)std::cout<<",";std::cout<<"["<<k<<","<<count<<","<<orbit_count<<"]";
 }
 std::cout<<"],\"seeds\":"<<seeds<<",\"orbits\":"<<orbits<<",\"time_states\":"<<times<<",\"bad_steps\":"<<bad_steps<<",\"pruned_initial_quotas\":"<<pruned_c<<",\"minimum_margin\":"<<min_margin<<"}\n";
}

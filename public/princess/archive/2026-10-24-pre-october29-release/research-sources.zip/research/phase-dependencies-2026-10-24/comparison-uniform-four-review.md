# Independent audit of the uniform four-day assembly

24 October 2026. The assembly is sound conditional on independent acceptance
of its explicitly named new first-quota, shifted-seed, signed-late and middle
lemmas. Reviewed source: `root-uniform-four.md`. No zero-gap claim follows.

## A finite gate prefix may be normalized

Polarization works on an arbitrary finite inspection prefix: its new belief
at each time is contained in the compressed old belief, so its terminal
cardinality, and therefore terminal signed mass, cannot increase. Capture
is not required at the endpoint. For last-full normalization include the
terminal pre-inspection belief among the candidate last-full times. If its
larger cohort is full, this last time may be the terminal time T; replace
every preceding larger survivor by full. The smaller history and both
terminal beliefs are then unchanged, yielding an entirely solo prefix.
Otherwise the usual last-full time is before T and the accepted activation
argument applies. This verifies the universal gate-history premise rather
than assuming a terminal capture day.

## Endpoint ranges and coverage

For b>=32 and b<k<2b, put d=k-b and H=b(b-1). The late maximum is

    H+d+1=(b-1)^2+k=Zcap,

and the early minimum H-d+1 is positive and exceeds (b-1)^2. Every late
endpoint exceeds k. The sum of early and late maxima is at most
2b^2-2b+d+1<2b^2<=h; thus the cuts are ordered even on the shortest board.

For 2b<=k<3b use H=(b-6)^2. Its late maximum is H+k-b+6. It is below
(b-1)^2+k by 10b-35, and below b^2+1 by 13b-k-41, both positive. The early
maximum is bounded by H-1+k<b(b-1), including the genuine crossing
overshoot. Here too late endpoints exceed k and both cuts fit in their
correct temporal order. This range has d>=b>=32, above both earlier
large-excess comparison thresholds. Consequently no finite-width gap
between the two new analytic families remains.

Odd-area boards retain the accepted exact evaluator; widths<=64 retain the
previous three-day certificate; every other even-area board has b>=32.
Feasibility is k>=b+1, and k>=3b retains the previous stronger result.
These cover the full stated domain, with no restriction on n beyond w<=n.

## Clocks, phases and final quota

The endpoint minimum must use every integer pair in the displayed ranges.
Replacing the early and late numerical bounds at the old optimizer would
not be a proof, but the source does not do that. Normalized actual history
supplies all three durations and the accepted merger cut counts them with
no overlap.

At the construction step the true ordinary head has spread<=d. The late
ordinary pair is progressive, and the finite-board maps dominate its
quadrant maps. The middle comparison therefore applies in the physical
compatible labels. In the larger-budget range the accepted stronger
minimum-coordinate conclusion needs no head label choice. Hence
Pc<=J(c)+alpha, alpha=1 at even-width pronic cases and alpha<=2 elsewhere.

Since every endpoint Y exceeds k, V_1^0=V_0^k gives the exact hitting-time
shift ell_0(Y)=ell_k(Y)+1, not merely an inequality. The endpoint set is
independent of c, so J(0)=J(k)+1. Monotonicity gives Jhalf in{J,J+1}.
The final intersection lower bound and actual sequential/shared-final-shot
constructions then give exactly

    L>=max(2J+1,2Jhalf),
    U<=min(2J+2alpha+2,2Jhalf+2alpha+1).

The two possible Jhalf values yield U-L<=2alpha. Thus the claimed global
four-day ceiling, and the two-day even-width pronic subfamily, follow once
the new dependency reviews are complete. Retaining previous stronger
bounds is legitimate and cannot worsen the ceiling.

The remaining uncertainty is mathematical middle compatibility, not a
claim that these constructed prefixes are unrestricted optimal strategies.
The argument does not supply a fixed-size numerical expression or new Lean
coverage; it is a uniform bound theorem with computable evaluators.

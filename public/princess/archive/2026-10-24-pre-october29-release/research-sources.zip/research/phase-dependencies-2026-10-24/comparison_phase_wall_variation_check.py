"""Arithmetic stress check for the separately proved wall-variation ledger."""
import math,json,random,hashlib,pathlib,time

def R(x):
 r=math.isqrt(x);return r+(r*r<x)
def rho(x):
 r=(math.isqrt(1+4*x)-1)//2;return r+(r*(r+1)<x)

def check(A,B,k,seed,steps):
 orbit=[(seed,seed)]
 for _ in range(steps):
  x,y=orbit[-1];out=(y+k-A(y),x+k-B(x))
  assert min(out)>=max(x,y)
  orbit.append(out)
 count=0;max_drop=0
 for u in range(len(orbit)):
  x,y=orbit[u];M=max(x,y);I=A(x)-A(y)if x>=y else B(y)-B(x)
  eu=B(M)-A(M);au=(-1)**u*(2*(x-y)-eu)
  for v in range(u+1,len(orbit),max(1,(len(orbit)-u)//13)):
   xx,yy=orbit[v];N=max(xx,yy);ev=B(N)-A(N)
   av=(-1)**v*(2*(xx-yy)-ev)
   walls=A(N)-A(M)+B(N)-B(M)
   assert abs(av-au)<=walls+2*I,(k,seed,u,v,orbit[u],orbit[v])
   variation=abs(abs(xx-yy)-abs(x-y))
   assert variation<=B(N)-B(M)+I+eu
   count+=1;max_drop=max(max_drop,abs(x-y)-abs(xx-yy))
 return count,max_drop

def main():
 start=time.process_time();checks=0;drop=0;families=0
 for k in[2,3,7,13,32,64,127,200,1001]:
  for c in sorted(set([0,k//2,k])):
   for cap in[None,max(1,k//2),k-1]:
    A=rho if cap is None else lambda x,b=cap:min(rho(x),b)
    B=R if cap is None else lambda x,b=cap:min(R(x),b+1)
    n,z=check(A,B,k,c,120);checks+=n;drop=max(drop,z);families+=1
 # Interleaved arbitrary staircases exercise the general lemma, including
 # coincident walls and several walls crossed within a single update.
 rng=random.Random(241026)
 for _ in range(24):
  aa=[0];bb=[0]
  for j in range(1,100):
   a,b=aa[-1],bb[-1]
   if rng.randrange(3)==0:a+=1;b+=1
   elif a==b:b+=rng.randrange(2)
   else:a+=rng.randrange(2)
   aa.append(a);bb.append(b)
  A=lambda x,aa=aa:aa[min(x,99)]
  B=lambda x,bb=bb:bb[min(x,99)]
  k=bb[-1]+1
  n,z=check(A,B,k,0,80);checks+=n;drop=max(drop,z);families+=1
 here=pathlib.Path(__file__)
 sources=[here,here.with_name('comparison-phase-wall-variation.md')]
 out=dict(status='stress checks passed; the universal proof is the separate wall ledger',families=families,interval_checks=checks,max_observed_span_drop=drop,source_hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in sources},CPU_seconds=time.process_time()-start)
 here.with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
 print(json.dumps(out,indent=2))
if __name__=='__main__':main()

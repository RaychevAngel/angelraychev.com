# Fixed-size successor memory for localized transitions

24 October2026. Necessary operator proposed for independent review. It does
not claim exact reachability, a uniform numerical gap, or Lean verification.

Assume odd width w=2b+1 and even n>=w. The geometric operator itself only
requires these dimensions; its ordinary signed-late intersections additionally
require k>=max(13,b+1) and terminal quota0<=c<=k. The assembled entrance
evaluator currently uses b>=32 and1<=k-b<b, matching its accepted head API.
Retain the accepted nine backward
thresholds B(c,e). Add three scalar thresholds for subsets of the following
localized source classes:

* P: source features(1,0), inside an own-corner ball of radius at most2b-2;
* S: source features(0,1), inside an opposite-corner ball of radius at most
  2b-3 (a subcritical square target);
* C: source features(0,1), inside an opposite-corner ball of radius2b-1.

Their next targets necessarily satisfy, respectively,

    P: j=0,v<=1; S: j<=1,v=0; C: v=0.                 (1)

The last case allows BOTH own corners. These are the accepted one-step radius
feature consequences in `../bridge-lower-frontier-terminal-family.md` (all-radius
pronic intervals and the critical square interval) and
`../uniform-gap-2026-10-23/lower-wide-square.md` (the wider subcritical square
interval q>(r-1)^2, with its identity-merger argument). The all-radius pronic
endpoint is also proved in `../resumed-odd-even-pronic-all-radii.md`.
They apply to the actual nonfull cohort:
formation is an identity guarded merger, and later signed mass is at most
the still-localized cohort size while merged corner features cannot exceed
its features. The source thresholds need only overapproximate those actual
marked histories, not arbitrary independent partial-state strategies.

Use the usual backward quota inversion with exactly the same source,
survivor and target feature guards as BAND9. For each candidate target
threshold T=B(j,v), let q be its accepted survivor capacity. The following
only remove a potentially unsupported TOP integer q, retaining every
smaller integer as a safe relaxation.

If i=0,j=1, surplus T-q=r, 2<=r<=b and

    (r-1)(r-2)<q<=r(r-1),                              (2)

accepted pronic localization forces target v=0 and the target is in classP.
If v!=0, or T exceeds the previous P threshold, replace q by q-1.

If i=1,j=0,v=1, T-q=r, the square localization applies for

    (r-1)^2<q<=r², r<b;
    r(r-1)<q<=r², r=b.                               (3)

The target belongs to S orC respectively. If T exceeds that class's
previous threshold, replace q by q-1.

Why is excluding this top survivor safe despite threshold intervals?
For the relevant own/outgoing corner pair the accepted static profile
requires surplus at least r at that q; thus no target smaller than T=q+r
can support q. Any actually winning witness with survivor q and target
bounded by T must use equality, hence the localized class. Unsupported
localization therefore rules out precisely that top candidate. Keeping
all smaller sizes, even if some also require localization, only relaxes
the necessary condition. Targets larger than T are unavailable at that
backward horizon. This argument does not assume the admitted sizes form
an exact interval.

After these replacements, recompute the nine ordinary thresholds with the
unchanged BAND9 quota maximum. Compute P,S,C with source features(1,0),
(0,1),(0,1) and the respective target filters(1), using those same corrected
survivor capacities. This permits chains of differently localized events;
it does not prematurely forget the next formation's flag.

At horizon zero all four kinds of thresholds are bounded by the terminal
quota. Along a globally normalized history, the independently accepted
ordinary signed-late maximum and its exact-capacity marker restrictions
can also intersect both ordinary and auxiliary thresholds. Induction on
the remaining horizon proves necessity of the resulting operator.

Implementation: `comparison_localization_flags.py`. It uses12 thresholds
regardless of w,n,k. The head marker/core clock and final inspection cut
remain separate. A result of the resulting evaluator is a rigorous lower
bound only after this operator and its boundary assembly are independently
reviewed; no attainment is inferred from an abstract accepting path.


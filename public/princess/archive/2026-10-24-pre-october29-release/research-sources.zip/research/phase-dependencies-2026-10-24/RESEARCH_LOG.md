# Phase compatibility and overlapping dependencies — 24 October 2026

Current status is in `CHECKPOINT.md`; the sections below preserve the
chronology, including conjectures subsequently accepted or rejected.

This pass resumes the uniform capture-time problem for every rectangle
`w <= n` and every feasible constant budget. The accepted starting result is
the previous checkpoint's computable uniform gap at most eight. The target
remains zero everywhere. No expression simplification, publication, or new
Lean coverage is part of this pass. The previous checkpoint is frozen.

## Baseline and independent lanes

The baseline is `../overnight-uniform-2026-10-24/CHECKPOINT.md` and its
source manifest. Its 27 frozen baseline inputs were checked unchanged at
resumption. Lower investigates physical dependency and phase constraints;
comparison investigates the two ordinary clocks and their numerical
interfaces; upper investigates actual constructions and independently
reviews physical claims. Root checks assembly and counterexamples.

## Preserved findings and failed routes

1. The exact overlap ledger in `lower-causal-overlap-ledger.md` identifies
   duplicated inspections as intersection surplus plus the fork correction.
   A total identity does not permit reallocating probes between days. It
   therefore does not supply a free independent-corner decomposition.
2. An independent compression of the loop-ended folded axis cannot help:
   `upper-fold-axis-rigidity.md` proves every monotone, cardinality-preserving,
   neighborhood-subcommuting map of that factor is the identity. This says
   nothing against a coupled or history-dependent compression. Root's
   odd-axis compression idea was already in `../odd-cylinder-exact-recurrence.md`
   and the manuscript; it is not a new achievement.
3. Keeping only sensitive endpoints, F-only intervening updates, and the
   exact total geometric inspection charge is insufficient. The necessary
   physical reduction remains valid, but its proposed scalar exclusion is
   false. `root-sensitive-transition.py` and its JSON receipts include
   k=200, b=199, u=1390, Delta=103: an old mass 38801 at root197 can
   numerically reach39007 at root198, while the matching ordinary phase
   reaches39006. The block requires at least19899 probes and allows20600.
   This is a counterexample to the relaxation, not a physical strategy.
   Comparison also obtained an infinite symbolic family of such tuples.
4. The omitted information in those tuples is intermediate localization:
   many F-only targets are zero-slack good states and cannot freely change
   their actual corner. Keeping all zero-slack good events initializes an
   ordinary reference in the exact phase without an extra day; see
   `comparison-first-zero-good.md` and its independent review.

## Current promising interfaces

* Absolute-time ordinary interlacing can make a retreat into the fast region
  free: if `min P_(t+1) >= max P_t`, a decreasing actual mass previously
  controlled in one phase is now controlled in both. The guard and proof
  are in `comparison-fast-interlacing.md`. This is a conditional interface,
  not yet a full early-boundary necessity theorem.
* Root checked the arithmetic guards at b=200,300,500,1000,3000,10000,100000,
  d=1,19 using the accepted optimized cutoff. Every displayed example has
  substantial interlacing and disjoint rigid-outlier-cone margin. The
  receipt is `root-fast-interface-guards.json`; these are diagnostics,
  not a proof for an infinite range.
* Erosion persistence may provide a stronger corner-switch delay than total
  inspection counting. A dense old corner component contains a full inner
  core. Inspections cannot destroy that core faster than ordinary erosion.
  If it still contains more cells than the new good event's outlier allowance,
  the dominant corner cannot change. Lower and comparison are working out
  the phase, defect, and endpoint conditions independently.
* For the already accepted even-width free-transport ranges, genuine
  ordinary head/tail necessity at the same elapsed time would make the
  existing constructive upper and terminal-quota lower coincide exactly.
  See `upper-ordinary-boundary-exact-interface.md`. This is an exact
  conditional assembly, not a claim of gap zero.

## Evidence boundary

No improvement of the uniform numerical ceiling has been assembled in this
pass so far. The verified uniform gap remains at most eight. The new ordinary
lemmas and negative results must be distinguished from an improved full-game
classification. Source-level reviews and finite checks do not imply Lean
formalization of these additions.

## Accepted advancement: uniform gap four

The earlier status paragraphs above are the chronology of this pass. The
current accepted whole-domain bound is now **U-L<=4**, replacing the
starting eight-day ceiling. The source is `root-uniform-four.md`, with root,
comparison and lower assembly reviews and independently checked physical
lemmas. Every width, length and feasible budget remains covered. Even
width with b>=32 and b<k<2b has the stronger two-day bracket.

The two boundaries now use genuine ordinary clocks without an extra day.
Early corner cores cannot disappear before bad steps remove their phase
advantage. The late proof reverses the actual solo portion and joins it to
the permanently mixed portion at its real activation state, retaining
original time and both terminal capacities. Finite-prefix normalization
preserves the actual signed terminal gate, so this is a universal gate
lower bound, not merely an argument for one normal-form winning word.

The only computer-assisted base is a complete small-root arithmetic lemma:
41,944,610 seeds, independently replayed by an integer-table implementation;
large roots have a uniform analytic proof. These are ordinary proofs with
independent arithmetic verification, not new Lean proofs.

The earlier causal-overlap ledger remains useful but does not itself justify
independent allocation of a day's quota. The activation proof resolves this
part of the argument without that unjustified decomposition.

Next work stays on gap zero. The remaining losses in the new assembly are
middle phase/shape alignment. The scalar necessary middle clock forgets
some compatibility between its incoming and outgoing physical corners.
No expression simplification or website/PDF publication has begun.

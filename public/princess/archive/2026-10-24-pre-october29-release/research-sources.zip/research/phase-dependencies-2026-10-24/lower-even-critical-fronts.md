# Critical surplus on even widths, away from the two shortest lengths

24 October 2026. Proposed physical classification for independent review.
No strategy compression or dynamic optimality is asserted.

Let the rectangle have dimensions 2b by n, with b>=4 and n>=2b+2.
Put h=bn, L=(b-1)^2 and U=h-b(b+1). Let S be a one-color physical set
with

    L<q=|S|<U,       |N(S)|-|S|=b.                       (1)

Then S has at least one of these descriptions:

1. A single genuine corner-quadrant component. For an own-colored corner,
   q<=b² and S lies in its radius 2b-2 ball. For an opposite-colored corner,
   q<=b(b-1) and S lies in its radius 2b-3 ball. Its raw minimal-shadow
   layers give the same literal triangular-defect core as in the accepted
   zero-good core theorem.
2. q=L+1, and S is a full own-colored (b-1)-triangle plus the singleton
   at the other own-colored corner.
3. S is a genuine end-facing pyramid along the long axis, toward either
   y=0 or y=n-1. Its actual same-color fibers are prefixes (or suffixes)
   with physical virtual cutoffs a_x of the appropriate parity satisfying
   |a_(x+1)-a_x|=1. Empty endpoint fibers are allowed in this description.

In particular, if b²<q<U, only case 3 is possible, and every physical
fiber is nonempty. Unlike the odd-width critical theorem, the orientation
is NOT fixed by the current physical color.

## 1. Exact matching coordinates and a clean ladder

Use the directed b-by-n matching array from
`../uniform-even-rectangle-isoperimetry.md`. Match physical rows 2i,2i+1;
identify a current-color vertex with (i,y). Horizontal edges are
bidirectional, vertical rungs alternate direction with y, and there are
loops. Write R for S in these coordinates and

    B=N_D^+(R) minus R,       |B|=b.

The n>=2b+2 hypothesis guarantees two consecutive B-free columns. Their
full directed ladder lies in one strongly connected component C of D-B.
Every B-free row meets C. R is outgoing-closed in D-B, so R either contains
C or avoids C.

The two clean columns represent two consecutive EMPTY physical y-columns
for a set avoiding C. Their left and right pieces have disjoint physical
neighborhoods. An empty matching row similarly represents two consecutive
empty physical x-rows, and separates the upper and lower neighborhoods.
Thus, if a set avoiding C also has an empty matching row, it decomposes
into genuine corner-quadrant pieces with additive nonnegative surpluses.
Splitting further into components joined by a common neighbor preserves
this additivity. No compressed set replaces the physical set here.

Every nonempty genuine quadrant component of surplus s has size at most
s² and positive surplus. Therefore a set avoiding C and an empty row has
size at most b². Under q>L, convexity forces either one component or the
exact equality q=L+1, with surpluses b-1 and 1 and square equality in both.
The latter is exactly case 2. In the single-component case, q>L forces the
origin layer, all b own layers or b-1 opposite layers, and equality in the
raw minimal-shadow equations. This is case 1, with the accepted literal
outer radius and core formulas.

## 2. One boundary vertex per row: the empty-row estimate

If there is a B-free row and the set avoids C, that row is empty and
Section 1 applies. Otherwise suppose B meets every matching row. It has
exactly one point in each of the b rows.

We need an estimate also for an empty row that itself contains its one
boundary point. Let A avoid B, be outgoing-closed outside B in D or D^T,
and let A_r be empty. The horizontal matching inequality from the static
proof remains valid. If n is odd, its exceptional entire-majority set
would require (n-1)/2<=b; here n>=2b+2 makes (n-1)/2>b, so that exception
is unavailable.

Use the parity pointing toward row r on each side. The one boundary
point in row r belongs to exactly ONE of those two parities. If it belongs
to the upper-side parity, the row-count argument bounds the area above r
by r²+2r and the area below by (b-r-1)². Hence

    |A| <= (r+1)²+(b-r-1)²-1 <= b²-1.                  (2)

If it belongs to the other parity, the same calculation gives
r²+(b-r)²-1<=b²-1. These estimates do not require occupied rows to be
consecutive; using all rows only increases the displayed upper bounds.
They apply when B merely CONTAINS the boundary of A.

## 3. A set avoiding C has one longitudinal side, or is the rigid exception

First assume R avoids C. If some matching row is empty, Section 1 gives
cases 1 or 2. Otherwise every row is nonempty. If there were a B-free row,
it would be empty, so every row has exactly one boundary point.

A nonempty subset of a bidirectional path whose outside boundary lies in
one point is a whole prefix before that point, a whole suffix after it,
or both components. The last alternative is impossible here: R avoids
both clean columns, whereas the union of both components contains at
least one clean column. Thus every row is a single prefix or suffix.

Split R to the left and right of the clean ladder. The two physical
neighborhoods are disjoint, so their surpluses add to b. If both pieces
are nonempty, each has surplus at most b-1. The exact even-area profile
applied to either piece gives a small or co-small alternative. The
co-small alternative is impossible since the piece is contained in R and

    h-|R| > b(b+1) > s(s+1).

Thus each piece has size at most its surplus squared. Convexity gives
q<=L+1. Under (1), equality is forced and again gives case 2.

If there is only one piece, every matching row is a prefix toward the
SAME end, or every row is a suffix toward the same end. This is case 3.
To see the physical pyramid property directly, let its contracted prefix
length in row i be beta_i. The two physical row cutoffs in that matched
pair differ by one. Across the boundary between matched pairs, the
vertical outgoing edges and the sole allowed boundary point exclude a
cutoff difference of at least three. The two cutoffs have opposite
parities, so their difference is exactly one. Reflection gives the suffix
case. This is the actual set, not a normalization.

## 4. The case containing C

If R contains C, put A=V(D) minus (R union B). It avoids C and is
outgoing-closed outside the SAME B in D^T. Its size is

    |A|=h-q-b>b².                                      (3)

If a B-free row exists, it is empty in A; Section 1's quadrant bound
contradicts (3). Hence B has one point per row. If any row of A is empty,
(2) contradicts (3). Each row is therefore a single prefix or suffix:
the two-component alternative would meet the clean ladder.

Split A at the clean ladder. If both pieces were nonempty, their actual
surpluses sum to at most b. Each is at most b-1, since every nonempty
proper set has positive surplus. The co-small alternative is excluded by

    h-|A|=q+b > L+b = b(b-1)+1 > s(s+1).

Their combined size is consequently at most b², contradicting (3).
Thus A occupies only one longitudinal side and its rows are whole prefixes
or whole suffixes. Taking the complement of A union B gives the opposite
end-facing rows for R. The same physical cutoff argument proves case 3.

Finally, an end-facing pyramid with an empty physical fiber has at most
b² cells: the slope-one height bound from that empty fiber is maximized
by the own-colored full corner triangle of radius 2b-2. Thus q>b² forces
all fibers to be nonempty, as stated.

## Scope boundary

The clean ladder is guaranteed only for n>=2b+2. For the two shortest
lengths n=2b and n=2b+1, a critical boundary can block all adjacent pairs
of columns; the proof does not classify that equality case. The strict
middle interval b²<q<h-b(b+1) is empty at those lengths, so their remaining
phase issue is intrinsically in the critical collar. Neither the present
classification nor the older odd-width classification resolves their
whole capture-time problem by itself.

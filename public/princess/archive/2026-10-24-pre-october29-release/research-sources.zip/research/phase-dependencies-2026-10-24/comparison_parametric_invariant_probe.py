"""Symbolic counterexample/closure probe for a critical max invariant.

SMT diagnostic only. A successful closure would need independent exact
certificate conversion; no theorem is inferred from finite width samples.
"""
import z3 as z
from comparison_wall_automaton import SIG,KEYS,F,PHYS
import comparison_localization_flags as loc
import json,time
b,d,J,q,delta=z.Ints('b d J q delta')
def mx(vals):
 a=vals[0]
 for v in vals[1:]:a=z.If(a>=v,a,v)
 return a
def reg(x):
 walls=[-2*b+2,-2*b+3,-2*b+4,-b+1,1,b+1,J,J+b,J+2*b-1,J+2*b]
 v=z.IntVal(10)
 for i,w in reversed(list(enumerate(walls))):v=z.If(x<w,i,v)
 return v
def lookup(r,vals):
 v=z.IntVal(vals[-1])
 for i in reversed(range(len(vals)-1)):v=z.If(r==i,vals[i],v)
 return v
def sgn(x):return z.If(x>0,1,z.If(x<0,-1,0))
def transition(pat):
 caps={};fr=dict(zip(('P','S','C'),pat[9:]))
 for key in KEYS:
  i,u,j,v=key;off=pat[F.index((j,v))];r=reg(q+off)
  cost=lookup(r,[s[key][0]for s in SIG]);pf=lookup(r,[s[key][1]for s in SIG]);sf=lookup(r,[s[key][2]for s in SIG])
  corr=z.If(z.And(pf==1,z.BoolVal(v!=0 or off>fr['P'])),1,0)
  corr+=z.If(z.And(sf==1,z.If(r<5,z.BoolVal(off>fr['S']),z.BoolVal(off>fr['C']))),1,0)
  caps[key]=off-cost-corr
 def bound(feature,pred=lambda j,v:True):
  return mx([caps[i,u,j,v]for i,u,j,v,c in loc.er.OPTIONS[feature]if pred(j,v)])
 B=[bound(f)for f in F]+[bound((1,0),lambda j,v:j==0 and v<=1),bound((0,1),lambda j,v:j<=1 and v==0),bound((0,1),lambda j,v:v==0)]
 x0=z.If(delta>=0,0,delta);x1=z.If(delta>=0,-delta,0)
 # The only extra low physical wall can occur for a lagging phase0 input.
 c0=z.If(q+x1<=-3*b+2,-2,lookup(reg(q+x1),[p[0]for p in PHYS]))
 c1=lookup(reg(q+x0),[p[1]for p in PHYS])
 y0=x1-c0;y1=x0-c1;m=mx([y0,y1]);out=[z.simplify(v-m)for v in B]
 return out,q+d+m,y0-y1,(y0+d>=0,y1+d>=0)
def main(seconds=45):
 st=time.process_time();states=[];seen=set();todo=[]
 for phase in(-1,0,1):
  pat=tuple(-int((phase>0 and f[0]==0)or(phase<0 and f[1]==0))for f in F)
  pat+=tuple(pat[F.index(f)]for f in[(1,0),(0,1),(0,1)])
  for r in range(4):
   state=(pat,r,phase);states.append(state);seen.add(state);todo.append(state)
 base=[b>=32,d>=1,d<=b-3,J>=3*b+1,q>=-2*b+1,q<J+2*b-1+d]
 checked=0;counter=None
 while todo and time.process_time()-st<seconds:
  pat,r,phase=todo.pop(0);out,qn,dn,prog=transition(pat);s=z.Solver();s.set(timeout=2000)
  s.add(*base,reg(q)==r,sgn(delta)==phase,*prog,qn<J+2*b-1+d)
  while True:
   result=s.check()
   if result==z.unknown:counter={'status':'solver timeout','state':(pat,r,phase)};break
   if result==z.unsat:break
   model=s.model();op=tuple(model.eval(v).as_long()for v in out);rn=model.eval(reg(qn)).as_long();pn=model.eval(sgn(dn)).as_long()
   witness={str(v):model.eval(v).as_long()for v in[b,d,J,q,delta]}
   if max(op[:9])>0:
    counter=dict(status='abstract invariant false',state=(pat,r,phase),output=(op,rn,pn),parameters=witness);break
   new=(op,rn,pn)
   if new not in seen:
    seen.add(new);states.append(new);todo.append(new)
   s.add(z.Not(z.And(*[a==v for a,v in zip(out,op)],reg(qn)==rn,sgn(dn)==pn)))
  checked+=1
  if counter:break
 result=dict(status='closure'if not todo and not counter else'probe incomplete or counterexample',states=len(states),checked=checked,pending=len(todo),counter=counter,CPU_seconds=time.process_time()-st)
 with open(__file__.replace('.py','.json'),'w')as f:json.dump(result,f,indent=2)
 print(json.dumps(result,indent=2))
if __name__=='__main__':main()

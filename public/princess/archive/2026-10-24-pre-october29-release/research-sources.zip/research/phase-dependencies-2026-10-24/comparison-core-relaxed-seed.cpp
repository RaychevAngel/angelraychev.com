// Challenge a sufficient coarse seed invariant; not physical evidence.
#include <algorithm>
#include <cmath>
#include <iostream>
using I=long long;
I R(I x){if(!x)return 0;I r=sqrtl(x);while(r*r<x)++r;while((r-1)*(r-1)>=x)--r;return r;}
I rho(I x){I r=(sqrtl(4.0L*x+1)-1)/2;while(r*(r+1)<x)++r;while(r&&(r-1)*r>=x)--r;return r;}
I F(I x,I k){return x+k-R(x+k);}I G(I x,I k){return x+k-rho(x+k);}
int main(){I checks=0;for(I k=12;k<=300;++k){for(I r=4;r<=k-2;++r){for(I defect=0;defect<r;++defect){I q=r*r-defect,m=(sqrtl(8.0L*defect+1)-1)/2;while((m+1)*(m+2)/2<=defect)++m;I delta=2*r-2*m-1;I z=0,J=0;while(z<q && F(z,k)>z){z=F(z,k);++J;}if(z<q)continue;I e=std::min((J-1+1)/2,k-r+1);while(e>0&&e>G(q-e,k)-(q-e))--e;I a=q,b=q-e,x=q;for(I t=1;t<=delta;++t){I na=G(b,k),nb=F(a,k);a=na;b=nb;if(t<delta)x=F(x,k);}I relaxed=G(x,k);++checks;if(relaxed>a){std::cout<<"{\"k\":"<<k<<",\"r\":"<<r<<",\"q\":"<<q<<",\"defect\":"<<defect<<",\"gap\":"<<e<<",\"J\":"<<J<<",\"delta\":"<<delta<<",\"relaxed\":"<<relaxed<<",\"phase\":"<<a<<",\"checks\":"<<checks<<"}\n";return 0;}}}}std::cout<<"passed "<<checks<<"\n";}

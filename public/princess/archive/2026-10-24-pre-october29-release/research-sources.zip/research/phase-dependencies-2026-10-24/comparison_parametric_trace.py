"""Dominance-compressed universal relation challenge; still exploratory.

Coordinates retain a signed initial-gap interval. Upper threshold profiles
are compared only in exactly the same physical parameter domain. No accepted
source is changed, and a timeout is not reported as a proof.
"""
from comparison_parametric_relation_probe import *
from functools import lru_cache
from pathlib import Path
from collections import deque
transition=lru_cache(None)(transition)
INF=1000000
# INF is a serialization sentinel, NEVER a mathematical bound on a phase gap.
def infinite_normalize(x):return INF if x>INF//2 else -INF if x<-INF//2 else x
def interval(bc):return(-INF,-3)if bc==-3 else(3,INF)if bc==3 else(bc,bc)
def go(seconds=180):
 st=time.process_time();todo=deque();seen=set();dom={};checked=0;counter=None;parents={};current=None
 def add(pat,r,phase,c,lo,hi,initial=False):
  state=(pat,r,phase,c,lo,hi,initial);key=(r,phase,c,lo,hi,initial)
  if state in seen:return
  pool=dom.setdefault(key,[])
  if any(all(a<=v for a,v in zip(pat,old))for old in pool):return
  dom[key]=[old for old in pool if not all(v<=a for a,v in zip(pat,old))]+[pat]
  seen.add(state);todo.append(state);parents[state]=current
 if True:
  for bc in range(-3,4):
   pat=tuple(-int((bc>0 and f[0]==0)or(bc<0 and f[1]==0))for f in F)
   pat+=tuple(pat[F.index(f)]for f in[(1,0),(0,1),(0,1)])
   lo,hi=interval(bc)
   for r in range(4):add(pat,r,bc,0,lo,hi,True)
 base=[b>=32,d==2,d<=b-3,J>=3*b+1,q>=-2*b+1,q<J+2*b-1+d]
 while todo and time.process_time()-st<seconds:
  state=todo.popleft();pat,r,phase,c,lo,hi,initial=state
  current=state
  if pat not in dom[r,phase,c,lo,hi,initial]:continue
  for marked in(True,False):
   pp=tuple(min(v,-int((phase>0 and f[0]==0)or(phase<0 and f[1]==0)))for v,f in zip(pat,F+[(1,0),(0,1),(0,1)]))if marked else pat
   out,qn,dn,prog=transition(pp)
   def clamp(v,f):
    cap=-z.If(z.Or(z.And(dn>0,f[0]==0),z.And(dn<0,f[1]==0)),1,0)
    return z.If(qn<-b+d+1,z.If(v<=cap,v,cap),v)
   out=[clamp(v,f)for v,f in zip(out,F+[(1,0),(0,1),(0,1)])]
   s=z.Solver();s.set(timeout=1800)
   s.add(*base,reg(q)==r,phase_bounds(delta,phase),delta>=-d-2+c,delta<=d+2+c,*prog,qn<J+2*b-1+d)
   if initial:s.add(q<=-2*b+2+d,delta<=d+2,delta>=-d-2)
   if lo!=-INF:s.add(delta>=lo)
   if hi!=INF:s.add(delta<=hi)
   s.add(q<-b+d+1 if marked else q>=-b+d+1)
   next_min=qn-q-z.If(dn>=0,dn,-dn)
   clipped=z.If(max(pp[:9])+q<J+2*b-1+d,max(pp[:9]),J+2*b-1+d-q)
   s.push();s.add(q+max(pp[:9])>=J+2*b-1,clipped>next_min)
   test=s.check()
   if test==z.unknown:
    counter={'status':'terminal solver timeout','state':state};break
   if test==z.sat:
    md=s.model();counter=dict(status='abstract terminal minimum relation false',state=state,parameters={str(v):md.eval(v).as_long()for v in[b,d,J,q,delta]},clipped=md.eval(clipped).as_long(),next_min=md.eval(next_min).as_long());break
   s.pop()
   while time.process_time()-st<seconds:
    result=s.check()
    if result==z.unknown:counter={'status':'solver timeout','state':state};break
    if result==z.unsat:break
    md=s.model();op=tuple(md.eval(v).as_long()for v in out);rn=md.eval(reg(qn)).as_long();pn=md.eval(bucket(dn)).as_long();diff=md.eval(dn+delta).as_long()
    cn=-c+diff;pl,ph=interval(pn)
    ln,hn=max(pl,infinite_normalize(-hi+diff)),min(ph,infinite_normalize(-lo+diff))
    assert ln<=hn
    if max(op)>8 or min(op)<-12 or abs(cn)>30:counter=dict(status='abstract offset escaped',state=state,output=(op,rn,pn,cn,ln,hn));break
    add(op,rn,pn,cn,ln,hn)
    s.add(z.Not(z.And(*[x==v for x,v in zip(out,op)],reg(qn)==rn,bucket(dn)==pn,dn+delta==diff)))
   if counter:break
  if time.process_time()-st>=seconds and not counter:
   todo.appendleft(state)
   break
  checked+=1
  if checked%100==0:print('checked',checked,'states',len(seen),'pending',len(todo),flush=True)
  if counter:break
 trace=[]
 if counter:
  cur=state
  while cur is not None:trace.append(cur);cur=parents[cur]
 result=dict(status='closure'if not todo and not counter else'incomplete parametric relation',states=len(seen),active=sum(map(len,dom.values())),checked=checked,pending=len(todo),counter=counter,trace=list(reversed(trace)),profiles=[list(x)for x in seen],remaining=[list(x)for x in todo],CPU_seconds=time.process_time()-st)
 with open(__file__.replace('.py','.json'),'w')as f:json.dump(result,f,indent=2)
 print(json.dumps({k:v for k,v in result.items()if k not in('profiles','remaining')},indent=2))
if __name__=='__main__':go()

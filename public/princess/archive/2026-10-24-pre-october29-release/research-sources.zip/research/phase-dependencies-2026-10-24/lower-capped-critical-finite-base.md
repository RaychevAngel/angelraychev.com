# Removing the analytic cap-transfer cutoff

24 October2026. Corollary with independently reproduced finite arithmetic
base. No rectangle lengths or physical-state catalogues are enumerated.

The conclusions of `lower-capped-critical-continuation.md` and
`lower-capped-critical-first-cut.md` hold under the weaker guard

    b>=max(32,4d+8),          d>=1.

All geometry, critical-core bounds and large-root mixing in the continuation
proof already hold in this range. The guard b>=200 was used only in its
Section4 to reuse an uncapped small-root numerical certificate without a
cap interaction. Replace that step for32<=b<=199 as follows.

For each of the4,452 pairs (b,d) with32<=b<=199 and4d+8<=b, iterate the
GENUINE capped ordinary pair until its minimum reaches
min((b-1)^2,99^2). At every preceding time, both phases, and every integer
q in the gap between the coordinates, retain exactly the valid zero-good
root/phase cases

    4<=r<=min(99,b-1),       (r-1)^2<q<=r(r-p).

Use the exact raw core radius, including the minimum with2r-4 at the own
singleton exception. The necessary assertion is the literal capped mixing
inequality

    Bc^(Rcore-1)(q)<=min Pc_(u+Rcore-1).

`root-capped-small-root-audit.py/.json` checks all1,154,597 such seeds.
Every case passes; the minimum core-minus-mixing margin is4. These loops
are complete because the ordinary minimum is monotone, so no later time
can have a dangerous root below100 after reaching the stated cap.

The independent implementation `lower_capped_small_root_review.py`
enumerates by ROOT first and computes every map by binary inversion of
its defining target-size-plus-surplus inequality, instead of using the
root subtraction formulas. It reproduced every per-(b,d) seed count,
the total1,154,597, and minimum margin4. Its source-hashed receipt is
`lower-capped-small-root-review.json`.

Thus the finite certificate replaces exactly the sole unavailable step
for b<200; the physical induction and its quantified length range are
unchanged. This is a finite arithmetic base for an unbounded-parameter
history theorem, not an extrapolation from solved board instances.

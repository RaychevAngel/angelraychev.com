# Comparison lane — 24 October 2026 phase-dependency pass

This lane preserves the accepted all-parameter eight-day bound. No publication,
new Lean coverage, or numerical-expression simplification is performed here.
The eventual target remains exact capture time for every rectangle and budget.

## Accepted advances

1. **First zero-good event has an exact ordinary matching phase.**
   `comparison-first-zero-good.md`, independently reviewed in
   `upper-first-good-and-plateau-review.json`, includes both phases and the
   triangle-plus-singleton case. The earlier first-sensitive argument omitted
   important nonsensitive zero-good events.
2. **Ordinary interlacing is global.** Root and this lane independently noticed
   the abstract monotone/inflationary tied-origin proof. The early and arbitrary
   late-gate pairs satisfy min(next)>=max(current), with no cutoff or time guard.
   `comparison-global-interlacing.md` and `upper-global-interlacing-review.json`
   supersede the guarded source and receipt, which remain preserved. The new
   use is a free retreat/phase reset; the elementary interlacing was implicit
   in earlier boundary arguments.
3. **Physical core persistence plus ordinary bad-map mixing gives a uniform
   scalar identity-switch guard.** Lower proved B²(x)<=min(GF(x-1),FG(x-1)),
   which removes one room of positive phase error every two bad steps.
   For genuine ordinary origins, e<=3r/4 when r>=20; every zero-good core
   survives enough steps for all r>=100. I independently accepted the proof
   in `comparison-large-root-mixing-review.json`.
4. **The small-root complement is a complete finite arithmetic base.**
   Root's reduction is to k13..9900, roots4..99, all relevant ordinary times,
   both phase ranges, every danger mass. My independent C++ implementation
   enumerates roots first and computes bad updates directly from their defining
   inequality. It agrees on all100105 seeds, every per-budget count and margin0.
   See `comparison-finite-base-review.cpp/.json`. This is a finite base for a
   uniform theorem, not a collection of selected-width experiments.

The resulting scalar guard still requires the physical history assembly:
tiny targets, critical-root neutral intervals, returns, and final crossing
must be stated. No improved global capture-time ceiling is asserted by this log.

## Failed and superseded approaches

* The endpoint-only sensitive comparator is false even with a one-room initial
  phase gap and the exact endpoint inspection charge. The exact infinite family
  in `comparison-sensitive-plateau-obstruction.md` is independently accepted.
  Its omitted intermediate targets are zero-good and have persistent corners.
* Adding the old core delay eliminated the targeted sensitive counterexamples,
  including every sensitive seed between the two genuine ordinary coordinates
  at k20,200,783,1000,2000,10000. This diagnostic was superseded by the stronger
  all-zero-good B proof. It is not itself a uniform F-only mixing theorem.
* Core-delay mixing fails for arbitrary coarse seed boxes. A local seed
  k12,r4,q13,gap1 and a slower-region seed k100,r59,q3444,gap30 violate the
  proposed F-only comparison, despite passing crude span/time constraints.
  Genuine ordinary ancestry cannot be silently discarded. The challenge source
  is `comparison-core-relaxed-seed.cpp`; the slower variant was temporary.
* A global phase-spread bound delta²<=k is false; delta²<=2k survived targeted
  accelerated checks but was never proved. No such square-root theorem is
  needed for the accepted large-root core-mixing argument: a coarse linear
  bound is already enough.
* `comparison-bad-pair-exceptions.md` correctly isolates square exceptions to
  the pointwise strict inequality B²<=min(FG,GF)-1 (338448 local checks passed).
  Lower's input-shift inequality is strictly better for mixing: the ordinary
  composition is flat at those exceptions, so error still decreases by one.
  The exception-counting route is retained as an intermediate observation,
  not a required ingredient of the new uniform guard.
* The guarded fast-interlacing note originally overstated arbitrary future
  growth after a small retreat; that sentence was corrected before review.
  Multi-step cap domination requires a source above the cap or independent
  domination of the whole cap. The new global lemma states this precisely.

## Remaining issues and next interfaces

The early proof can divide history at zero-good events. Same identity keeps
its matching phase; a different identity waits for the raw old core to erode,
by which time the bad map has made both ordinary phases available. Tiny states
are free at k>=13. Critical-root targets within the pronic ceiling obey F and
preserve a carried phase; returning below that root is decreasing and invokes
global interlacing. These facts need a single audited physical induction.

The forward small-support late problem does not inherit hole-core persistence:
inspections can destroy a support core. Reversing a COMPLETE winning inspection
sequence on an undirected board yields another winning sequence. Consequently
an exact early theorem at both ends, joined by a bidirectional middle separator,
may be a cleaner route to the full-capture objective than an unnecessarily
strong exact late theorem for arbitrary forward partial states. No such joined
exact theorem is claimed here.

## First-quota extension and the late activation splice

The ordinary early physical induction has now been independently accepted by
the upper lane. Its use in the existing analytic capture-time assembly removes
the early extra day. I independently reviewed that assembly in
`comparison-gap-six-interface-review.md/.json`; its stated unbounded families
have a six-day bracket, while the old finite-width complement does not change
automatically.

The late issue has a concrete solution under review. Reverse only the genuine
solo prefix ending at the actual activation PRE-state. The permanently mixed
suffix comparison applies from that same PRE-state because it requires proper
post-inspection survivors. It supplies a BOTH-phase ordinary capacity for the
real terminal set D. E(D) then initializes the reversed hole induction at the
genuine shifted reference time, retaining ordinary ancestry. The original
one-shot survivor surplus is |D|-|E(D)|, whereas the dual hole surplus
|N(E(D))|-|E(D)| can be smaller. I initially conflated these in a review
objection, then withdrew it after checking the complement identity. Zero
original slack forces dual equality, and extra original slack supplies the
worse inverse bound, so the original initialization is sound.

The only new scalar orbit is the first-quota seed
W0=(c-rho(c),c-R(c)), 0<=c<=k. Lower proves its large-root mixing and the rigid
initial one-room exception. My complete finite base checks every k13..9900,
initial quota c0..k, relevant u>=1, roots4..99, both phases and all eligible
sizes. All41,944,610 seeds pass; minimum time margin is zero. Sources and
coverage are `comparison-first-quota-finite.cpp/.md/.json`. This is a uniform
arithmetic complement, not a sampled rectangle panel. Independent review is
pending; the saved receipt does not call itself a Lean proof.

I also wrote `comparison-ordinary-head-pronic-middle.md`: with a genuine
ordinary head the asymmetric pronic middle comparison needs only b>=32,
1<=d<=b-1 and no small-d residue enumeration. At odd d1 the exact head spread
is at most one, and the final middle update's two possible ordered outputs
meet either compatible head phase. This remains conditional on the separate
boundary hypotheses until its independent review and the late splice finish.

## Accepted four-day coverage and new phase-dependent lower clocks

The first-quota finite base, ordinary-head middle interface, and exact signed
late splice have now all passed independent review. The full coverage argument
in `root-uniform-four.md` is independently accepted in
`comparison-uniform-four-review.md/.json`: it gives a computable bracket of
width at most4 over the whole rectangle domain, and at most2 in the stated
even-width pronic-cut range. This is a uniform bound, not a zero-gap solution.

Early dangerous phase histories retain an actual corner/neighbor marker.
Intersecting the necessary head feature faces with that marker, and intersecting
the backward nine thresholds with the true ordinary late capacities, is a
uniformly defined stronger evaluator. A subsequent forward inversion preserves
the exact quota/feature guards at the first safe subcritical crossing. Lower
independently accepted that inversion. Exact transport cases400x402,k202 and
400x800,k202 remain at their previously proved optima under the new necessity,
providing an adversarial check against incorrectly imposing fixed orientation.

The last-good/core-age envelope retains the physical core even after both
ordinary numerical phases dominate. Its root-bin evaluation is in
`comparison_core_head.py`; it matched lower's literal size enumeration on16
targeted feature/time checks. The assembled diagnostic considers all later
crossing times until every core feature cap provably reachesL. For127x128,k64,
the cornerless fake entrance is removed, but the best gate remains1374 via the
actual full-triangle entrance(1,2),Q=(b-1)^2. Thus a core-age improvement alone
does not close that example's two-day gap.

Tracing its necessary path identifies an immediate geometric violation after
a critical pronic reset. This motivated `comparison_localization_flags.py`:
nine ordinary thresholds plus THREE one-successor localization thresholds,
using accepted all-radii pronic/wide-square/critical-square interval geometry.
The proof is `comparison-localization-flags.md`. Lower and parent independently
accepted the top-survivor exclusion argument, including explicit enumeration
of smaller possible targets. Upper's final review is in progress. This is a
fixed-size uniform necessary operator, with no claim every accepted transition
is physical. It proves targeted clocks1375/1375 on127x128,k64 and5541/5541
on419x420,k210, both matching their physical upper times. On81x162,k41 it gives
7282/7282 and a two-day remaining gap; the already accepted full paired-radius
model closes that particular case. These examples are challenges/effects of
the uniform operator, not an all-width comparison theorem.

The proposed one-day phase-face comparison fails for unrefined BAND9 even
after clipping to the entrance interval:81x162,k41,c41,t7080 has compatible
face5041 versus physical phase5040, with genuine early pair(1520,1518).
The12-threshold operator removes this observed obstruction. A symbolic proof
may start when the ordinary late orbit first reachesL=(b-1)^2, where the
physical inverse is exactly the ordinary orbit. An initial arbitrary seed
box produced fake pair(959,962) at b32,k33, but that pair violates the already
proved global interlacing minPhi(C)>=maxC. It is NOT a counterexample to a
progressive/interlaced input theorem. The corrected local seed box is under
falsification before any symbolic wall certificate is attempted.

## Uniform minimum-budget symbolic middle, 24 October continuation

The twelve-threshold localization operator has now passed BOTH independent
reviews (`lower-localization-flags-review.json`,
`upper-localization-flags-review.json`). The old note's pending-review language
is historical; numerical and geometric sources are frozen under those receipts.

A new all-b/all-n comparison is in `comparison-minimum-budget-one-day.md`.
`comparison_critical_cost_certificate.py` proves396 primitive cost/formation
entries and22 physical costs by polynomial inequalities for everyb>=32 and
n=2b+2+2S. `comparison_wall_automaton.py` then checks only normalized states
and residue representatives of exact affine cycles. Band lengths are allowed
independently, so this is not a scan of selected widths. States reduce
6->3->1->1->1->1->2; all clipped phase-face inequalities pass. Upper's
independent review is in progress.

The stronger `comparison-minimum-budget-exact-gate.md` uses its unique bulk
state to create a tied split at any hypothetical gate horizon one below the
physical prefix gate clock. It would prove exact g_c=P_c for EVERY terminal
quota0<=c<=k in the odd minimum-budget family. It needs only the already
accepted capped EARLY theorem, not the newly developed capped late theorem.
The two-front phase/time interface is under independent review. No exact
full-game claim has yet been promoted from this proposed proof.

The separate `comparison_fixed_excess_automaton.py` exploration passed
fixed d2,3,4,5 with independent band lengths. These are not accepted theorems:
outer primitive table ranges and symbolic initial seed boxes must be extended
before using them. The normalized threshold patterns have only0/1/2 room
offsets from physical maximum, while only the signed physical phase gap varies
withd. This suggests a parametric invariant rather than more budget runs.

## Phase-wall ledger and general-excess comparison, later continuation

Upper independently accepted the minimum-budget primitive/translation
certificate in `upper-minimum-budget-one-day-review.json`. Parent's shorter
`root-tied-cut-exact-gate.md` and its independent review now establish the
odd minimum-budget exact family; this supersedes the older pending language
above, without altering the frozen comparison sources.

The new `comparison-phase-wall-variation.md` is independently accepted by
both parent and upper. For interlaced paired maps with costs A<=B<=A+1,
the change in absolute phase gap between u and v is at most
B(M_v)-B(M_u)+I_u+(B-A)(M_u), with I_u the relevant initially straddled
walls. The signed wall sum proves this uniformly, including simultaneous
walls and incomplete final crossings. It bounds loss as well as growth of
phase gap, and so can support physical core-age arguments. It is not itself
a new capture theorem. The checker contains164601 arithmetic challenges;
the all-parameter argument is the wall-by-wall proof.

An earlier general-d threshold abstraction was incomplete and then failed
when rerun with sound timeout handling. Its failure is abstract: it lets the
smaller physical coordinate cross a root wall twice. Actual global
interlacing forbids that. `comparison_parametric_interlaced_trace.py` adds
the smaller coordinate's root interval and obtains a candidate closed
relation at d=2 for every b>=32 and every length (237 nondominated states).
`comparison_parametric_interlaced_closure.py` is checking the same relation
for2<=d<=b-3. These remain exploration until independent validation of the
inductive state coverage and mathematical interface. No width sampling is
used to establish their parameter quantifiers.

The expanded primitive table has a separate exact polynomial receipt:
`comparison_general_critical_cost_certificate.py/.json`. It extends the
last interval to h-L+b-2 and adds the lagging physical input interval above
(b-2)^2. This is a necessary dependency, not a substitute for closure.

At the requested wrap-up, the repaired general relation completed:900
profiles,751 nondominated,850 checks, no pending states or counter. All
threshold offsets are between-2 and0 relative to physical maximum. This is
still a CANDIDATE pending independent inductive replay and the explicit
mathematical range/entrance/assembly checks listed in
`comparison-checkpoint-wrap.md`. Search has stopped; no gap reduction is
promoted from the discovery alone.

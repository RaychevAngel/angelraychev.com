# Complete finite mixing base after a first smaller quota

24 October 2026. Exhaustive integer certificate, not a board-size experiment.
The physical assembly is separate in `lower-first-quota-ordinary-boundary.md`.

Write R(x)=ceil(sqrt(x)), rho(x)=min{r:x<=r(r+1)}, and

    F(x)=x+k-R(x+k), G(x)=x+k-rho(x+k),
    W_0=(c-rho(c),c-R(c)), W_(u+1)=(G(W_u[1]),F(W_u[0])),
    B(x)=x+k-1-rho(x+k-1).

For every k>=13, 0<=c<=k, u>=1, phase p in{0,1}, and integer q satisfying

    min W_u < q <= W_u[p],
    r=R(q), 4<=r<=min(99,k-2), q<=r(r-p),

define the conservative physical core radius

    C=2r-2-p-2m(r(r-p)-q),
    m(D)=max{j:j(j+1)/2<=D}.

At p=0,q=(r-1)^2+1 replace C by min(C,2r-4), to include the possible
singleton-outlier alternative. The certificate establishes

    B^(C-1)(q) <= min W_(u+C-1).                         (1)

## Why the enumerated range is complete

The two initial coordinates are nondecreasing in c; F and G are monotone.
The initial pair lies below k and differs by at most one. At k>=13 its
first update is coordinatewise larger. Hence every seeded orbit increases
coordinatewise in time, and W_u>=P_u for the ordinary zero-origin orbit.

For u>=1 a dangerous q of root r requires

    k-R(k)=min P_1 <= min W_u < q <= r^2.

The nondecreasing function k-R(k) has reached r^2 by k=r^2+r+1.
Consequently k<=r^2+r<=9900. This proves the budget bound; it is not an
assumed cutoff. For fixed k put cap=min(99^2,(k-2)^2). Once min W_u>=cap,
all later times have no eligible q. If min W_1>=cap for one initial quota c,
all larger initial quotas are also vacuous by monotonicity in c. These are
the only parameter/time pruning rules in the checker.

Within every retained time state, the checker enumerates EVERY integer in
each coordinate gap, then checks its root and its phase capacity. Thus no
assumption about the maximum gap, its sign, or its phase has been used.

The checker literally advances B and the ordinary pair until both-phase
domination or C updates. A hit after j<=C-1 proves (1): once z<=min W,
the inequalities B<=F,G and monotonicity preserve domination at all later
steps. Every integer square, pronic and triangular endpoint is corrected
by exact multiplication after the initial floating-point estimate.

## Result and evidence boundary

`comparison-first-quota-finite.cpp` completes all 9,888 budgets and checks
41,944,610 dangerous seeds, in 24,745,740 nonvacuous initial-quota orbits
and 53,840,340 time states. It makes 76,081,986 bad updates. All checks pass;
the minimum margin C-1-j is zero, so the asserted stopping-time endpoint
must not be strengthened by one without further proof.

`comparison-first-quota-finite.json` records all per-budget seed/orbit
counts and the source hash. This is a finite computer-assisted arithmetic
base for a uniform theorem. It is neither a Lean proof nor a classification
of individual widths. The complementary r>=100 case, u=0 initial state,
tiny-root geometry, and physical use of the core radius are proved separately.

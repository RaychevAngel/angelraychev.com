# Rectangle capture time: frozen research results, 24 October 2026

Research stopped at the user's wrap-up request. This is the current private
result summary; the chronological CHECKPOINT and lane logs preserve the
development history. The objective remains gap zero for every w<=n and
every feasible k>=floor(w/2)+1. Numerical-expression simplification is
deferred until that is achieved.

## 1. Whole-domain bounds

The accepted combined bounds are computable and constructive:

    L_k(w,n) <= T_k(w,n) <= U_k(w,n),    U-L <= 4

for EVERY rectangle and feasible budget. This improves the preceding
uniform-eight checkpoint by four days. All stronger older results are
retained by taking the maximum of proved lowers and minimum of proved
uppers. No width, length, or budget is omitted.

More precisely:

* Odd-by-odd rectangles retain their earlier exact algorithmic evaluation.
* Every even width w>=64 has gap at most TWO for every n>=w and every
  feasible k. This includes the difficult low budgets.
* For odd w=2b+1>=65 and even n, k>=2b also has gap at most TWO.
* Widths at most64 retain the earlier gap-at-most-three coverage, plus
  all older and new exact cases. The large odd-width low-budget interval
  b<k<2b retains the universal four-day ceiling where no stronger result
  below applies.

Sources: root-uniform-four.md, root-large-excess-one-middle.md, their
independent reviews, and the previous width-at-most64/odd-odd coverage
explicitly cited by the assembly. These are ordinary proofs and exact
arithmetic certificates, not new Lean results.

## 2. Exact even-width regimes

Write w=2b, k=b+d, with b>=32. The bounds match in both ranges:

* d=1, EVERY n>=2b;
* 2<=d<=b-1, EVERY n>=2b+2d-2.

The exact value is J(k)+J(floor(k/2))+1, where J is the explicitly stated
ordinary endpoint recurrence and finite endpoint minimum in
upper-exact-even-transport-families.md. The reflection construction
attains it. Lower's independent review accepts the physical phase join
and terminal shared-budget argument. These are unbounded parameter
families, not selected numerical boards.

## 3. Exact odd-width/even-length regimes

Write w=2b+1, n=2ell, k=b+d. Under

    d>=1, b>=4d+8, (2b+1)(ell-b)>2d^2,

every terminal-quota gate has its exact physical prefix clock P(c), and

    T_k(w,n)=P(k)+P(floor(k/2))+1.

The established concatenation/palindrome rule supplies optimal inspections.
In particular the condition holds for EVERY length n>=w when b>=d^2 in
addition to b>=4d+8. It includes minimum budget on every odd width>=25.

Source: lower-full-front-exact-gates.md; independently accepted by upper
and root. The earlier tied-cut argument is a separate independently
checked proof at minimum budget.

The stronger computable criterion retains the genuine central phase span
G. Let C be the specified capped forward pair from zero, s its first time
with min C_s>b^2, D=C_s[0]-C_s[1], and G=max(|D|,|1-D|). Put
A=wn/2-b^2-k. The sufficient condition becomes

    A-b^2 > 2G(d-1)+d.

This subsumes the preceding length condition because G<=d. Under the same
natural guard b>=4d+8, G<=3 suffices for EVERY length. G is computed from
the genuine recurrence; no universal small-G assumption is made.
Source: upper-central-span-exact-gates.md, independently reviewed by lower.

These are exact algorithmic answers with attaining strategies. They do
not satisfy, or claim to satisfy, the eventual O(1)-operation numerical goal.

## 4. Why the new exact proof works

The proof compares the beginning and end of ONE actual hypothetical faster
strategy at ONE common time. The two phase capacities cannot be chosen
independently. Failure of the physical prefix meeting forces both actual
endpoints into the larger, incompatible phase. Their numerical deficits
and the extra cells in the reverse allowed set share a single budget.

Once that common cut is far enough inside the middle, both endpoints must
retain actual broad fronts from recent cheap-surplus events. Their phases
force the same longitudinal end. Their whole shapes overlap in more cells
than the shared deficit allows, contradicting physical disjointness.
The actual inspections attain the remaining lower bound.

This directly addresses the phase-compatibility and overlapping-dependency
issues. The present length/span conditions ensure that both required actual
front ancestors exist. Removing those conditions is still work to do.

## 5. Accepted tools for the remaining cases

Raw localized erosion preserves its ORIGINAL area defect at every age.
The proof uses literal diagonal intervals, including empty intermediate
layers. It avoids the former loss from replacing an area defect by a
missing inner radius. Source: root-localized-erosion-defect.md; upper review.

Phase-span variation is charged once per crossed square/pronic wall, with
explicit initial endpoint corrections. It controls decreases as well as
increases and remains valid for the capped orbits. Source:
comparison-phase-wall-variation.md; root and upper reviews. It is not a
universal square-root bound on the span.

Whole-front overlap now retains the shared age/deficit budget. There is
also an explicit independently checked mixed front/triangle overlap
inequality. Sources: upper-whole-front-overlap.md,
upper-whole-front-sum-overlap.md, upper-front-triangle-overlap.md.
The first and third have independent proof receipts; the sum refinement
has the root derivation and upper proof, with its complete discrete check.

Actual critical sets on even widths are classified for n>=w+2, and the
one-longer case n=w+1 has its separately accepted extension. These
classifications retain actual localized sets, the rigid triangle/singleton
exception, or actual end-facing fronts; they do not assume arbitrary
strategies can be compressed to prefixes. Exact even squares still have
an unreviewed separator analysis. This is static geometry, not another
exact capture-time claim.

A conditional normalized two-ancestor inequality, independently reviewed,
leaves a positive overlap margin of17/16. Its finite-board corrections and
physical premises have NOT yet been assembled into a capture theorem.
The stronger9/8 conjecture failed and its rational counterexample is saved.

## 6. Candidate at the stopping point

The comparison lane completed a finite symbolic inductive closure for
every b>=32, 2<=d<=b-3 and its stated area parameter, with751 final
nondominated profiles and850 checks. It retains the smaller coordinate's
root interval so that a wall cannot be crossed twice in a false history.

This is a CANDIDATE certificate. Independent replay, primitive-table range
verification, and the complete physical entrance/exit interface remain
outstanding. It is NOT used to lower the current four-day global ceiling.
Read the comparison lane's frozen checkpoint before resuming this branch.

## 7. Remaining work, in priority order

First complete and independently check the candidate comparison interface:
it may sharpen the all-budget odd-width bracket uniformly.

For gap zero, remove the short-board collar restriction by combining the
phase-wall ledger with literal localized erosion and shared-slack overlap.
Both localized/localized and localized/full-front ancestors must be handled,
with exact integer errors and real activation states. The normalized
inequality alone is insufficient.

For even widths, turn the actual critical-set classification into a
phase-compatible short-board lower bound or an equally fast physical
joining strategy. Finish the square separator classification without
silently assigning a convenient orientation to a bent configuration.

Retain the stronger existing results in all other budget ranges. Only
after the lower and upper bounds match throughout the domain should work
move to fixed-size numerical expressions.

## Artifact and evidence boundary

The current checkpoint, handoff, research proofs, review receipts, failed
approaches and computational outputs are saved privately. The public
website, main manuscript/PDFs, downloads, and Lean coverage have NOT been
updated to this research checkpoint. No new complete Lean theorem is
claimed. The frozen source manifest records what was present at wrap-up;
source-hash audits verify the selected accepted proof receipts.

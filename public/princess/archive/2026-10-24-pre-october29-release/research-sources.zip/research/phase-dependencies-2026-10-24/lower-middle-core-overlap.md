# Physical middle compatibility from two actual corner cores

24 October 2026. Geometric lemmas for independent review. These retain
actual corner and cohort labels; no prefix normal form or middle optimality
is asserted. The overlap form also applies to a reverse allowed set which
contains the actual survivor, without claiming its core lies in that survivor.

## Time and color convention

Let B_t be the belief of one FIXED initial cohort before inspection day t,
H_t its complement in its current checkerboard color, and S_t its survivor
after that inspection. Then B_(t+1)=N(S_t), S_t subset B_t, and

    H_(t+1)=E(H_t union I_t).

Suppose an earlier actual hole state H_u contains a complete one-color
corner ball B_Re(Ce), and a later actual survivor S_v contains B_Rl(Cl).
Put Delta=v-u>=0. The raw radii are parity-normalized: Re has the color
parity of H_u relative to Ce, and Rl has the color parity of S_v relative
to Cl. Erosion persistence gives

    B_(Re-Delta)(Ce) subset H_v,                     (1)

whenever Re-Delta>=0. Inspections can only enlarge holes, so this is
independent of all intermediate shapes and quotas. The sets in(1) and
S_v have the SAME current color and are disjoint.

At early and late zero-good events the core radii are supplied by
`upper-zero-good-core-persistence.md`: own no-outlier
2r-2-2m(r²-q), opposite no-outlier2r-3-2m(r(r-1)-q), or the own singleton
exception2r-4. For a late event the other survivor is exactly full, so
the same raw component/layer proof applies to its small survivor.
Under the accepted alternating polarization, early dominant holes and
late small survivors belong to the same permanently smaller cohort.

## 1. A necessary delay for distinct actual corners

Let Ce and Cl be distinct corners at graph distance D. Suppose Rl<D,
as is automatic for subcritical zero-good roots: Rl<=2b-4 while
D>=w-1>=2b-1. Then

    Delta>=max(0,Re+Rl-D+1).                         (2)

Indeed if Delta<=Re+Rl-D, the retained radius R=Re-Delta is nonnegative
(in fact positive because Rl<D), and R+Rl>=D. Along a shortest grid path
between the corners, there is a current-color vertex at distances at most
R and Rl from the respective endpoints. To see parity exactly, R and Rl
have compatible current-color parity, so R+Rl-D is even. The permissible
path interval therefore contains an integer of the required parity even
when the radii sum equals D. This vertex belongs to both H_v and S_v,
a contradiction.

For Ce=Cl, the sum-of-radii formula is NOT valid. The correct obstruction
is simply Delta>=Re+1 whenever the later core is nonempty: any nonempty
retained core of the same color intersects the later core at their shared
corner or its current-color neighbors.

The elapsed quantity is v-u, where u is a post-movement/pre-inspection
hole time and v is a POST-inspection survivor time on day v. There is no
extra movement on day v in(2).

## 2. Exact adjacent-corner overlap and a quantitative room charge

Suppose Ce and Cl are adjacent corners, D their side length in edges,
0<=R<D,0<=S<D, and both corner balls use the SAME physical checkerboard
color. Let delta=R+S-D, automatically even. The perpendicular side is at
least the smaller side of the rectangle; in the intended subcritical use
R,S<=2b-4, so it never truncates the overlap. Then the exact intersection is

    |B_R(Ce) intersect B_S(Cl)| = 0                 if delta<0,
                                    (t+1)(t+2)/2  if delta=2t>=0. (3)

Use coordinates Ce=(0,0),Cl=(D,0). At perpendicular height y the allowed
horizontal interval is [D-S+y,R-y]. Its endpoints have the desired
checkerboard parity, and for0<=y<=t it contains exactly t-y+1 allowed
cells. Summing gives(3). The radii<D keep the horizontal endpoints inside
the rectangle; the stated perpendicular guard keeps every such y inside.

More generally, let C_v be ANY one-color allowed set containing S_v,
and suppose C_v contains a core B_Rl(Cl). Put

    eta=|C_v|-|S_v|>=0.

Because H_v is disjoint from S_v,

    |B_(Re-Delta)(Ce) intersect B_Rl(Cl)|<=eta.       (4)

This is the valid replacement when the later core is known only for a
reverse allowed set. It must NOT be silently moved into the actual S_v.
For adjacent corners, (3) turns(4) into the exact condition

    tri((Re-Delta+Rl-D)/2+1)<=eta

whenever the numerator is nonnegative; otherwise the overlap charge is0.
Here tri(z)=z(z+1)/2. Thus a geometric phase relocation either consumes
enough elapsed movement to separate the cores or requires an explicit
number of extra allowed rooms. The case eta0 recovers the parity-sharp
version of(2).

## 3. A phase marker survives every dangerous early interval

Before any critical-root excursion, suppose Q_t>min P_t in the accepted
ordinary early theorem. At the last zero-good event u responsible for its
matching branch, Q_u must also exceed min P_u; otherwise all intervening
B steps preserve both-phase domination. The uniform mixing inequality
guarantees both-phase domination after R_core-1 such steps. Consequently
a still-dangerous time satisfies t-u<R_core-1. The retained actual core
then has radius at least2.

It follows that the matching current own phase has an actual hole at its
anchor, while the matching opposite phase has holes at both neighbors of
the anchor. Same-identity good events simply refresh the core; a different
identity is initialized only after the previous interval has mixed, then
carries its own actual core. Tiny or critical events already reset both
phases and cannot generate a later dangerous subcritical interval.

This provides a physical marker, not just a numerical MAX choice, whenever
the two ordinary phases differ in a way relevant to the actual count.
Translating it into the precise merged corner/erosion feature faces must
retain the established complement/parity convention. That translation and
its effect on the middle clock are separate work.

## Remaining task

The raw two-front delay requires actual zero-good endpoints or an allowed
set with a certified core and quantified eta. A mere ordinary numerical
capacity does not automatically give such a set or core. To close the
remaining capture gap one must connect these constraints to the actual
boundary/central passage, including any surplus or unused-capacity credit.
The lemmas here do not themselves assert a new uniform day bound.

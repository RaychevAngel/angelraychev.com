# Critical even-width classification at length one larger than the width

24 October 2026. Extension of the independently reviewed
`lower-even-critical-fronts.md`. The older source stays unchanged.

Let the board be 2b by 2b+1, b>=4, h=b(2b+1), L=(b-1)^2. For any
one-color physical set S with

    L<|S|<b²,       |N(S)|-|S|=b,                       (1)

S is a genuine localized corner component, the rigid own triangle plus
singleton, or an actual end-facing pyramid along ONE of the two axes.
The localized radii and literal raw-layer cores are exactly those in the
accepted even critical classification. No orientation is chosen freely
by a lower evaluator: the assertion concerns the actual physical set.

Use the original b-by-(2b+1) matching array, matching the even physical
axis. Its boundary B has b vertices.

## 1. If an adjacent pair of B-free columns exists

The proof of `lower-even-critical-fronts.md` applies without change except
for its exclusion of the odd-path horizontal-matching exception. Here the
minority horizontal class has size b, so cardinality alone does not exclude
that exception. The clean ladder does.

In the only exceptional row, all b+1 vertices of the majority column
parity are selected. Every minority column therefore has a selected or
boundary vertex at that row. The minority parity is the direction pointing
toward the empty anchor row used in the area argument. Following that
directed column to the empty anchor forces a B vertex in the SAME column,
including the anchor row itself when its boundary point is used. Hence all
b minority columns contain B. Since |B|=b, these are precisely the odd
columns, leaving no adjacent B-free pair. This contradicts the present
case. The argument also applies in the transposed graph and when the
anchor row contains its one boundary point.

All clean-ladder splitting, empty-row estimates, dual exclusions and
physical cutoff arguments therefore remain valid. The conclusion here
is the original localized/rigid/longitudinal-pyramid classification.

## 2. If no adjacent pair of B-free columns exists

The b+1 unmarked columns form the unique maximum independent set of the
odd path: columns 0,2,...,2b. Thus B has one point on each odd column and
none on any even column. In phase 0 the boundary-free even-column fibers
are actual prefixes along the matched short axis; phase 1 gives suffixes.
This is exactly the alternating-column argument in
`lower-critical-core-or-frontier.md`, now with b matched rows rather than
at least b+1. That row-count inequality was used only to guarantee a clean
row in its OTHER case and is unnecessary here.

For completeness, the needed exceptions are as follows. If the clean
fiber at column 2j is empty, horizontal closure and the one-point barriers
give

    |S|<=j²+(b-j)².

An internal empty fiber and (1) force |S|=L+1, j=1 or b-1, and equality
in every count. This is the full own (b-1)-triangle plus the other own
corner singleton. If only an endpoint clean fiber is empty, the same
length bounds put the original set and its neighborhood in a genuine
corner quadrant; the accepted additive-component and raw-layer argument
gives the localized case (or the same rigid exception).

No clean fiber can be full. Applying the empty-fiber bound to the
transposed complement of S union B would give

    h-|S|<=b²+b,

contrary to |S|<b². Hence, unless one of the already described empty-fiber
exceptions applies, every clean fiber is nonempty and nonfull. Each marked
fiber is contained in its neighboring clean prefix and differs from it by
at most the single boundary point. Its directed edges exclude any portion
above that point, so it too is a prefix. Adjacent lengths differ by zero
or one in the appropriate staggered convention. In physical coordinates
this is a genuine pyramid facing an end of the SHORT axis.

The suffix phase is its reflection. This proves the stated classification.

## Remaining equality case

The exact square 2b by 2b is not covered. In its b-by-2b matching array,
there are b+1 maximum independent unmarked-column patterns; the interior
patterns have two clean parities separated by a pair of marked columns.
There need not be a boundary-free matched row. A square proof must classify
that additional separator configuration, not silently reuse the odd-path
uniqueness argument above.

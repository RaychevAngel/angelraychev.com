# The natural range of the capped odd-width continuation

24 October 2026. Independently checked finite-base and guard corollary.
This preserves the accepted analytic sources without changing their hashes.

All the following accepted statements hold under the single natural guard

    w=2b+1, n even and n>=w, k=b+d, d>=1, b>=4d+8:

* `lower-capped-critical-continuation.md`: actual zero-origin matched
  continuation while total holes stay below U=h-b(b+1);
* `lower-capped-critical-first-cut.md`: all-time clipped early necessity
  at A=U-d;
* `lower-capped-critical-marker.md`: actual marker at a dangerous phase;
* `upper-capped-first-quota-continuation.md`: every genuine first quota
  0<=c<=k and its shifted actual-set initialization;
* `upper-capped-signed-late-splice.md`: normalized signed late necessity
  clipped at Z=U+b=h-b^2.

In particular b>=12 and k>=13 follow from the guard. There is no additional
cutoff at32 or200. No capture-time conclusion is asserted here.

## Complete arithmetic coverage

For b>=200 the accepted analytic cap-transfer proof and its original
all-first-quota certificate apply. For32<=b<200, the complete independent
inverse-profile replay in `lower-capped-seeded-review.json` checks4452
parameter pairs,690942 genuine first-quota orbits and160021649 dangerous
phase/size seeds; the minimum core-minus-mixing margin is4.

For12<=b<32, `lower-capped-small-width-seeded-review.json` independently
replays every row of the additional exact base:60 parameter pairs,1650
orbits,130183 time states and130966 dangerous seeds; minimum margin0.
The two implementations construct the capped maps differently: the
independent one inverts their defining target-profile inequalities.

The finite checks include all c in[0,k], every genuine time before the
ordinary minimum passes the small-root range, both possible leading
phases, and every admitted target size. The time-zero seed exception is
handled by the accepted analytic first-quota initialization. No board
length or physical state is sampled.

## Every nonarithmetic guard already holds

The critical separator theorem requires only b>=4 and ell>=b+1. For the
full-span core, b>=4d+8 implies

    b^2-3b+4 > (d+1)(4b+2),

so its endpoint length is at least d+2. For localized critical cores,
tri(b-d-1)>2b-2 and the smaller opposite-phase defect give the same radius
at least2d+2. The singleton core is longer still. These inequalities hold
already at b=4d+8 and grow with b; no use of b>=32 occurs.

The tiny-state reset needs k>=13, supplied by b>=12. The exceptional
first-quota origin cannot jump directly to the critical range because
2k<(b-1)^2 already at b12,d1 and throughout the stated guard. The raw
subcritical-core theorem requires r>=4; all smaller counts are covered by
the tiny-state reset. The large-root argument is unchanged; all other
roots are covered by the complete finite base above.

The mixed signed comparison uses

    U+b-d+1 < U+2b-2,

which holds since b+d>3. Its small mixed-boundary profile and central
barrier have no larger width hypothesis. The shifted initialization uses
only d>=1, b>=4, the same good-event classification, and the seeded base.
Finally U>=b^2+2b+1 guarantees A>L, the strict first-crossing overshoot,
and the required safe clipped interval. Thus no remaining geometric,
time-index or initialization hypothesis retains32 or200.

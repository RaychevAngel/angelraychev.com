# Critical surplus: an actual corner core or an oriented full-span frontier

24 October2026. Odd-width physical classification for independent review.
This extends the sharp strict-middle classification down through the entire
critical root bin. It is not a compression or an optimality theorem.

Let the board be (2b+1) by2ell, where b>=4 and ell>=b+1. Write
h=(2b+1)ell and L=(b-1)^2. Let S be a one-color physical support with

    L<q=|S|<h-b(b+1),     |N(S)|-|S|=b.              (1)

Then at least one of the following physical descriptions holds.

1. S is a genuine corner-quadrant support with no other component.
   If its corner has S's color, q<=b² and its actual core radius is
       2b-2-2m(b²-q).
   If its corner has the other color, q<=b(b-1) and its actual core is
       2b-3-2m(b(b-1)-q).
   The support lies in the corresponding outer ball of radius2b-2 or2b-3.
2. q=L+1, and S is the disjoint union of the full own-corner triangle
   of (b-1)^2 cells and the singleton at the other own-colored corner.
   The large actual core has radius2b-4.
3. S is a phase-oriented full-span critical frontier: in the contracted
   coordinates of `../uniform-odd-short-critical-frontiers.md`, phase0
   has genuine prefixes on every fiber, with
       1<=l_u<=ell-1 on every majority fiber u,
       l_v<=l_u<=l_v+1 on every adjacent minority/majority pair.
   Phase1 has the longitudinally reflected suffix form. In particular S
   contains BOTH own-colored board corners and its neighborhood contains
   neither opposite-colored corner.

Here m(z)=max{j:j(j+1)/2<=z}. In case1 the core formula is the already
proved raw-layer formula; it is a subset of the ORIGINAL support. Case3
is not asserted to contain a large corner ball. It may have a shallow
majority fiber, so it must retain its front orientation rather than borrow
the core of case1.

## 1. The separator alternative remains valid at this odd critical width

Contract a perfect matching along the even side, as in the sharp critical
proof. The directed array has2b+1 columns, ell rows, and b outside-boundary
vertices. Since ell>=b+1, an entire matched row avoids the boundary.

If two adjacent columns also avoid it, the old common strongly connected
component and two perpendicular separators exist exactly as in the
subcritical finite-board proof. If S avoids the common component, its four
corner pieces have unchanged genuine-quadrant neighborhoods and additive
nonnegative surpluses. If S contains it, apply the same argument to the
opposite-color complement of N(S). That gives

    h-q-b<=b²,

contrary to(1). Thus S is on the small side and has the genuine quadrant
decomposition. No strict inequality b<floor(w/2) was needed: the required
empty matched row comes from the longer side's ell>=b+1.

Each nonempty component has positive surplus s_i and size at most s_i².
If at least two components occur and sum s_i=b, convexity gives

    q<= (b-1)²+1=L+1.

Under(1), equality is the only possibility. For b>=4 equality requires
exactly two positive surpluses b-1 and1, and equality in both square
capacities. These are full own-corner triangles, the second a singleton.
The two available own-colored corners are distinct, giving case2.

Otherwise S has one component in a genuine quadrant. If it omitted its
own quadrant origin, or in the opposite case omitted both neighbors of
its origin, the punctured capacities C2(b) or C3(b) would be <=L. Thus
its appropriate origin layer is occupied. Sharing-neighbor connectivity
makes occupied layers consecutive. Size q>L forces all b own layers or
all b-1 opposite layers, and exact surplus b forces the raw minimal-shadow
layer equations. The existing triangular-defect propagation gives the
stated core, as in `upper-zero-good-core-persistence.md`. This is case1.

## 2. The alternating-fiber alternative

If no adjacent pair of columns avoids the boundary, the b marked columns
are exactly the minority fibers V={1,3,...,2b-1}, with one boundary point
each. The clean majority fibers U={0,2,...,2b} are actual phase0 prefixes
(and phase1 suffixes). Adjacent majority lengths differ by at most1, while
an intervening minority fiber is contained in both neighboring prefixes
and differs from each by at most its one boundary point.

If majority fiber2j is empty, the sharp proof gives

    q<=j²+(b-j)².                                    (2)

For an internal empty fiber1<=j<=b-1 the right side is at most L+1.
Equality under(1) forces q=L+1 and j=1 or b-1. Every length and cardinality
in the summation proving(2) must then attain its bound. All majority
lengths are |i-j| and every minority fiber is the entire shorter neighbor
prefix. Returning to physical coordinates gives exactly the full
(b-1)-triangle plus the singleton at the opposite own corner: case2.

If the only empty majority fibers are at an endpoint, reflect so that
l_(2b)=0. Then l_(2j)<=b-j and each intervening minority fiber lies in the
following shorter majority prefix. In physical coordinates every selected
cell satisfies x+y<=2b-2. Thus S and N(S) have exactly their genuine
quadrant neighborhoods. The component/capacity argument from Section1
now gives case1 (or the already allowed equality exception, which cannot
use the empty opposite own corner).

Finally suppose every majority fiber is nonempty. No majority fiber can
be full: the sharp transposed-complement empty-fiber bound would give
h-q<=b(b+1), contrary to(1). The sharp proof's last step therefore applies
verbatim: each minority fiber misses its far endpoint, has only one possible
boundary point, and must itself be a prefix. We obtain case3.

## Consequence and limitation

Above b² only case3 remains, recovering the sharp strict-middle theorem.
Within L<q<=b², a cheap critical step cannot be treated as an arbitrary
unlabelled profile: it creates a real localized core, the rigid singleton
exception, or the phase-forced spanning frontier. In the own-color core
case and the spanning-frontier case the physical longitudinal side is the
same side carrying the current color's two board corners.

A history may pass between these alternatives. The statement does not
assert that an old core always survives an entire middle segment, or that
all such passages have an extra time cost. Those require a separate
transition/history argument; the existing relaxed witness's first two
critical-surplus steps are not ruled out merely by this classification.

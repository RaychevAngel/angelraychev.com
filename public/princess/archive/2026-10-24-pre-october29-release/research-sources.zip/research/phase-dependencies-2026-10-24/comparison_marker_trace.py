"""Witness paths in the necessary nine-feature relaxation, never physical plans."""
import comparison_marker_clock as m
import json

def frontiers(w,n,k,c,t):
 h=w*n//2;b=w//2;V=(c,c);B={f:min(c,h-4+sum(f))for f in m.band.FEATURES};out=[]
 for j in range(t+1):
  M=max(V);cap=min((b-1)**2+k,b*b+1)
  if M<cap:
   B={f:min(q,M-int(M-k>=10 and ((V[0]>V[1]and f[0]==0)or(V[1]>V[0]and f[1]==0))))for f,q in B.items()}
  out.append(B)
  if j<t:B=m.band.step(w,n,k,B);V=m.late_step(V,k)
 return out

def trace(w,n,k,c,t,a,feature):
 layers=frontiers(w,n,k,c,t);assert a<=layers[-1][feature]
 er=m.band._geometry.er;rows=[]
 for remaining in range(t,0,-1):
  if a<=k:break
  q=a-k;options=[]
  for i,u,j,v,cost in er.OPTIONS[feature]:
   if cost>k:continue
   hi=layers[remaining-1][j,v]
   if m.band.survivor(w,n,hi,i,u,j,v)<q:continue
   lo=0
   while lo<hi:
    mid=(lo+hi)//2
    if m.band.survivor(w,n,mid,i,u,j,v)>=q:hi=mid
    else:lo=mid+1
   options.append((lo,i,u,j,v))
  assert options,(remaining,a,feature)
  T,i,u,j,v=min(options)
  rows.append(dict(remaining=remaining,a=a,source=feature,q=q,survivor=(i,u),T=T,target=(j,v),surplus=T-q))
  a,feature=T,(j,v)
 return dict(w=w,n=n,k=k,c=c,t=t,path=rows,terminal=(a,feature))

if __name__=='__main__':
 x=trace(127,128,64,32,1001,4284,(1,2))
 print(json.dumps(x,indent=2))

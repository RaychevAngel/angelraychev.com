# An actual marker whenever the capped critical phase matters

24 October2026. Physical corollary of the independently reviewed capped
critical continuation and finite arithmetic base. No attainment claim.

Use w=2b+1,n even>=w,k=b+d,b>=max(32,4d+8),d>=1,
h=wn/2,U=h-b(b+1), and the genuine capped ordinary pair Pc from zero.
Suppose an actual full-origin history stays Q_j<U through time t and

    Q_t>min Pc_t.                                       (1)

Then some actual cohort/end has current relative phase p such that

    Q_t<=Pc_t[p],

and the holes of that actual cohort contain a full corner core of current
radius at least two. In particular:

* p0: the corresponding own-colored corner is an actual hole;
* p1: both neighbors of the corresponding opposite-colored corner are
  actual holes.

The physical end and cohort are those of a real last good event, not a new
choice made after numerical phase comparison.

## Proof

A tiny event is controlled by both phases. Before the first good event,
every other update obeys Bc and is likewise controlled by both. Once below
both coordinates, any further Bc update preserves that control.

Let u<=t be the last actual good event. It exists by(1), and its count must
also have been dangerous; otherwise all subsequent Bc steps preserve
both-phase control. No later tiny event is possible for the same reason.
Follow the actual phase of this event through the subsequent bad updates;
the accepted continuation proof gives Q_t<=Pc_t[p].

At this good event the proof supplies an ACTUAL core radius R and the
literal numerical mixing assertion

    Bc^(R-1)(Q_u)<=min Pc_(u+R-1).

For a critical event this follows from R>=2d+2 and mismatch<=d. For a
subcritical event it is the accepted large-root argument or complete
small-root cap-transfer certificate. Therefore a still-dangerous time
must have

    t-u<R-1.

Deterministic hole erosion retains the raw core of radius R-(t-u)>=2.
Its current parity gives exactly the stated own-corner or opposite-neighbor
marker. The fact that an earlier numerical orbit could already have caught
up does not erase geometry; here danger itself ensures that the physical
core has not disappeared.

## Exact merged feature cap

For each physical belief cohort, let c be its number of occupied own-colored
board corners and e the number of opposite-colored corners whose complete
neighbor set lies in that belief. The accepted nine-feature merger takes
the nonnegative excess of the two respective counts over two.

An own hole marker forces the merged c<=1. An opposite neighbor-pair hole
marker forces merged e<=1. Hence an actual merged source of feature(c,e)
and total holes Q_t necessarily satisfies

    Q_t<=max(min Pc_t,
              Pc_t[0] if c<=1 else 0,
              Pc_t[1] if e<=1 else 0).                    (2)

No monotonicity of the numerical frontier in c or e is assumed. A later
optimization must preserve the whole relevant feature face, or separately
prove any reduction to its maximal coordinate.

At the safe first crossing A=U-d from
`lower-capped-critical-first-cut.md`, all actual prefix counts remain<U,
so(2) applies there with the additional upper bound Q_t<=U-1. This extends
the earlier small-boundary marker rule through the physical middle collar.

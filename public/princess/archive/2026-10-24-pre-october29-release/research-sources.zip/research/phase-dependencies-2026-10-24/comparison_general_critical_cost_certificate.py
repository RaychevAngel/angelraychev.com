"""Expanded critical table certificate; depends only on b, not d.

This extends the accepted eleven-region table upward as far as the next
high pronic wall, and certifies the extra lagging-physical lower interval.
"""
import comparison_critical_cost_certificate as old
import time,json

def main():
 st=time.process_time();checks=[]
 old.RANGES[-1]=(old.h-old.L+1,old.h-old.L+old.b-2)
 for reg,(lo,hi)in enumerate(old.RANGES):
  assert(hi-lo).nn()
  for key in old.KEYS:
   got=old.cost(reg,key);expect=old.SIG[reg][key][0]
   assert got==(expect,expect),(reg,key,got,expect)
   i,u,j,v=key
   p=int(i==0 and j==1 and((reg==0 and expect==-1)or(2<=reg<=4 and expect==0)))
   s=int(i==1 and j==0 and v==1 and((reg<=3 and expect==-1)or(reg==5 and expect==0)))
   assert old.SIG[reg][key][1:]==(p,s)
   checks.append([reg,list(key),expect,p,s])
  dl,dh=old.h-hi,old.h-lo
  pc0=old.mn(old.root(lo,hi,1),old.root(dl,dh,0),(0,0))
  pc1=old.mn(old.root(lo,hi,0),old.plus(old.root(dl,dh,1),1),(1,1))
  assert(pc0,pc1)==tuple((a,a)for a in old.PHYS[reg])
 lo=(old.b-2)**2+1;hi=(old.b-1)*(old.b-2)
 assert old.root(lo,hi,1)==(-2,-2)
 assert old.root(lo,hi,0)==(-1,-1)
 out=dict(status='expanded exact polynomial table passed',primitive_checks=len(checks),physical_checks=24,scope='b>=32; last rank up to h-L+b-2; extra low physical interval above (b-2)^2',CPU_seconds=time.process_time()-st)
 with open(__file__.replace('.py','.json'),'w')as f:json.dump(out,f,indent=2)
 print(json.dumps(out,indent=2))
if __name__=='__main__':main()

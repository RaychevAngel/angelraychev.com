# A necessary corner marker at exact late capacity

24 October 2026. Physical phase-feature lemma for independent review.
It strengthens the ordinary late numerical ceiling only at an exact
capacity contact; no arbitrary prefix shape or generic state compression
is assumed.

Use the signed-late theorem's notation and hypotheses:

    max(13,b+1)<=k<=b², 0<=c<=k,
    Zcap=min((b-1)²+k,b²+1),
    W_j=V_(j+1)^c-(k,k).

Consider a normalized full-origin history at a pre-inspection source whose
signed mass m reaches gate c after t further unsuccessful updates. Suppose

    M=max V_t^c < Zcap,
    V_t^c[p]>V_t^c[1-p],
    M-k>=10,
    m=M.                                               (1)

Then the larger source cohort is full, and the smaller source set S has
the following actual geometric marker:

* p0: S contains an own-color board corner;
* p1: S contains BOTH neighbors of an opposite-color board corner.

Equivalently, if c_S counts own corners of S and e_S counts opposite-color
corners in E(S), exact capacity in phase0 requires c_S>=1 and exact capacity
in phase1 requires e_S>=1. A source with the incompatible zero feature
therefore has signed mass at most M-1.

## 1. Exact capacity cannot start in the mixed portion

If the source is at or after activation, the accepted mixed comparison
gives min(m,Zcap)<=min V_t^c. Under(1) its left side is M, strictly larger
than the right side. Thus the source is strictly before activation, or
there is no activation before the terminal gate. Its larger cohort is
full and its smaller actual set S has cardinality exactly M.

## 2. Equality in the real reversed word identifies the source set

In the activation case, write a>=1 for the solo prefix length and ell=t-a
for the mixed suffix length. The actual activation set D satisfies
|D|<=both V_ell^c. The alternative min V_ell>=Zcap is impossible because
the later maximum M is below Zcap. Reverse the actual solo prefix and put

    C_0=D, C_(j+1)=I_(a-1-j) union E(C_j), H_j=E(C_j).

The signed splice proves S subset C_a and the exact chain

    M=|S| <= |C_a| <= k+|H_(a-1)| <= max V_t^c=M.       (2)

The final inequality is UNCLIPPED here: the final ordinary maximum is
strictly below Zcap, so its erosion capacity is below
Dcap=Zcap-k. Any actual erosion count reaching Dcap would contradict the
accepted clipped comparison and time monotonicity. Thus every reversed
count is below Dcap, and the ordinary bound applies literally.

Every inequality in(2) is an equality. Therefore S=C_a, H_(a-1) subset S,
and |H_(a-1)|=M-k=max W_(t-1). The comparison's genuine orbit index is t-1,
since ell+a=t; it has not been reinitialized at activation.

If there is no activation, use the real terminal D of size<=c and reverse
the entire solo word. The same equalities hold with a=t, ell0, and the
genuine first-quota-c initial erosion. This includes the initial-state
case t1 without treating a signed gate as a fictitious solo terminal set.

## 3. The actual erosion retains the matching marker

Every reversed count is below Dcap<= (b-1)². Tiny reversed states are below
both ordinary coordinates and reset both-phase control. Nongood non-tiny
steps obey B. At a zero-good event the actual core has the matching phase;
if its numerical count exceeds the smaller ordinary coordinate, the
uniform mixing theorem makes both phases available after R_core-1 bad
steps. Hence a still-dangerous final erosion retains a positive raw core
around its carried actual corner. It contains the origin in own phase
or both neighbors in opposite phase.

This is the marker argument of `lower-middle-core-overlap.md`, with the
genuine seeded and shifted orbit. Initial shifted good events have real
cores, so no earlier physical history is required. At the first-quota
initial time, a unique dangerous seed is itself an own-sensitive component
containing its origin. The assumption M-k>=10 excludes the tiny initial
cases; the same origin conclusion would hold in those cases as well.

The final erosion size equals the UNIQUE larger ordinary coordinate, so
its actual matching phase must be precisely p. Since H_(a-1) subset S,
the corresponding marker is contained in the actual source S. This proves
the claim.

## 4. Exact relation to a merged feature state

The full partner has both own corners and both erosion corners. Therefore
the usual merged corner and erosion counts of this full-plus-small source
are exactly the corresponding counts c_S,e_S of the smaller source.
The required marker consequently survives the accepted merger; it is not
an untracked label on only one component of a genuinely mixed source.

The lemma concerns a contact at M=max V_t^c with a UNIQUE larger phase.
It grants no one-room improvement when the pair is tied or when the source
has the required marker. The missing phase's bound, and the conversion of
this feature restriction into a sharp middle time, require their own
numeric recurrence proof. This is not yet another whole-board day bound.

# Exact late contact retains a large core in the last root bin

24 October 2026. Analytic geometric refinement for independent review.
The budget excess is a parameter, not a fixed integer. No width samples or
new day-bound claim are used.

Use the exact late contact of `lower-late-capacity-marker.md`, and put
d=k-b. In addition suppose

    k>=100,   k>d²+4d+3,
    H+1<=M=max V_t^c<Zcap,     H=b(b-1),
    V_t^c has a unique larger coordinate,   actual m=M.

The guard implies d<b-1, so Zcap=(b-1)²+k. The equality proof produces
an actual one-color erosion H_* contained in the pre-inspection source set S, with

    q=|H_*|=M-k,
    (b-1)²-d<=q<(b-1)².                              (1)

The last zero-good ancestor of H_* has root EXACTLY b-1. At most2d+1
subsequent bad moves have occurred. Consequently S contains a full raw
corner core of radius at least

    R_*(b-1)-(2d+1),                                 (2)

where, with m(z)=max{j:j(j+1)/2<=z},

    R_*(r)=min(2r-2-2m(2r-2),
               2r-3-2m(r-2),
               2r-4).

The actual retained radius has the required checkerboard parity. If (2)
is used as a prescribed radius rather than a lower bound, round it down
to that parity. This is a core of the ACTUAL pre-inspection source set, not just of
a reverse allowed set.

## 1. An ancestral growth bound while the phase is still dangerous

The exact-contact proof has no reverse count reaching Dcap=(b-1)²; such
a crossing would make the later ordinary capacity at least Zcap. At the
last zero-good event let its root be r, its size q0, its ordinary mismatch
be e=q0-min W>0, and let delta be the subsequent number of bad moves.
Then r<=b-1. Tiny states or both-phase states cannot produce the final
danger without a later good event, so this last event exists. A tiny
initial seed loses its one-room mismatch after one B step; it cannot be
the ancestor of the much larger final count in(1).

The exact two-step B comparison gives

    delta<=2e-1,    e<=k-r.                           (3)

For r>=20, the proved genuine seeded-origin estimate also gives
e<=3r/4+1. For r<20 use physical core persistence/mixing instead:
delta<=R_core-2<=2r-4.

Since q0>(r-1)² and k>=r+2, every value x>=q0 satisfies
rho(x+k-1)>=r. Along the increasing B orbit from q0, therefore

    B(x)-x<=k-r-1.

The orbit is increasing on the relevant range below its first fixed point
(k-2)², and all relevant roots are at most k-2. Thus

    q<=r²+delta(k-r-1).                               (4)

This upper bound concerns the necessary B relaxation of the actual bad
suffix; actual retreats are allowed and can only reduce the final count.

## 2. Small and intermediate ancestral roots cannot reach the endpoint

The main guard implies d+1<sqrt(k). Hence by(1)

    q> (k-sqrt(k))²-sqrt(k)>4k²/5                     (5)

for k>=100:2sqrt(k)<=k/5, and k-sqrt(k)>0.

For r<20, equations(3)--(4) instead give

    q<=r²+(2r-4)(k-r-1)<=34k-319<7k²/9.

For20<=r<=2k/3, use delta<=3r/2+1. The upper polynomial is

    r²+(3r/2+1)(k-r-1)
       =-r²/2+3kr/2+k-5r/2-1.

It is increasing in this r interval when k>=100. At r=2k/3 it equals
7k²/9-2k/3-1. Both bounds contradict(5). Therefore

    r>2k/3.

## 3. Only the final ancestral root remains

Put a=k-r. Now a<k/3, while r<=b-1 gives a>=d+1. Equations(3)--(4) yield

    q<=f(a):=k²-2ka+3a²-3a+1.                        (6)

For a<k/3 the polynomial is strictly decreasing. If a>=d+2, its maximum
on the allowed range is f(d+2), and direct subtraction gives

    f(d+2)-[(k-d-1)²-d]
       =-2k+2d²+8d+6<0.

This contradicts(1). Hence a=d+1, or r=b-1, as claimed. Equation(3) now
gives delta<=2d+1.

At a zero-good event with root r, the largest possible own defect is
2r-2 and the largest opposite defect is r-2; the singleton exception has
radius2r-4. The raw-core theorem therefore supplies radius at least R_*(r).
Erosion loses at most one radius per subsequent move, proving(2).

## Use and limit

For bounded or moderately growing excess d, this retains a radius close
to2b: the loss is O(sqrt(b)+d), with the explicit expression(2). Combined
with a genuine early core, the overlap/allowed-room charge of
`lower-middle-core-overlap.md` can rule out an incompatible adjacent-corner
passage at its putative drift time. That combination still needs its own
actual early endpoint and capacity-credit proof. The present lemma is not
a claim that every optimal late source has this shape; it applies at the
stated exact unique-phase capacity contact.

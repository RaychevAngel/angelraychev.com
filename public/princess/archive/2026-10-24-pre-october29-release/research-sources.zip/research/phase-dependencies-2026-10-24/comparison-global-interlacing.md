# Global ordinary interlacing and a free retreat interface

24 October 2026. Elementary algebraic lemma, jointly noticed independently by
root and comparison after reviewing the earlier guarded proof. Submitted for
independent review. This supersedes the guard in comparison-fast-interlacing.md;
the earlier source/review is preserved as a historical artifact.

## Abstract tied-origin lemma

Let f,g map an interval I of integers into itself, be nondecreasing, and satisfy
f(x)>=x and g(x)>=x on I. From a tied seed a in I define

    X_0=(a,a), X_(t+1)=(g(X_t[1]),f(X_t[0])).

Then every t satisfies

    min(X_(t+1)) >= max(X_t).                         (1)

Indeed X_1>=X_0, so monotonicity gives X_(t+1)>=X_t coordinatewise. Each
new coordinate also dominates the OTHER old coordinate by inflationarity of
its scalar map. Thus it dominates both old coordinates. No Lipschitz estimate,
phase-spread bound, root cutoff, or elapsed-time restriction is needed.

## Both ordinary boundary pairs

For the early pair take

    F(x)=x+k-ceil(sqrt(x+k)), G(x)=x+k-rho(x+k),
    I=[0,k(k-1)], a=0.

Both maps are nondecreasing, inflationary on I, and fix its upper endpoint.
Hence(1) holds globally for the ordinary zero-origin pair P.

For the late pair with ANY terminal gate 0<=c<=k, take

    Fhat(x)=x+k-ceil(sqrt(x)), Ghat(x)=x+k-rho(x),
    I=[0,k²], a=c.

These maps have the same three properties and fix k². Hence(1) also holds
for the ordinary late pair V^c, without using the special c=k conjugacy.

In the early pair, if P_t[0]>=P_t[1] then its gap is at most
G(P_t[1])-P_t[1]; in the reverse ordering it is at most
F(P_t[0])-P_t[0]. This follows from coordinatewise time monotonicity. It is
an exact local-speed bound on ordinary phase spread, although it is not the
stronger square-root bound sought elsewhere.

## Retreatment from a matched physical reference

Suppose an actual state at elapsed index t is dominated in ONE matching
ordinary phase, Q_t<=X_t[p]. If Q_(t+1)<=Q_t, then(1) gives

    Q_(t+1) <= min(X_(t+1)).

More generally the same holds for any target Q_(t+1)<=max(X_t), whether or
not it is a retreat of the actual total. If additionally Q_t>C, every later
actual target of size at most C is dominated by both phases: the first
post-retreat pair already exceeds C and the pair is coordinatewise monotone.
Thus a matched slow reference may retreat into a cap, remain there, and later
restart from either phase without adding a day for the fast episode.

The lemma does not initialize an arbitrary first slow event, establish the
physical matching bound before the retreat, or permit arbitrary growing
states above max(X_t). Its new use here is to remove an artificial repeated
fast-reset obligation. The underlying interlacing was already used implicitly
in previous boundary comparisons; this is not presented as a new capture-time
classification or new Lean coverage.

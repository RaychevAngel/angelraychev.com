# Independent review of the ordinary-head six-day interface

24 October 2026. Accepted as a conditional assembly with its stated ranges.
Reviewed source: `upper-ordinary-head-gap-six-interface.md`.

The newly accepted ordinary early theorem supplies the necessary clock for
the actual first crossing, including its overshoot and all preceding retreats.
It therefore replaces the hybrid early clock inside the endpoint minimum;
one must recompute that minimum, not merely change an old optimizing pair.

The exact inversion used for the head spread is correct: G(x)>=m iff
x+k>=m+R(m). Global interlacing gives max A<=G(min A), and m>=Q>(b-1)^2
then gives spread<=k-b=d. This genuinely satisfies the shifted-pronic
middle's input contract while keeping the physical phase labels. The late
comparison remains same-phase and costs one update, so the full gate clock
costs two middle updates plus one late update, with no early surcharge.

In the older H6=(b-6)^2 large-excess range, all early endpoints are also
inside the new theorem's domain. Indeed a first crossing has

    Q <= H6-1+k <= b^2-9b+34 <= b(b-1)   (b>=32,k<3b).

Here the accepted middle conclusion controls both output coordinates, so
it needs only max A>=Q and imposes no head-spread or phase-choice premise.
The arbitrary terminal gate audit already covers these budgets k>=50.

The relation J_half in{J,J+1} is preserved: the replacement early clock and
the endpoint domain are independent of the terminal seed, while the old
late clocks retain the exact seed-zero/seed-k one-step relation and monotonic
interpolation. Taking endpoint minima respects both inequalities.

The final conversion is arithmetically correct. With J=J_new(k),
J_half=J_new(floor(k/2)), the physical upper bounds and necessary cuts give

    U <= min(2J+8, 2J_half+7),
    L >= max(2J+1, 2J_half).

The two possible values of J_half yield U-L<=6. This is uniform in length
and in the stated unbounded width/budget families. It does not improve the
old finite-width certificate by itself. The source correctly leaves that
remaining coverage visible and does not claim a global six-day ceiling.

This review does not prove the separate ordinary late theorem or physical
first-quota/terminal-gate adjunction; neither is needed for this conditional
six-day assembly because its late hybrid comparison is retained.

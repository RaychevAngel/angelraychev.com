# A uniform phase-gap ledger across square and pronic walls

24 October 2026. New ordinary lemma for independent review. It is a statement
about genuine interlaced scalar orbits, not a new physical necessity theorem,
and has no new Lean coverage.

Let A and B be nondecreasing integer-valued functions, with

    0 <= B(z)-A(z) <= 1.

Integer jumps may be regarded as labelled unit walls; coincident A and B
walls are counted separately. Consider an orbit

    x_(t+1)=y_t+k-A(y_t),
    y_(t+1)=x_t+k-B(x_t)

that is globally interlaced:

    min(x_(t+1),y_(t+1)) >= max(x_t,y_t).

Write M_t=max(x_t,y_t), delta_t=x_t-y_t, epsilon(z)=B(z)-A(z), and

    I_t = A(x_t)-A(y_t), if x_t>=y_t;
          B(y_t)-B(x_t), if x_t<y_t.

Thus I_t counts only the walls currently straddled in the phase that can
affect the next update. For any u<=v,

    | |delta_v|-|delta_u| |
       <= B(M_v)-B(M_u) + I_u + epsilon(M_u).       (1)

In particular this controls a DECREASE of the phase gap as well as an
increase. The number of steps, the inspected budget and the distance between
the two endpoints do not appear separately in the bound.

## Exact signed identity

Set epsilon_t=epsilon(M_t) and

    a_t=(-1)^t (2 delta_t-epsilon_t).

Define

    eta_t = A(x_t)-A(y_t), if x_t>=y_t;
            -(B(y_t)-B(x_t)), if x_t<y_t.

Direct substitution gives

    delta_(t+1)=-delta_t+epsilon_t+eta_t,
    a_(t+1)-a_t=(-1)^t(epsilon_(t+1)-epsilon_t-2eta_t). (2)

We claim the sharper signed bound

    |a_v-a_u|
      <= A(M_v)-A(M_u)+B(M_v)-B(M_u)+2I_u.         (3)

To prove it, sum (2) wall by wall. A B-wall increases epsilon by one
when M first crosses it; an A-wall decreases epsilon by one. The resulting
contribution to a is therefore +1 or -1. If the two coordinates straddle
that wall after the crossing, interlacing resolves the straddle in the very
next state. There cannot be a later straddle of the same wall.

For a B-wall crossed between times t and t+1, the first contribution is
(-1)^t. If y_(t+1) is the larger coordinate and x_(t+1) is still below the
wall, eta_(t+1) includes -1, and its additional contribution is
-2(-1)^t. Their total is -(-1)^t. In every other case there is no
additional contribution. Thus this wall contributes exactly +1 or -1
over a completed crossing, or just its first +1/-1 at an unfinished endpoint.

For an A-wall the first contribution is -(-1)^t. A straddle with x_(t+1)
larger contributes +2(-1)^t in the following update. Again the total is
exactly +1 or -1. Multiple walls crossed in one update are handled by
linearity, including coincident A and B walls.

The walls already straddled at time u have their first crossing before the
summation starts. Only their possible correction remains, of size two each;
there are precisely I_u such relevant walls. Every other contributing wall
is crossed by M in (M_u,M_v], of which there are

    N=A(M_v)-A(M_u)+B(M_v)-B(M_u).

This proves (3). In particular no assertion that a step crosses at most one
wall is needed.

## From the signed ledger to the ordinary span

For epsilon in{0,1},

    | |2delta-epsilon|-2|delta| | <= epsilon.

Consequently (3) gives

    2 | |delta_v|-|delta_u| |
       <= N+2I_u+epsilon_u+epsilon_v.

But A=B-epsilon, so

    N=2(B(M_v)-B(M_u))+epsilon_u-epsilon_v.

Cancellation yields exactly (1).

## The ordinary and capped princess maps

For the ordinary late pair use

    A(z)=rho(z), B(z)=ceil(sqrt(z)).

If r=ceil(sqrt(M_u)) and s=ceil(sqrt(M_v)), (1) becomes

    |span_v-span_u| <= s-r+I_u+epsilon(M_u).       (4)

For the capped odd-width late pair use

    A(z)=min(rho(z),b), B(z)=min(ceil(sqrt(z)),b+1).

The same proof applies unchanged: the caps simply remove all later walls
of their respective type. For the capped forward pair, replace both
coordinates by x+k and y+k. Its recurrence is then exactly the displayed
late-form recurrence with these same capped A and B functions. Gaps and
global interlacing are preserved by that fixed translation.
The even-width version, with both caps equal to b, also satisfies the same
hypotheses and therefore the same exact ledger.

If an initial ordinary pair has maximum root r>=3 and span<=r-2, it
straddles at most one square/pronic wall. Indeed consecutive wall positions
in its possible interval are separated by at least r-1. Hence I_u<=1,
and the convenient root-to-root consequence is

    |span_v-span_u| <= s-r+2.                       (5)

If the initial pair straddles no relevant wall, the sharper allowance is
I_u=0; if additionally epsilon(M_u)=0, the allowance is exactly s-r.
The explicit form (1) should be retained when an application has these
stronger endpoint data.

## Application boundary

This lemma supplies the previously missing quantitative statement that a
genuine phase gap cannot drop by more than one room per crossed root, apart
from the explicit initial endpoint term. It does not itself prove a new
capture-time bound. A physical core/activation argument must still connect
the relevant two times and use its original defect, quota and phase labels.

# Pronic middle comparison with the genuine ordinary head

24 October 2026. Conditional middle lemma submitted for independent review.
This removes a width threshold from the middle algebra, not from the separate
late physical boundary necessity theorem.

Let b>=32, 1<=d<=b-1, k=b+d, w<=n, wn even, b=floor(w/2), h=wn/2,
H=b(b-1), and choose

    H-d+1<=Q<=H, H+1<=Y<=H+d+1.

Let tau be the ordinary necessary middle clock from equal seed Y to maximum
M=h-Q (or any larger accepted necessary clock). Let C be a physical backward
pair with max C>=Y and Phi(C)>=C. Let A be a genuine ordinary early pair from
zero with max A>=Q. Then

    max_p[Phi^(tau+2)(C)[p]+A[p xor chi]]>=h,
    chi=(w+n-2) mod2.                                  (1)

At even width the stronger tau+1 conclusion holds. No finite residue
certificate is needed in this true-head formulation.

## Common guards and the ordinary head's spread

The accepted asymmetric-pronic algebra uses only

    Y<=H+d+1<=b², Q>=H-d+1>(b-1)²,
    E-L>=2b+1>d in odd width,

where E=h-b² and L=b(b+1). These hold in the stated range. Q+Y<h also
holds at both minimal board areas. Thus the unshifted inverse-cost substitutions
and first-hit terminal argument of
`../overnight-uniform-2026-10-24/comparison-asymmetric-pronic-middle.md`
remain valid; they do not use b>=200 beyond these guards.

Global ordinary interlacing gives max A<=G(min A), where
G(x)=x+k-rho(x+k). If max A=m, inversion yields min A+k>=m+R(m).
Since m>=Q>(b-1)², its root is at least b, and therefore

    max A-min A<=d.                                   (2)

The progress of C and inflationarity of the physical scalar maps imply
Phi(C)>=(Y,Y). This spends one alignment update and allows comparison with
the equal physical pair thereafter.

## Even width and odd d>=2

The accepted asymmetric equal-seed calculation has the following conclusions:
for even width both physical phases reach M by the ordinary first-hit clock;
for odd width their minimum is at least M-1. In odd width the sole possible
central improvement is excluded by E-L>d, while the high-pronic edge beyond
h-H can affect only a step already reaching the target.

For even width, alignment plus this comparison gives tau+1 immediately.
For odd d>=2, one additional lower-physical update increases every coordinate
by at least d-1>=1 until clipping (which already wins). Hence at tau+2 both
coordinates reach M, proving(1) using whichever head coordinate reaches Q.

## Odd d=1: retain the head's actual one-room spread

Here Q=H, and M=h-H. The equal physical comparator, after its low passage,
follows the constant central map

    (x,y) -> (y+1,x).

At its first-hit time the maximum is at least M and its spread is at most1.
Thus it dominates either (M,M-1) or (M-1,M). Both inputs exceed b², since
M>=b²+4b+1; the following lower-physical update is still the displayed map.
It sends these two worst possibilities to

    (M,M), or (M+1,M-1), respectively.

The first meets a head coordinate>=H. The second also meets, because(2)
gives EVERY head coordinate>=H-1. This argument works for either compatible
phase pairing; it introduces no artificial head-phase choice. Physical
high-boundary acceleration can only improve the lower-physical outputs.
Together with the initial alignment, this is exactly tau+2.

Finally Phi(C)>=C makes its physical orbit coordinatewise nondecreasing,
so a larger accepted necessary middle clock preserves the conclusion.

## What this does not prove

The separate late pronic necessity theorem still has its own geometric and
arithmetic parameter guards. Extending the middle to b>=32 does not silently
extend that late theorem, update the finite-width panel, or establish a new
whole-domain six-day ceiling. This is a shorter structural middle contract
for use wherever the boundary hypotheses have been physically justified.

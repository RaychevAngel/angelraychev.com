# Comparison lane checkpoint at the requested wrap-up

24 October2026. New mathematical searches are stopped. No public artifacts
or Lean sources were changed by this lane.

## Accepted new result

`comparison-phase-wall-variation.md` proves a uniform ledger for an interlaced
pair x'=y+k-A(y), y'=x+k-B(x), where A,B are nondecreasing and0<=B-A<=1.
If M=max(x,y), the absolute phase gap changes by at most

    B(M_v)-B(M_u)+I_u+(B-A)(M_u),

where I_u counts the relevant walls initially straddled. The proof controls
both loss and growth, counts coincident/multiple walls separately, and
handles incomplete terminal crossings. Ordinary, capped odd/even, and
translated early maps are included. It is independently accepted in
`root-phase-wall-variation-review.json` and
`upper-phase-wall-variation-review.json`.

This is a new general proof tool. It does not by itself change the certified
capture-time gap. Upper is using it to improve the localized-front overlap
argument; that application remains a separate dependency.

## Candidate uniform middle comparison: completed discovery, not accepted

Let w=2b+1, n be even with n>=w, b>=32, k=b+d,
2<=d<=b-3. Put L=(b-1)^2, A=L-d. Start at the first ordinary late horizon
where its maximum reaches L, preserving the signed pair C. Use the accepted
12-threshold localization recurrence and exact-capacity late markers.
The proposed conclusion is

    max B_t <= max X_t

while max X_t<h-A, where X is the physical prefix backward pair from C.
Consequently one further physical update would dominate every clipped
threshold min(B_t,h-A), since genuine physical pairs are interlaced.
This would supply an all-width, all-length one-day middle comparison in
the stated budget range. It is NOT yet an accepted theorem or a new
whole-game capture bound.

The finite symbolic discovery is
`comparison_parametric_interlaced_closure.py/.json`:

* 900 discovered profiles;751 nondominated profiles.
* 850 processed states; no pending states; no solver-unknown results.
* Every discovered threshold offset lies between-2 and0 relative to
  physical maximum; only12 distinct offset patterns occur.
* b,d and the area remainder J=h-2b^2 are symbolic integers, constrained
  by b>=32,2<=d<=b-3,J>=3b+1. There is no width or length panel.
* Runtime42.6CPU seconds. The computation is a completed discovery run,
  not an independent proof replay.

The state retains both physical root intervals, signed phase-gap bucket,
and an affine interval for the initial phase gap. Retaining the SMALLER
physical coordinate's root interval is essential: the earlier abstraction
permitted a coordinate to recross a root wall after it should have cleared
it. That produced fake one-day failures. Literal replay of the proposed
b32,d2 seed did not fail; the repaired symbolic relation closes.

## Dependencies and remaining verification

The expanded cost table was checked by exact polynomial inequalities in
`comparison_general_critical_cost_certificate.py/.json`. It extends the
accepted final rank interval to h-L+b-2 and adds the physical lagging-input
interval above(b-2)^2. Its396 primitive entries and24 physical entries pass.
The original accepted table, operator, and review receipts were preserved.

Before promoting the candidate:

1. Independently replay the inductive relation, preferably with a separate
   encoding. Verify every seed is included, every admitted transition enters
   a dominating recorded state, and the exact source-region constraints.
2. Check the genuine entrance box max C in[L,L+d+1], span<=d+2,
   interlacing, and marker applicability until Z=L+k=H+d+1.
3. Check the outer primitive ranges for every reached source/target and
   lagging physical input. No extrapolation beyond the expanded polynomial
   table is authorized.
4. Check the stopping rule: the search retains states with max X<h-A.
   At and after the first max X>=h-A, one next physical update already
   dominates h-A by interlacing. This must be explicit in the proof.
5. Reuse the accepted physical normalization/head-marker/gate assembly only
   after the comparison is accepted. Budgets d=b-2,b-1 are outside this
   candidate; do not silently combine them into its scope.

The discoverer rejects solver unknown, records incomplete timeout states,
and treats1000000 as an infinity serialization sentinel only. It uses
componentwise dominance only within identical physical state domains.
Those implementation choices also need independent review.

## Superseded exploratory files

`comparison_parametric_closure.py`, `_v2.py`,
`comparison_parametric_trace.py`, and the older signed-history probes remain
as failed/incomplete attempts. They are not certificates. The d2-only repaired
`comparison_parametric_interlaced_trace.py/.json` closes237 nondominated
states, but the general discovery above is the useful restart target.

No new classification or numerical closed form is claimed. The parent owns
the authoritative combined theorem coverage and the retained all-parameter
fallback.

// Exact scalar-root-wall acceleration of the zero-origin phase orbit.
// Diagnostics challenge conjectures; finite runs are not a uniform proof.
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <iostream>
#include <string>
#include <vector>
using I=long long;
I root(I x){if(!x)return 0;I r=sqrtl((long double)x);while(r*r<x)++r;while((r-1)*(r-1)>=x)--r;return r;}
I rho(I x){I r=(sqrtl(4.0L*x+1)-1)/2;while(r*(r+1)<x)++r;while(r&&(r-1)*r>=x)--r;return r;}
struct Ans{I k,gap=0,t=0,x=0,y=0,steps=0,cells=0;};
void record(Ans&a,I x,I y,I t){I d=std::abs(x-y);if(d>a.gap){a.gap=d;a.t=t;a.x=x;a.y=y;}}
Ans jump(I k){Ans a{k};I x=0,y=0,t=0;const I INF=1LL<<60;
 for(;;){record(a,x,y,t);I r=root(x+k),s=rho(y+k),r2=rho(x+2*k-r),s2=root(y+2*k-s);
  I vx=2*k-r-r2,vy=2*k-s-s2;
  I ux=std::min(r*r-k,r2*(r2+1)-2*k+r),uy=std::min(s*(s+1)-k,s2*s2-2*k+s);
  if(vx<0||vy<0||ux<x||uy<y){std::cerr<<"bad cell\n";exit(2);}
  if(vx==0&&vy==0){record(a,y+k-s,x+k-r,t+1);break;}
  I m=std::min(vx?(ux-x)/vx+1:INF,vy?(uy-y)/vy+1:INF);
  record(a,y+k-s,x+k-r,t+1);
  record(a,y+(m-1)*vy+k-s,x+(m-1)*vx+k-r,t+2*m-1);
  x+=m*vx;y+=m*vy;t+=2*m;++a.cells;
 }
 a.steps=t;return a;}
Ans literal(I k){Ans a{k};I x=0,y=0,t=0;for(;;){record(a,x,y,t);I xx=y+k-rho(y+k),yy=x+k-root(x+k);if(xx==x&&yy==y)break;x=xx;y=yy;++t;}a.steps=t;return a;}
int main(int argc,char**argv){
 for(int k=2;k<=500;++k){auto a=jump(k),b=literal(k);if(a.gap!=b.gap||a.t!=b.t||a.x!=b.x||a.y!=b.y){std::cerr<<"Mismatch "<<k<<"\n";return 3;}}
 for(int j=1;j<argc;++j){I k=std::stoll(argv[j]);auto a=jump(k);std::cout<<"{\"k\":"<<k<<",\"gap\":"<<a.gap<<",\"ratio\":"<<(double)a.gap*a.gap/k<<",\"t\":"<<a.t<<",\"x\":"<<a.x<<",\"y\":"<<a.y<<",\"steps\":"<<a.steps<<",\"cells\":"<<a.cells<<"}\n";}
}

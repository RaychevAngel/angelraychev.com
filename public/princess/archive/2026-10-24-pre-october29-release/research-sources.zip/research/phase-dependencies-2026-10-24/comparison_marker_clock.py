"""Research evaluator retaining the ordinary head's exact corner-marker faces.

Conditional on the subcritical marker corollary and ordinary signed-late
necessity. Not an exact game evaluator or a uniform zero-gap assertion.
"""
from pathlib import Path
from math import isqrt
from functools import lru_cache
import importlib.util,json,time,argparse
P=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('marker_band9',P.parent/'uniform-gap-2026-10-23/lower-band9.py')
band=importlib.util.module_from_spec(sp);sp.loader.exec_module(band)
def R(x):return isqrt(x-1)+1 if x else 0
def rho(x):
 r=(isqrt(4*x+1)-1)//2
 return r+(r*(r+1)<x)
def early_step(x,k):return(x[1]+k-rho(x[1]+k),x[0]+k-R(x[0]+k))
def late_step(x,k):return(k+x[1]-rho(x[1]),k+x[0]-R(x[0]))
def head_faces(w,k,markers=True):
 b=w//2;d=k-b;L=(b-1)**2;A=L-d
 assert b>=5 and 1<=d<L and A>0
 x=(0,0);e=0;heads=[]
 while True:
  if max(x)>=A:
   faces={f:min(L,max(min(x),x[0] if f[0]<=1 else 0,x[1] if f[1]<=1 else 0) if markers else max(x)) for f in band.FEATURES}
   # Faces below A cannot realize the first crossing in this time state.
   faces={f:q for f,q in faces.items() if q>=A}
   heads.append((e,x,faces))
  if min(x)>=L:break
  x=early_step(x,k);e+=1
 return A,L,heads
def evaluate(w,n,k,c,markers=True,late_clamp=True,late_markers=False):
 b=w//2;h=w*n//2;A,L,heads=head_faces(w,k,markers)
 Zcap=min((b-1)**2+k,b*b+1)
 V=(c,c);B={f:min(c,h-4+sum(f)) for f in band.FEATURES}
 remaining=list(range(len(heads)));wins=[];t=0;clamped=0
 while remaining:
  if late_clamp and max(V)<Zcap:
   clamped+=int(any(z>max(V) for z in B.values()))
   caps={f:max(V)-int(late_markers and max(V)-k>=10 and ((V[0]>V[1] and f[0]==0) or (V[1]>V[0] and f[1]==0))) for f in B}
   B={f:min(z,caps[f]) for f,z in B.items()}
  nxt=[]
  for i in remaining:
   e,x,faces=heads[i]
   matches=[f for f,q in faces.items() if q+B[f]>=h]
   if matches:wins.append(dict(head_time=e,head_pair=x,back_time=t,total=e+t,features=matches,back_frontier=[B[f] for f in band.FEATURES]))
   else:nxt.append(i)
  remaining=nxt
  if not remaining:break
  B=band.step(w,n,k,B);V=late_step(V,k);t+=1
  assert t<10000000
 return dict(w=w,n=n,k=k,c=c,A=A,L=L,head_states=len(heads),gate_lower=min(a['total']for a in wins),ordinary_late_clamp_steps=clamped,winners=wins)
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('w',type=int);ap.add_argument('n',type=int);ap.add_argument('k',type=int);a=ap.parse_args();start=time.process_time()
 rows=[evaluate(a.w,a.n,a.k,c)for c in(a.k,a.k//2)]
 out=dict(status='conditional research diagnostic; physical marker proof separate',rows=rows,lower=max(2*rows[0]['gate_lower']+1,2*rows[1]['gate_lower']),CPU_seconds=time.process_time()-start)
 print(json.dumps(out,indent=2))

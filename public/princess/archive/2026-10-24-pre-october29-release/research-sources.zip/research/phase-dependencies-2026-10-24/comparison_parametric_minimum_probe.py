"""Challenge the general-excess one-day minimum relation by SMT abstraction.

Diagnostic only: the abstraction forgets within-band arrival position, so
any reported path must be checked before treating it as a real obstruction.
"""
from comparison_parametric_relation_probe import *

def go_min(seconds=60):
 st=time.process_time();states=[];seen=set();todo=[];parents={}
 for phase in range(-3,4):
  pat=tuple(-int((phase>0 and f[0]==0)or(phase<0 and f[1]==0))for f in F)
  pat+=tuple(pat[F.index(f)]for f in[(1,0),(0,1),(0,1)])
  for r in range(4):
   state=(pat,r,phase);states.append(state);seen.add(state);todo.append(state);parents[state]=None
 base=[b>=32,d>=2,d<=b-3,J>=3*b+1,q>=-2*b+1,q<J+2*b-1+d]
 checked=0;counter=None
 while todo and time.process_time()-st<seconds:
  pat,r,phase=todo.pop(0)
  for marked in(True,False):
   pp=tuple(min(v,-int((phase>0 and f[0]==0)or(phase<0 and f[1]==0)))for v,f in zip(pat,F+[(1,0),(0,1),(0,1)]))if marked else pat
   out,qn,dn,prog=transition(pp);s=z.Solver();s.set(timeout=2000)
   s.add(*base,reg(q)==r,phase_bounds(delta,phase),*prog,qn<J+2*b-1+d)
   s.add(q<-b+d+1 if marked else q>=-b+d+1)
   # Exact next physical minimum relative to current maximum.
   next_min=qn-q-z.If(dn>=0,dn,-dn)
   clipped=z.If(max(pp[:9])+q<J+2*b-1+d,max(pp[:9]),J+2*b-1+d-q)
   s.push();s.add(q+max(pp[:9])>=J+2*b-1,clipped>next_min)
   if s.check()==z.sat:
    md=s.model();counter=dict(status='abstract terminal minimum relation false',state=(pat,r,phase),parameters={str(v):md.eval(v).as_long()for v in[b,d,J,q,delta]},clipped=md.eval(clipped).as_long(),next_min=md.eval(next_min).as_long());break
   s.pop()
   while True:
    result=s.check()
    if result==z.unknown:counter={'status':'solver timeout','state':(pat,r,phase)};break
    if result==z.unsat:break
    md=s.model();op=tuple(md.eval(v).as_long()for v in out);rn=md.eval(reg(qn)).as_long();pn=md.eval(bucket(dn)).as_long()
    if max(op)>8 or min(op)<-12:counter=dict(status='abstract offset escaped',state=(pat,r,phase),output=(op,rn,pn));break
    new=(op,rn,pn)
    if new not in seen:seen.add(new);states.append(new);todo.append(new);parents[new]=(pat,r,phase)
    s.add(z.Not(z.And(*[a==v for a,v in zip(out,op)],reg(qn)==rn,bucket(dn)==pn)))
   if counter:break
  checked+=1
  if counter:break
 if counter and 'state'in counter:
  cur=counter['state'];trace=[]
  while cur is not None:trace.append(cur);cur=parents.get(cur)
  counter['trace']=list(reversed(trace))
 result=dict(status='closure'if not todo and not counter else'incomplete abstraction challenge',states=len(states),checked=checked,pending=len(todo),counter=counter,CPU_seconds=time.process_time()-st)
 with open(__file__.replace('.py','.json'),'w')as f:json.dump(result,f,indent=2)
 print(json.dumps(result,indent=2))
if __name__=='__main__':go_min()

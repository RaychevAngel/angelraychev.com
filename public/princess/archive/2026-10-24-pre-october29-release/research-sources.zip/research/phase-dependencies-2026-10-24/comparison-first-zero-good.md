# Exact initialization at the first zero-slack good event

24 October 2026. Ordinary lemma proposed for independent review. This extends
the accepted first-sensitive initialization to both corner phases, including
the dominant triangle-plus-singleton equality case.

Let an even-area rectangle have w<=n, b=floor(w/2), k>=max(13,b+1), and
H=b(b-1). Consider an actual full-origin history through time t with total
holes Q_s<=H for all0<=s<=t. Let sigma_s be its ORIGINAL total survivor
surplus and r_s=ceil(sqrt(Q_s)). Call an event zero-good when

    4<=r_s<=b-1, sigma_s=r_s.

Suppose t is the FIRST zero-good event. Its accepted dominant corner and
phase p determine an exact TOTAL profile, including any permitted singleton
outlier. Then its matching ordinary zero-origin phase satisfies

    Q_t <= P_t[p],
    P_0=(0,0), P_(s+1)=(G(P_s[1]),F(P_s[0])).             (1)

Here F(x)=x+k-ceil(sqrt(x+k)), G(x)=x+k-rho(x+k).

## Proof

Put f_0=0 and f_(s+1)=F(f_s). Both ordinary coordinates dominate f_s by
monotonicity and G>=F. Also f_s is nondecreasing, and

    f_1=k-ceil(sqrt(k))>=9                           (k>=13).

We show Q_s<=f_s for s<t. A target with r_s<=3 has Q_s<=9<=f_s for s>=1,
regardless of its surplus or previous state. A target with4<=r_s<b is
not zero-good; the accepted small/co-small exclusion gives sigma_s>=r_s,
so integrality forces sigma_s>=r_s+1>=1+rho(Q_s). The exact F inverse
therefore gives Q_s<=F(Q_(s-1))<=f_s. Finally, if r_s=b, the hypothesis
Q_s<=b(b-1) gives1+rho(Q_s)<=b<=sigma_s, so the same F argument applies.
These cases exhaust the prehistory; Q_0=f_0=0 handles the initial endpoint.

At t, the accepted zero-slack dominant-component theorem gives the TOTAL
own-corner bound Q_t<=r_t² if p0, and TOTAL opposite-corner bound
Q_t<=r_t(r_t-1) if p1. The original budget relation is
Q_(t-1)+k>=Q_t+r_t. Inverting the relevant profile gives respectively

    Q_t<=G(Q_(t-1))  or  Q_t<=F(Q_(t-1)).

Since Q_(t-1)<=f_(t-1)<=min(P_(t-1)), these are exactly(1).
No backwards-cone, independence of outliers, or assumed earlier anchor is
used. The outlier issue is handled by the already proved TOTAL phase profile.

## Boundary and use

This theorem initializes the first zero-good reference at its actual elapsed
index, without a free phase reset. It does NOT by itself track later changes
of corner convention. The plateau counterfamily in
comparison-sensitive-plateau-obstruction.md shows why intermediate zero-good
labels must be retained; the first-sensitive proof alone discarded them.

The stay-below-H condition is essential as stated. A previous excursion above
H or a change to a broader slack-good definition needs its own argument.
Cases k<13 have not been claimed here. The lemma is an ordinary proof, not
new Lean coverage or a new complete capture-time classification.

# A head capacity retaining the age of the last actual corner core

24 October2026. Necessary full-origin history envelope for independent review.
It retains a physical core after the two ordinary numerical phases have
caught up. It is an evaluator/constraint, not an optimality assertion.

Let wn be even, w<=n, b=floor(w/2), k>=max(13,b+1), and
L=(b-1)^2. Consider a full-origin hole history with every count through
time t at most L. Let P_u be the genuine zero-origin ordinary pair.
A zero-good event has root4<=r<=b-1 and ORIGINAL surplus exactly r.
All such events have the actual cores in
`upper-zero-good-core-persistence.md`.

For each root r and size (r-1)^2<q<=r^2 the permissible raw core types are:

* own, no outlier: radius R=2r-2-2m(r^2-q), phase p=0;
* opposite, no outlier: q<=r(r-1), radius
  R=2r-3-2m(r(r-1)-q), phase p=1;
* own singleton exception: q=(r-1)^2+1, radius R=2r-4, phase p=0.

Here m(z)=max{j:j(j+1)/2<=z}. The first type may be retained even at the
singleton size: allowing both only weakens the envelope. A type is
admissible at time u only if q<=P_u[p]. Its radius belongs to its ACTUAL
dominant cohort/corner, and is not inferred from the numerical upper bound.

Write B(x)=x+k-1-rho(x+k-1). Define

  C_00(t) = max( B^t(0),
    B^(t-u)(q) over all 1<=u<=t, roots/types above,
                         q<=P_u[p], t-u>=R+1 ).           (1)

The maximum is over a finite explicitly defined set; an empty inner set
is ignored. Then a head whose merged remaining-support features are
(c,e)=(2,2) satisfies

  Q_t<=min(L,C_00(t)).                                   (2)

The subscript00 refers to absent HOLE markers; (2,2) are the remaining
SUPPORT features. This distinction prevents reversing the filter.

## Proof

If there is no zero-good event, all non-tiny targets obey B. Tiny targets
have Q<=9<=B(0) for k>=13. The B orbit is nondecreasing from0 and bounds
all these targets inductively, proving the first alternative in(1).

Otherwise take the LAST actual zero-good time u. Its size q, phase p,
and actual radius R satisfy one listed type and the accepted matching
ordinary inequality q<=P_u[p]. After u there are no further zero-good
events, and no critical-root events because all counts are <=L. Every
non-tiny target therefore obeys B. Tiny targets are at most9<q; the B
orbit from q is nondecreasing since q<=L<=(k-2)^2, B's first fixed point.
Consequently Q_t<=B^(t-u)(q), even when the actual history retreats.

Erosion persistence leaves the entire corner core of radius R-(t-u)
in the actual holes at time t whenever that radius is nonnegative.
Its parity is automatically the current cohort parity. A nonempty core
contains its own corner in own phase, or both adjacent cells of its
opposite corner in opposite phase. The former forces the merged support
corner count c<=1; the latter forces its eroded-corner count e<=1.
Thus (c,e)=(2,2) requires R-(t-u)<0, or t-u>=R+1. This supplies exactly
the second alternative in(1), proving(2).

If A=L-(k-b)>=1, the conclusion also holds at a FIRST crossing of A, because
G_k(A-1)=L gives the required overshoot guard. No history after that
crossing is assumed to obey the small-root restriction.

## Feature-dependent version

For a proposed target feature f=(c,e), retain a last-good candidate if
its core has disappeared, or if its forced marker is compatible with f:

  t-u>=R+1, or
  (p+(t-u)) mod2=0 and c<=1, or
  (p+(t-u)) mod2=1 and e<=1.                           (3)

Use this candidate filter in(1). The resulting capacity is necessary for
that particular target feature. Current phase is relative to the SAME
actual corner; no choice of a fresh corner is made at the target. The
no-good alternative remains unrestricted. Individual maxima may come
from different histories, which is a safe relaxation.

## Scope and limitation

This is a uniform history constraint over all widths, lengths and feasible
budgets in the stated range. It neither assumes physical prefix optimality
nor reconstructs an attaining strategy. Its direct finite evaluation may
be accelerated by root/defect bins, but such acceleration must preserve
the size dependence of R and the matching phase bound at time u.

"""Root-bin evaluation of the accepted last-good/core-age head envelope.

The inverse defect calculation is exact; no rectangle optimality is assumed.
"""
import comparison_marker_clock as m
from functools import lru_cache

class CoreEnvelope:
 def __init__(self,b,k,max_time):
  assert b>=32 and b<k<2*b
  self.b,self.k,self.L=b,k,(b-1)**2
  self.P=[(0,0)]
  for _ in range(max_time):self.P.append(m.early_step(self.P[-1],k))
  fixed=(k-2)**2
  self.maps=[[q+k-1-m.rho(q+k-1)for q in range(fixed+1)]]
  for _ in range(max_time.bit_length()):
   a=self.maps[-1];self.maps.append([a[a[q]]for q in range(fixed+1)])
 @lru_cache(None)
 def iterate(self,q,d):
  j=0
  while d:
   if d&1:q=self.maps[j][q]
   j+=1;d>>=1
  return q
 @lru_cache(None)
 def bestgood(self,limit,p,age,compatible):
  # Enumerate roots, not sizes. Every inverse cap stays in its genuine root.
  best=-1
  for r in range(4,min(self.b-1,m.R(limit))+1):
   lower=(r-1)**2+1
   need=0 if compatible else max(0,(2*r-1-p-age+1)//2)
   cap=min(limit,r*(r-p)-need*(need+1)//2)
   if cap>=lower:best=max(best,cap)
   if p==0 and limit>=lower and (compatible or age>=2*r-3):
    best=max(best,lower) # accepted singleton-outlier radius2r-4
  return best
 def capacities(self,t):
  # Four marker faces suffice: c<=1/e<=1 or c=e=2.
  ans={key:self.iterate(0,t)for key in((0,0),(0,1),(1,0),(1,1))}
  for u in range(1,t+1):
   age=t-u
   for p in range(2):
    limit=min(self.L,self.P[u][p])
    if limit<10:continue
    current=(p+age)%2
    free=self.bestgood(limit,p,age,True)
    aged=self.bestgood(limit,p,age,False)
    for key in ans:
     q=free if key[current] else aged
     if q>=0:ans[key]=max(ans[key],self.iterate(q,age))
  return {f:min(self.L,ans[(int(f[0]<=1),int(f[1]<=1))])for f in m.band.FEATURES}


"""Literal finite audit of an exact identity, not evidence of optimality."""
from pathlib import Path
from random import Random
import hashlib,json

rng=Random(20261024)

def run():
    steps=histories=shared=forks=nonzero=0
    for w,n in [(2,3),(4,4),(5,6),(8,10)]:
        cells=[(x,y)for x in range(w)for y in range(n)]
        colors=[{v for v in cells if sum(v)%2==p}for p in(0,1)]
        adj={v:{u for u in cells if abs(u[0]-v[0])+abs(u[1]-v[1])==1}for v in cells}
        def N(S):return set().union(*(adj[v]for v in S)) if S else set()
        for _ in range(150):
            T=rng.randrange(2,15);H=[set()];I=[];phase=rng.randrange(2)
            for t in range(T):
                available=sorted(colors[(phase+t)%2]-H[-1])
                count=rng.randrange(len(available)+1)
                shot=set(rng.sample(available,count));I.append(shot)
                full=H[-1]|shot
                H.append({v for v in colors[(phase+t+1)%2] if adj[v]<=full})
            A=[set()for _ in H];B=[set()for _ in H]
            for v in H[-1]:
                z=rng.randrange(3)
                if z==0:A[-1].add(v)
                elif z==1:B[-1].add(v)
            for s in range(T-1,-1,-1):
                A[s]=N(A[s+1])-I[s];B[s]=N(B[s+1])-I[s]
                assert A[s]<=H[s] and B[s]<=H[s]
            assert not(A[0]or B[0]) and not(A[-1]&B[-1])
            lhs=rhs=0
            for s in range(T):
                aa,bb=A[s+1],B[s+1];v=aa&bb
                na,nb=N(aa),N(bb);nv=N(v);W=(na&nb)-nv
                pc=len(I[s]&na&nb);sig=len(nv)-len(v)
                assert sig>=0
                assert pc==len(v)-len(A[s]&B[s])+sig+len(W)
                assert len(na)-len(aa)+len(nb)-len(bb)-(len(N(aa|bb))-len(aa|bb))-sig==len(W)
                lhs+=pc;rhs+=sig+len(W);steps+=1;forks+=len(W)
            assert lhs==rhs
            shared+=lhs;nonzero+=lhs>0;histories+=1
    return dict(histories=histories,steps=steps,total_shared_shots=shared,
                total_fork_cells=forks,histories_with_shared_quota=nonzero)

if __name__=='__main__':
    p=Path(__file__);proof=p.with_name('lower-causal-overlap-ledger.md')
    out=dict(status='EXACT_IDENTITY_AUDIT_PASS',**run(),
             hashes={q.name:hashlib.sha256(q.read_bytes()).hexdigest()for q in(p,proof)})
    p.with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))

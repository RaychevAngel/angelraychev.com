# One phase-resolved middle day at every odd minimum budget

24 October 2026. Proposed ordinary theorem with a finite symbolic certificate;
independent review requested. No Lean or physical attainment claim.

Let w=2b+1, n>=w be even, b>=32, k=b+1, h=wn/2, and 0<=c<=k.
Write L=(b-1)^2, H=b(b-1), A=L-1. Let V be the ordinary late pair from
(c,c), and X the finite-board physical backward prefix pair from(c,c),
with the phase convention of `comparison_face_probe.py::physical`.
Let B_t and the three localization thresholds be the accepted twelve-threshold
necessary recurrence in `comparison_localization_flags.py`, intersected with
the ordinary late maximum and its exact-capacity feature restriction.

At every t for which max B_t>=h-L, put

    F_p(t)=max{B_t(a,e): (a,e)_p<=1}, p=0,1;
    M(t)=max B_t.

Then

    min(F_0(t),h-A) <= X_(t+1)[1],
    min(F_1(t),h-A) <= X_(t+1)[0],
    min(M(t),h-A)   <= max X_(t+1).                 (1)

The clipping is essential: this is an entrance comparison for holes between
A and L, not an unrestricted comparison of all partial states.

## 1. Exact entrance box, including the signed phase

Let ell be the first ordinary late time with max V_ell>=L. It exists because
c<=k<L and the ordinary fixed point exceeds L. Before this time the two
finite-board inverse costs equal the ordinary low costs, so X_ell=V_ell=C.
Global interlacing gives min C>=max V_(ell-1).
Since both old coordinates are<L, monotonicity gives max C<=G(L-1)=L+1.
A predecessor below L-2 has G value<L, hence max V_(ell-1)>=L-2.
Thus C lies in [L-2,L+1]^2, has maximum at least L, and satisfies
min(late_step(C))>=max C. Exact substitution gives these TEN offset pairs:

    C-L in {(-2,0),(-1,0),(-1,1),(0,-2),(0,-1),
            (0,0),(0,1),(1,-1),(1,0),(1,1)}.        (2)

This preserves which coordinate is larger; it does not allow an arbitrary
phase swap. At ell, ordinary late equality markers give the necessary seed

    B(a,e)<=max C - [C0>C1 and a=0] - [C1>C0 and e=0].

The auxiliary classes inherit their source-feature ceilings. Here
max C-k>=10 and max C<Z=L+k=H+2, so the marker theorem applies. Continue
these ceilings at every horizon while max V<Z. All three bounds become
irrelevant after that time. Until this stopping horizon X=V.

## 2. The primitive geometry has only eleven rank intervals

After subtracting b from every survivor cost, the complete tuple of
36 costs and pronic/square formation flags is constant on each interval:

    [L-4,L], {L+1}, {L+2}, [L+3,H], [H+1,b^2],
    [b^2+1,b(b+1)], [b(b+1)+1,h-b^2-1],
    [h-b^2,h-H-1], [h-H,h-L-1], {h-L}, [h-L+1,h-L+8].

`comparison_critical_cost_certificate.py` proves all396 primitive entries
and the22 physical-phase costs. It uses interval inversions of the exact
quadratic root formulas. Every required polynomial inequality is certified
by nonnegative coefficients after b=32+B and n=2b+2+2S, with B,S>=0.
This is a symbolic all-parameter check, not interpolation from board sizes.
The representative table is merely the proposed integer table; every entry
is checked against these uniform bounds.

The two static bands and formation flags have exact endpoints. The high
square band first turns on at T=h-L. The high critical pronic band turns
on at T=h-H; for v!=1 it turns off at T=h-L+1. A low pronic formation has
root b-1 below L+1 and root b from L+2 through b^2. The subcritical square
formation persists through H, and the accepted narrow critical square
formation occurs from b^2+1 through b(b+1). These are direct substitutions
in the accepted formation conditions; no newly strengthened critical
square theorem is used here.

The finite source/target size caps are inactive throughout these intervals.
Every removed top survivor still requires its auxiliary localization
threshold, exactly as in the accepted operator. No flag is forgotten.

## 3. Finite states and exact translations across arbitrary band lengths

`comparison_wall_automaton.py` carries all twelve thresholds and both physical
coordinates, including their signed difference. It never replaces them by
an equal seed. The initial three adjacent walls are at L+1,L+2,L+3.
After all14 coordinates pass L+7, the ten initial pairs have only six
possible states relative to L+1.

The subsequent wall clusters are centered at

    H+1, b^2+1, b(b+1)+1, h-b^2, h-H, h-L.

Their separations from the preceding cluster are respectively

    b-1, b, b, h-2b^2-b-1, b, b-1,

and hence are at least31,32,32,64,32,31. The marker-ceiling stop is the
second point of the first cluster; the final cluster also contains h-L+1.

Within a homogeneous band, normalizing all14 coordinates by their common
minimum yields a finite orbit. The certificate records the entire cycle,
its time period and its positive common rank increment. For successive
bands the only(period,increment) pairs are

    (2,3); (1,1) or(2,2); (2,1); (2,1); (2,1); (2,2).

Every cycle is already reached at the incoming state, and its entire block
lies strictly before the next wall even at the smallest allowed separation.
For each incoming state it is therefore enough to check one separation in
each residue class modulo its rank increment. Increasing the separation
by that increment inserts one exact homogeneous cycle: it translates every
threshold AND both physical coordinates by the same amount and takes the
same number of days for both. The remaining wall calculation is identical.
This proves the reduction for every larger separation, independently in
each band. In particular it permits all actual b and n, without requiring
or assuming a relation between their residues.

After each wall all coordinates are at least4 ranks beyond it and at most6
ranks beyond it; the next cluster is therefore separate. Reachable state
counts are6,3,1,1,1,1,2. Every terminal state/time with max B>=h-L is checked
against(1), including both phases and the clipped maximum. Once both
physical coordinates are at least h-A, (1) remains true forever by physical
monotonicity. All fourteen coordinates remain in the certified primitive
rank range; the first transient never falls below L-4 and the final one
never rises above h-L+8.

## 4. Domination and assembly boundary

The seed at ell is a necessary relaxation of every actual terminal-history
state at that horizon. The twelve-threshold update remains necessary from
these ceilings, so the finite calculation applies to every such history.
Equivalently, it dominates the original twelve-threshold frontier. Its
coordinate monotonicity follows from the same minimal-surplus fact used
in the top-exclusion proof: whenever a new top q is removed at T, the raw
capacity at T-1 is at most q-1; increasing a target threshold therefore
cannot reduce its corrected capacity. Increasing an auxiliary threshold
can only restore a previously removed top. Maxima and late intersections
preserve this order.

At earlier horizons t<ell, M(t)<=max V_t<L<h-L, so the entrance condition
cannot hold. Thus the argument covers every t in the statement.

The intended physical use is the accepted head-marker dichotomy at the
first crossing of A: a dangerous own-hole phase requires a<=1; a dangerous
opposite-hole phase requires e<=1; if neither phase is dangerous, both head
phases already suffice. Equation(1) retains exactly that distinction. The
whole-game terminal-quota assembly must still be checked separately; this
note proves the middle comparison, not an unrestricted new classification.

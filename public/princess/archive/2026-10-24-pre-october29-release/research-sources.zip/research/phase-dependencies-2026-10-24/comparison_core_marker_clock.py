"""Forward/backward necessary clock with persistent-core entrance caps."""
import comparison_forward_marker as f
from comparison_core_head import CoreEnvelope
import json,time,argparse

def heads(w,n,k):
 b=w//2;d=k-b;L=(b-1)**2;A=L-d
 assert b>=32 and w<=n and w*n%2==0 and 1<=d<b
 pair=(0,0);u=0
 while pair[0]<L:pair=f.m.early_step(pair,k);u+=1
 horizon=u+2*b-3
 core=CoreEnvelope(b,k,horizon)
 prev={(2,2):0};P=(0,0);e=0;ans=[];signature=None
 while True:
  e+=1;P=f.m.early_step(P,k)
  raw=f.propagate(w,n,k,prev,L)
  caps={z:min(L,max(min(P),P[0]if z[0]<=1 else 0,P[1]if z[1]<=1 else 0))for z in f.F}
  if max(raw.values(),default=0)>=A:
   geometric=core.capacities(e) if e<=horizon else {z:L for z in f.F}
   caps={z:min(q,geometric[z])for z,q in caps.items()}
  raw={z:min(q,caps[z])for z,q in raw.items()}
  cross={z:q for z,q in raw.items()if q>=A}
  sig=tuple(cross.get(z,-1)for z in f.F)
  if cross and sig!=signature:ans.append((e,P,cross));signature=sig
  new={z:max(prev.get(z,-1),min(raw.get(z,-1),A-1))for z in f.F}
  new={z:q for z,q in new.items()if q>=4-sum(z)}
  if new==prev and e>=horizon:break
  prev=new
  assert e<=horizon+L
 return A,L,ans,e

def evaluate(w,n,k):
 hd=heads(w,n,k)
 rows=[f.evaluate(w,n,k,c,hd)for c in(k,k//2)]
 return dict(w=w,n=n,k=k,rows=rows,lower=max(2*rows[0]['gate_lower']+1,2*rows[1]['gate_lower']))

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('w',type=int);p.add_argument('n',type=int);p.add_argument('k',type=int);a=p.parse_args();start=time.process_time()
 out=evaluate(a.w,a.n,a.k);out.update(status='necessary evaluator diagnostic; no uniform exactness claim',CPU_seconds=time.process_time()-start)
 print(json.dumps(out,indent=2))

# Exact central contact has a current or one-step-old full front

24 October2026. Actual-history lemma with explicit target-size guards.
This addresses exact contact, not every dangerous state with a positive
numerical deficit. Independent review requested for this strengthened form.

Use the accepted odd-width capped continuation, under its natural guard
b>=4d+8, k=b+d. Let P denote either the zero-origin capped pair or a
genuine seeded capped pair with its corresponding accepted actual history.
Suppose Q_j<U through time t and

    Q_t=max P_t>min P_t.

Then the following actual full-front conclusions hold:

* if phase0 is the unique numerical maximum and Q_t>b^2, the CURRENT
  actual holes are a critical full-span good frontier;
* if phase1 is the unique maximum and Q_t>=b^2+d, a critical full-span
  good frontier occurs at t-1 and its one-step erosion is contained in
  the actual holes at t.

The frontier has the actual longitudinal end prescribed by the tracked
phase. No affine assumption on uninspected numerical predecessors is made.

## Proof

At any target q>b^2 the exact inverse of Gc is q-d: its incoming target
cost is q+b. Thus Gc(y)=q forces y=q-d. The inverse of Fc at such a target
is q-d+1, because its incoming target cost is q+b+1. In this range the
maps are strictly increasing at the relevant preimages.

In the phase0 case put q=Q_t and y=P_(t-1)[1]. Since Gc(y)=q, y=q-d.
The other output Fc(x), x=P_(t-1)[0], is strictly less than q. Because
Fc(x)>=x+d-1, integrality gives x<=q-d=y. Thus y is the preceding
numerical maximum and actual Q_(t-1)<=y. Any nongood target q>b^2 would
have original total surplus at least b+1, and the quota inequality would
force q<=Q_(t-1)+d-1<=y+d-1<q. Therefore this target is good, with original
surplus b. Every localized critical alternative has size at most b^2 and
the singleton exception is smaller still. Hence this actual target is a
full-span frontier at its matching phase0 end.

In the phase1 case the unique current maximum q=Fc(x) has preimage
x=q-d+1>b^2 by the stated target guard. The other predecessor y satisfies
Gc(y)<q and Gc(y)>=y+d, so x-y>=2. The preceding phase0 maximum is therefore
unique. A current good event would have to be a full-span frontier, whose
matching phase is0, contradicting q>P_t[0]. Hence the current event is
nongood and q<=Q_(t-1)+d-1. Since Q_(t-1)<=x, equality forces
Q_(t-1)=x. The preceding phase0 case gives a full-span actual frontier at
t-1, and deterministic hole evolution retains its erosion at time t.

## Interface and limitation

These contacts retain an ENTIRE actual oriented front, not just a selected
corner core. The phase1 target guard is material: q immediately above b^2
can have predecessor at or below b^2 and does not force a full-span shape.

To apply the lemma to an actual late source, first use equality in the
accepted real-word reversal and its genuine shifted capped orbit. Numerical
capacity alone does not supply an actual front. General dangerous endpoints
with positive deficit may have a substantially older last good event; no
age bound for those endpoints or new capture classification is asserted.

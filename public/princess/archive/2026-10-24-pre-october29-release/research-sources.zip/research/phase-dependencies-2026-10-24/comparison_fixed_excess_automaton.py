"""Finite translation exploration for odd fixed-excess localization flags.

The proposed geometry table is independently proved for all parameters by
comparison_critical_cost_certificate.py; band iterations record exact cycles.
"""
import json,time
import comparison_localization_flags as f
from comparison_wall_geometry import KEYS,signature
from comparison_local_seed_probe import seeds
F=f.F
EXCESS=1
b0=64;h0=(2*b0+1)*(b0+1)
POINTS=[(b0-1)**2-4,(b0-1)**2+1,(b0-1)**2+2,(b0-1)**2+3,b0*(b0-1)+1,b0*b0+1,b0*(b0+1)+1,h0-b0*b0,h0-b0*(b0-1),h0-(b0-1)**2,h0-(b0-1)**2+1]
SIG=[dict(zip(KEYS,signature(b0,2*b0+2,t)))for t in POINTS]
PHYS=[(-1,-1),(-1,0),(-1,0),(-1,0),(0,0),(0,1),(0,1),(0,1),(0,0),(-1,0),(-1,0)]
# square flag targets S below regime5, C in regime5.
def advance(S,region,marker):
 B=dict(zip(F,S[:9]));flags=dict(zip(('P','S','C'),S[9:12]));X=S[12:]
 if marker(X):
  M=max(X);ceilings={z:M-int((X[0]>X[1]and z[0]==0)or(X[1]>X[0]and z[1]==0))for z in F}
  B={z:min(t,ceilings[z])for z,t in B.items()}
  flags={z:min(t,ceilings[(1,0)if z=='P'else(0,1)])for z,t in flags.items()}
 caps={}
 for key in KEYS:
  i,u,j,v=key;T=B[j,v];reg=region(T);off,p,s=SIG[reg][key]
  val=T+EXCESS-off
  if p and(v!=0 or T>flags['P']):val-=1
  if s and T>flags['S'if reg<5 else'C']:val-=1
  caps[key]=val
 def value(z,pred=lambda j,v:True):
  return max(caps[i,u,j,v]for i,u,j,v,cost in f.er.OPTIONS[z]if pred(j,v))
 out=[value(z)for z in F]+[value((1,0),lambda j,v:j==0 and v<=1),value((0,1),lambda j,v:j<=1 and v==0),value((0,1),lambda j,v:v==0)]
 out += [X[1-p]+EXCESS-PHYS[region(X[1-p])][p]for p in(0,1)]
 return tuple(out)
def norm(S):
 m=min(S);return tuple(x-m for x in S),m
def initial():
 out=set()
 for C in seeds(b0,EXCESS):
  C=tuple(x-(b0-1)**2-1 for x in C);M=max(C)
  B=[M-int((C[0]>C[1]and z[0]==0)or(C[1]>C[0]and z[1]==0))for z in F]
  S=tuple(B+[B[3],B[1],B[1]]+list(C))
  while min(S)<6:
   S=advance(S,lambda x:0 if x<0 else 1 if x<1 else 2 if x<2 else 3,lambda X:True)
  out.add(S)
 return out

def stage(inputs,newreg,mindist,terminal=False):
 outputs=set();proofs=[];fail=[]
 oldreg=newreg-1
 for S in sorted(inputs):
  # Certified homogeneous orbit translation; no finite size inference.
  seen={};Z=S;t=0
  while norm(Z)[0]not in seen:
   seen[norm(Z)[0]]=(t,Z);Z=advance(Z,lambda x:oldreg,lambda X:newreg==4);t+=1
   assert t<200,(newreg,S,'no cycle')
  t0,Z0=seen[norm(Z)[0]];shift=Z[0]-Z0[0];period=t-t0
  assert shift>0 and all(z-z0==shift for z,z0 in zip(Z,Z0))
  # The complete repeating block must lie strictly before every wall.
  assert max(Z)<mindist,(newreg,S,Z,mindist)
  rows=[]
  for D in range(mindist,mindist+shift):
   Z=S;count=0
   def reg(x):return oldreg if x<D else(newreg+1 if terminal and x>=D+1 else newreg)
   marker=lambda X:newreg==4 and max(X)<D+EXCESS
   while True:
    Y=advance(Z,reg,marker)
    if terminal:
     B=Z[:9];Xnext=Y[12:]
     if max(B)>=D:
      faces=[max(q for feature,q in zip(F,B)if feature[p]<=1)for p in(0,1)]
      dif=[min(faces[0],D+EXCESS)-Xnext[1],min(faces[1],D+EXCESS)-Xnext[0],min(max(B),D+EXCESS)-max(Xnext)]
      if max(dif)>0:fail.append(dict(input=S,D=D,t=count,state=Z,next=Y,diffs=dif));break
     if min(B)>D+EXCESS and min(Z[12:])>=D+EXCESS:break
    elif min(Z)>=D+4:break
    Z=Y;count+=1
    assert count<500,(newreg,S,D,'long')
   out=tuple(z-D for z in Z);outputs.add(out);rows.append(dict(D=D,steps=count,out=out))
  proofs.append(dict(input=S,cycle_start=t0,period=period,shift=shift,cycle_state=Z0,cycle_end=tuple(z+shift for z in Z0),representatives=rows))
 return outputs,dict(region=newreg,input_count=len(inputs),output_count=len(outputs),proofs=proofs,failures=fail)
if __name__=='__main__':
 import sys
 EXCESS=int(sys.argv[1]) if len(sys.argv)>1 else 2
 start=time.process_time();S=initial();rows=[]
 print('initial',len(S),flush=True)
 for reg,dist in[(4,31),(5,32),(6,32),(7,64),(8,32),(9,31)]:
  S,row=stage(S,reg,dist,terminal=reg==9);rows.append(row)
  print('stage',reg,len(S),len(row['failures']),flush=True)
  if row['failures']:break
 out=dict(status='fixed-excess exploration only; scope and table range pending',initial=list(initial()),stages=rows,CPU_seconds=time.process_time()-start)
 with open(__file__.replace('.py',f'-d{EXCESS}.json'),'w')as z:json.dump(out,z,indent=2)

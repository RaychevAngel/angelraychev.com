"""Fixed-size one-step consequences of accepted square/pronic localization.

Odd widths only. Three auxiliary backward thresholds retain forced target
shape information. Thresholds remain necessary overapproximations.
"""
import comparison_marker_clock as m
import comparison_pronic_flag as old
F=m.band.FEATURES
er=m.band._geometry.er

def step(w,n,k,B,flags):
 b=w//2;h=w*n//2;assert w%2 and not n%2 and w<=n
 caps={(i,u,j,v):m.band.survivor(w,n,B[j,v],i,u,j,v)
      for j,v in F for i in range(v+1)for u in range(j+1)}
 for key,q in list(caps.items()):
  i,u,j,v=key;T=B[j,v]
  if T<=0:continue
  # Pronic interval formation, including the full critical root interval.
  r=m.R(T)
  if i==0 and j==1 and 2<=r<=b and (r-1)*(r-2)<q<=r*(r-1) and T-q==r:
   if v!=0 or T>flags['P']:caps[key]=q-1
  # Wide subcritical squares; accepted narrower critical square interval.
  r=m.rho(T)
  if i==1 and j==0 and v==1 and 2<=r<=b and T-q==r:
   trigger=((r-1)**2<q<=r*r)if r<b else (r*(r-1)<q<=r*r)
   if trigger and T>flags['S'if r<b else'C']:caps[key]=q-1
 def bound(feature,predicate=lambda j,v:True):
  c,e=feature
  return min(h-4+c+e,k+max([0]+[caps[i,u,j,v]for i,u,j,v,cost in er.OPTIONS[feature]if cost<=k and predicate(j,v)]))
 out={z:bound(z)for z in F}
 following={'P':bound((1,0),lambda j,v:j==0 and v<=1),
            'S':bound((0,1),lambda j,v:j<=1 and v==0),
            'C':bound((0,1),lambda j,v:v==0)}
 return out,following

def frontier(w,n,k,c):
 b=w//2;h=w*n//2;L=(b-1)**2;cap=min(L+k,b*b+1)
 assert w%2==1 and n%2==0 and w<=n and k>=max(13,b+1) and 0<=c<=k
 B={f:min(c,h-4+sum(f))for f in F};V=(c,c)
 flags={z:min(c,h-3)for z in('P','S','C')};t=0
 while True:
  M=max(V)
  if M<cap:
   ceilings={f:M-int(M-k>=10 and((V[0]>V[1]and f[0]==0)or(V[1]>V[0]and f[1]==0)))for f in F}
   B={f:min(q,ceilings[f])for f,q in B.items()}
   flags={z:min(q,ceilings[(1,0)if z=='P'else(0,1)])for z,q in flags.items()}
  yield t,B,flags,V
  B,flags=step(w,n,k,B,flags);V=m.late_step(V,k);t+=1

def evaluate(w,n,k,c,head_data=None):
 from comparison_forward_marker import heads
 b=w//2;assert b>=32 and 1<=k-b<b
 h=w*n//2;A,L,rows,stable=head_data or heads(w,n,k)
 remaining=list(range(len(rows)));wins=[]
 for t,B,flags,V in frontier(w,n,k,c):
  nxt=[]
  for i in remaining:
   e,P,caps=rows[i];matches=[f for f,q in caps.items()if q+B[f]>=h]
   if matches:wins.append(dict(head_time=e,back_time=t,total=e+t,features=matches,head_pair=P))
   else:nxt.append(i)
  remaining=nxt
  if not remaining:break
 return dict(w=w,n=n,k=k,c=c,gate_lower=min(z['total']for z in wins),wins=wins)

def face_probe(w,n,k,c):
 original=old.frontier;old.frontier=frontier
 try:return old.face_probe(w,n,k,c)
 finally:old.frontier=original

if __name__=='__main__':
 import json,time
 start=time.process_time();rows=[]
 for w,n,k in[(127,128,64),(81,162,41),(419,420,210)]:
  for c in(k,k//2):
   row=dict(clock=evaluate(w,n,k,c),face=face_probe(w,n,k,c));rows.append(row)
   print(w,n,k,c,row['clock']['gate_lower'],row['face']['worst'],flush=True)
 with open(__file__.replace('.py','.json'),'w')as f:json.dump(dict(status='necessary refinement pending independent review',rows=rows,CPU_seconds=time.process_time()-start),f,indent=2)

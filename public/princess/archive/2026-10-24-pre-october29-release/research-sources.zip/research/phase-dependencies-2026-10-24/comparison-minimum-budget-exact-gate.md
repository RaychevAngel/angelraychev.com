# A tied central split gives exact minimum-budget gate clocks

24 October2026. Proposed uniform theorem, conditional on the separate
symbolic twelve-threshold certificate passing independent review. No new
formalization claim. This proof uses the already accepted capped EARLY
necessity; it does not need the new capped signed-late theorem.

Assume w=2b+1,n>=w even,b>=32,k=b+1,0<=c<=k. Put h=wn/2,
W=b(b+1)+1,U=h-b(b+1), so U+W=h+1. Let X_r be the actual finite-board
physical inverse prefix pair from(c,c), and define

    P_c=min{r:max X_r>=h}.

This is the minimum solo prefix GATE clock to residual at most c. If c=k,
a further inspection captures; that final inspection is not included in P_c.
Let g_c be the minimum such signed gate time over arbitrary full-origin
inspection histories. Claim:

    g_c=P_c.                                            (1)

The upper direction is the explicit physical prefix construction.

## A universal backward central state

The symbolic band certificate in `comparison-minimum-budget-one-day.md`
provides a horizon r, depending on the actual ordinary late entrance pair,
with the following physical state and necessary threshold upper vector:

    X_r=(W+5,W+4),
    B_r(a,e)<=W+4 for a=0,1;
    B_r(2,e)<=W+5;
    all three auxiliary thresholds<=W+4.                (2)

This is the unique normalized state after crossing the wall W. One more
homogeneous central update gives

    X_(r+1)=(W+5,W+5),  max B_(r+1)<=W+5.               (3)

The gap to the next wall h-b^2 is at least2b, so this update is in the same
central band. The finite symbolic certificate proves (2) for EVERY entrance
pair and every preceding band length, rather than selecting a residue.

## The physical gate clock forces a tied forward split

Let A_t be the genuine finite-board physical forward HOLE-prefix pair from
zero. The exact two-front adjunction says

    P_c<=t+s iff max_p(A_t[p xor1]+X_s[p])>=h.            (4)

Take g=P_c-1 and t=g-r. Since X_(r+1)<h, P_c>=r+2 and t>=1.
Applying failure at g and success at g+1 to (2),(3) gives

    A_t[0]<=U-6,  A_t[1]<=U-7,
    max A_t>=U-6.

Thus A_t[0]=U-6. Both coordinates lie in the genuine central phase regime.
Indeed global physical interlacing and a per-update gain of at most k give
min A_t>=max A_t-k>=U-b-7>b^2 for b>=32, using U>=b^2+2b+1.
In this central range the maps are (x,y)->(y+1,x). Global interlacing then
forces the current ordered gap to be0 or1. Consequently

    A_t=(U-6,U-7),  A_(t-1)=(U-7,U-7).                 (5)

The inverse conclusion is literal: A_t[0]=A_(t-1)[1]+1 and
A_t[1]=A_(t-1)[0]. The preceding pair is also in the same central regime,
since its minimum is at least U-2b-8>b^2-b for b>=32; the capped branches
are already active there. More directly, the exact inverse of the capped
central maps at these two outputs is unique, giving (5).

Up to this time the finite-board physical forward pair coincides with
the capped ordinary pair Pc: all current and preceding coordinates are
below U, and the far-boundary improvement has not yet activated.

## The same split excludes every physical history

Suppose a full-origin inspection history reaches signed residual at most c
by time g. Normalize its finite prefix using the accepted polarization and
last-full normalization. At time t-1, its remaining horizon is r+1.
The accepted capped early first-crossing theorem, with A_cut=U-1, gives

    actual Q_(t-1)<=max Pc_(t-1)=U-7,

because this numerical maximum is strictly below the cut. In particular
there was no earlier crossing of the protected collar.

The backward necessary twelve-threshold calculation (3) applies to the
same normalized history and gives

    actual residual_(t-1)<=max B_(r+1)<=W+5.

But signed residual=h-Q, so the first inequality instead requires

    actual residual_(t-1)>=h-(U-7)=W+6.

Contradiction. Thus no such history reaches the gate by P_c-1, proving(1).
No arbitrary independent choices of a head phase and a tail phase were
combined: the tied split is forced by the actual prefix clock.

## Checks still needed before promotion

The symbolic primitive and translation certificates require their pending
independent review. The precise physical-forward inverse argument in(5),
including the central input guard, should be independently checked against
the accepted prefix API. Once(1) is accepted, the final-inspection theorem
can use exact g_k and g_floor(k/2); its separate physical assembly should
state the resulting full capture-time evaluator and attainment explicitly.

# A safe first cut beyond the middle of an odd rectangle

24 October2026. Corollary of the independently accepted actual capped
critical continuation. Ordinary proof, no new exact capture formula.

Use its parameters w=2b+1,n=2ell>=w,k=b+d,h=(2b+1)ell,
b>=max(200,4d+8),d>=1, U=h-b(b+1), and capped pair Pc from zero.
Define

    A=U-d.

For ANY actual full-origin hole history, let tau be the first time Q_tau>=A.
Then

    A<=Q_tau<=U-1,          Q_tau<=max Pc_tau.           (1)

Consequently the all-time clipped inequality holds:

    min(Q_t,A)<=min(max Pc_t,A).                        (2)

The same consequence inherits any independently established broader
parameter range of the capped continuation theorem.

## Overshoot proof

The shortest possible even long side has ell=b+1, so
U>=b^2+2b+1. In particular A>L=(b-1)^2 and A>=1.
At its first crossing, nonnegative total surplus gives

    Q_tau<=Q_(tau-1)+k<=A-1+k=U+b-1<U+2b.

If the original total surplus were at most b-1, every dual component is
subcritical. The accepted separator alternatives would give either total
small size at most(b-1)^2=L, or one co-small component of size at least

    h-b(b-1)=U+2b.

Both contradict the displayed first-crossing range. Thus sigma_tau>=b,
and the actual quota inequality strengthens to

    Q_tau<=Q_(tau-1)+k-b<=A-1+d=U-1.

All previous counts are below A<U. The strict-collar theorem therefore
applies to the complete prefix through tau, proving(1). For(2), a first
violation before the ordinary maximum reaches A would contradict(1);
after it reaches A the clipped inequality is tautological.

The one-room distance from U is intentional. At U itself the co-small
critical branch becomes available; merely proving surplus>=b there would
not preserve both labelled capped maps.

## Coverage of a central cut

The threshold A lies strictly beyond h/2. Indeed

    A-h/2=h/2-b(b+1)-d
          >=(b+1)/2-d>0

under b>=4d+8. Thus this is a genuine extension of physical necessary
control across the entire lower boundary and the center of every stated
odd-width rectangle, not only a small-corner assertion. Translating it
into a full capture-time bound still requires the terminal cut/phase
assembly; that is not asserted here.

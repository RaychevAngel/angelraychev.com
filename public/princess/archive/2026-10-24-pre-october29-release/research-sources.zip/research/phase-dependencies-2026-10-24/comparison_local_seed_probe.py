"""Falsify a local late-entry seed box before symbolic wall certification."""
import comparison_localization_flags as f
from comparison_face_probe import physical
import json,time
def seeds(b,d):
 k=b+d;L=(b-1)**2;out=set()
 for a in range(L-2*d-6,L):
  for z in range(L-2*d-6,L):
   if abs(a-z)>d+2:continue
   C=f.m.late_step((a,z),k)
   if max(C)>=L and max(C)<=L+d+1 and min(C)>=L-d-2 and min(f.m.late_step(C,k))>=max(C):out.add(C)
 return sorted(out)
def run(b,d,n,C):
 w=2*b+1;k=b+d;h=w*n//2;L=(b-1)**2;A=L-d;Z=min(L+k,b*b+1)
 V=X=C;M=max(C)
 B={z:M-int((C[0]>C[1]and z[0]==0)or(C[1]>C[0]and z[1]==0))for z in f.F}
 flags={z:B[(1,0)if z=='P'else(0,1)]for z in('P','S','C')};t=0
 while max(B.values())<=h-A+3:
  M=max(V)
  if M<Z:
   ceilings={z:M-int((V[0]>V[1]and z[0]==0)or(V[1]>V[0]and z[1]==0))for z in f.F}
   B={z:min(q,ceilings[z])for z,q in B.items()}
   flags={z:min(q,ceilings[(1,0)if z=='P'else(0,1)])for z,q in flags.items()}
  Y=physical(w,n,k,X)
  if max(B.values())>=h-L:
   faces=[max(q for z,q in B.items()if z[p]<=1)for p in(0,1)]
   diffs=[min(faces[0],h-A)-Y[1],min(faces[1],h-A)-Y[0],min(max(B.values()),h-A)-max(Y)]
   if max(diffs)>0:return dict(b=b,d=d,n=n,C=C,t=t,B=list(B.values()),flags=flags,X=X,Y=Y,diffs=diffs)
  B,flags=f.step(w,n,k,B,flags);V=f.m.late_step(V,k);X=Y;t+=1
 return None
if __name__=='__main__':
 start=time.process_time();count=0;bad=[]
 for b,d,n in[(32,1,66),(40,1,162),(63,1,128),(32,2,66)]:
  ss=seeds(b,d);print('seedbox',b,d,n,len(ss),flush=True)
  for C in ss:
   count+=1;x=run(b,d,n,C)
   if x:bad.append(x);print('FAIL',x,flush=True);break
  if bad:break
 out=dict(status='arbitrary-seed overapproximation challenge, not theorem',cases=count,failures=bad,CPU_seconds=time.process_time()-start)
 with open(__file__.replace('.py','.json'),'w')as z:json.dump(out,z,indent=2)

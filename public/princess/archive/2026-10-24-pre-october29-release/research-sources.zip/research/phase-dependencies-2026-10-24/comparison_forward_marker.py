"""Monotone nine-feature first-crossing relaxation with exact marker caps.
Research evaluator; no attainment or uniform exactness claim.
"""
import comparison_marker_clock as m
from functools import lru_cache
import json,time,argparse
F=m.band.FEATURES
def propagate(w,n,k,prev,limit):
 h=w*n//2;out={}
 for j,v in F:
  # For each survivor (i,u), choose the largest admissible predecessor hole cap.
  options=[]
  for i in range(v+1):
   for u in range(j+1):
    vals=[q for(c,e),q in prev.items() if i<=c and u<=e and c-i+e-u<=k and i>=max(0,c+v-2)]
    if vals:options.append((i,u,max(vals)))
  if not options:continue
  def allowed(q):
   T=h-q
   return any(old+m.band.survivor(w,n,T,i,u,j,v)>=h-k for i,u,old in options)
  lo=4-j-v;hi=min(limit,max(prev.values())+k)
  if lo>hi or not allowed(lo):continue
  while lo<hi:
   mid=(lo+hi+1)//2
   if allowed(mid):lo=mid
   else:hi=mid-1
  out[j,v]=lo
 return out
def heads(w,n,k):
 b=w//2;d=k-b;L=(b-1)**2;A=L-d
 assert 32<=b and w<=n and w*n%2==0 and 1<=d<b
 prev={(2,2):0};P=(0,0);e=0;ans=[];signature=None
 while True:
  e+=1;P=m.early_step(P,k)
  raw=propagate(w,n,k,prev,L)
  caps={f:min(L,max(min(P),P[0] if f[0]<=1 else 0,P[1] if f[1]<=1 else 0)) for f in F}
  raw={f:min(q,caps[f]) for f,q in raw.items()}
  cross={f:q for f,q in raw.items() if q>=A}
  sig=tuple(cross.get(f,-1)for f in F)
  if cross and sig!=signature:ans.append((e,P,cross));signature=sig
  # Reachability up to e is a safe monotone overapproximation of reachability
  # at e. Retain earlier noncrossing states as well as this day's new ones.
  new={f:max(prev.get(f,-1),min(raw.get(f,-1),A-1))for f in F}
  new={f:q for f,q in new.items()if q>=4-sum(f)}
  if new==prev and min(P)>=L:break
  prev=new
  assert e<1000000
 return A,L,ans,e
def evaluate(w,n,k,c,head_data=None):
 h=w*n//2;b=w//2
 assert 0<=c<=k
 A,L,rows,stable=head_data or heads(w,n,k)
 V=(c,c);B={f:min(c,h-4+sum(f))for f in F};t=0;remaining=list(range(len(rows)));wins=[]
 Zcap=min((b-1)**2+k,b*b+1)
 while remaining:
  M=max(V)
  if M<Zcap:
   caps={f:M-int(M-k>=10 and((V[0]>V[1]and f[0]==0)or(V[1]>V[0]and f[1]==0)))for f in F}
   B={f:min(q,caps[f])for f,q in B.items()}
  nxt=[]
  for i in remaining:
   e,P,caps=rows[i];matches=[f for f,q in caps.items()if q+B[f]>=h]
   if matches:wins.append(dict(head_time=e,head_pair=P,back_time=t,total=e+t,features=matches,head_caps={str(f):q for f,q in caps.items()}))
   else:nxt.append(i)
  remaining=nxt
  if not remaining:break
  B=m.band.step(w,n,k,B);V=m.late_step(V,k);t+=1
 return dict(w=w,n=n,k=k,c=c,head_stable_time=stable,head_vectors=len(rows),gate_lower=min(r['total']for r in wins),wins=wins)
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('w',type=int);a.add_argument('n',type=int);a.add_argument('k',type=int);x=a.parse_args();start=time.process_time();hd=heads(x.w,x.n,x.k)
 rows=[evaluate(x.w,x.n,x.k,c,hd)for c in(x.k,x.k//2)]
 print(json.dumps(dict(status='research diagnostic',rows=rows,lower=max(2*rows[0]['gate_lower']+1,2*rows[1]['gate_lower']),CPU_seconds=time.process_time()-start),indent=2))

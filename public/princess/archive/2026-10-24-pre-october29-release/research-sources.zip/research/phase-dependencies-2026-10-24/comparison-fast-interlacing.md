# Ordinary phase interlacing until a fast cap is free

24 October 2026. Ordinary lemma submitted for independent review. This is a
reset-interface lemma, not a new full-game capture bound.

Write R(x)=ceil(sqrt(x)), rho(x)=min{r>=0:x<=r(r+1)}, and

    F(x)=x+k-R(x+k), G(x)=x+k-rho(x+k),
    P_0=(0,0), P_(t+1)=(G(P_t[1]),F(P_t[0])).

Let C>=1, and let J be the finite first time that the slower scalar orbit
f_0=0, f_(t+1)=F(f_t) reaches C. Put

    Rhat=R(C-1+k).

If

    floor(J/2)+Rhat <= k,                              (1)

then for every t with min(P_t)<C,

    min(P_(t+1)) >= max(P_t).                          (2)

After min(P_t)>=C, both ordinary phases dominate every state of size at
most C at every later time.

## Proof

Both F,G are nondecreasing and 1-Lipschitz on the nonnegative integers, and
0<=G-F<=1. If K=k(k-1), then F(K)=G(K)=K and F,G are at least the identity
on[0,K]. The zero-origin pair remains in this interval and is coordinatewise
nondecreasing by monotonicity of its pair update.

The two scalar compositions differ by at most one:

    |G(F(x))-F(G(x))| <=1.

Indeed both lie between G(G(x))-1 and G(G(x)). Their 1-Lipschitz property
therefore gives

    |P_(t+2)[0]-P_(t+2)[1]| <= |P_t[0]-P_t[1]|+1.

Starting at P_0=(0,0), and using |P_1[0]-P_1[1]|<=1, we obtain

    |P_t[0]-P_t[1]| <= ceil(t/2).                     (3)

Both coordinates dominate f_t. Hence min(P_t)<C implies t<=J-1, so the
current gap is at most floor(J/2). If x=min(P_t), then x<=C-1, and

    F(x)-x = k-R(x+k) >= k-Rhat >= floor(J/2).

The same holds for G. Thus whichever map acts on the smaller coordinate
reaches the current larger coordinate. The map on the larger coordinate
cannot decrease it, because both inputs lie in[0,K]. This proves(2).
The assertion after crossing C follows from coordinatewise monotonicity.

## Rectangle guard and exact parity

For w<=n, b=floor(w/2), k>=b+1, the familiar causal guard

    J+2Rhat <= w+2                                    (4)

implies(1). If w=2b, its right side is at most2k; if w=2b+1, it is at most
2k+1. In either case the even integer2floor(J/2)+2Rhat is at most2k.
The needed radius is R(C-1+k), not merely R(C).

## Consequence for a retreat, with the scope explicit

Suppose an actual source at time t is dominated by one ordinary phase:
Q_t<=P_t[p]. If its next total Q_(t+1) is at most min(Q_t,C), then it is
dominated by BOTH ordinary phases at time t+1. When min(P_t)<C use(2);
otherwise both phases were already at least C. Thus a one-step retreat
into the fast cap erases any matching-phase ambiguity without spending
an extra day or injecting an artificial equal seed.

For a retreat FROM SLOW, also assume Q_t>C. Then max(P_t)>=Q_t>C,
so the same proof gives min(P_(t+1))>=C (indeed strict inequality when
(2) is used). Coordinatewise monotonicity then dominates every later
fast target<=C, even if it grows again. For a source Q_t<=C the one-step
conclusion still holds, but no arbitrary subsequent growth up to C is
claimed without independently knowing min(P_(t+1))>=C.
This does not initialize an unrelated first slow event, prove domination
through targets above C, or justify a corner switch outside the fast cap.
It can be joined to an already established matching slow-history argument.

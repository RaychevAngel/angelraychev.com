"""Exact polynomial certificate for critical cost/formation table, odd width.

All inequalities are proved by nonnegative coefficients after b=32+B,
length n=2b+2+2S, B,S>=0. No width sample establishes the bounds.
"""
import json,time
from comparison_wall_automaton import SIG,KEYS,PHYS
class P:
 def __init__(self,c=0):self.c=c if isinstance(c,dict)else{(0,0):c}
 def __add__(a,b):
  b=b if isinstance(b,P)else P(b);d=dict(a.c)
  for z,v in b.c.items():d[z]=d.get(z,0)+v
  return P({z:v for z,v in d.items()if v})
 __radd__=__add__
 def __neg__(a):return P({z:-v for z,v in a.c.items()})
 def __sub__(a,b):return a+-asP(b)
 def __rsub__(a,b):return asP(b)+-a
 def __mul__(a,b):
  b=asP(b);d={}
  for (i,j),v in a.c.items():
   for (k,l),w in b.c.items():d[i+k,j+l]=d.get((i+k,j+l),0)+v*w
  return P({z:v for z,v in d.items()if v})
 __rmul__=__mul__
 def __pow__(a,n):
  z=P(1)
  for _ in range(n):z=z*a
  return z
 def nn(a):return all(v>=0 for v in a.c.values())
 def pos(a):return a.nn()and a.c.get((0,0),0)>0
 def __repr__(a):return str(a.c)
def asP(x):return x if isinstance(x,P)else P(x)
b=P({(1,0):1,(0,0):32});ss=P({(0,1):1});h=2*b*b+3*b+1+(2*b+1)*ss;L=(b-1)**2;H=b*(b-1);E=h-b*b;U=h-H
RANGES=[(L-4,L),(L+1,L+1),(L+2,L+2),(L+3,H),(H+1,b*b),(b*b+1,b*(b+1)),(b*(b+1)+1,E-1),(E,U-1),(U,h-L-1),(h-L,h-L),(h-L+1,h-L+8)]
# Interval arithmetic for inverse values MINUS b. Clipping at b+8 is safe:
# each inverse is only used through minima with b or b+1; additive shifts
# are nonnegative except -1, still safely above both caps.
def root(lo,hi,m):
 assert(lo-(b-9)*(b-9+m)).pos(), ("root lower floor",m,lo)
 lower=-8;upper=8
 for c in range(-8,9):
  if(lo-(b+c-1)*(b+c-1+m)).pos():lower=c
  if((b+c)*(b+c+m)-hi).nn():upper=min(upper,c)
 assert lower<=upper,(m,lo,hi,lower,upper)
 return lower,upper
def plus(x,a):return x[0]+a,x[1]+a
def mn(*x):return min(t[0]for t in x),min(t[1]for t in x)
def mx(*x):return max(t[0]for t in x),max(t[1]for t in x)
def low(lo,hi,v,u,j):
 if u:return plus(root(lo-2*v-3*j-u,hi-2*v-3*j-u,4),v+2*j)
 if v:return plus(root(lo-2*v-3*j,hi-2*v-3*j,3),v+2*j)
 if j:return plus(mn(root(2*lo-6*j,2*hi-6*j,5),root(lo-3*j+2,hi-3*j+2,2)),2*j)
 return mn(root(2*lo,2*hi,1),root(lo,hi,-1))
def high(lo,hi,A,B):
 if B:
  c=A+2*B-2;return plus(root(lo-c,hi-c,-1),c)
 if A:return plus(root(lo-A+1,hi-A+1,0),A-1)
 return mn(root(2*lo,2*hi,-1),plus(root(lo+1,hi+1,0),1))
def small(lo,hi,i,j):
 if j:
  c=i+2*j-2;return plus(root(lo-2*c,hi-2*c,0),c)
 if i:
  c=i-1;return plus(root(lo-2*c,hi-2*c,1),c)
 return mn(root(2*lo,2*hi,1),plus(root(lo,hi,1),1))
def large(lo,hi,i,j):
 A=2-i;B=2-j
 if B:return plus(root(lo-B+1,hi-B+1,0),A+B-1)
 if A:return plus(root(lo,hi,1),A)
 return mn(plus(root(2*lo,2*hi,1),1),plus(root(lo+1,hi+1,0),1))
def cost(reg,key):
 lo,hi=RANGES[reg];i,u,j,v=key;delta=v-i;dl,dh=h-hi,h-lo
 th=mn(low(lo,hi,v,u,j),high(dl,dh,2-j,2-v),(0,0))
 od=mn(small(lo,hi,v,j),large(dl,dh,v,j),(0,0)if(v,j)==(2,0)else(1,1))
 out=plus(mx(th,od),delta)
 assert (h-4+i+u-hi+b+out[0]).nn(),('sizecap',reg,key)
 # Wide square band: r=b-1 exactly in regions9,10.
 if(j,v)==(1,2)and u!=1 and reg>=9:out=mx(out,(delta,delta))
 # Critical pronic band has r=b; v1 persists, other v stop at D=L-1.
 if j==2 and reg>=8 and(reg<=9 or v==1)and(i,u,v)!=(1,2,1):out=mx(out,(1,1))
 assert (lo-b-out[1]).pos(),('positiveq',reg,key)
 return out

def main():
 st=time.process_time();checks=[]
 for reg,(lo,hi)in enumerate(RANGES):
  assert(hi-lo).nn()
  for key in KEYS:
   got=cost(reg,key);expect=SIG[reg][key][0];assert got==(expect,expect),(reg,key,got,expect)
   i,u,j,v=key
   p=int(i==0 and j==1 and((reg==0 and expect==-1)or(2<=reg<=4 and expect==0)))
   s=int(i==1 and j==0 and v==1 and((reg<=3 and expect==-1)or(reg==5 and expect==0)))
   assert SIG[reg][key][1:]==(p,s),(reg,key,SIG[reg][key],p,s)
   checks.append([reg,list(key),expect,p,s])
  # Physical inverse costs, in source phases0 and1.
  dl,dh=h-hi,h-lo
  pc0=mn(root(lo,hi,1),root(dl,dh,0),(0,0))
  pc1=mn(root(lo,hi,0),plus(root(dl,dh,1),1),(1,1))
  assert(pc0,pc1)==tuple((a,a)for a in PHYS[reg]),(reg,pc0,pc1,PHYS[reg])
  # Every omitted root/max2/max1 branch is below b-8>=24.
  assert(b-8-6).pos()
 out=dict(status='exact polynomial certificate passed',scope='b>=32,n=2b+2+2S,S>=0, eleven critical rank intervals',primitive_checks=len(checks),checks=checks,CPU_seconds=time.process_time()-st)
 with open(__file__.replace('.py','.json'),'w')as z:json.dump(out,z,indent=2)
 print(out['status'],len(checks))
if __name__=='__main__':main()

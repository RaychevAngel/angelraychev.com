# Exact odd-width gates from a common cut with two whole fronts

24 October2026. Proposed uniform theorem for independent review. This uses
actual histories, accepted capped necessities, and whole-front overlap.
It does not assume that arbitrary partial-state prefixes are optimal.

Let w=2b+1, n=2ell>=w, k=b+d, h=(2b+1)ell, and assume

    d>=1, b>=4d+8,       (2b+1)(ell-b)>2d^2.           (1)

For0<=c<=k let P(c) be the physical prefix gate clock from full uncertainty
to residual at most c, using the exact finite-board inverse prefix pair.
Then the minimum signed gate time over ALL full-origin physical histories
is exactly P(c). Consequently the full capture time is

    T_k(w,n)=P(k)+P(floor(k/2))+1.                     (2)

This is an exact computable answer with the established physical inspection
construction. It is not an O(1)-operation numerical expression.

In particular(1) holds for EVERY length n>=w when b>=d^2, in addition to
the natural guard b>=4d+8. For other budgets in that natural guard, (1)
is an explicit length condition. No claim is made for the omitted range.

## 1. Fix one allegedly faster actual history

Write U=h-b(b+1), A=U-d=h-b^2-k, Z=h-b^2. Let C_t be the genuine capped
early pair from zero and V_r the genuine capped late pair from(c,c).
Suppose an arbitrary history reaches signed gate c in T<P(c) updates.
Apply the accepted finite-prefix polarization/last-full normalization once.
All subsequent counts and sets refer to THIS normalized physical history.

At any time t with

    min C_t>b^2,       max C_t<A,                     (3)

the physical forward prefix pair equals C_t: its far-boundary branches
are inactive below U, and all previous counts are smaller by monotonicity.
Physical adjunction fails at the split t+r=T. It follows that the physical
backward maximum is less than h-min C_t<Z. Every preceding backward state
is also below Z, where physical and capped backward maps agree. Hence
that backward pair is exactly V_r and both compatible meeting sums fail.

Early clipping gives Q_t<=max C_t. Signed late clipping gives
m_t=h-Q_t<=max V_r, since max V_r<Z. The failed meeting implies the sharper
danger conditions

    Q_t>min C_t,          m_t>min V_r.                (4)

Otherwise one of the compatible sums already reaches h. Thus neither
pair is tied, and their unique leading phases are the SAME phase (the
antipodal correction for an odd-by-even rectangle is1).

Set M_E=max C_t, M_L=max V_r and

    delta_E=M_E-Q_t,       delta_L=M_L-m_t.

The same-cut identity and failed compatible sums give

    delta_E+delta_L=M_E+M_L-h
        <min(gap(C_t),gap(V_r))<=gap(C_t)<=d.         (5)

The last bound follows from global interlacing and the central capped
inverse at a maximum>b^2. In particular both deficits are nonnegative
integers and their sum is at most d-1.

## 2. There is a cut where the early whole-front criterion is barely met

Define at times satisfying(3)

    D_E(t)=Q_t-b^2-(2delta_E(t)+1)(d-1)
          =M_E-b^2-d+1-(2d-1)delta_E(t).              (6)

Let s be the first time min C_s>b^2. At the preceding time the minimum
is at most b^2. Global interlacing yields the sharper bound

    max C_s<=b^2+2d-1.                              (7)

Indeed if the preceding smaller coordinate is x<=b^2, the other is at
most Gc(x)<=b^2+d when x is phase1, or at most Fc(x)<=b^2+d-1 when x is
phase0. Its next image is therefore at most b^2+2d-1 in either orientation.
The other image is at most b^2+d. This proves(7).
Consequently if D_E(s)>0 it is at most d.

Throughout(3),(4), actual targets exceed b^2. A good target must be a
full-span frontier with matching phase0. If the numerical leader is
phase0, its maximum increases by d and any actual target increases by
at most d. If the leader is phase1, danger excludes a good target, so
its maximum and actual target increase by at most d-1. Thus delta_E is
nondecreasing on these updates, and (6) increases by at most d per step.
This reasoning uses the exact inverse of the dominating branch at an
output>b^2; no unproved affine assumption on both predecessors is needed.

The equivalent form of the length hypothesis is

    A-b^2=h-k-2b^2>2d^2-d.                         (8)

The capped maximum eventually reaches
B=b^2+2d(d-1)+1. Its first such value at or after s is at most
B+d-1=b^2+2d^2-d<A: if that time is s, use(7) and
b^2+2d-1<=B; otherwise use the central one-step increase at most d.
From s through that time (3) holds. By(5), delta_E<=d-1, so
(6) is positive there. The alleged terminal time T cannot be earlier:
whenever max C_T<A, early clipping contradicts the terminal requirement
Q_T>=h-c>A. Thus this first crossing occurs within the actual history.

Choose the first time t>=s at which D_E(t)>0. We have proved

    (3),(4) hold at t,             0<D_E(t)<=d.       (9)

## 3. The actual late reversal uses the same slack budget

The mixed-suffix comparison controls BOTH late phases. By(4), the chosen
cut cannot already be in that mixed suffix, including its activation
inspection. The normalized cut is therefore solo: one belief cohort is
full and the other is an actual set S of size m_t. All actual holes at
the cut belong to this smaller cohort.

The accepted activation splice reverses the real remaining solo segment,
using either its actual later activation set or its actual terminal set.
It supplies an allowed set C=I union J containing S, with |I|<=k, and a
genuine zero/first-quota or shifted erosion history ending at J. Its exact
reference at that time is V_r-(k,k). Since max V_r<Z, the clipped bound
is unclipped and

    |J|<=M_L-k,         |S|<=|C|<=k+|J|.

The case of immediate activation is excluded by(4), and the remaining
horizon is positive because m_t>h-A=b^2+k>c. Thus the real final inspection
union C=I union J exists; no reverse prehistory is invented.

Let delta_J=M_L-k-|J| and eta=|C minus S|. Then

    delta_J>=0, eta>=0,       delta_J+eta<=delta_L.   (10)

Moreover |J|>=m_t-k>min V_r-k, so this actual erosion endpoint is also
dangerous, in the unique leading phase of V_r.

Define D_J=|J|-b^2-(2delta_J+1)(d-1). From |J|>=m_t-k,
Q_t+m_t=h, and (5),(10),

    D_E+D_J >=h-k-2b^2-2(delta_E+delta_J+1)(d-1)
             >=h-k-2b^2-2d(d-1)>d.                 (11)

Together with(9), this gives D_J>0. Both actual endpoints therefore meet
the ancestor-forcing criterion in `upper-central-deficit-ledger.md`.

For a shifted activation start, its accepted initial invariant is sufficient:
an initial central good erosion is itself a full-span frontier; an initial
nongood erosion is below both coordinates, so a later dangerous endpoint
requires an intervening good event. If the history later visits <=b^2,
use the last-crossing argument instead. This is the genuine initial-set
alternative, not a fictitious earlier erosion word.

## 4. The two real whole fronts cannot coexist

The early endpoint contains the erosion of an actual full-span frontier
of age at most2delta_E+1. The late allowed set C contains the corresponding
erosion of another actual full-span frontier of age at most2delta_J+1.
Both ages are at most2d-1. The late front is asserted only inside C, not
silently placed inside the actual source S.

The two fronts have the SAME current color and SAME longitudinal end.
They belong to the same solo cohort identified above. Their current phase
labels are the two numerical leaders, which coincide by(4),(5); on an
odd-width even-length board the current relative phase determines the
longitudinal end uniquely. Their actual ancestor sizes exceed b^2>L.

The accepted whole-front overlap theorem therefore gives intersection
strictly greater than d under b>=4d+8. But one retained front lies in
actual holes, disjoint from S, and the other lies in C. Their intersection
can have at most |C minus S|=eta<=d-1 cells by(10). This contradiction
excludes T<P(c).

The exact physical prefix construction attains P(c), proving gate equality.
Finally P(0)=P(k)+1 and P(floor(k/2)) is either P(k) or P(k)+1. The accepted
shared final-quota lower and palindrome/concatenation upper constructions
then coincide and give(2).

## Proof boundary

The quantified range(1) is essential here: it supplies enough central room
to force both actual full-front ancestors at one cut. This argument does
not resolve the remaining short boards with larger budget excess, nor
does it remove the natural geometric guard b>=4d+8. Localized ancestors
may require a sharper erosion/overlap argument in those ranges.

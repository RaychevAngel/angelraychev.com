"""Extract the exact common bulk state from the finite translation proof."""
import comparison_wall_automaton as a
import json
S=a.initial();rows=[]
for reg,dist in[(4,31),(5,32),(6,32)]:
 S,row=a.stage(S,reg,dist);rows.append(row)
expected=(4,4,4,4,4,4,5,5,5,4,4,4,5,4)
assert S=={expected},S
nxt=a.advance(expected,lambda x:6,lambda X:False)
assert nxt[12:]==(5,5) and max(nxt[:9])==5,nxt
out=dict(status='exact common central state extracted',state=expected,next=nxt,scope='conditional on the independently reviewed primitive table and band translations')
with open(__file__.replace('.py','.json'),'w')as f:json.dump(out,f,indent=2)
print(out)

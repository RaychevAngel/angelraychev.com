# A sensitive corner cannot disappear before its full core erodes

24 October 2026. Physical lemma proposed for independent review. This adds
an elapsed-time restriction to the accepted sensitive-switch reduction. It
does not yet prove an exact capture clock.

Use its notation: w<=n, even area, b=floor(w/2), holes H_t in one fixed
initial cohort, and H_(t+1)=E(H_t union I_t). Let a sensitive event at u
have Q holes, root r<b and original surplus r, so

    r(r-1)<Q<=r².

The accepted reduction says ALL holes form a single two-step connected
component at an actual own-color corner C, inside radius2r-2, and its
neighborhood surplus is exactly r. Put

    delta=r²-Q,
    m=max{j>=0:j(j+1)/2<=delta},
    Rcore=2r-2-2m.

## The forced raw core

The component actually contains C. Otherwise the punctured-quadrant
capacity is at most max(r(r-1)/2,r(r-2))<Q. Its occupied distance layers
are consecutive by two-step connectivity and start at0. Since
Q>r(r-1)>=(r-1)², the accepted full-layer lemma in
`../uniform-history-2026-10-23/lower-dual-bin-stability.md`, Section1,
applies with p0 and L=r. Consequently H_u contains EVERY cell of C's
color within distance Rcore of C. This conclusion concerns the original
uncompressed physical set. For r1 it is simply the corner singleton.

## Persistence is independent of inspections

For any radius R of the current parity, let B_R(C) be the corresponding
full one-color corner ball. Directly from the definition of erosion,

    E(B_R(C)) contains B_(R-1)(C).

Every neighbor of a room at distance at most R-1 has distance at most R.
The rectangle boundary only removes neighbors and cannot invalidate this
inclusion. Since E is monotone and H_(t+1) contains E(H_t), induction gives

    H_(u+j) contains B_(Rcore-j)(C)                 (1)

whenever Rcore-j>=0, with the naturally alternating current color.
No perfect-matching transport, inspection budget, or monotonicity of the
TOTAL number of holes is assumed.

Let v=u+Delta be a later sensitive event at a DIFFERENT corner C', with
root s<b. Its entire hole set lies in radius2s-2<=2b-4 about C'. Every
corner distinct from C is at distance at least w-1>=2b-1 from C. Thus C
and both board neighbors of C are OUTSIDE that new ball: their distances
from C' are respectively at least2b-1 and2b-2.

If Delta is even and Delta<=Rcore, (1) retains C, a contradiction.
If Delta is odd and Delta<=Rcore-1, (1) retains both neighbors of C, again
a contradiction. Therefore

    Delta >= Rcore+1 = 2r-2m(delta)-1.              (2)

When the corners have the same physical color, Delta is even and the
stronger parity-rounded bound is Rcore+2. For the opposite-color switch
relevant to a first matching failure, Delta is odd and(2) is exact as an
integer necessary bound. It remains valid if the old core is empty in a
more general application, interpreted as the trivial Delta>=1; here the
sensitive defect delta<r makes the stated core nonempty.

## What this excludes, and what remains

For the independently checked relaxed k200 witness, r197,Q38801 give
delta8,m3, and(2) requires Delta>=387. Its proposed Delta103 is impossible
for ANY physical hole history, regardless of quota.

For the symbolic plateau family k divisible4, old r=k-3 and Q=r²-1,
m1 gives Delta>=2k-9, contradicting its proposed Delta=k/2+1 for k>=12.
Thus those tuples are eliminated by persistence of actual old holes, not
by increasing the already insufficient endpoint shot charge.

To use this toward the full ordinary boundary clock, append(2) to the
necessary conditions in lower-sensitive-switch-obstruction.md, retaining
the old defect delta, old root, ordinary phase and final sensitive bin.
It is NOT yet proved that the strengthened numerical conditions admit no
tuple, nor that a failure involving earlier excursions above the pronic
cut is covered. This lemma supplies a genuine additional causal constraint;
it does not assert that every abstract tuple satisfying it is realizable.

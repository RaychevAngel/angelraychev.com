# Exact physical agreement below the capped collar, including no jumps

24 October2026. Explicit interface for the accepted capped-cut arguments.
Use w=2b+1,n even>=w,h=wn/2,k=b+d and U=h-b(b+1).

The genuine physical prefix neighborhood target profiles for a forward
hole update, indexed by the NEW hole phase, are, for positiveq,

    N0(q)=q+min(ceil_sqrt(q),b,rho(h-q)),
    N1(q)=q+min(1+rho(q),b+1,ceil_sqrt(h-q)).          (1)

Set N0(0)=N1(0)=0 for the empty prefix.

They follow from the accepted exact finite-board prefix inverse formulas
by complementing the cardinality and applying the antipodal phase xor1.
For input hole mass x, the physical target is the largestq with
Np(q)<=x+k. These are actual prefix neighborhood profiles, hence
nondecreasing inq; no arbitrary-shape optimality is asserted.

For EVERY q<=U, the far-end terms satisfy

    rho(h-q)>=b,       ceil_sqrt(h-q)>=b+1.

Therefore(1) agrees with the two capped profiles

    q+min(ceil_sqrt(q),b),
    q+min(1+rho(q),b+1).

The equality includes the endpointq=U: there the far terms are exactlyb
andb+1. Thus agreement of small targets cannot be bypassed by a physical
jump over the collar. If a capped update has targetq<U, its input obeys
x+k<Np(U). Monotonicity of the physical profile forbids ANY target>=U.
The physical target is itself<U, where the two profiles agree, so it is
exactly the capped target.

Inducting from the common zero seed proves exact physical/capped forward
agreement through any time whose capped maximum is<U. All earlier capped
coordinates are also<U by coordinatewise monotonicity. In particular the
safe cuts max C_t<A=U-d used by the tied-cut and whole-front arguments
satisfy this exact agreement, with no hidden input-size restriction.

For completeness, the backward pair agrees with the capped backward pair
until its physical maximum reaches Z=h-b^2. At any inputx<Z, h-x>b^2, so
ceil_sqrt(h-x)>=b+1 and1+rho(h-x)>=b+1. The far-end costs are no smaller
than the relevant width capsb or b+1. The explicit backward updates are
therefore equal. A final physical maximum<Z and monotonicity ensure this
at EVERY earlier backward update as well.

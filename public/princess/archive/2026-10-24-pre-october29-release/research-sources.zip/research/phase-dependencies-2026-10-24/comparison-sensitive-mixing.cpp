// Adversarial scalar test for a sufficient sensitive-event corner-switch lemma.
#include <algorithm>
#include <cmath>
#include <iostream>
#include <vector>
using I=long long;
I R(I x){if(!x)return 0;I r=sqrtl((long double)x);while(r*r<x)++r;while((r-1)*(r-1)>=x)--r;return r;}
I rho(I x){I r=(sqrtl(4.0L*x+1)-1)/2;while(r*(r+1)<x)++r;while(r&&(r-1)*r>=x)--r;return r;}
I F(I x,I k){return x+k-R(x+k);}I G(I x,I k){return x+k-rho(x+k);}
I down(I x){I r=R(x);return x>r*(r-1)?x:(r-1)*(r-1);}
I up(I x){I r=R(x);return std::max(x,r*(r-1)+1);}
int main(int argc,char**argv){
 for(int z=1;z<argc;++z){I k=std::stoll(argv[z]),H=(k-1)*(k-2);std::vector<std::pair<I,I>> p={{0,0}};
  while(std::max(p.back().first,p.back().second)<=H+k){auto [a,b]=p.back();auto q=std::make_pair(G(b,k),F(a,k));if(q==p.back())break;p.push_back(q);}
  I cases=0,maxmix=0;double maxratio=0;I wu=0,wv=0,wq=0,wa=0;
  for(I u=1;u<(I)p.size();++u){I a=down(p[u].first),ro=R(a);if(!a||ro>=k-1)continue;I x=a;
   for(I m=0;u+2*m+1<(I)p.size();++m){I v=u+2*m+1,dt=2*m+1,q=up(p[v].first+1),rn=R(q);if(rn>=k-1)break;
    if(G(x,k)>=q){I charge=q+rn-ro*(ro-1)/2; // b>=rn+1 makes ell<=ro-1
     double ratio=(double)(dt*k)/charge;
     if(ratio>maxratio){maxratio=ratio;wu=u;wv=v;wq=q;wa=a;}
     ++cases;
     if(dt*k>=charge){std::cout<<"{\"status\":\"SENSITIVE_MIXING_OBSTRUCTION\",\"k\":"<<k<<",\"u\":"<<u<<",\"v\":"<<v<<",\"oldQ\":"<<a<<",\"oldRoot\":"<<ro<<",\"newQ\":"<<q<<",\"newRoot\":"<<rn<<",\"relaxedNew\":"<<G(x,k)<<",\"ordinaryNew\":"<<p[v].first<<",\"minimum_b\":"<<rn+1<<",\"charge\":"<<charge<<",\"available\":"<<dt*k<<"}\n";return 0;}
    }
    if(x<=p[u+2*m].second){maxmix=std::max(maxmix,2*m);break;}
    x=F(F(x,k),k);
   }
  }
  std::cout<<"{\"status\":\"NO_OBSTRUCTION\",\"k\":"<<k<<",\"cases\":"<<cases<<",\"max_ratio\":"<<maxratio<<",\"u\":"<<wu<<",\"v\":"<<wv<<",\"oldQ\":"<<wa<<",\"newQ\":"<<wq<<",\"max_mix\":"<<maxmix<<"}\n";
 }
}

# Independent audit of the ordinary signed-late splice

24 October 2026. Mathematical argument accepted subject to the separately
reviewed first-quota arithmetic base. Reviewed source:
`upper-signed-late-ordinary-splice.md`.

The activation move is correctly included in the mixed suffix: the accepted
mixed profile requires both POST-inspection survivors to be proper. The
activation PRE-state may still have a full partner. Its real smaller set D
therefore has a clipped BOTH-phase capacity ceiling. Extending the mixed
comparison from gate k to 0<=c<=k is valid: whenever its reference has size
at most k it may be erased completely on the next update; if that is already
the terminal day the actual signed gate gives the required endpoint directly.

If the mixed suffix already has min V_r>=Zcap, monotonicity finishes the
clipped statement. Otherwise its clipped ceiling forces the REAL size
|D|<=min V_r. No artificial c-room solo terminal set has been introduced.
Reversing only the preceding a moves gives |S|<=k+|H_(a-1)|, and comparing
H_j at reference index r+j is the correct time convention:

    k+W_(r+a-1)=V_(r+a)=V_t.

Initialization is phase-valid. Put q=|E(D)| and M=|D|. The original surplus
of the one-shot survivor V minus D is exactly M-q; its dual hole surplus
|N(E(D))|-q can be smaller. An initial reviewer objection conflated these
two quantities and was withdrawn after checking the complement identity.
If the original surplus is zero-good, the square lower bound forces the
dual surplus to agree, giving the actual core and its phase. The own/opposite
capacity then yields respectively q<=M-rho(M) and q<=M-R(M).
Since M<=both V_r coordinates, these initialize the matching W_r coordinate.
If the actual event is nongood, its extra surplus yields the worse inverse
bound and therefore both coordinates. Tiny initial states are free because
r>=1, k>=13 and min W_r>=min P_1>=9. Core geometry then belongs to the actual
E(D), while the scalar mixing certificate applies at the genuine orbit
index r+j. This preserves the ancestry that failed under arbitrary seed boxes.

The clipping proof is complete. When the initial q is at least Dcap, its
static square inequality immediately forces max W_r>=Dcap. Otherwise the
first crossing from q<Dcap has raw target at most Dcap-1+k<=b^2, and its
square inverse gives target<=G(Dcap-1)<=b(b-1). Hence the accepted early
induction applies through that crossing; later clipped bounds are automatic.
Combining |S|<=k+|H| with Zcap=k+Dcap is legitimate for every initial |S|,
including |S|>Zcap. Entirely solo suffixes use the first-quota initial seed
at index zero, with the already stated tiny-root initialization obligation.

The physical conclusion is restricted to normalized full-origin histories,
as stated. It does not assert that an arbitrary signed partial state can be
replaced by a solo state, or that both phases dominate its initial geometry.
The exact gate, endpoint, normalization and clipping restrictions remain part
of the theorem. This audit supplies no Lean formalization.

"""Inspect primitive critical-wall locations; no theorem inferred."""
import comparison_localization_flags as f
from itertools import product
KEYS=[(i,u,j,v) for j,v in f.F for i in range(v+1) for u in range(j+1)]
def signature(b,n,T):
 w=2*b+1;out=[]
 for i,u,j,v in KEYS:
  q=f.m.band.survivor(w,n,T,i,u,j,v);r=f.m.R(T)
  p=int(i==0 and j==1 and 2<=r<=b and (r-1)*(r-2)<q<=r*(r-1) and T-q==r)
  r=f.m.rho(T)
  s=int(i==1 and j==0 and v==1 and 2<=r<=b and T-q==r and (((r-1)**2<q<=r*r) if r<b else(r*(r-1)<q<=r*r)))
  out.append((T-q-b,p,s))
 return tuple(out)
def walls(b,n):
 h=(2*b+1)*n//2;windows=[((b-1)**2-8,b*b+b+8),(h-b*b-b-8,h-(b-1)**2+8)]
 out=[]
 for lo,hi in windows:
  old=None;cuts=[]
  for T in range(lo,hi+1):
   new=signature(b,n,T)
   if new!=old:cuts.append(T)
   old=new
  out.append(cuts)
 return out
if __name__=='__main__':
 for b in(64,65,66):
  h=(2*b+1)*(b+1);a,z=walls(b,2*b+2)
  print(b,'low',[(T-b*b)for T in a]);print(b,'high',[(T-h+b*b)for T in z])

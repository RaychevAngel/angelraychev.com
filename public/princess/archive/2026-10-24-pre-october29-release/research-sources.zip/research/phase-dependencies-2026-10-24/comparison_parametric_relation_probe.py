"""SMT abstraction challenge with signed phase-gap buckets and marker caps.

This is exploration, not a certificate. False abstractions do not refute
the genuine-origin comparison. All accepted mathematical sources are frozen.
"""
from comparison_parametric_invariant_probe import *

def bucket(x):
 return z.If(x<=-3,-3,z.If(x>=3,3,x))

def phase_bounds(v,bc):
 return v<=-3 if bc==-3 else v>=3 if bc==3 else v==bc

def go(seconds=50):
 st=time.process_time();states=[];seen=set();todo=[];parents={}
 for phase in range(-3,4):
  pat=tuple(-int((phase>0 and f[0]==0)or(phase<0 and f[1]==0))for f in F)
  pat+=tuple(pat[F.index(f)]for f in[(1,0),(0,1),(0,1)])
  for r in range(4):
   state=(pat,r,phase);states.append(state);seen.add(state);todo.append(state)
   parents[state]=None
 base=[b>=32,d>=1,d<=b-3,J>=3*b+1,q>=-2*b+1,q<J+2*b-1+d]
 checked=0;counter=None
 while todo and time.process_time()-st<seconds:
  pat,r,phase=todo.pop(0)
  # Below the accepted late cap, actual physical and ordinary inputs agree.
  # Split the marker-active and inactive half spaces exactly.
  for marked in (True,False):
   pp=tuple(min(v,-int((phase>0 and f[0]==0)or(phase<0 and f[1]==0))) for v,f in zip(pat,F+[(1,0),(0,1),(0,1)])) if marked else pat
   out,qn,dn,prog=transition(pp);s=z.Solver();s.set(timeout=2500)
   s.add(*base,reg(q)==r,phase_bounds(delta,phase),*prog,qn<J+2*b-1+d)
   s.add(q<-b+d+1 if marked else q>=-b+d+1)
   while True:
    result=s.check()
    if result==z.unknown:counter={'status':'solver timeout','state':(pat,r,phase)};break
    if result==z.unsat:break
    model=s.model();op=tuple(model.eval(v).as_long()for v in out);rn=model.eval(reg(qn)).as_long();pn=model.eval(bucket(dn)).as_long()
    witness={str(v):model.eval(v).as_long()for v in[b,d,J,q,delta]}
    if max(op[:9])>0:
     trace=[];cur=(pat,r,phase)
     while cur is not None:
      trace.append(cur);cur=parents[cur]
     counter=dict(status='abstract maximum invariant false',state=(pat,r,phase),output=(op,rn,pn),parameters=witness,trace=list(reversed(trace)));break
    new=(op,rn,pn)
    if new not in seen:
     seen.add(new);states.append(new);todo.append(new);parents[new]=(pat,r,phase)
    s.add(z.Not(z.And(*[a==v for a,v in zip(out,op)],reg(qn)==rn,bucket(dn)==pn)))
   if counter:break
  checked+=1
  if counter:break
 result=dict(status='closure'if not todo and not counter else'probe incomplete or counterexample',states=len(states),checked=checked,pending=len(todo),counter=counter,CPU_seconds=time.process_time()-st)
 with open(__file__.replace('.py','.json'),'w')as f:json.dump(result,f,indent=2)
 print(json.dumps(result,indent=2))
if __name__=='__main__':go()

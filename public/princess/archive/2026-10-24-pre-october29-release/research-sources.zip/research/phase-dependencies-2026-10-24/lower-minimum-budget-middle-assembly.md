# Physical assembly of the odd minimum-budget one-day middle contract

24 October2026. Independent physical-interface review. The numerical middle
input is `comparison-minimum-budget-one-day.md`; this note does not replace
its separate symbolic-table and finite-translation certificate review.

Assume that input theorem. Let w=2b+1,n>=w be even,b>=32,k=b+1,
h=wn/2,L=(b-1)^2,A=L-1. Use the accepted ordinary head, late boundary,
head-marker and twelve-threshold necessary recurrence.

For each gate0<=c<=k, let J12(c) minimize e+t over every necessary head
first-crossing state and compatible twelve-threshold backward state:

    A<=Q<=L,        Q<=head_cap_e(feature),
    h-Q<=B_t^c(feature).

One may intersect the head with the accepted forward-feature/core envelopes;
the following argument applies to every retained candidate independently.
All actual gate-c histories supply a candidate by the existing first-cut,
physical merger and normalized signed-late arguments. Thus g_c>=J12(c).

## 1. A compatible physical prefix is only one middle day behind

Fix any retained candidate(e,t,Q,f), where f=(a,z). Since Q<=L,
max B_t>=h-L, so the middle theorem applies. Its clipping at h-A is safe
because h-Q<=h-A.

If Q>min P_e, the accepted head-marker lemma identifies an ACTUAL matching
phase p with Q<=P_e[p]. For p0, a<=1 and

    h-Q<=min(F_0(t),h-A)<=X_(t+1)[1].

For p1, z<=1 and the corresponding theorem gives
h-Q<=X_(t+1)[0]. Because the diagonal parity of an odd-by-even rectangle
is chi1, these are exactly the complementary phase coordinates in the
physical two-front adjunction. Their sums with P_e[p] are at least h.

If Q<=min P_e, both early phases suffice. The middle theorem's MAX clause
gives some X_(t+1) coordinate at least h-Q, so the same adjunction applies.

Therefore an actual physical single-cohort gate-c prefix word exists with

    P_gate(c)<=e+t+1.

Minimizing over the retained candidates proves

    P_gate(c)<=J12(c)+1.                              (1)

No head feature is chosen retrospectively without its required face, and
no equal numerical seed is treated as a physical partial state.

## 2. The terminal-quota dichotomy survives the localization flags

The initialized gate0 frontier has every ordinary and auxiliary threshold
zero. One backward update gives k in all nine ordinary coordinates and all
three auxiliary coordinates: the zero-survivor choice is present, every
corner deletion cost is at most4<k, and all source size caps exceed k.
The ordinary late pair likewise goes from(0,0) to(k,k). Thus the entire
marked gate0 evolution is precisely the gatek evolution shifted one step.
There is no possible head meeting at its initial zero frontier, because
Q<=L<h. Consequently

    J12(0)=J12(k)+1.                                  (2)

The numerical update is monotone in every ordinary/auxiliary ceiling by
the accepted minimal-surplus top-removal argument. The ordinary late
marker ceiling is also monotone in the componentwise late pair: if its
maximum rises by at least one, subtracting a possible single marker room
cannot lower the ceiling; if its maximum is unchanged, a newly larger
opposite coordinate can only remove the old unique-phase penalty, not
create a new one. Entering the M-k>=10 marker regime likewise raises the
maximum by at least one. Reaching the clipping cap removes a restriction.
Hence J12(c) is nonincreasing in c. If J=J12(k),

    J12(floor(k/2)) belongs to {J,J+1}.               (3)

## 3. Uniform two-day bracket in this family

The accepted whole-game terminal-inspection intersection gives

    T>=max(2J+1,2Jhalf),       Jhalf=J12(floor(k/2)).

Applying the actual sequential/reflected constructions to(1) gives

    T<=min(2J+4,2Jhalf+3).

If Jhalf=J, the second upper is two above the first lower. If Jhalf=J+1,
the first upper is two above the second lower. Therefore the retained
computable bracket satisfies

    U-L<=2

for every odd width2b+1 with b>=32, every even length n>=2b+1, and minimum
feasible budget k=b+1, subject to the independently verified one-day
middle certificate. Existing stronger bounds are retained. This is not
a claim of exactness for the entire family or a bounded-operation formula.

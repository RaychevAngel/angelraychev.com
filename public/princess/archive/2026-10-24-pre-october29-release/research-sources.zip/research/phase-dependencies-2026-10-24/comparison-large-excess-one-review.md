# Independent review: one middle day at large excess

24 October2026. Accepted ordinary argument in
`root-large-excess-one-middle.md`; no new formalization claim.

I checked the signed phase-difference induction directly. For a previous
nonnegative difference Delta the next lies in[-Delta,1]; for a negative
difference it lies in[0,1-Delta]. This proves the stated asymmetric interval
and the ceil(t/2) spread bound from a tied terminal quota.

The first-crossing time estimate uses a minimum-coordinate lower bound, not
an assertion that each fixed phase separately gainsd while labels swap.
Before the maximum reachesY<b², each output is at least the minimum previous
coordinate plusd; induction gives both>=c+td. At d>=b,

    Y/d <=1+((b-6)^2+6)/b=b-11+42/b.

For b>=32 its ceiling is at mostb-9. Consequently d-s>=20 at the smallest
caseb32,d32, with increasing margin thereafter.

The old accepted three-region proof can replace its initial room debt d+7
by the actual smaller debts because all its comparisons use an equal virtual
pair dominated by the real input. Six low injections plus one exit room give
debt s+7. One extra physical update suppliesd-1 globally in the minimum,
including root-wall crossings and clipping; the resulting lead>=12 pays the
conservative central3 and high7 rooms. Skipped regions only reduce the cost.

The input C is progressive under the finite-board operator: the genuine
ordinary late orbit is coordinatewise nondecreasing, and the finite-board
physical maps dominate its uncapped low-corner maps. Monotonicity therefore
permits padding from the faster necessary comparator's time to tau+1.
The exact fixed phase labels and all previous region endpoint guards remain
those of the accepted base proof.

Finally, the unchanged terminal-quota assembly with alpha1 gives gap<=2
for both width parities when2b<=k<3b. Combined with the already accepted
even-width pronic range and old high-budget result, every even width>=64
has the two-day bracket at every feasible budget. The main unresolved
unbounded family is odd width with b<k<2b; the global four-day ceiling is
not silently replaced by two.


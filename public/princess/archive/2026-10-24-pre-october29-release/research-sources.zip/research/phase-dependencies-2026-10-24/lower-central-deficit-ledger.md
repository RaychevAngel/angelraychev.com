# Central bad moves consume the same room deficit as endpoint slack

24 October2026. Local actual-history lemma submitted for independent review.
This supplies an age bound only while the stated central guards hold.

Let k=b+d and use the accepted capped early/seeded actual-hole comparison.
On an interval of integer times u,...,t suppose:

* the numerical pairs P_j and inputs to their updates are centrally affine;
* every actual target is in b^2<Q_j<U;
* Q_j>min P_j at every time in the interval.

Write M_j=max P_j and e_j=M_j-Q_j. Then e_j is a nonnegative integer.
No numerical pair can be tied. The numerical leading phase alternates,
and its gap is at most d by global interlacing and the central maps.
Consequently0<=e_j<=d-1.

If the targets at u+1,...,t are all nongood, then

    e_t >= e_u + #{j in(u,t]: phase0 is the leader at j}
        >= e_u + floor((t-u)/2).                       (1)

In particular an interval of2d such updates cannot have all its targets
nongood. If an actual full-span good frontier occurs at u and every later
target through t is nongood, its erosion age obeys

    t-u <= 2(e_t-e_u)+1 <= 2e_t+1.                    (2)

## Direct proof

The affine update is (x,y)->(y+d,x+d-1). If the new unique leader is
phase0, its preceding input y is a numerical maximum and M increases by d.
If the new leader is phase1, its preceding input x is the unique maximum
and M increases by d-1. Untied consecutive pairs therefore alternate
leaders. Every nongood actual target has original surplus at least b+1,
so Q_j<=Q_(j-1)+d-1. Subtracting proves an increment of at least one in
e on the former steps and at least zero on the latter. This is(1).

A good actual target in this size interval is necessarily a full-span
critical frontier and matches phase0. Since the target is dangerous, that
phase is the numerical leader. Thus every good event identified here
comes with its literal full-front shape and actual longitudinal end.
There is no appeal to optimality of arbitrary partial-state prefixes.

## One common-cut slack budget

Suppose at one physical cut the necessary early maximum is M_E and the
necessary late maximum is M_L, while actual holes are Q and signed mass is
m=h-Q. Define

    delta_E=M_E-Q,       delta_L=M_L-m.

Then delta_E+delta_L=M_E+M_L-h exactly. If exact physical adjunction still
fails at the proposed full horizon, but both maxima are necessary for this
actual history, their leading phases must be the incompatible same phase
(the antipodal correction is1), and

    delta_E+delta_L < min(gap_E,gap_L).                (3)

Indeed either compatible sum consists of one maximum and the other
minimum. Its strict failure says the total excess of the two maxima is
less than each gap. This assertion requires that the numerical pairs at
the cut agree with the physical prefix fronts, or have an independently
proved same-phase physical comparison; it is not true for arbitrary
unrelated numerical envelopes.

For an actual solo late reversal, let C=I union J contain the actual source
S of size m, with |I|<=k and max reference J=M_L-k. Set

    delta_J=M_L-k-|J|,       eta=|C minus S|.

Whenever the accepted necessary comparison gives delta_J>=0, the literal
union bound |C|<=k+|J| gives

    delta_J+eta <= delta_L.                           (4)

Thus the early numerical deficit, reverse-hole deficit and allowed-set
defect use ONE shared budget. For centrally affine endpoint pairs of gap
at most d, (3),(4) give delta_E+delta_J+eta<=d-1.
When the required full-span ancestors exist in the same central interval,
(2) bounds their ages by2delta_E+1 and2delta_J+1. Their actual cores or
whole-front overlap must then be compared using this coupled budget,
rather than charging all three quantities at separate worst cases.

## Limitation

The lemma does not assert that the last actual good event is already
full-span. A bad run can enter the central collar from an older localized
state; numerical room deficits can contract at the intervening root walls.
To use(2) as a full-front age bound, supply an actual good event in the
central interval, or a window of2d wholly central dangerous updates, which
forces one by(1). The global cut and those entry guards remain separate
proof obligations.

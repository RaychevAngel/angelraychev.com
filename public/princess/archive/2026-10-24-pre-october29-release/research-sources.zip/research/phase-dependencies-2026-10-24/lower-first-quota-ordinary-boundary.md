# A first smaller quota: the exact ordinary boundary interface

24 October 2026. Complete proof candidate for independent review. The
uniform small-root arithmetic base has completed successfully; the combined
physical theorem and arithmetic coverage are undergoing independent review.

Let w<=n have even area, b=floor(w/2), k>=max(13,b+1), and0<=c<=k.
Starting from full uncertainty, use at most c inspections in the first
inspection-and-movement update and at most k in every later update.
Index the resulting hole states by u=0,1,... AFTER the first update, and put

    W_0=(c-rho(c), c-ceil(sqrt(c))),
    W_(u+1)=(G_k(W_u[1]),F_k(W_u[0])).

Here F_k(x)=x+k-ceil(sqrt(x+k)), G_k(x)=x+k-rho(x+k).
The intended theorem is Q_u<=max W_u while every hole count up to u is
at most H=b(b-1), with matching coordinate control at every zero-good
event. As before, zero-good means original surplus r=ceil(sqrt(Q)),
4<=r<=b-1; the matching coordinate is determined by the actual dominant
cohort/corner. The only additional physical issue is the first state.

## 1. The unequal seed is particularly rigid

The two coordinates differ by zero or one, with coordinate0 larger.
If Q_0<=min W_0 there is already both-phase control. Otherwise the static
square bound and the first useful quota give Q_0<=max W_0, so necessarily

    Q_0=W_0[0]=W_0[1]+1=:q.

Writing r=rho(c), the strict seed gap occurs precisely when

    r²<c<=r(r+1),   q=c-r,   r(r-1)<q<=r².

Consequently the actual first state is sensitive: its original surplus
is exactly r, all its holes belong to one actual cohort and one own-corner
component, and its origin is present. For r>=4 this is the accepted
sensitive geometry. For r=1,2,3 the same conclusion follows directly:
splitting positive integer surpluses has capacity at most(r-1)²+1,
which is below q for r>=2, and a punctured own component or opposite
component has capacity at most r(r-1)<q. The case r1 is a corner singleton.
The other cohort is full, since any positive surplus there would likewise
reduce the available square capacity below q.

Thus this exceptional initial state has its correct OWN matching phase.
It is not an arbitrary one-room asymmetric seed with an unlabelled shape.

## 2. Numerical properties of the genuine seeded orbit

The seeded pair is coordinatewise nondecreasing and satisfies

    min W_(u+1)>=max W_u.

Indeed W_0 has gap at most1 and lies below k. For k>=13 both first scalar
increments there are greater than1, so H_k(W_0)>=W_0. Monotonicity then
gives coordinatewise time monotonicity. F_k,G_k are inflationary on their
common invariant interval[0,k(k-1)], which contains W_0; together these
give the displayed interlacing. Also W_u>=P_u for the empty-origin pair.

For a dangerous seed q in one coordinate gap of W_u, put r=ceil(sqrt(q))
and e=q-min W_u. The exact inverse identity and interlacing give e<=k-r.
The oriented gap induction from the initial gap1 gives

    |W_u[0]-W_u[1]|<=ceil((u+1)/2).

As in `lower-zero-good-mixing-large-roots.md`, splitting at k=7r/4 and
using the lower drift before r² therefore yields, for r>=20,

    e<=3r/4+1.

The exact two-step inequality B_k² reduces mismatch by one. Every actual
zero-good core of root r>=100 satisfies

    R_core-1>=2r-4-4sqrt(r)>=3r/2+2>=2e.

Hence all large-root seeded mixing inequalities are proved uniformly.
For u>=1 and r4..99, W_u>=P_u forces k<=r²+r<=9900 whenever a dangerous
seed exists. The complete finite arithmetic base in `comparison-first-quota-finite.cpp`
checks every0<=c<=k, every relevant u and both phases:41944610 dangerous
seeds in24745740 nonvacuous initial-quota orbits, with minimum core-time
margin0. It prunes only when time/initial-quota monotonicity makes every
later seed vacuous. Its root functions are corrected to exact integer
values before use. No arbitrary-origin relaxation is being substituted.

At u0 no finite base is needed for r>=4. The only dangerous state is
the own-sensitive q above, its core has radius at least2, and exactly

    B_k(q)=G_k(q-1)<=min H_k(q,q-1).

One intervening bad move therefore makes both phases available.

## 3. The tiny initial exception does not need a fictitious core

At u>=1 all tiny targets Q<=9 are below both W coordinates, since W_u>=P_u
and min P_1>=9. The only new case is the initial own-sensitive state of
root r<=3 followed by a different good identity at the very next update.

If the next target is tiny, it is already controlled. If it is critical
(root b), its F bound preserves MAX and triggers the usual permanent
critical reset. If there is an intervening true B step before the next
good target, the exact one-step mixing identity in Section2 applies.
If the next good identity is unchanged, its correct phase bound applies.

It remains to treat a different next good identity with no intermediate
step. The old own origin is an OLD hole. It cannot be in N of the new
dominant component: distinct corners are at distance at least2b-1, while
that component and its neighborhood have radii at most2b-4 and2b-3.
Nor can the old origin neighbor a possible new corner-singleton outlier:
distinct corners are not adjacent when b>=5, and a cell is not adjacent
to itself. The new good range requires b>=5. If the cohort differs, the
old hole belongs to the wrong cohort and is unusable for the same reason.

Therefore at most q-1 old holes can contribute to the entire target
neighborhood. Since N(new holes) is contained in old holes union probes,
the target satisfies its exact incoming own/opposite profile with input
at most q-1+k. Both ordinary source coordinates are at least q-1. This
proves the matching target bound without any unsupported persistence of
a radius-zero core.

## 4. Physical assembly and clipping

After the initial interface, the proof of
`lower-ordinary-early-boundary-theorem.md` applies verbatim: tiny targets
reset both coordinates; critical F targets permanently dominate all later
subcritical targets in both phases; consecutive different good identities
are separated by the old core, and the seeded mixing inequality supplies
both coordinates before the final matching update. Same identities retain
their actual phase branch. Arbitrary retreats remain allowed.

The first shifted cut A=b²-k+1, if positive, still has overshoot at most H
after a k-quota update. An initial c-quota crossing is even smaller because
c<=k. Thus the all-time clipped statement at A follows as before.

This note supplies the first-quota extension, including its complete finite
arithmetic verification. It does not by itself turn a signed two-cohort
late terminal gate into a c-room solo terminal set; that joining argument
must retain the actual last-full activation and its remaining time.

# Exact accounting for overlapping backward dependencies

24 October 2026. Proposed physical identity for independent review.
This identifies the precise missing term in a causal partition into corner
processes. It does not by itself give a new capture-time bound.

Let H_(s+1)=E(H_s union I_s), H_0=empty, be one actual cohort's hole
history on an even-area rectangle. Here E takes vertices whose entire
neighborhood is in its argument, and I_s is that cohort's useful inspection
set. Let A_T,B_T be disjoint subsets of H_T. Define backwards, exactly,

    A_s=N(A_(s+1)) minus I_s,
    B_s=N(B_(s+1)) minus I_s.                       (1)

Then A_s,B_s are subsets of H_s, by induction, so A_0=B_0=empty.
These are the ACTUALLY REQUIRED uninspected ancestors, not the much larger
unpruned distance cones. They remain valid whether their components are
anchored at corners, floating, connected, or disconnected.

Write U_s=A_s union B_s and V_s=A_s intersect B_s. Define the fork set

    W_s=(N(A_(s+1)) intersect N(B_(s+1)))
         minus N(V_(s+1)).                         (2)

Its vertices neighbor each ancestry label, but none of the vertices bearing
BOTH labels at the next time. It is disjoint from N(V_(s+1)). Also put

    pA_s=|I_s intersect N(A_(s+1))|,
    pB_s=|I_s intersect N(B_(s+1))|,
    pU_s=|I_s intersect N(U_(s+1))|,
    pcap_s=|I_s intersect N(A_(s+1)) intersect N(B_(s+1))|.

Thus pA_s+pB_s=pU_s+pcap_s. The left is the daily quota that would be
charged if one reproduced the two backward histories independently; pU_s
is their actual joint useful quota. The difference is precisely shared
inspections, not every spatially overlapping hole.

## The exact intersection ledger

For a one-color set S let sigma(S)=|N(S)|-|S|. Then at every step,

    pcap_s = |V_(s+1)|-|V_s| + sigma(V_(s+1)) + |W_s|.   (3)

Indeed intersections distribute over deletion by the SAME I_s, hence

    V_s=(N(A_(s+1)) intersect N(B_(s+1))) minus I_s.

The neighborhood intersection is the disjoint union N(V_(s+1)) union W_s.
Taking cardinalities proves(3). In an even-area rectangle sigma(S)>=0
for every one-color S, by its perfect matching.

Since the terminal targets are disjoint and the initial holes are empty,
V_T=V_0=empty. Summing(3) gives the exact closed-history identity

    sum_s pcap_s = sum_s sigma(V_(s+1)) + sum_s |W_s|.  (4)

There are no omitted endpoint terms and no approximation. If the right
side vanishes, the terminal histories really can be reproduced with
disjoint charged inspection quotas. If it is positive, duplicating the
histories spends exactly that many extra probes across the whole word.
Per-day quota constraints still matter; (4) is a total identity and does
not authorize moving inspection expenditure between days.

The identity also explains why simply assigning a shared ancestor to one
terminal component can fail. The missing other component requires the
intersection's whole sequence of neighborhood costs and fork production,
even though the intersection is empty at BOTH ends.

## Submodularity identifies the same term

For any two same-color sets A,B,

    sigma(A)+sigma(B)-sigma(A union B)-sigma(A intersect B)
       = |N(A) intersect N(B)|-|N(A intersect B)|.     (5)

The right side is the cardinality of the fork set and is nonnegative.
Therefore the extra expansion in the two separate ancestries is exactly
the intersection expansion plus the fork correction. Equation(4) is the
time-telescoped version of this submodularity identity.

This is an exact algebraic reconciliation, not a proof that the extra
expansion is paid by UNUSED budget in the original history. It can all
be genuine savings from shared ancestors. Any claimed independent-corner
decomposition must either eliminate these terms by a valid uncrossing,
or charge them against a separately proved room/time advantage.

## The first backward meeting

Starting from disjoint A_T,B_T, a first nonempty intersection moving
backward can only be produced by a fork: if V_(s+1)=empty, then

    V_s=W_s minus I_s.

Thus a spatial first meeting is NOT automatically a shared inspection;
it can be an already existing hole with two future descendants. Shared
inspections may only be charged at earlier times when this intersection
ancestry is eliminated. This distinction rules out a naive first-meeting
argument that charges all of W_s to that day's quota.

Floating ramps remain an issue: a fork or intersection can lie far from
all actual corners at small cardinality. The accepted dominant-component
localization applies only above its precise half-capacity threshold, so
it cannot simply be applied to V_s or W_s.

## Concrete next obligation

For near-extremal terminal corner components, prove either:

1. an uncrossing/replacement of the two ancestry histories that removes
   their intersection without increasing ANY daily total quota and preserves
   the needed terminal corner phase; or
2. a quantitative lower bound on the actual union's accumulated surplus
   that pays the duplicate-quota ledger relative to the ordinary fixed-corner
   clock, rather than only a lower bound on the total probes.

The second comparison is not supplied by(4): counting the same probe once
in an anchor-change charge and again in a profile charge would be invalid.
This note makes that missing obligation explicit without downgrading the
goal of exact bounds.

"""Nine thresholds plus exact critical-pronic square successor feasibility.

Odd width only. The extra Boolean applies only to the physically forced
square reached by the accepted critical-pronic equality transition.
"""
import comparison_marker_clock as m
from comparison_face_probe import physical
import json,time
F=m.band.FEATURES
er=m.band._geometry.er

def step(w,n,k,B,square_ok):
 b=w//2;h=w*n//2;assert w%2==1 and n%2==0 and w<=n
 sq=b*b;pr=b*(b-1)
 raw={(i,u,j,v):m.band.survivor(w,n,B[j,v],i,u,j,v)
      for j,v in F for i in range(v+1)for u in range(j+1)}
 # One step from the flagged exact square: every next own corner is absent.
 sqcap=k+max([0]+[raw[i,u,j,v]for i,u,j,v,cost in er.OPTIONS[1,0]if cost<=k and j==0 and v<=1])
 next_square=sq<=sqcap
 caps=dict(raw)
 if not square_ok and B[1,0]==sq:
  for u in range(2):
   key=(0,u,1,0)
   if caps[key]==pr:caps[key]=pr-1
 out={(c,e):min(h-4+c+e,k+max([0]+[caps[i,u,j,v]
      for i,u,j,v,cost in er.OPTIONS[c,e]if cost<=k]))for c,e in F}
 return out,next_square

def frontier(w,n,k,c):
 b=w//2;h=w*n//2;L=(b-1)**2;cap=min(L+k,b*b+1)
 B={f:min(c,h-4+sum(f))for f in F};V=(c,c);square_ok=b*b<=c;t=0
 while True:
  M=max(V)
  if M<cap:
   B={f:min(q,M-int(M-k>=10 and((V[0]>V[1]and f[0]==0)or(V[1]>V[0]and f[1]==0))))for f,q in B.items()}
   square_ok=square_ok and b*b<=M
  yield t,B,square_ok,V
  B,square_ok=step(w,n,k,B,square_ok);V=m.late_step(V,k);t+=1

def evaluate(w,n,k,c,head_data=None):
 from comparison_forward_marker import heads
 h=w*n//2
 A,L,rows,stable=head_data or heads(w,n,k)
 remaining=list(range(len(rows)));wins=[]
 for t,B,square_ok,V in frontier(w,n,k,c):
  nxt=[]
  for i in remaining:
   e,P,caps=rows[i];matches=[f for f,q in caps.items()if q+B[f]>=h]
   if matches:wins.append(dict(head_time=e,back_time=t,total=e+t,features=matches,head_pair=P))
   else:nxt.append(i)
  remaining=nxt
  if not remaining:break
 return dict(w=w,n=n,k=k,c=c,gate_lower=min(z['total']for z in wins),wins=wins)

def face_probe(w,n,k,c):
 b=w//2;h=w*n//2;chi=(w+n-2)%2;L=(b-1)**2;A=L-(k-b)
 X=(c,c);worst=[-h]*3;witness=[None]*3
 for t,B,E,V in frontier(w,n,k,c):
  Y=physical(w,n,k,X)
  faces=[max(q for f,q in B.items()if f[p]<=1)for p in(0,1)]
  diffs=[min(faces[0],h-A)-Y[chi],min(faces[1],h-A)-Y[1-chi],min(max(B.values()),h-A)-max(Y)]
  if max(B.values())>=h-L and min(B.values())<=h-A:
   for j,z in enumerate(diffs):
    if z>worst[j]:worst[j]=z;witness[j]=dict(t=t,B=[B[f]for f in F],X=X,Y=Y,square_ok=E)
  if max(B.values())>=h:break
  X=Y
 return dict(w=w,n=n,k=k,c=c,worst=worst,witness=witness)

if __name__=='__main__':
 start=time.process_time();rows=[]
 for w,n,k in[(127,128,64),(81,162,41),(419,420,210)]:
  hd=None
  for c in(k,k//2):
   row=dict(clock=evaluate(w,n,k,c,hd),face=face_probe(w,n,k,c));rows.append(row)
   print(w,n,k,c,row['clock']['gate_lower'],row['face']['worst'],flush=True)
 with open(__file__.replace('.py','.json'),'w')as f:json.dump(dict(status='new necessary-operator diagnostic, review pending',rows=rows,CPU_seconds=time.process_time()-start),f,indent=2)

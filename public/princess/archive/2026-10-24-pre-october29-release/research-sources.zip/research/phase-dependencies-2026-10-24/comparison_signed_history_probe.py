"""Preserve the initial signed phase gap through a parametric SMT challenge.

Exploration only; this records an exact affine expression for the phase gap,
instead of allowing its magnitude to change between abstract states.
"""
from comparison_parametric_relation_probe import *
eta=z.Int('eta')
INF=1000000
def intersect_phase(lo,hi,a,c,bc):
 l,h=(-INF,-3)if bc==-3 else(3,INF)if bc==3 else(bc,bc)
 if a==1:l,h=l-c,h-c
 else:l,h=c-h,c-l
 return max(lo,l),min(hi,h)
def go_signed(seconds=65):
 st=time.process_time();todo=[];seen=set();parents={};checked=0;counter=None
 for bc in range(-3,4):
  pat=tuple(-int((bc>0 and f[0]==0)or(bc<0 and f[1]==0))for f in F)
  pat+=tuple(pat[F.index(f)]for f in[(1,0),(0,1),(0,1)])
  lo,hi=intersect_phase(-INF,INF,1,0,bc)
  for r in range(4):
   state=(pat,r,bc,1,0,lo,hi);todo.append(state);seen.add(state);parents[state]=None
 base=[b>=32,d>=2,d<=b-3,J>=3*b+1,q>=-2*b+1,q<J+2*b-1+d,eta>=-d-2,eta<=d+2]
 while todo and time.process_time()-st<seconds:
  state=todo.pop(0);pat,r,phase,a,c,lo,hi=state
  for marked in(True,False):
   pp=tuple(min(v,-int((phase>0 and f[0]==0)or(phase<0 and f[1]==0)))for v,f in zip(pat,F+[(1,0),(0,1),(0,1)]))if marked else pat
   out,qn,dn,prog=transition(pp)
   # Commit the genuine late marker at arrival, before abstracting position.
   # Deferring it to the next state would let an arrival below the marker
   # ceiling teleport above that ceiling without receiving its clamp.
   out=[z.If(qn<-b+d+1,
             z.If(v <= -z.If(z.Or(z.And(dn>0,f[0]==0),z.And(dn<0,f[1]==0)),1,0),
                  v,-z.If(z.Or(z.And(dn>0,f[0]==0),z.And(dn<0,f[1]==0)),1,0)),v)
        for v,f in zip(out,F+[(1,0),(0,1),(0,1)])]
   s=z.Solver();s.set(timeout=1500)
   s.add(*base,reg(q)==r,phase_bounds(delta,phase),delta==a*eta+c,eta>=lo,eta<=hi,*prog,qn<J+2*b-1+d)
   s.add(q<-b+d+1 if marked else q>=-b+d+1)
   next_min=qn-q-z.If(dn>=0,dn,-dn)
   clipped=z.If(max(pp[:9])+q<J+2*b-1+d,max(pp[:9]),J+2*b-1+d-q)
   s.push();s.add(q+max(pp[:9])>=J+2*b-1,clipped>next_min)
   if s.check()==z.sat:
    md=s.model();counter=dict(status='abstract terminal minimum relation false',state=state,parameters={str(v):md.eval(v).as_long()for v in[b,d,J,q,delta,eta]},clipped=md.eval(clipped).as_long(),next_min=md.eval(next_min).as_long());break
   s.pop()
   while time.process_time()-st<seconds:
    result=s.check()
    if result==z.unknown:counter={'status':'solver timeout','state':state};break
    if result==z.unsat:break
    md=s.model();op=tuple(md.eval(v).as_long()for v in out);rn=md.eval(reg(qn)).as_long();pn=md.eval(bucket(dn)).as_long();diff=md.eval(dn+delta).as_long()
    an,cn=-a,-c+diff;ln,hn=intersect_phase(lo,hi,an,cn,pn)
    assert ln<=hn
    if max(op)>8 or min(op)<-12 or abs(cn)>30:counter=dict(status='abstract offset escaped',state=state,output=(op,rn,pn,an,cn,ln,hn));break
    new=(op,rn,pn,an,cn,ln,hn)
    if new not in seen:seen.add(new);todo.append(new);parents[new]=state
    s.add(z.Not(z.And(*[x==v for x,v in zip(out,op)],reg(qn)==rn,bucket(dn)==pn,dn+delta==diff)))
   if counter:break
  checked+=1
  if counter:break
 if counter and 'state'in counter:
  cur=counter['state'];trace=[]
  while cur is not None:trace.append(cur);cur=parents.get(cur)
  counter['trace']=list(reversed(trace))
 result=dict(status='closure'if not todo and not counter else'incomplete signed-history challenge',states=len(seen),checked=checked,pending=len(todo),counter=counter,CPU_seconds=time.process_time()-st)
 with open(__file__.replace('.py','.json'),'w')as f:json.dump(result,f,indent=2)
 print(json.dumps(result,indent=2))
if __name__=='__main__':go_signed()

# Ordinary early boundary necessity with no phase reset

24 October 2026. Complete physical theorem submitted for independent review.
The proof combines exact corner-core persistence with a uniform algebraic
mixing lemma and an independently checked finite arithmetic base. It is not
new Lean coverage and is not by itself a full capture-time classification.

Let w<=n, wn even, b=floor(w/2), h=wn/2, and k>=max(13,b+1). Let Q_t
be the TOTAL holes of the two actual parity cohorts after t unsuccessful
inspection-and-movement updates from full initial uncertainty. Each day
uses at most k inspections, with any strategy and arbitrary retreats.
Put H=b(b-1). Define the genuine ordinary quadrant pair by

    P_0=(0,0),
    P_(t+1)=(G(P_t[1]),F(P_t[0])),
    G(x)=x+k-rho(x+k),
    F(x)=x+k-ceil(sqrt(x+k)).

**Theorem.** If Q_j<=H for every0<=j<=t, then

    Q_t<=max P_t.                                      (1)

Moreover, at every zero-good event u<=t, meaning

    4<=r=ceil(sqrt(Q_u))<=b-1,
    original total survivor surplus sigma_u=r,

the accepted unique dominant actual cohort/corner has a phase p (own0,
opposite1), and the stronger MATCHING inequality holds:

    Q_u<=P_u[p].                                      (2)

No change of initial corner convention is inserted for free. No compression
of arbitrary partial states to a fixed prefix is assumed. Polarization is
not needed: the actual dominant cohort is included in the identity tracked
below.

## 1. The numerical and physical ingredients

The ordinary pair is coordinatewise nondecreasing and satisfies

    min P_(j+1)>=max P_j.                             (3)

This follows from monotone iteration from zero and inflationarity of F,G
on their invariant interval[0,k(k-1)]. The exact root interlacing gives

    B(x):=x+k-1-rho(x+k-1)=G(x-1)<=F(x)<=G(x).          (4)

At every actual step, useful quota and ORIGINAL total surplus satisfy

    Q_(j-1)+k>=Q_j+sigma_j.

For Q_j<=H, the accepted small/co-small separation gives
sigma_j>=ceil(sqrt(Q_j)). In particular:

* A subcritical target with4<=r<=b-1 which is not zero-good has sigma>=r+1,
  and exact inversion gives Q_j<=B(Q_(j-1)).
* A target with r=b has1+rho(Q_j)<=b<=sigma_j, since Q_j<=b(b-1), and
  therefore Q_j<=F(Q_(j-1)).
* A target with r<=3 has Q_j<=9<=min P_j for j>=1, because
  min P_1=k-ceil(sqrt(k))>=9.

The critical-root assertion only uses F; it is NOT mistakenly treated as
a B-bad step.

At a zero-good event, the accepted total own/opposite profile gives the
correct incoming map G or F, including the possible one-hole outlier.
Its dominant component contains a raw full corner core of certified radius
R(q,p), as specified in `upper-zero-good-core-persistence.md`. If a later
zero-good event has a different dominant cohort/corner, its time separation
is at least R(q,p), across arbitrary intermediate history.

The uniform arithmetic mixing statement is

    q<=P_u[p] and q>min P_u
      implies B^(R(q,p)-1)(q)<=min P_(u+R(q,p)-1).      (5)

For roots r>=100 this is proved analytically in
`lower-zero-good-mixing-large-roots.md`: two B steps lower the mismatch
by one, actual ordinary mismatch is at most3r/4, and the core lasts long
enough. For roots4..99, the analytic reduction forces13<=k<=9900. The
complete integer certificate `root-zero-good-finite-base.py/.json` checks
all100105 relevant seeds (all times, both phases and all q in the gap).
The independent implementation/review in `comparison-finite-base-review.json`
reproduces those counts and every inequality. This is a finite arithmetic
base for a uniform theorem, not a finite collection of board results.
The minimum core is used when the own triangle-plus-singleton case is possible.

Once a B orbit is below both coordinates, it stays below both under further
B steps by(4). Likewise, after a genuine good target is controlled in its
matching phase, following its SAME actual cohort/corner through a B step
preserves matching control: the physical relative phase flips, and B is no
larger than either of the correct maps F,G.

## 2. Tiny and critical targets are genuine resets

A tiny target Q_j<=9 is already below BOTH ordinary coordinates. Until the
next good event, B and F steps preserve this two-phase domination. The next
good event can therefore choose its actual matching incoming map.

If a critical target first occurs, Q_j>(b-1)². Its F-bound preserves MAX
control from the preceding time. By(3),

    min P_(j+1)>=max P_j>=Q_j>(b-1)².

Both coordinates remain above(b-1)² forever afterward. Thus EVERY subsequent
subcritical target is trivially below both phases; every subsequent critical
target preserves MAX control by its F-bound. This remains valid through any
number of retreats and returns. In particular no large-root phase label is
reset on the basis of an unproved monotonicity of the actual hole count.

Consequently it suffices to analyze a segment between good events with no
tiny or critical target in its interior. Every intermediate target there
is a true B-bad step.

## 3. Matching control at every good event

Before the first good event, all nontrivial steps are B or F, both dominated
by the smaller ordinary map F; tiny events reset both. Starting from0,
both ordinary coordinates therefore dominate the actual count until that
first good event. Its actual own/opposite profile proves(2).

Now let u<v be consecutive zero-good events, assuming(2) at u. Tiny or
critical targets in between are already handled by Section2. Otherwise
write Delta=v-u; all Delta-1 intermediate targets obey B.

If the two good identities coincide, follow the ordinary branch fixed by
that actual cohort/corner. Its phase flips once each actual day, exactly
as the ordinary pair recurrence requires. Every B step is no larger than
its appropriate F or G map, and the final good step uses its exact matching
profile. This proves(2) at v.

If the identities differ, persistence gives Delta>=R(Q_u,p_u). If Q_u was
already below BOTH P_u coordinates, the intervening B steps keep it there.
Otherwise apply(5), then continue with B for any remaining intermediate
steps. In either case

    Q_(v-1)<=min P_(v-1).

The final good step is therefore bounded by its actual matching ordinary
coordinate, proving(2) at v. No uncharged rewind or free phase switch occurs:
the old physical core prevents the new identity until the bad-step dynamics
have made BOTH ordinary phases available at the actual elapsed time.

This proves(2) inductively. Between good events the followed B branch also
bounds the total count by max P; the tiny and critical cases preserve that
bound as already shown. Hence(1) holds at every time claimed.

## 4. Exact first-cut consequence, including the overshoot

Write d=k-b>=1 and choose the standard shifted early threshold

    A=H-d+1=b²-k+1,

assuming A>=1. Let tau be the FIRST time Q_tau>=A. Then

    A<=Q_tau<=H,      e_ord(Q_tau)<=tau,              (6)
    e_ord(q)=min{t:max P_t>=q}.

Indeed Q_(tau-1)<=A-1 and nonnegative total surplus gives
Q_tau<=Q_(tau-1)+k<=b². On the whole range Q<=b² the same separation
argument gives sigma>=ceil(sqrt(Q)): if sigma>=b this is automatic;
otherwise every dual component is small and their total capacity is at
most sigma². Thus

    Q_tau<=G(Q_(tau-1))<=G(A-1)=b²-rho(b²)=H.

All earlier Q_j are below A<=H, so the theorem applies through tau. This
proves the exact ordinary head clock in(6), with its actual integer overshoot.
It handles every width and length in the stated domain; A>=1 is the explicit
condition for this particular cut to be meaningful.

Equivalently, for this cut the all-time clipped inequality

    min(Q_t,A)<=min(max P_t,A)

holds: a first clipped violation must have every earlier count below A
while max P_t<A, and its first possible overshoot is bounded by H as above.
After the ordinary maximum reaches A the clipped inequality is tautological.
This does not claim an ordinary bound on arbitrary larger hole counts;
the known moving-corner counterexamples beyond the boundary remain valid.

## Evidence and remaining scope

The core geometry, the large-root analytic mixing and the complete finite
base have independent reviews. The combined physical assembly in this note
is submitted for an additional independent attack, particularly the time
indices, neutral critical steps and first-cut clipping.

The result establishes the genuine early boundary necessity for k>=13.
It does NOT establish the late signed two-cohort boundary theorem from an
arbitrary terminal gate, the compatible middle phase on every short board,
or the full rectangular capture-time formula. Those obligations remain
separate, with no change to the final zero-gap objective.

"""Challenge a phase-resolved one-day comparison; diagnostics are not proofs."""
import comparison_marker_clock as m
import json,time
def physical(w,n,k,X):
 b=w//2;h=w*n//2;chi=(w+n-2)%2;out=[]
 for p in(0,1):
  T=X[1-p]
  if T==h:out.append(h);continue
  low=m.rho(T)if p==0 else m.R(T)
  high=m.R(h-T)if p==1-chi else 1+m.rho(h-T)
  out.append(min(h,k+T-min(low,b+(w%2)*p,high)))
 return tuple(out)
def probe(w,n,k,c):
 b=w//2;h=w*n//2;chi=(w+n-2)%2;L=(b-1)**2;A=L-(k-b)
 B={f:min(c,h-4+sum(f))for f in m.band.FEATURES};V=(c,c);X=(c,c);t=0;worst=[-h]*3;witness=[None]*3
 while max(B.values())<h:
  M=max(V)
  if M<min(L+k,b*b+1):
   B={f:min(q,M-int(M-k>=10 and((V[0]>V[1]and f[0]==0)or(V[1]>V[0]and f[1]==0))))for f,q in B.items()}
  Y=physical(w,n,k,X)
  faces=[max(q for f,q in B.items()if f[p]<=1)for p in(0,1)]
  diffs=[min(faces[0],h-A)-Y[chi],min(faces[1],h-A)-Y[1-chi],min(max(B.values()),h-A)-max(Y)]
  # Only entrance-relevant ranks: residual in[h-L,h-A].
  if max(B.values())>=h-L and min(B.values())<=h-A:
   for j,z in enumerate(diffs):
    if z>worst[j]:worst[j]=z;witness[j]=dict(t=t,B=[B[f]for f in m.band.FEATURES],X=X,Y=Y,faces=faces)
  B=m.band.step(w,n,k,B);V=m.late_step(V,k);X=Y;t+=1
 return dict(w=w,n=n,k=k,c=c,worst=worst,witness=witness)
if __name__=='__main__':
 st=time.process_time();rows=[]
 for w,n,k in[(127,128,64),(419,420,210),(400,402,202),(81,162,41),(96,96,50),(65,66,34),(2001,2002,1001)]:
  for c in(k,k//2):
   z=probe(w,n,k,c);rows.append(z);print(w,n,k,c,z['worst'],flush=True)
 with open(__file__.replace('.py','.json'),'w')as f:json.dump(dict(status='targeted counterexample search, no theorem',rows=rows,CPU_seconds=time.process_time()-st),f,indent=2)

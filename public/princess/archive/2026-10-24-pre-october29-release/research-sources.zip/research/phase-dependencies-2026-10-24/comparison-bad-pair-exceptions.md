# Exact two-step bad-map loss and its square exceptions

24 October 2026. Ordinary algebraic lemma proposed for independent review.
Let k>=2 and, on nonnegative inputs, put

    F(x)=x+k-R(x+k), G(x)=x+k-rho(x+k),
    B(x)=x+k-1-rho(x+k-1),

where R=ceil(sqrt) and rho(z)=min{r>=0:z<=r(r+1)}. The map B is the exact
inverse of q+R(q)+1<=x+k, hence an upper bound for a non-zero-good target
whose original surplus is at least R(q)+1.

## One-step differences

Let z=x+k. Direct square/pronic inversion gives

    G(x)-B(x) = 0 if z=s(s+1)+1 for an integer s>=0,
                1 otherwise.                            (1)

Also F(x)-B(x) belongs to{0,1}. It is zero on the lower half of a square
root bin and at the first integer immediately above its pronic threshold;
it is one elsewhere. Whenever G(x)=B(x), its common output is s².

Both B and F,G are nondecreasing. Thus

    B²(x) <= min(F(G(x)),G(F(x))).                       (2)

The equality cases are exact:

    B²(x)=F(G(x)) iff G(x)=B(x) AND F(B(x))=B(B(x));    (3)
    B²(x)=G(F(x)) iff F(x)=B(x) AND G(B(x))=B(B(x)).    (4)

In particular EVERY exception to the strict inequality

    B²(x) <= min(FG(x),GF(x))-1

has a perfect square among its two B outputs B(x),B²(x).

To prove necessity in(3), if G(x)=B(x)+1 then F may only erase that unit
at a flat of F. Such a flat has B(x)+k=s², and at that input F-B=1 by(1)
and R(s²)=rho(s²)=s. Hence even after the flat the outer B output is
strictly smaller. The analogous possible flat of G in(4) has
B(x)+k=s(s+1); there too G-B=1, so it cannot produce equality. The remaining
cases are precisely(3),(4). Sufficiency is immediate by substitution.

## A root-visit counting consequence, without a false credit assumption

Suppose x_0=q and x_(j+1)=B(x_j), and this trajectory is STRICTLY increasing
through j=2m. Compare it with either ordinary two-step phase trajectory
z_(j+2)=FG(z_j) or GF(z_j), with z_0<=q. If the positive difference has
not already vanished, monotonicity and1-Lipschitzness give a decrease of at
least one for each nonexceptional B pair. More explicitly,

    (x_(2m)-z_(2m))_+
       <= max(0, q-z_0-m+E),                            (5)

where E counts exceptional pairs among the m disjoint pairs of B steps.
Once the difference vanishes it stays nonpositive by(2).

Every such exceptional pair contains a distinct perfect-square B output:
the pairs use disjoint output times, and strict increase prevents revisiting
a square. Therefore a conservative bound is

    E <= floor(sqrt(x_(2m)))-floor(sqrt(q))+1.            (6)

Equations(5),(6) account for root-wall losses explicitly. They do NOT assume
one permanent room of credit is earned on every pair, nor do they ignore
contraction of a previously accumulated lead. If the B orbit stalls, one
must stop this strict-increase argument there; repeated appearances of the
same square must not be counted as distinct roots.

## Remaining task

This converts the proposed physical core delay into an exact scalar target:
use the available number of B pairs, the initial ordinary phase discrepancy,
and the attained root to force the right side of(5) to zero. Parent has tested
this conclusion directly on genuine ordinary origins, but a uniform bound
on these three correlated quantities is not proved here. The stronger F-only
sensitive comparator and the all-zero-good B comparator remain different
claims. This lemma alone does not improve the accepted eight-day ceiling.

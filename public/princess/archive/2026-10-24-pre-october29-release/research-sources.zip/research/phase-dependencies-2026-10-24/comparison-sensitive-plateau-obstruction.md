# A uniform plateau obstruction to the sensitive-only scalar comparison

24 October 2026. Exact algebraic counterfamily. It is NOT a physical strategy
or a counterexample to the retained capture bounds. It identifies information
lost by retaining only sensitive endpoints and their single endpoint charge.

Use F(x)=x+k-ceil(sqrt(x+k)), G(x)=x+k-rho(x+k),
H(x,y)=(G(y),F(x)). Take ANY integer k>=12 divisible by4, and put

    b=k-1, q=(k-3)^2-1, B=k²-5k+4,
    Delta=k/2+1 (odd), z=B+5=k²-5k+9.

Then

    H^Delta(q,q-1)=(z-1,z),
    G(F^(Delta-1)(q))=z.                              (1)

Thus an old own-phase target q, followed by nonsensitive worst-phase steps
and a final sensitive update, permits one room more than the new own phase
of the ordinary reference.

## Exact evaluation

Throughout x<=B in the displayed interval, F(x)=x+2. At x>B, while
x<=B+4, F(x)=x+1. Throughout the needed interval G(x)=x+2.
Consequently F^(k/2-1)(q)=B+2, F^(k/2)(q)=B+3, and the final G givesB+5.

Before the square wall, both coordinates of H translate by2 and swap.
At j=k/2-2 (even) their pair is(B,B-1); at j+1 it is(B+1,B+2).
The next two pairs are(B+4,B+2) and(B+4,B+5), proving(1).
All root/rho assertions follow by comparison with the consecutive square
(k-2)^2 and pronic(k-2)(k-1); the lower endpoint for rho is
(k-3)(k-2)=B+2. The smallest k12 satisfies every endpoint inequality.

## Both endpoints and the exact accepted charge are admissible

The old target has root r=k-3 and lies strictly above r(r-1).
The new target has root s=k-2 and equals s(s-1)+3. Both are in their
sensitive upper square half-bins, with s<b. For opposite-color adjacent
corners and the same cohort, the accepted phase-aware matching lens uses

    ell=max(0,r+s-b)=k-4,
    Delta*k >= z+s-tri(ell), tri(a)=a(a+1)/2.

The required right side is exactly(k²-k)/2+1, while the available quota is
Delta*k=k²/2+k. Hence the scalar counterfamily satisfies the endpoint charge
with excess3k/2-1. A stronger bound on the initial phase span cannot repair
this: the starting pair already has span ONE.

## The missing physical history is visible inside the plateau

Nearly every intervening F update attains surplus s=k-2 with target in
s's LOWER half-bin. These are nonsensitive, but they ARE zero-slack good
states. Except for the first bin endpoint, their complete hole set lies in
one actual corner component by the accepted rigidity theorem. The final
pre-sensitive F step instead has surplus s+1.

Therefore the F-only abstraction has discarded a long sequence of localized
intermediate corner labels. It allows the old corner convention to change
over Delta days even though consecutive zero-slack intermediate states may
forbid that relocation. Retaining all zero-slack good events, or the broader
C4 good history, is necessary to exploit this information. An endpoint lens
bound and an O(sqrt(k)) ordinary phase-span bound alone cannot settle the
proposed sensitive-only induction.

## Actual ordinary-zero-origin checks

The local starting pair is not asserted reachable from zero for every k.
It IS reached at k20, elapsed49, and at k10000, elapsed147943. In both
cases Delta=k/2+1 yields exactly the one-room failure in(1). Variants with
starting span2 or3 occur at k200,1000,2000. These literal diagnostics are
saved in comparison-sensitive-mixing.json; no physical realizability of
the corner-switch history is inferred.

// Independent exhaustive reimplementation: enumerate roots before phase/size;
// compute bad updates from the defining inequality by integer binary search.
#include <algorithm>
#include <cmath>
#include <iostream>
#include <vector>
using I=long long;
I rt(I x){I z=sqrtl(x);while(z*z<x)++z;while(z>0&&(z-1)*(z-1)>=x)--z;return z;}
I pr(I x){I lo=0,hi=rt(x);while(lo<hi){I mid=(lo+hi)/2;if(mid*(mid+1)>=x)hi=mid;else lo=mid+1;}return lo;}
I bad(I x,I k){I lo=0,hi=x+k;while(lo<hi){I mid=(lo+hi+1)/2;if(mid+rt(mid)+1<=x+k)lo=mid;else hi=mid-1;}return lo;}
I invtri(I d){I m=0;while((m+1)*(m+2)/2<=d)++m;return m;}
int main(){I total=0,globalmin=999,steps=0;std::cout<<"{\"counts\":[";
for(I k=13;k<=9900;++k){I cap=std::min<I>(9801,(k-2)*(k-2)),count=0,margin=999;std::vector<std::pair<I,I>> P={{0,0}};
auto next=[&](){auto [a,b]=P.back();P.push_back({b+k-pr(b+k),a+k-rt(a+k)});};
while(std::min(P.back().first,P.back().second)<cap)next();I last=P.size()-1;for(int j=0;j<200;++j)next();
for(I u=1;u<last;++u){for(I r=4;r<=std::min<I>(99,k-2);++r){for(I p=0;p<2;++p){I own=p?P[u].second:P[u].first,other=p?P[u].first:P[u].second;I lo=std::max<I>((r-1)*(r-1)+1,other+1),hi=std::min<I>(own,r*(r-p));for(I q=lo;q<=hi;++q){I core=2*r-2-p-2*invtri(r*(r-p)-q);if(p==0&&q==(r-1)*(r-1)+1)core=std::min(core,2*r-4);I x=q,j=0;while(x>std::min(P[u+j].first,P[u+j].second)&&j<core){x=bad(x,k);++j;++steps;}if(j>core-1){std::cerr<<"FAIL "<<k<<" "<<u<<" "<<p<<" "<<q<<" "<<core<<" "<<j<<"\n";return 1;}margin=std::min(margin,core-1-j);++count;}}}}
if(k>13)std::cout<<",";std::cout<<count;total+=count;globalmin=std::min(globalmin,margin);
}std::cout<<"],\"seeds\":"<<total<<",\"minimum_margin\":"<<globalmin<<",\"bad_steps\":"<<steps<<"}\n";}

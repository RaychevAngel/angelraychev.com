# Actual phase continuity through the odd critical collar

24 October 2026. Complete ordinary physical theorem submitted for independent
review. The analytic statement below preserves actual longitudinal-side and
cohort labels; it is not a full capture-time classification.

Let w=2b+1, n=2ell>=w, h=(2b+1)ell and k=b+d, where

    d>=1,                  b>=max(200,4d+8).

Put L=(b-1)^2 and U=h-b(b+1). Let Q_t be the total actual holes after t
unsuccessful inspection-and-movement updates from full uncertainty. Assume
Q_j<U for every0<=j<=t. Define

    Gc(x)=max(x+k-rho(x+k), x+d),
    Fc(x)=max(x+k-ceil(sqrt(x+k)), x+d-1),
    Pc_0=(0,0),            Pc_(j+1)=(Gc(Pc_j[1]),Fc(Pc_j[0])).

Then

    Q_t<=max Pc_t.                                         (1)

Call an actual target good if either

* 4<=r=ceil(sqrt(Q))<=b-1 and its original total surplus is r; or
* L<Q<U and its original total surplus is b.

At every good event, its actual dominant cohort and longitudinal end define
a relative phase p: p0 when that end's two corners have the cohort's current
color, p1 otherwise. A full-span frontier has its actual near end. The
stronger conclusion is

    Q_t<=Pc_t[p]                                           (2)

at every good event. Short-axis corner changes at the SAME longitudinal end
preserve this phase and need not be excluded.

## 1. Physical targets and the capped numerical maps

Write sigma for the ORIGINAL sum of the two cohort survivor surpluses.
Useful inspections give Qprev+k>=Q+sigma. Because Q<U, the accepted
small/co-small separator excludes a co-small hole component whenever
sigma<=b: such a component already has at least h-b(b+1) holes. The dual
hole surpluses sum to at most sigma.

For Q<=L this gives sigma>=ceil(sqrt(Q)); for Q>L it gives sigma>=b.
At a subcritical good event the existing original-surplus concentration
and raw-core theorem applies. At a critical good event Q>L, the dual
surplus sum equals b: a smaller sum would give at most(b-1)^2 holes.
If two positive cohorts or corner components occur, both have subcritical
positive surplus, and their total area is at most L+1. Equality is the
rigid own-(b-1)-triangle plus a different own-corner singleton. Otherwise
there is one actual hole cohort, the other cohort has no holes, and the
actual support has surplus b. The accepted critical dichotomy
`lower-critical-core-or-frontier.md` therefore applies literally.

The critical alternatives are a localized own support, a localized opposite
support, the rigid singleton exception, or a full-span oriented frontier.
Their exact phase capacities imply the following incoming costs:

    own phase:      min(ceil(sqrt(Q)),b),
    opposite phase: min(1+rho(Q),b+1).

For a critical opposite support Q<=b(b-1); a full-span frontier is own-phase
at its actual near end. The corresponding inverse maps are exactly Gc and
Fc. No phase is freely reselected in these bounds.

Every nontiny nongood target has surplus at least
min(ceil(sqrt(Q)),b)+1 and hence obeys

    Q<=Bc(Qprev),              Bc(x)=Gc(x-1).             (3)

The same inverse identity holds across the cap, since
Bc(x)=max(x+k-1-rho(x+k-1),x+d-1). A tiny target Q<=9 is below both Pc
coordinates at any positive time: k>=13 and min Pc_1>=k-ceil(sqrt(k))>=9.

## 2. Every critical good event has a long actual core

For a full-span frontier let a_i be its majority-fiber lengths,0<=i<=b,
and m=max(a_0,a_b). Adjacent majority lengths differ by at most one, so

    a_i<=m+min(i,b-i).

Each minority length is bounded by its two neighboring majority lengths.
Summing gives the exact elementary estimate

    Q<=(2b+1)m+b(b-1)/2.                                 (4)

An endpoint attaining m contains the full physical same-color corner ball
of radius2m-2: majority lengths are at least m-i and intervening minority
lengths at least m-i-1 when measured from that endpoint.

Since Q>L, (4) yields

    m>=ceil((b^2-3b+4)/(4b+2))>=d+2.                      (5)

For the last inequality, b>=4d+8 implies
b^2-3b+4>(d+1)(4b+2). Thus the frontier contains an actual radius at least
2d+2 core at its near end.

Localized critical alternatives have the accepted raw radii

    own:      2b-2-2mtri(b^2-Q),
    opposite: 2b-3-2mtri(b(b-1)-Q),
    singleton exception: 2b-4,

where mtri(z)=max{j:tri(j)<=z}. Their defects are at most2b-2 and b-2,
respectively. All these radii are at least2d+2 under b>=4d+8. For example,
tri(b-d-1)>2b-2 gives mtri(2b-2)<=b-d-2; the opposite defect is smaller
and gives the corresponding odd radius bound. The singleton case is direct.

## 3. Persistence forbids an unpaid change of side or cohort

Every good event therefore has an actual full corner core: use its existing
raw radius R at a subcritical event and any certified R>=2d+2 at a critical
one. Hole evolution retains the full current-color ball of radius R-j
after j further updates.

Suppose the next good event has a different actual cohort or longitudinal
end. If its time separation Delta were less than R, at least two old-cohort
cells at distance at most two from the old corner would remain.

A different dominant cohort has at most the one-hole singleton remainder,
so cannot contain these retained old-cohort holes. A localized dominant
component at the opposite longitudinal end has radius at most2b-2, whereas
the end-to-end corner distance is n-1>=2b+1. Both retained cells lie outside
it. The singleton exception again permits at most one outside hole.
Finally an opposite-end full-span frontier misses both current-color
neighbors of the old far corner: the majority far paired row is missing,
and its neighboring minority fiber has no greater length. There is no
outlier in this case. Thus every different-side/cohort good event satisfies

    Delta>=R.                                            (6)

This statement does not forbid moving between the two short-axis corners
at one end. Those corners have the same color because w is odd, so such a
move does not change the numerical phase being tracked.

## 4. Capped bad steps mix the phases

The capped maps are monotone and1-Lipschitz and satisfy

    Fc(x)<=Gc(x)<=Fc(x)+1,       Gc(x-1)<=Fc(x).

Both are inflationary on all nonnegative inputs. Their zero-origin pair is
coordinatewise nondecreasing and globally interlaced:

    min Pc_(j+1)>=max Pc_j.

Exactly as in the uncapped proof,

    Bc^2(x)<=Gc(Fc(x-1)),
    Bc^2(x)<=Fc(Gc(x-1)).                                (7)

Consequently a positive mismatch e=x-min Pc_u loses at least one room per
two bad steps, and Bc^(2e)(x)<=min Pc_(u+2e). Once below both coordinates,
further bad steps preserve that property.

For a dangerous critical good seed q>L, q<=max Pc_u<=Gc(min Pc_u), and
the exact inverse of Gc at q is q+b<=min Pc_u+k. Hence

    e<=d.                                                (8)

Its core has R>=2d+2, so the R-1 intermediate bad steps before any identity
change more than suffice for mixing.

For a dangerous subcritical seed, the large-root proof applies unchanged
to the capped pair: e<=k-r, the oriented span is at most ceil(u/2), and
Fc>=F gives the same genuine-origin time bound e<=3r/4 for r>=20.
Thus the accepted raw-core inequality R-1>=2e holds for r>=100.

It remains to justify reuse of the already accepted arithmetic base for
4<=r<=99; one must not substitute Bc for B without checking the cap.
A dangerous subcritical capped seed still has Pc_u=P_u. Indeed, at the
FIRST difference of capped and uncapped reference pairs, the previous
maximum is at least b^2-d+1>L. Global interlacing then puts the current and
all later capped minima above L, excluding every dangerous subcritical seed.

Moreover every first R-1 bad iterate from q<=r^2 is at most

    r^2+(2r-3)(k-r-1)
      <=r^2+(2r-3)(5b/4-r-3)
       <b^2-b/4+3<=b^2-d+1.                             (9)

Here r<=99 and b>=200. The middle expression increases with r; at r99
the strict difference is b^2-244b+10092, which is1292 at b200 and increases
thereafter. Bc equals B at every input at most b^2-d+1. Thus the entire
certified R-1 suffix is unchanged, while Pc remains at least the uncapped
pair. The accepted complete small-root certificate therefore gives
Bc^(R-1)(q)<=min Pc_(u+R-1) as required.

## 5. Actual-history induction

Before the first good event, every nontiny update obeys Bc and every tiny
state is controlled by both coordinates. The first good event therefore
uses its actual matching incoming map.

Between consecutive good events, tiny states reset both phases. Otherwise
all intermediate updates obey Bc. If cohort and end are unchanged, follow
the same actual relative phase: it flips each day, every bad step is bounded
by both correct incoming maps, and the final good step uses its actual map.

If cohort or end changes, (6) and Section4 put the count below BOTH ordinary
coordinates before the final good step. That final step can therefore use
its actual incoming phase without adding an elapsed day. This proves(2)
inductively. Bad and tiny targets then prove(1) at all claimed times.

## Scope

The argument covers arbitrary retreats within Q<U, every even length n>=w,
and every stated b,d. It retains an actual end/cohort label beyond the
pronic boundary instead of discarding it at root b. There is no assertion
past the upper collar U, no arbitrary-seed or signed-late extension here,
and no new formal verification claim. A clipped first-crossing corollary or
a dual late theorem needs its own explicit overshoot/initialization proof.
The b>=200 guard belongs only to the analytic reuse of the small-root
arithmetic certificate; a bounded cap-parameter certificate may remove it.

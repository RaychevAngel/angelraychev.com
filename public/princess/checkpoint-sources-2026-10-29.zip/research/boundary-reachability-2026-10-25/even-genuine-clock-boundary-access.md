# Exact dangerous boundary access from a tied-restart corridor

25 October 2026. **Conditional ordinary theorem pending independent attack.**
The physical and combinatorial reductions below use the new arbitrary-tied-
origin ordinary restart theorem as an explicit premise. They do not claim
that the restart theorem has already been accepted. Earlier dated sources
are preserved.

## 1. Domain and the restart premise

Let the rectangle have width 2b and length n>=2b, with h=bn,
k=b+d, 1<=d<=b-1, k>=13, H=b(b-1), and A=H-d+1=b^2-k+1.
Use the genuine ordinary pair

    E_0=(0,0),
    E_(j+1)=(G(E_j[1]), F(E_j[0])),
    G(x)=x+k-rho(x+k),
    F(x)=x+k-ceil_sqrt(x+k),
    rho(z)=min{r>=0:z<=r(r+1)}.

The frozen ordinary theorem gives |Q_j|<=max E_j whenever the entire
actual initial hole history remains at most H. The pair is interlaced:
min E_(j+1)>=max E_j, and G,F are monotone.

**Restart premise.** From any actual state with total hole count q_0,
initialize a numerical pair at (q_0,q_0). For any actual continuation whose
hole counts all remain at most H, its count at each time is no larger than
the maximum of this restarted ordinary pair. This applies to arbitrary
physical shapes, both cohorts, and retreats; it does not reset a real
corner label or choose a favorable phase.

The source for that premise is being developed by the odd lane in this
same dated directory. The argument below needs precisely its count
statement, not a shape normalization theorem.

## 2. An exact one-clock corridor for every preceding actual state

Suppose a full-origin actual history ends at time e with

    Q_j<=H for 0<=j<=e,
    Q_e>min E_e.

Here Q_j denotes total hole count. Then for EVERY 1<=j<=e,

    min E_(j-1) < Q_j <= max E_j.                  (C1)

The upper bound is the frozen genuine-origin theorem. For the lower bound,
suppose Q_j<=min E_(j-1). Restart at the literal actual state at time j,
under the tie (Q_j,Q_j). This pair is coordinatewise at most E_(j-1).
After the actual remaining e-j moves, monotonicity and the restart premise
give

    Q_e <= max E_(e-1) <= min E_e,

contradicting danger. This comparison preserves e-j actual moves. It does
not insert or remove an inspection and does not assume earlier counts
were monotone.

Let sigma_j be the sum of ORIGINAL survivor surpluses on update j, and
u_j the number of useful inspections. Exact physical accounting gives

    Q_j+sigma_j = Q_(j-1)+u_j <= Q_(j-1)+k.

Combining (C1) at j with the upper bound at j-1 yields

    sigma_j <= k+span(E_(j-1))-1 <= 2k-1.         (C2)

Indeed E_(j-1) is obtained by maps which increase their inputs by at most
k, and interlacing gives span(E_(j-1))<=k (the zero pair is tied).
The actual dual-hole surplus of either cohort is no greater than its
corresponding original survivor surplus, so each is also at most 2k-1.

This is a bound on every boundary intermediate shape, not merely the final
one. At a dangerous endpoint the stronger frozen bound sigma_e<=k-1 may
also apply, but that improvement is unnecessary for this construction.

The same corridor and surplus conclusion hold for any genuine ordinary
reference orbit R, including W^c, once its actual history is known to lie
below max R and its final endpoint is dangerous. At index t>=1 the lower
threshold is min R_(t-1), using that precise predecessor index.

## 3. Exact physical transitions between literal one-cohort hole sets

For a set D of one color, write

    Erosion(D)={v of the other color : N(v) subset D}.

Let X be the current literal one-color hole set and Y a proposed next
literal hole set of the opposite color. A budget-k update reaches EXACTLY
Y from X if and only if

    |N(Y) minus X| <= k,
    Erosion(X union N(Y)) = Y.                    (C3)

Necessity: if Y=Erosion(X union I), then N(Y) subset X union I. Hence
X union N(Y) subset X union I, while Y subset Erosion(N(Y)). Monotonicity
therefore gives equality in the second condition. The first condition
follows from N(Y) minus X subset I.

Sufficiency: inspect exactly I=N(Y) minus X. Its cardinality obeys the
budget, and the resulting erosion is Y by the second condition.

In particular, possible positive-time hole images satisfy
Erosion(N(Y))=Y. The transition test also retains X: image closure alone
does not suffice when X already contains other cells.

## 4. A compressed exact recurrence for early endpoint access

The accepted cutset theorem represents any one-color set of dual surplus
s in the connected b-by-n matching array using at most

    K(s)=6s+(b-1) 1[n odd]

undirected cut edges and one membership bit. Reconstructing from path
parity and rejecting inconsistent cycles gives its literal physical set.
Take

    K=12k-6+(b-1) 1[n odd].                       (C4)

Let U_p be the exact collection of physical color-p sets obtained by
enumerating cutsets of size at most K and both base membership bits, then
testing actual dual surplus<=2k-1. Deduplicate the literal sets. This is
an exact universe, not a surrogate perimeter condition.

Fix a genuine endpoint time e and fix the initial cohort/color. Start the
reachable family with the empty hole set at time zero. At time j, retain
only states Y in the correct physical color universe which satisfy (C1),
and retain Y precisely if a reachable previous X satisfies (C3). To
compute the standard FIRST pronic-cut endpoints, also require

    |Y|<A for j<e,
    A<=|Y|<=H and |Y|>min E_e for j=e.             (C5)

Every normalized actual solo history ending at such a dangerous pronic
cut appears in this recurrence: all its boundary sets obey (C2), the
cutset representation is exhaustive, and (C3) retains its transitions.
Conversely, every path accepted by the recurrence reconstructs an actual
inspection sequence through (C3), at exactly e moves, and has exactly its
reported literal endpoint. Thus this is exact genuine-clock early
endpoint reachability for this domain, conditional on the restart premise.

The solo restriction here is explicit. In the frozen failed-join reduction,
the late dangerous cut is before activation; the last-full-normalized
history is solo at every earlier time. Inspections of the full partner
which create no holes can be omitted, so the one-cohort recurrence contains
every actual normalized history to which that reduction applies. This is
not a claim that all arbitrary strategies were solo.

There are only finitely many possible dangerous cut times e. In particular,
min E_e<H and max E_e>=A are necessary, and the genuine pair eventually
passes H. Its interval and every required reference value depend on b,k,
not n; they are obtained by the stated ordinary recurrence.

If the matching graph has M=b(n-1)+(b-1)n edges, then each color universe
has at most

    2 sum_(r=0)^min(K,M) binom(M,r)

states. The straightforward layered recurrence takes at most e times the
square of this state count, with polynomial board-size work per transition.
For k<2b and n=O(b), this is exp(O(b log b)), rather than 2^(Theta(b^2)).
The exponent is not claimed small, and no large enumeration is proposed.

## 5. Exact shifted reverse initialization, with its real scope

Let V^c be the genuine ordinary pair from (c,c), 0<=c<=k, and
W_t=V_(t+1)^c-(k,k). Suppose a real shifted erosion starts at index r
from J_0=Erosion(D), with the ACTUAL terminal/activation set satisfying
|D|<=min V_r^c. Let its endpoint at index r+t be dangerous and let the
genuine maximum remain below A throughout the relevant range. The accepted
shifted theorem therefore gives unclipped actual comparison to W and
keeps every actual erosion count below A<=H.

For r>=1, the tied corridor at the actual initial index gives

    |J_0|>min W_(r-1)=min V_r^c-k.

Since N(J_0) subset D, its actual dual surplus is strictly below k. For
r=0, the direct bound |D|<=c<=k gives dual surplus<=k (strictness is not
needed). All subsequent states satisfy (C2) with W at their genuine indices.

For a specified cardinality cap B on D, a literal seed J occurs as exactly
Erosion(D) for SOME D with |D|<=B if and only if

    Erosion(N(J))=J,       |N(J)|<=B.               (C6)

Necessity follows from N(J) subset D and erosion monotonicity; sufficiency
takes D=N(J). Thus (C6), the correct physical phase, and the real index r
give an exact compact initialization for the arbitrary-terminal-set
erosion problem. Subsequent transitions are exactly (C3), with the same
genuine-clock corridor.

This does NOT say that every D with |D|<=min V_r^c admits the real mixed
signed continuation which produced that necessary bound. With the actual
seed D or its exact reachability predicate retained, the recurrence is
exact. Replacing that predicate by cardinality alone is a necessary
overapproximation for the full signed gate. This distinction remains an
explicit full-game interface, not a presumed construction.

## 6. What this closes and what remains

Conditional on the tied restart theorem, the missing EARLY boundary
reachability problem has an exact physically sound compressed recurrence:
all required intermediate shapes, not only endpoint candidates, belong
to an O(k)-cutset universe. No arbitrary partial-state prefix optimality,
fresh favorable phase, or previously conjectural pyramid normalization
is used.

The genuine reverse cap guard remains. The arbitrary-activation-set
cardinality bound alone does not provide its exact future mixed suffix.
The remaining central front/axis compatibility and actual signed terminal
interfaces must still be joined to this endpoint recurrence before any
full-board gap-zero conclusion. No expression simplification, publication,
or new Lean coverage is asserted here.

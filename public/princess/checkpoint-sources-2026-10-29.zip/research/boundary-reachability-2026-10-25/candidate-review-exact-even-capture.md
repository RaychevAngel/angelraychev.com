# Independent review of the literal endpoint capture evaluator

25 October 2026. Accepted ordinary proof, on the stated family
w=2b, b>=32, n>=2b, k=b+d, 1<=d<=b-1. This review covers both
`even-near-optimal-prefix-endpoint-recurrence.md` and the simpler final
assembly `root-exact-low-budget-even-capture.md`. The sources are pinned
in the accompanying JSON receipt.

## The clocks are the right clocks

The older even-width ordinary-middle branch has constant necessary drift
d throughout the stated endpoint interval. Its clock is exactly
ceil((h-Q-Y)/d), as recorded explicitly in
`../phase-dependencies-2026-10-24/upper-exact-even-transport-families.md`.
The older genuine-head comparison needs at most one additional middle
update at even width. Thus the lower J and upper 2J(k)+4 used here are
the same clocks; an unrelated weaker endpoint minimum has not been
substituted. The frozen terminal shift also gives J(0)=J(k)+1 and the
half-quota dichotomy used by L0,U0.

I independently accepted the exact four-clock interface in
`candidate-review-fixed-clock-corridor.md/.json`. The first actual gate-k
crossing has positive mass, so the literal reverse endpoint has mass at
most k-1. Both prefix clocks are bounded below by A=J(k); the known
construction then bounds each above by A+3. The transformations used for
completeness preserve actual time, gate membership, and the required
endpoint intersection inequality. No statement that every gate is solo
is used.

## Exact transitions, including the physical color change

Take source holes X in one physical color and proposed target holes Y
in the opposite color. If a real inspection I produces Y, then

    Y=Erosion(X union I),
    N(Y) subset X union I.

Let Z=X union N(Y). Then Z is contained in X union I, so
Erosion(Z) is contained in Y. Conversely, N(Y) is contained in Z,
so Y is contained in Erosion(Z). Hence Erosion(Z)=Y, and the
minimal useful inspection N(Y) minus X uses no more rooms than I.
This proves necessity of the graph edge. Inspecting exactly that set
proves sufficiency. The two source colors are disjoint, so their costs
add. The parent assembly correctly sends target holes of color 1-p
through the source holes of color p.

This proof does not require proper beliefs, positive masses, nesting,
or any normal form. Empty/full individual components are also included.
Thus all paths of the parent's larger, unrestricted graph are actual
physical histories. Keeping extra paths cannot generate false positive
captures.

The supporting normalized endpoint recurrence is also sound. At every
layer it retains the initial-cohort color i+j mod2, the fixed reflection
and permanent smaller-cohort choice, and the last-full flag. Minimal
inspection on a partner whose target remains full is empty; when the
target becomes proper, the raw survivor cannot be full since N(full)
is full. Once the source is proper its raw survivor is proper too.
Consequently minimalizing an edge does not invalidate that normalization.

## Completeness is for all intermediate states of optimal witnesses

The independently reviewed fixed-clock theorem with s=4 bounds the sum
of original survivor surpluses by C=13k-1 on EVERY update of each relevant
normalized prefix. A target cohort's actual hole dual surplus is at most
its own original survivor surplus, hence at most C. The accepted matching
array encoding then bounds its internal cut edges by

    K=6C+(b-1)*1_[n odd].

The array is connected. A cut pattern plus one membership bit uniquely
reconstructs a set when consistent; rejecting inconsistent patterns is
exact. The initial empty hole sets have zero cut edges. Therefore the
two actual witness paths are entirely present in the parent's universe,
not only their final endpoints. Optional dual-surplus rejection in the
normalized recurrence is safe. Omitting it in the larger parent graph
is also safe, since every retained state is still a literal physical set.

Layered reachability records EXACT update counts; it does not retain only
shortest distances and accidentally discard a later relevant occurrence.
Minimalizing each actual edge preserves the prescribed next state, so
induction preserves the exact literal endpoints of both optimal witnesses.

## Capture uses an intersection, not a mass surrogate

For returned physical prefix endpoints F and R, the parent tests
|F intersect R|<=k. Run the F word, inspect that literal intersection,
then reverse the stored R inspection word. An avoiding walk through all
these days would have its middle vertex both in F and R, by reversing
its suffix, and so would be inspected on the middle day. The count is
exactly a+b+1 inspection days. Physical movement is undirected, so no
new direction or checkerboard convention is needed at the splice.

Some actual optimal word supplies a pair in the restricted graph by
the preceding completeness proof. Every pair accepted by the graph
supplies an actual winning word by the preceding reversal argument.
The minimum successful q in [L0,U0] therefore equals the actual optimum.
Stored predecessor edges reconstruct an attaining inspection sequence.

The exact connected counterexample in
`candidate-connected-gate-obstruction.md` is an important guard here:
on that matched color-symmetric graph the scalar gate convolution is 7
but capture takes 8. The present evaluator does not make that false
replacement. It retains the literal intersection all the way through.

## Complexity and the precise result

For M internal array edges, at most
2 sum_(j<=min(K,M)) binom(M,j) one-color descriptions are enumerated.
Forming state pairs, dense transition pairs, and endpoint pairs raises
this quantity only to fixed powers. The time horizon A+3 and polynomial
membership/erosion tests give (A+4) exp(O(k log(wn))) time up to
polynomial factors. For k<2b and n=O(b), this is exp(O(b log b)).

This is an ordinary exact-evaluation and optimal-word reconstruction
theorem on a complete stated parameter family. It does not show the
old scalar lower and corner-strategy upper bounds coincide, and does
not determine an uncomputed instance merely by declaring the graph.
The explicit cut bound can exceed M at moderate b, so practical speed
is not established. It is not a direct parameter rule for inspections,
an O(1)-operation numerical expression, an all-rectangle theorem, or a
new Lean verification. No large enumeration was performed in this audit.

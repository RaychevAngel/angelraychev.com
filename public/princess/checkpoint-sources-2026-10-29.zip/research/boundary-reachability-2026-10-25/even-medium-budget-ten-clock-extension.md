# Ten-clock capture compression for every medium budget

25 October 2026. New ordinary family argument for independent review.
It extends the cutset approach beyond k<2b without using the BAND9
comparator or a width sample. Old sources and accepted hashes are preserved.

Let

    w=2b, b>=32, n>=2b, h=bn,
    2b<=k<=floor(b^2/2), d=k-b,
    L=(b-1)^2, H=b(b-1), z=b^2-k+1,
    U=h-H-1, D0=ceil((h-2b^2+b)/d).

Thus d>=b, 1<=z<=L, and z>k. With the ordinary early E and late V^k
pairs, put

    e0=min{j:max E_j>=z},
    ell0=min{j:max V_j^k>=z},
    J*=e0+ell0+D0.                                (M1)

The conclusions are:

1. J* is a necessary full-origin signed-gate-k clock.
2. A physical solo word reaches gate k in at most J*+4 updates, so a
   full capture construction takes at most 2J*+10 inspection days.
3. Every normalized full-origin gate-k prefix with length in[J*,J*+9]
   has original total survivor surplus at most 31k-1 on every update.
4. The same exact literal cutset graph and forward/reverse intersection
   evaluator therefore determine the full capture time on this ENTIRE
   parameter family, using ten possible prefix clocks.

The asymptotic state bound is exp(O(k log(wn))). This is informative
relative to area-exponential enumeration when k log(wn) is small compared
with wn; it does not assert a useful compression at quadratic budgets.

## 1. The boundary comparisons have the needed larger-budget domain

The accepted arbitrary tied-origin restart theorem assumes
k>=max(13,b+1), with no upper bound on k. The artificial raw initializer
also works at every such k: for a raw set D with |D|<=x<=b^2 and x>=k,
start with holes X subset D of size min(|D|,x-k) and inspect D minus X.
The tied source x-k<=b^2-k<=H produces the exact reference
(x-rho(x),x-ceil_sqrt(x)). For x<k the accepted true first-quota theorem
applies instead. No new numerical base is required.

Consequently `even-arbitrary-terminal-late-comparison.md` extends to
every b+1<=k<=b^2 and terminal quota a in[0,H]. Its proof only needs
the clipped reverse threshold b^2-k+1>=1: before its first crossing the
raw set has size<=b^2 and the target hole count<=H. The auxiliary H-1
first-exit buffer is not used. For a<k the frozen signed-late theorem
already has this budget range and cap b^2+1; for a>=k use the displayed
artificial initialization. Thus all early and late corridor inputs below
are valid at the present k.

## 2. Actual cuts and a uniform lower clock

Normalize an actual full-origin prefix of length T reaching signed mass
at most k. Let e be its first total-hole crossing Q_e>=z. Before this
update, total raw holes are at most z-1+k=b^2. The target hole count
therefore obeys

    z<=Q_e<=H.                                    (M2)

For completeness, if the target exceeded H and original surplus were
at least b, raw<=b^2 would already give Q_e<=H. If surplus were below b,
the two-target-hole small/co-small alternatives give either Q_e<=L or
Q_e>=h-H>b^2. Both contradict the hypothetical target and raw cap.
All preceding early counts are <z<=H. Hence e>=e0 by ordinary restart.

Let v be the LAST index with m_v>z-1 and m_(v+1)<=z-1, and write Y=m_v.
It exists because the terminal mass<=k<=z-1. Perfect-matching
noncontraction gives drop<=k on one update, so exactly

    z<=Y<=z-1+k=b^2.                              (M3)

After this crossing, every mass stays <=z-1<=H. The actual late suffix
has length ell=T-v and, by the ordinary capped late comparison,
Y<=max V_ell^k. Thus ell>=ell0. At e the mass is at least h-H>b^2,
so v>e. Put Delta=v-e>=1.

The universal double clamp C_t=min(U,max(L,Q_t)) still has each gain
at most d=k-b. Its proof uses only the small/co-small dichotomy and
perfect-matching accounting, not the former d<b restriction. At e,
C_e<=H. At v, Q_v=h-Y>=h-b^2 and U>=h-b^2, so

    C_v>=h-b^2,
    C_v-C_e>=h-b^2-H=h-2b^2+b.

Therefore Delta>=D0. Together with e>=e0 and ell>=ell0 this proves
the necessary clock T>=J*.

## 3. A guarded physical construction within four extra updates

The ordinary early pair at its first maximum>=z is an actual corner
construction: all its preceding inputs are <z, hence their raw sizes
are <=z-1+k=b^2, and both outputs are <=H. It supplies a physical
head with at least z holes after exactly e0 updates.

Likewise the ordinary late pair C=V_ell0^k is physical. Every preceding
input is <z<=H, so the ordinary corner survivor and its neighborhood
fit the rectangle. Its terminal coordinates are at most

    k+z-1-rho(z-1)<=b^2.

Let r=span(C). The genuine-origin spread bound is r<=ceil(ell0/2).
Before the maximum reaches z<=b^2, each scalar output exceeds its
source input by at least d; hence the pair minimum gains at least d
per update. Thus ell0<=ceil(z/d)<=b, since z<=b^2 and d>=b.
Consequently r<=ceil(b/2)<=d and min C>=z-r.

The exact finite-board backward prefix operator at even width increases
the pair MINIMUM by at least d, clipped at h (each output exceeds its
corresponding source input by at least d). After

    D=ceil((h-2z+r)/d)

such physical middle updates, both coordinates are at least h-z.
They therefore meet whichever actual early head phase attained z, by
the accepted antipodal prefix-complement meeting criterion. This is
a real gate-k strategy in e0+D+ell0 updates, with no free phase switch.

The extra middle numerator above D0's target is

    (h-2z+r)-(h-2b^2+b)=2k-b-2+r
       <=2k-b-2+d=3d+b-2<=4d-2.

Hence D<=D0+4, proving the solo gate construction J*+4. Applying its
final capture inspection separately to the two initial cohorts gives
full capture in at most 2(J*+4)+2=2J*+10 days. Color symmetry at even
width supplies either initial cohort phase; no scalar signed-gate
palindrome or mixed endpoint substitution is needed.

## 4. Every near-optimal prefix has a ten-clock shape corridor

Consider any normalized gate-k prefix with T<=J*+s-1, initially with
s arbitrary. Its actual cuts from Section2 satisfy

    (e-e0)+(Delta-D0)+(ell-ell0)<=s-1.             (M4)

Thus each nonnegative delay is at most s-1. Early tied restart gives
the same s-clock lower corridor as before: if e>=s, then e-s<e0 and
Q_e>=z>max E_(e-s). Hence all early original surpluses are at most
(s+1)k-1. The first fewer than s updates use the direct Q<=tk bound.

For the late tail, ell-s<ell0 and Y>=z>max V_(ell-s). Every positive-
time late mass is <=z-1<=H. The arbitrary-terminal comparison applied
to each ACTUAL initial late segment therefore gives exactly the same
s-clock lower mass corridor, and the late original surpluses are at most
(s+1)k-1, including the possible negative terminal masses.

The clamped middle loss satisfies

    R=d*Delta-(C_v-C_e)
      <=d*(D0+s-1)-(h-2b^2+b)<=sd-1.              (M5)

There are consequently at most s-1 nonpositive clamped steps. The
excursion-depth proof still applies even though these cuts need not
lie inside both clamp walls. The initial actual Q_e<=H<U, so every
above-U excursion has an actual first entry and overhang<=sk. The final
actual Q_v>=h-b^2>=b^2>L, so every below-L excursion has a final exit.
On that exit, the generic physical gain<=k forces its last below-L
source to be >=L+1-k. At most s-1 earlier plateau steps then give
depth at most k-1+(s-1)k<sk. This includes an excursion already in
progress at the initial middle cut. No inequality U-d>L is needed,
and even a return which jumps across both walls is covered.

Writing epsilon=Q-C, every middle original surplus is therefore at most

    b+R+2sk <= b+sd-1+2sk <=(3s+1)k-1.            (M6)

This is the same uniform all-state estimate without a restriction on
activation time or intermediate monotonicity. Taking s=10 gives31k-1.

## 5. Exact capture evaluation and precise limitations

The first-forward-crossing argument from the reviewed capture interface
uses only a gate-k lower clock and a capture upper construction. With
J* and2J*+10, some optimal word splits into two actual gate-k prefixes
whose lengths both lie in[J*,J*+9], with a central literal endpoint
intersection of size at most k. Separate normalizations preserve that
condition, and Section4 bounds every intermediate hole set.

Use the exact literal two-color hole graph from
`root-exact-low-budget-even-capture.md`, now with

    C=31k-1, K=6C+(b-1)*1_[n odd],
    prefix clocks J*,...,J*+9.

Its necessity and physical sufficiency are unchanged. Search the actual
capture interval, or conservatively2J*+1 through2J*+10, using the stored
prefixes and exact central intersection. The first successful day is the
true optimum and its inspection word is reconstructed literally.

The complexity is (J*+10)exp(O(k log(wn))). In particular this gives
exp(O(b log b)) for every linear budget k=O(b) on short boards n=O(b),
covering the entire previously missing2b<=k<3b band uniformly. For
k approaching b^2/2 the representation can contain the full power set;
no asymptotic or practical speedup is asserted there. The theorem does
not evaluate the old one-day/two-day brackets symbolically, produce the
final O(1)-operation expression, or give a direct parameter inspection
rule. No large enumeration, new Lean coverage or publication is claimed.

# Connectedness, matching and polarization still do not determine capture

25 October 2026. Exact finite obstruction, independently checked by a
literal physical-state search and a separate thirteen-state folded proof.
This is not a rectangle counterexample.

Take the folded relation K on vertices0,...,4 with edges

    01,02,04,13,23,34 and a loop22.

Equivalently it is K_(2,3), with parts L={0,3} and R={1,2,4}, and a
loop at2. Its bipartite double cover is connected, exchanges its two
colors under the covering involution, and has the perfect matching

    (0,1'),(1,0'),(2,2'),(3,4'),(4,3').

At daily budget2 it has exact gate clocks G(0)=4, G(1)=3, but capture
time8. The gate-convolution lower bound is therefore7, strictly smaller.
Thus disconnectedness was not the essential obstruction in the preceding
P6-plus-matching example. Even connectedness, Hall noncontraction and a
looped folded relation do not supply the missing endpoint exchange.

Here is a small independently checkable proof of the values. Every open
neighborhood of a subset of the folded graph is one of

    0, L={0,3}, R={1,2,4}, C={0,2,3}, V={0,1,2,3,4}.

The accepted alternating-polarization theorem lets the two layers remain
nested without changing the capture or gate optimum. Exactly13 ordered
pairs (X,Y) from these five sets have Y subset X. Their exact transitions
enumerate A subset X and B subset Y with B subset A and
|X minus A|+|Y minus B|<=2, followed by (K(A),K(B)).

The minimum remaining capture times for these13 states are

    (0,0):0; (L,0):1; (L,L):3;
    (R,0):2; (R,R):4;
    (C,0):3; (C,L):5; (C,C):5;
    (V,0):4; (V,L):5; (V,R):6; (V,C):7; (V,V):8.

Each legal update decreases the displayed integer by at most one. A
decreasing path from (V,V) is

    (V,V),(V,C),(V,R),(V,L),(V,0),(C,0),(R,0),(L,0),(0,0).

Thus8 updates, equivalently8 inspection days for capture, are necessary
and sufficient. The first pair with total size at most6 is (C,C) at
update3; the first with total size at most5 is (V,0) at update4. These
give G(1)=3 and G(0)=4. The full transition and distance certificate is
`candidate-connected-gate-certificate.json`; the independent generator
`candidate_connected_gate_certificate.py` checks every one of the finite
transitions and the decreasing-potential property. The separate physical
search found the same result in24 literal states and337 transitions.

The rectangle task therefore needs more than generic nested-layer clock
algebra. One precise sufficient target is the actual cross-cover condition
in `candidate-gate-to-capture-interface.md`: after opposite polarization,
the two uncovered-hole terms must fit the unused central quota. Neither
the gate sizes nor all the abstract symmetries tested here force that.

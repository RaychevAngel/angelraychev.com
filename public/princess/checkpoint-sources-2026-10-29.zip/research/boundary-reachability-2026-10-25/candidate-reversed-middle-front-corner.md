# The remaining longitudinal front-to-corner switch is impossible

25 October 2026. New ordinary proof for independent attack. No claim of a
complete even temporal normal form, full-box gap zero, or Lean verification.

Use the actual failed-join solo middle from the reviewed 24 October ledger:

    w=2b, n>=2b, k=b+d, 1<=d<=b-1,
    L=(b-1)^2, H=b(b-1), h=bn,
    0<=R<=g-1<d,
    Q_t>L, m_t=h-Q_t>H,
    sigma_t>=b,
    R=sum_t [(k-i_t)+(sigma_t-b)].                  (1)

Here B_t is the actual pre-inspection belief, I_t subset B_t is the useful
inspection set, S_t=B_t minus I_t, B_(t+1)=N(S_t), H_t=V_t minus B_t,
Q_t=|H_t|, and i_t=|I_t|. Thus H_(t+1)=E(H_t union I_t). Every quantity
belongs to the same actual cohort. Let j and j+r be consecutive critical
moves, meaning their ORIGINAL survivor surplus is b and all intervening
moves have larger surplus. Assume their target beliefs satisfy m>=H+2,
so the reviewed central duality theorem applies to both. Put

    A_old=H_(j+1), A_new=H_(j+r+1).

The shared credit gives

    r<=R+1<=g<=d<=b-1,  R+r<=2b-3.                 (2)

**Claim.** For b>=128, if S_j is an actual longitudinal pyramid and
S_(j+r) is a localized critical survivor at corner C, then C is at the
S_j pyramid's longitudinal end. A turn to the opposite end is impossible.
Intermediate shapes and inspections are unrestricted subject to (1).

## 1. Reverse the actual word, allowing a controlled literal deficit

Let l=j+r and construct reverse post-inspection survivors

    Z_0=H_(l+1),
    Z_(s+1)=N(Z_s) minus I_(l-s),  0<=s<r.          (3)

This is a real inspection-and-movement word in post-inspection convention:
the forward inspection sets are used in reverse order, each still of size
at most k and in the correct physical color. It is not asserted to start
from full uncertainty. The genuine inclusion

    N(H_(t+1)) subset H_t union I_t

shows inductively that Z_s subset H_(l+1-s). Write

    eta_s=|H_(l+1-s) minus Z_s|.

Then

    eta_s <= s + sum_(t=l-s+1)^l (sigma_t-b)
           <=s+R.                                 (4)

Here is a noncircular surplus bootstrap proving (4). Assume it at s<r.
By Q_(l+1-s)>=L+1 and (2),

    |Z_s|>=L+1-(R+s)>=(b-2)^2+1.

Also h-|Z_s|>=h-Q_(l+1-s)=m_(l+1-s)>H. The accepted arbitrary-set
small/co-small separation therefore forces the actual surplus of Z_s
to be at least b-1: a surplus <=b-2 would give either |Z_s|<=(b-2)^2
or h-|Z_s|<=(b-2)(b-1)<H, both impossible.

For t=l-s, the identities Q_(t+1)=Q_t+i_t-sigma_t and
|N(Z_s)|=|Z_s|+sigma(Z_s), together with removal of at most i_t cells, give

    eta_(s+1)<=eta_s+sigma_t-sigma(Z_s)
              <=eta_s+(sigma_t-b)+1.

This proves (4) from eta_0=0. In particular the actual final reverse set
satisfies

    Z_r subset A_old,   |A_old minus Z_r|<=R+r<=2b-3. (5)

This is the needed reverse statement. Exact reversal is not assumed;
the lost allowed cells are retained explicitly. No final-gap bound on
the full endpoint bad age is used.

## 2. A large localized core survives inside the reverse holes

The critical endpoint duality gives N(A_new)=V_current minus S_l. Thus,
after the first reverse movement, every cell of S_l is an actual hole.
The first reverse inspection only enlarges that hole set. After another
r-1 updates, monotonicity of erosion retains the raw core of S_l with
radius reduced by at most r-1.

The reviewed raw critical quadrant theorem gives a literal full current-
color core radius at least 2b-4-4sqrt(b). From r<=b-1, even subtracting r
instead of the needed r-1 leaves the conservative radius

    rho=b-3-4sqrt(b).                              (6)

Consequently Z_r is disjoint from the actual current-color corner ball
B_rho(C). This statement concerns the reversed physical word (3), not a
chosen compressed representative.

## 3. Every large same-end pyramid meets that core in too many cells

The following elementary overlap lemma is uniform in n. Let A be an actual
longitudinal pyramid facing the end of C, in the color of B_rho(C), and
|A|>L. Match transverse rows in pairs starting from C's transverse side.
In the resulting b-by-n array, A is a literal prefix of length ell_i in
each matching row, and |ell_(i+1)-ell_i|<=2. These are actual lengths,
including empty/clipped fibers.

For any j, the Lipschitz upper tent gives

    |A| <= b*ell_j + 2 sum_(i=0)^(b-1) |i-j|
         = b*ell_j+b(b-1)-2j(b-1-j).

Since |A|>=L+1=b^2-2b+2, it follows that

    ell_j>=j  for 1<=j<=floor((b-2)/2).             (7)

Indeed ell_j<=j-1 would imply an area at most L+1 minus
2+j(b-2-2j), which is strictly less than L+1 in that range.

Every one of the first j cells in matching row j is at physical distance
at most (2j+1)+(j-1)=3j from C. Hence, for

    M=floor(rho/3),

the core and pyramid overlap in at least

    sum_(j=1)^M j=M(M+1)/2.                        (8)

The range in (7) contains these rows since rho<b and b>=128. To check the
constant uniformly, at b>=128 one has rho>=5b/8-1. This is equivalent to
3b/8-2-4sqrt(b)>=0; it holds at 128 and has positive derivative thereafter.
Thus M>=5b/24-4/3, and

    M(M+1)/2 >= (5b-32)(5b-8)/1152 > 2b-3.         (9)

For the last inequality the numerator after subtraction is
25b^2-2504b+3712, positive at 128 and strictly increasing thereafter.
The proof uses no enumeration or assumptions about a typical pyramid.

## 4. Contradiction and exact scope

The actual dual A_old of a longitudinal pyramid S_j is itself a pyramid
facing the opposite end. This follows from the reviewed exact neighborhood
and complement facts, including empty fibers; it is not a numerical label
choice. If C were at that opposite end, (8)-(9) would give

    |A_old intersect B_rho(C)|>2b-3.

But Z_r is disjoint from that ball and (5) deletes at most 2b-3 cells from
A_old. Contradiction. This proves the claim.

Together with the accepted 24 October longitudinal addendum, every mixed
transition between a localized critical description and an actual
longitudinal pyramid now preserves the actual survivor longitudinal end,
for b>=128, all n>=2b and 1<=d<=b-1, under the genuine failed-join ledger.

This does not yet exclude opposite-end pyramid-to-pyramid switches, handle
transverse-axis pyramids on n=2b or 2b+1, prove access from ordinary partial
layers, or handle the last equality target m_next=H+1. Widths b<128 still
need their uniform treatment. No new global capture-time gap or Lean claim
is inferred from this conditional actual-history lemma alone.

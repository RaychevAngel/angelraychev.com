# A total-surplus bound for literal capture endpoints

25 October 2026. Ordinary proof submitted for independent review. This is
a general compression parameter and a high-budget consequence. It does
not turn exhaustive state evaluation into a direct numerical formula.

Let an even-area rectangle of short side w>=2 have 2h rooms and budget
1<=k<h. Let A>=1
be any proved lower bound on the number of updates to full-origin signed
mass at most k, and U any proved constructive capture upper bound. Put

    C=(U-A)k-h.                                      (1)

Then some optimal capture word admits an exact forward/reverse splice
whose two actual prefixes each have total original survivor surplus at
most C. In particular EVERY update of those prefixes has surplus at most
C. No polarization, last-full normalization, corner comparison or boundary
restart is needed for this assertion.

## 1. The accounting identity is enough when the budget is large

For an arbitrary t-update full-origin word, write Q_t for total holes,
i_j for useful inspections, and sigma_j for the total original survivor
surplus in its two cohorts. Perfect matching gives sigma_j>=0. Exactly

    Q_t=sum_(j<t) i_j-sum_(j<t) sigma_j.

If this word reaches signed gate k, Q_t>=h-k. Consequently

    sum_(j<t) sigma_j <=tk-h+k=(t+1)k-h.             (2)

Now take an optimal capture word of T<=U days. At its first crossing
of signed mass into [1,k], the forward endpoint has signed mass m in
that interval. The reversed endpoint at the same pre-inspection cut has
signed mass <=k-m<=k-1, by the exact intersection lemma. Thus both
prefixes reach gate k and both have length at least A. Their lengths
sum to T-1, so each is at most U-1-A. Apply (2) to either prefix to
obtain (1). Nonnegative individual surpluses prove the pointwise bound.

This also shows C>=0 whenever the stated lower and upper bounds are
valid. It is safe to combine this parameter with independently proved
smaller pointwise bounds, but not to infer that arbitrary endpoint
cardinalities can be spliced.

## 2. The corresponding exact evaluator

Choose either even side as the paired physical axis, of length 2ell;
let the other side have length m. Each color has an ell-by-m matching
array. Represent each actual hole set by at most

    K=6C+(ell-1)*1_[m odd]

internal cut edges and one membership bit, rejecting inconsistent cycle
parities. Start the two-color hole graph at empty holes, use the exact
physical erosion transition from `root-exact-low-budget-even-capture.md`,
and retain reachable gate-k endpoints at times A,...,U-1-A.

For each candidate capture day q<=U, test literal endpoints at lengths
a+b=q-1 with intersection of size at most k. Return the smallest success
and reconstruct both prefixes, the central intersection inspection, and
the reversed second prefix. Necessity follows from (1)--(2) for some
optimal word; sufficiency follows from the actual physical splice.

Thus the exact graph has a surplus parameter C derived from EXISTING
proved numerical bounds. If C is as large as the board, this can be no
better than the generic power-set algorithm. The content is the smaller
state representation when C is small, not a newly discovered fact that
a finite game is computable.

## 3. Explicit high-budget bounds for every even-area rectangle

Let B=ceil(w/2) for w=min(side lengths), and assume B<k<h. The accepted
finite-board physical prefix profiles have cost at most B at every size
and in both phases. Their backwards pair minimum therefore grows by at
least k-B until clipping. Equivalently a directly constructed solo word
reaches residual at most k within

    P=ceil((h-k)/(k-B))

The explicit width-capped physical maps are recorded in
`paper/sections/bridge-uniform-upper.tex`, proof of
`prop:bridge-buffered-comparison` (path relative to the project root).

updates. Searching each initial cohort with this word and its final
capture inspection gives U=2P+2. Simple volume/noncontraction gives

    A=ceil((h-k)/k).

Use these actual integer bounds in (1). Since
P<=(h-k)/(k-B)+1 and A>=h/k-1,

    C <=2hB/(k-B)+3k.                               (3)

No middle phase or corner compatibility assumption is used. A stronger
known upper or gate lower bound may decrease C further.

For b=floor(w/2)>=32 and k>floor(b^2/2), we have k-B>=k/2. With
h=wn/2 and B<=b+1, (3) gives the convenient explicit estimate

    C<=9n+3k.                                      (4)

For example, 2hB/(k-B)<=4hB/k<4wn(b+1)/b^2,
and w<=2b+1 makes the coefficient at most9 for b>=32.
The rotated odd-width matching correction is at most n/2-1. Therefore
all these high-budget instances have an exact literal evaluator with

    U exp(O((n+k) log(wn)))

complexity, up to polynomial set operations. Its reconstruction is
optimal by exact intersection, not by reflecting an arbitrary gate witness.

For k>=h the values are elementary: T=2 if h<=k<2h, by inspecting
the SAME physical checkerboard color on both days; T=1 if k>=2h.

## Limits and relation to the other ranges

The high-budget result applies to BOTH even-width and odd-width/even-length
rectangles, all lengths retained. On short boards with k comparable to
b^2, the cutset bound may exceed the entire graph and supplies no useful
asymptotic compression. At longer lengths its cost can be far below
an unrestricted area-exponential search.

Small budgets require the stronger history-dependent corridor: their
total cumulative surplus can be large even when each update is efficient.
The four-clock, variable odd-clock and ten-clock theorems address those
ranges. This note complements them; it does not claim their proof was
unnecessary or that all old efficient bounds now match.

No new large state graph was evaluated, no direct parameter-only optimal
inspection rule or fixed-size numerical expression was obtained, and no
new Lean coverage or publication update is claimed.

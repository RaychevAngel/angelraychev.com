// Exact finite arithmetic challenge for arbitrary nonnegative TIED origins.
// No physical strategy enumeration; root r=4..99, k=13..9900.
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <iostream>
#include <unordered_set>
#include <vector>
using I=long long;
I rt(I x){I z=sqrtl(x);while(z*z<x)++z;while(z&&(z-1)*(z-1)>=x)--z;return z;}
I rp(I x){I z=(sqrtl(1+4*x)-1)/2;while(z*(z+1)<x)++z;while(z&&(z-1)*z>=x)--z;return z;}
I tri(I x){I z=(sqrtl(1+8*x)-1)/2;while((z+1)*(z+2)/2<=x)++z;while(z*(z+1)/2>x)--z;return z;}
struct P{I a,b;}; P nxt(P x,I k){return{x.b+k-rp(x.b+k),x.a+k-rt(x.a+k)};}
I mn(P x){return std::min(x.a,x.b);} I bad(I x,I k){return x+k-1-rp(x+k-1);}
uint64_t key(P x){return (uint64_t(x.a)<<32)|uint64_t(x.b);}
int main(int argc,char**argv){I stop=argc>1?atoll(argv[1]):9900,seeds=0,states=0,margin=99999;
for(I k=13;k<=stop;++k){I cap=std::min<I>(9801,(k-2)*(k-2)); std::unordered_set<uint64_t> seen;std::vector<P> todo;
 for(I q0=0;q0<cap;++q0){P x=nxt({q0,q0},k);if(mn(x)>=cap)break;if(seen.insert(key(x)).second)todo.push_back(x);}
 for(size_t j=0;j<todo.size();++j){P x=todo[j];++states;
  for(I p=0;p<2;++p){I a=p?x.b:x.a,b=p?x.a:x.b;
   for(I q=b+1;q<=std::min(a,cap);++q){I r=rt(q);if(r<4||r>99||r>k-2||q>r*(r-p))continue;
    I core=2*r-2-p-2*tri(r*(r-p)-q);if(p==0&&q==(r-1)*(r-1)+1)core=std::min(core,2*r-4);
    I z=q,steps=0;P y=x;while(z>mn(y)&&steps<core){z=bad(z,k);y=nxt(y,k);++steps;}
    if(steps>=core){std::cout<<"FAIL k="<<k<<" pair="<<x.a<<","<<x.b<<" p="<<p<<" q="<<q<<" r="<<r<<" core="<<core<<" steps="<<steps<<" states="<<states<<"\n";return 1;}
    ++seeds;margin=std::min(margin,core-1-steps);
   }
  }
  P y=nxt(x,k);if(y.a<x.a||y.b<x.b){std::cout<<"NONMONOTONE\n";return 2;}if(mn(y)<cap&&seen.insert(key(y)).second)todo.push_back(y);
 }
 if(k%500==0)std::cerr<<"k="<<k<<" cumulative_states="<<states<<" dangerous="<<seeds<<"\n";
}
std::cout<<"{\"status\":\"passed\",\"maximum_budget\":"<<stop<<",\"reachable_pair_states\":"<<states<<",\"dangerous_seeds\":"<<seeds<<",\"minimum_margin\":"<<margin<<"}\n";}

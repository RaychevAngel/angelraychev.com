# Critical collars preserve the strict common loss bound

25 October 2026. Strengthening of `even-critical-collar-loss-ledger.md`,
independently derived by root and the even lane and submitted for review.
The weaker source is preserved. No new full-game or Lean claim is made.

Retain all notation and hypotheses of that source, especially the genuine
early maximum M_j, actual cut u, first genuine index tau with M_tau>L,
clamp C_j=max(Q_j,L), and

    M_u<=H+d-1, A=H-d+1, 1<=d<=b-1.

Write

    c_E=d(u-tau)-(M_u-M_tau).

Then the sharper conclusions are

    c_E in {0,1};
    c_E=1 implies span(E_u)<=d-1.                    (S1)

Consequently, with Lambda_E and Lambda_J defined in the preceding note,
the actual extended shared account is

    Lambda_E+Lambda_J+eta+R
        <=g-1+c_E<=d-1.                             (S2)

In particular the collar losses do not destroy the strict <d guard used
by the accepted critical-transition geometry.

## 1. A maximum loss is necessarily the final collar update

Each genuine maximum increment is d or d-1; a loss requires M_j>=A.
If rho(M_j+k)>=b+1, then M_j>=b^2-d+1, and even the lower outgoing
branch gives

    M_(j+1)>=M_j+d-1>=b^2>H+d-1,

contradicting the terminal maximum bound. Therefore at every possible
loss source, rho(M_j+k)=b, so

    G(M_j)=M_j+d, F(M_j)=M_j+d-1.

For the maximum to lose one unit, it must occupy coordinate0, whose
outgoing branch is F; the other coordinate is strictly smaller. In the
next pair, coordinate1 realizes the new maximum

    M'=M_j+d-1>=A+d-1=H.

There can be no further update before u. If M'=H, its outgoing G branch
gains exactly d because H+k=b^2+d<=b(b+1)-1, producing H+d. If M'>H,
the general lower increment d-1 produces at least H+d. Both exceed the
allowed final maximum H+d-1. Thus every loss is the last update. This
proves c_E<=1, also for d=1, without a separate two-stall argument.

## 2. That last loss decreases the span

Let the loss source pair be (M,m), M>m. Since rho(M+k)=b and m<=M,
we have rho(m+k)<=b, hence G(m)>=m+d. The target pair is

    (G(m),F(M)),

with second coordinate realizing its maximum. Therefore its span is at
most

    (M+d-1)-(m+d)=(M-m)-1.

At any genuine early pair with maximum M>L, interlacing gives
M<=G(m). Exact inversion implies

    m+k>=M+ceil_sqrt(M)>=M+b,

so its span M-m is at most d. The final span after a loss is therefore
at most d-1. This proves (S1). In particular a failed join with d=1
cannot have a collar loss, since it has g>=1 and g<=span(E_u).

## 3. The original endpoint budget pays the complete collar trace

The preceding exact telescopes give

    Lambda_E<=delta_E+c_E, Lambda_J<=delta_J.

Combine them with the accepted whole low-excess account
delta_E+delta_J+eta+R<=g-1. If c_E=0, the total is at most g-1<=d-1.
If c_E=1, (S1) gives g<=span(E_u)<=d-1, so the total is at most
g<=d-1. This proves (S2), with the same physical endpoints and quotas.

## 4. Actual consequences, including the first clamp contact

All summands of each collar loss are nonnegative integers. A clamped
update with nonpositive progress would alone cost at least d and is
therefore impossible under (S2). Thus every nonempty collar progresses
strictly in its clamped counts. Its first source may have actual count
at most L; after its first update every actual count is greater than L.
No later retreat to L is possible.

On every update whose actual source and target exceed L, its collar
summand equals unused quota plus original surplus minus b. If only the
first source lies below L and its target exceeds L, the clamped summand
equals that same original physical charge PLUS L-Q_source. It therefore
upper-bounds the physical charge rather than hiding it. The target's
original surplus is at least b in either case.

For the early collar and actual middle, these are consecutive portions
of the SAME normalized solo history. They can be treated as one actual
critical trace after the first collar update. Every noncritical move
spends at least one unit, so consecutive critical moves in that extended
trace remain separated by at most

    Lambda_E+R+1<=d,

or by the sharper corresponding partial loss account. This permits the
previous temporal barriers to be applied through neutral early critical
steps whenever their target-set and endpoint hypotheses hold.

The reverse collar is a different actual reversed word. Equation(S2)
shares its cost but does NOT concatenate its sets with the forward middle
or discard the allowed-set excess eta. A literal splice or a reversed
deficit argument is still needed there.

No ordinary corner label is assigned at tau. Connecting the earlier
subcritical zero-good ancestry to the first critical description remains
a genuine interface. The result controls the intervening neutral collar
without declaring every partial boundary set canonical.

## Computational challenge

An exact integer diagnostic generated every genuine zero-origin early
collar state through M<=H+d-1 for 2<=b<=256 and all1<=d<=b-1.
It checked 215,124 states, of which14,354 had one accumulated loss:
no state had two losses, and every one-loss state had span<=d-1.
This is a bounded challenge only. Sections1--3 give the uniform proof.

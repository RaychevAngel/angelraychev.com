# Independent audit of the activated mixed-suffix corridor

25 October 2026. Ordinary proof review of
`even-mixed-suffix-two-clock-corridor.md`, including its literal-state
evaluator. The accepted domain is the genuine dangerous-seed domain M1,
with a normalized permanently mixed continuation, w=2b, b>=32,
n>=2b, k=b+d, 1<=d<=b-1 and 0<=c<=k. This is not a new global capture
formula or a boundary phase theorem.

## Arbitrary terminal gate and the inverse recurrence

M3 does not require the artificial restriction a<=k. Set
Z=min(max(m_start,0),b^2+1). While a reference x>k remains alive,
its survivor u=x-k satisfies u<=b^2+1-k=H-d+1<=H. Both actual
corner surplus functions are at most b<k; its next size is at most
H+b=b^2, so the reference stays inside this window thereafter.

Assuming x<=m, actual survivor signed mass is q>=m-k>=u>0. If
q is already at least the reference target, nonnegative actual surplus
proves comparison. Otherwise q is positive and at most b^2, where the
accepted static mixed-survivor bound applies because both actual
post-inspection survivors are proper. It pays either corner surplus.
When x<=k, the reference can clear on its next update. Once it is empty,
stop the comparison with actual signed mass; no false inequality
0<=m is required if that actual mass later becomes negative. It has
already reached every nonnegative gate. This proves the forward
comparison for any a>=0 and any finite number of updates.

For completeness, the ordinary inverse identities are exact integer
identities for the zero-clipped reference:

    max{u>=0: u+ceil_sqrt(u)<=y}=y-rho(y),
    max{u>=0: u+c_1(u)<=y}=y-ceil_sqrt(y),
    c_1(0)=0, c_1(u)=1+rho(u) for u>0.

Adding the quota and swapping physical phases gives exactly V^a.
No geometric profile is evaluated outside the proved forward window.
If one inverse coordinate leaves that window its bound on the initial
reference is already vacuous. If a>=b^2+1, both inverse branches keep
values at least b^2+1 by numerical monotonicity and their values at
b^2+1, so the clipped assertion is immediate. The t=0 case is also
immediate. Thus the claimed arbitrary-gate M3 is sound.

M4 follows by applying this comparison to each actual suffix. All its
reference minima are at most b^2, so clipping cannot hide an actual
positive state larger than the displayed upper bound.

## The two-clock contradiction, including zero and negative values

If s=r-t>=2 and m_t<=min V_(s-2)^c, put a=max(m_t,0). The reference
minimum is nonnegative, hence the tied seed (a,a) is coordinatewise
below V_(s-2)^c. M3 for the actual prefix of length t and monotonicity
of the same phase-swapping operator give

    |D|<=min V_t^a<=min V_(r-2)^c.

Both sides use exactly t further updates; there is no phase reset.
The one-shot square inverse is valid for |D|<=b^2, and x-rho(x) is
nondecreasing. The rho-coordinate of W_(r-2)=V_(r-1)^c-(k,k) applies
that function to a coordinate of V_(r-2)^c at least its minimum.
Therefore

    |J|<=max W_(r-2)<=min W_(r-1),

contradicting M1. This checks every index in M5, including t=0 and
r=2. Setting a=max(m_t,0) is legitimate when signed mass is negative;
it is not a replacement of the actual state by a fictitious zero set.

## All original survivor surpluses are bounded

For s>=2, the strict integer lower bound at the source and M4 at the
target imply

    sigma_t<=k+min V_(s-1)^c-min V_(s-2)^c-1<=2k-1.

The numerical minimum rises by at most k because the branch fed by
the previous minimum is at most that minimum plus k. For the final
update when r>=2, M5 two updates before the end gives m_(r-2)>=c+1.
One quota and nonnegative surplus give m_(r-1)>=c+1-k, even if this
number or the actual mass is negative. Together with m_r<=c this gives
the same bound 2k-1. For r=1, genuine danger implies |J|>0 and |D|>=1;
then sigma_0<=k+c-|D|<=2k-1. No first-hitting assumption was used.

The grid has a perfect matching, so each individual one-color survivor
surplus is nonnegative and no larger than the total. Each actual target
hole set has dual surplus no larger than the corresponding original
survivor surplus. The accepted cut-edge bound therefore applies to
both target beliefs at every positive time, giving exactly
K=6(2k-1)+(b-1)*1_[n odd]. Initial time is separately supplied by J.

## Canonical seed and exact transitions

For J=E(D), N(J) is contained in every admissible D and has erosion
exactly J. Repeating the original inspections from D_min=N(J) only
shrinks the smaller cohort; the partner history is identical. Nesting,
activation and later partner properness, all upper seed bounds, and the
terminal signed gate are preserved. Genuine danger depends only on J
and its unchanged reference index. The corridor is consequently applied
again to this reduced physical history, rather than assumed to survive
an arbitrary numerical substitution.

For literal consecutive beliefs B,B', every realizing survivor lies
in S_max=B intersect E(B'). If a realizing survivor exists, monotonicity
forces N(S_max)=B'; conversely this equality realizes the transition.
S_max maximizes surviving rooms, so it minimizes useful inspection cost
and cannot increase original surplus. Apply this separately to both
physical cohorts and add costs. Under the normalized folding relation,
both the input beliefs and target erosions are nested, hence the maximal
survivor pair is nested. This nesting condition is part of the normalized
state class, whether encoded with physical sets or folded coordinates.

The first maximal partner survivor is proper: otherwise N(full)=full
would make its first target full, prohibited by the permanent mixed
state guard. Later partner beliefs are already proper. Hence selecting
maximal survivors cannot accidentally erase the activation condition.
Every accepted graph edge reconstructs actual inspections and every
actual relevant continuation supplies nodes in this cutset universe.
These establish both sufficiency and necessity of the restricted exact
suffix evaluator, with literal colors, elapsed time and terminal gate.

## Complexity and remaining scope

The number of valid cutset descriptions is bounded by the stated
binomial sum, with terms above the actual edge count interpreted as zero.
There is also an explicit finite horizon bound: whenever min V_j<=b^2,
both numerical branches at that minimum increase it by at least one,
since k>=b+1. Monotonicity then gives min V_(j+1)>=min V_j+1. Thus M1
implies r<=b^2-c. Layers contribute only a polynomial factor. The claimed
exp(O(k log(bn))) enumeration bound follows; it is not a practical
runtime claim and no such enumeration was executed in this review.

The exact suffix predicate remains conditional on M1 and on the cited
ordinary cap/restart interfaces. Assembly with an actual early endpoint,
middle history, reverse allowed sets and terminal cuts is separate. No
claim that the canonical construction always wins this evaluator, no
uniform gap reduction, and no new Lean coverage is accepted here.

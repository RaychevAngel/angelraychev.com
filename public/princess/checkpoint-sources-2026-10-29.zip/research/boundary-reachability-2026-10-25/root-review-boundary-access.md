# Independent acceptance: restart, exact boundary access, and cap buffer

25 October 2026. Root review of the new physical interfaces, with the
independent finite arithmetic replay retained as a separate evidence tier.

## Tied restart and every-state corridor

Accepted `odd-arbitrary-tied-boundary-restart.md` within its stated domain:
even-area rectangle, k>=max(13,b+1), arbitrary physical initial shape with
total holes q0<=H, a TIED reference (q0,q0), and actual counts remaining
at most H. The proof is not an arbitrary unequal-seed comparison.

Checked the initialization, interlacing, and actual positive-time markers.
No marker is assigned to the initial physical shape. Before its first good
event the bad and critical branches preserve the relevant comparison; the
first good target supplies its own actual component/corner. The large-root
drift calculation in the frozen proof only improves when the numerical
origin is q0>=0: u*v<r^2-q0<=r^2. Its oriented span bound starts from a tie,
not from a geometric assumption. The existing core-persistence argument is
therefore applicable without a hidden full-origin hypothesis.

For the remaining roots, the finite-domain completeness argument is exact:
positive-time danger forces k<=r^2+r, q0<min(99^2,(k-2)^2), and r<=k-2.
The two independent implementations enumerate every retained ordinary pair
and every permitted dangerous target/phase. Their counts agree exactly:
78,874,764 pairs and 61,562,872 targets, with zero failed obligations.
The independent review explains why early stopping remains valid under
later bad updates, and bounds every integer lookup and arithmetic value.
This is an independently checked complete computational base, not Lean.

The restart uses the same actual future word. A state below min E_(j-1)
would finish below max E_(e-1)<=min E_e, contradicting its genuine dangerous
endpoint. Hence every preceding state satisfies the one-clock corridor,
and the original surplus on every update is at most 2k-1. This avoids the
false argument that area deficit cannot recover through radial walls.

## Exact literal early reachability

Accepted Sections 1--4 of `even-genuine-clock-boundary-access.md` using that
restart theorem. For literal one-color hole sets X,Y, necessity and
sufficiency of

    |N(Y) minus X|<=k,
    E(X union N(Y))=Y

follow by inclusion in the real raw inspected set. Sufficiency reconstructs
exactly the inspections N(Y) minus X. Thus the layered recurrence neither
grants a free favorable phase nor replaces exact target equality by mere
containment. All its intermediate states have the required cutset bound,
not just their final endpoints. The first-cut, genuine-time, physical-color,
solo-normalization, and dangerous-endpoint predicates remain explicit.

Its state bound exp(O(b log b)) applies when k<2b and n=O(b); it is not a
claim of a practical small running time. The transition diagnostic is
independent evidence; the bidirectional mathematical proof is the reason
the recurrence is exact.

Section 5 is accepted with its explicit restriction: erosion seeds described
by a cardinality cap are exact for that arbitrary-terminal-set problem.
They are only a necessary relaxation of a real activated mixed suffix.
The new spatial counterexample confirms why the missing predicate matters.

## The reverse-cap obstruction is removed

Accepted `even-reverse-cap-one-room-buffer.md`, independently reviewed also
by the odd lane. This result uses the frozen genuine shifted-orbit proof,
not the new arbitrary-tie computational base.

The actual activation set has |D|<=b^2 by the genuine interlacing and
enlarged mixed cap. Its actual erosion initializes the old phase invariant
inside H. The failed-join account supplies max W_final<=H-1 for every
1<=d<=b-1. At a hypothetical first exit above H, raw size<b^2+b excludes
the subcritical co-small alternative, so original surplus is at least b.
Then q_new<=G(M_prev)<=F(M_prev)+1<=M_next+1<=H, a contradiction. The
off-by-one buffer and exact ell-1 reference index are essential.

Consequently the actual reverse endpoint is unclipped for the WHOLE
low-budget even-width failed-join range, and the common account
delta_E+delta_J+eta+R<=g-1 needs no former d<=b/2 or M_L<b^2+1 guard.
This closes a prior interface gap; it does not establish that every relaxed
activation seed is physically realizable.

## Full-game boundary

These accepted results settle exact early boundary reachability and the
reverse cap interface. They do not yet prove a complete physical late
activation predicate, transverse/corner phase matching, or a smaller
uniform capture-time gap. All prior bounds and exact families remain in
force. No publication or formal-source coverage is upgraded by this review.

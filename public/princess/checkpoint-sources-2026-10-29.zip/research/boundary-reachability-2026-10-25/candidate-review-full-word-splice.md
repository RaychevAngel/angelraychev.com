# Independent review of full-word reversal and polarization

25 October 2026. Accepted as an ordinary finite-graph interface theorem.
Reviewed source: `odd-full-word-reversal-splice.md`. This review does not
establish a new capture-time value or a two-solo-prefix reduction.

## Exact cut and budgets

At the pre-inspection cut t, the forward prefix has t updates and the
reverse suffix has T-1-t updates. Their endpoints therefore represent the
same physical day. An endpoint outside I_t in their intersection produces
two compatible avoiding walks; reversing the suffix and concatenating
them gives an evading full walk. The converse follows by restriction.
There is precisely one central inspection and no extra terminal movement.
Consequently, replacing that inspection by the literal intersection gives
the claimed if-and-only-if splice test with its true quota. Time-varying
prefix quotas must be reversed with the suffix, as the source states.

## Polarization and last-full normalization

The neighborhood inclusion and useful-cost argument in
`../overnight-uniform-2026-10-24/lower-alternating-polarization.md`
apply to finite prefixes without requiring terminal capture. Choosing
opposite endpoint favored colors yields actual endpoints contained in
the two opposite compressions. In each two-vertex involution orbit their
intersection has size max(0,f+r-2), at most the old intersection size.
Thus this transformation preserves central splice feasibility.

I independently checked the endpoint-preservation step against
`../overnight-uniform-2026-10-24/lower-last-full-mixed-penalty.md`
and the explicit finite-prefix extension in
`../phase-dependencies-2026-10-24/comparison-uniform-four-review.md`.
Include the terminal pre-inspection time in the set of possible last-full
times. Before that last time, replace favored-cohort survivors by the full
folded graph; leave the smaller cohort unchanged. No-isolated-vertices
gives K(V)=V. Costs decrease, nesting holds, and the literal two-cohort
state at the last-full time is unchanged. Subsequent actions and the
terminal endpoint are therefore unchanged. If the terminal favored
cohort itself is full, this operation makes the entire prefix solo and
still preserves its endpoint. This is an actual word transformation,
not an unattained cardinality seed.

## Counterexample and limitations

The 2-by-4 three-day word in the source has successive beliefs equal to
columns 1,2,3 and then 2,3, before capture. The reversed word is symmetric.
Every set is a union of the row-reflection pairs, so either polarization
leaves it unchanged, and the last-full time in each direction is zero.
At every cut one prefix has already activated both cohorts. The separate
two-day whole-color word proves that this is not a counterexample to an
optimal-horizon exchange theorem. The source distinguishes these claims
correctly.

The accepted conclusion supplies two actual full-origin prefix endpoints
and their exact splice inequality. It does not bound permanent mixed
suffix duration, compress all such endpoints, guarantee simultaneous solo
activation order, or close a rectangle capture-time gap. No Lean claim is
made.

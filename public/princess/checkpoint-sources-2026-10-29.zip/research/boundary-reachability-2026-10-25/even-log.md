# Boundary reachability research log, 25 October 2026

## Objective

Resolve genuine-clock access to the literal boundary shapes needed by the
even-width failed-join reduction, or obtain a direct joint lower obstruction.
Previous dated sources remain frozen. Do not infer exact strategy access
from a numerical capacity or from an endpoint-only cutset bound.

## Failed first deficit telescope

An initial proposed claim was that delta_j=max E_j-Q_j can recover by at
most one per day because G is monotone and 1-Lipschitz. This uses
nonexpansiveness in the wrong direction and was withdrawn immediately.
The exact recovery includes rho(max E_j+k)-rho(Q_j+k), which can be larger
than one. No theorem or receipt was created for that false shortcut.

## Scalar inverse corridor is too loose

The true one-step inverse G bound gives
Q_j>=I^(e-j)(Q_e), I(q)=max(0,q+ceil_sqrt(q)-k). Combining it with
Q_j<=max E_j supplies a valid numerical surplus ceiling, but a small
discriminant found the ceiling grows quadratically at low excess. For
b=512,d=1, a genuine dangerous cut at e=5648 permits ceiling 64775,
approximately b^2/4. This is a failure of the relaxed bound, not a physical
counterexample. The relaxation discards the two-phase compatibility which
prevents the apparent delayed start. It is not the route being pursued.

## Tied restart provides the relevant corridor

The odd lane is proving the ordinary physical count theorem from EVERY
nonnegative tied numerical origin. If that premise is accepted, a genuinely
dangerous endpoint forces every previous actual count strictly above the
previous genuine minimum. Otherwise restart the literal actual state under
a tie beneath that previous pair; after the same remaining moves the final
count is below the final genuine minimum. The resulting exact original
surplus bound is <=k+span(E_(j-1))-1<=2k-1 at every boundary update.

The new even-genuine-clock-boundary-access.md spells out the conditional
early access recurrence and shifted reverse initialization. Its exact
physical transition uses the minimal raw superset X union N(Y): an erosion
step reaches exactly Y if and only if its erosion equals Y and
|N(Y) minus X|<=k. This prevents a hidden optimization over arbitrary
inspection sets at each graph edge. The old cutset theorem now applies to
EVERY necessary boundary intermediate set, yielding an exact exp(O(b log b))
state family on the remaining short boards, conditional on tied restart.

## Preserved full-game limitation

The reverse seed test is exact for a fixed actual D or for the union of all
arbitrary terminal sets satisfying a stated cardinality cap. The accepted
activation comparison |D|<=min V_r is necessary, not by itself a proof that
every such D has the real future mixed signed continuation. That genuine
terminal-access predicate remains explicit. No global exact capture-time
claim has been made from the new early recurrence.

## Independent acceptance and full reverse cap repair

The tied restart is now independently accepted by root, with a separate
candidate-lane replay of the ENTIRE small-root arithmetic base: the two
implementations agree on 78,874,764 reachable pairs and 61,562,872 dangerous
seeds, with zero failures. Root accepts the exact early recurrence and its
explicit reverse-suffix limitation in root-review-boundary-access.md.
The originally conditional source is retained unchanged for its receipt.

A separate ordinary argument removes the whole remaining even reverse-cap
band. The actual activation raw set has size at most b^2, while the failed
join forces the final genuine reverse maximum at most H-1. A first actual
exit above H would satisfy q_new<=G(M_prev)<=M_next+1<=H, contradiction.
Both root and the odd lane independently accepted
even-reverse-cap-one-room-buffer.md. Thus the physical shared account
delta_E+delta_J+eta+R<=g-1 now holds for every b>=32, all1<=d<=b-1,
alln>=2b, with no remaining d<=b/2 or M_L<b^2+1 reference guard.

The canonical activation reduction is also accepted by the odd lane:
for J=E(D), the least raw representative is N(J), with E(N(J))=J.
Any actual fixed-budget mixed suffix from D works from N(J) by monotonicity.
Hence the unresolved suffix predicate is a function of J and its true
clock, not an additional arbitrary raw shape. Its evaluation is still open.

## Neutral critical collars can share the strict loss account

The first collar derivation bounded early radial-wall loss by two. Root
and this lane independently sharpened it to one: a loss can occur only
on an outgoing-F maximum, whose next leader is on the outgoing-G side.
The final maximum cap forbids another update after that loss. Moreover
the loss decreases final ordinary span by at least one. Therefore its
one extra loss unit is offset in the g<=d bound:

    Lambda_E+Lambda_J+eta+R<=g-1+c_E<=d-1.

The reverse collar has no numerical extra loss at all. These statements
are recorded in even-critical-collar-strict-credit.md, currently proposed
for independent review. An exact bounded diagnostic checked215,124 genuine
early states through b256, with14,354 one-stall states and no failure of
the one-stall/span-drop assertions. The source contains the uniform proof.

If accepted, both clamped collars strictly advance; there is at most the
first source contact with L, whose clamp charge overcounts actual original
surplus rather than hiding it. The early collar and actual middle form a
single physical critical trace with the same consecutive-critical gap<=d
used by the earlier temporal barriers. This handles neutral critical time
without a false O(g) bound on all earlier subcritical ancestry.

Still unresolved: the genuine corner marker at entry from the earlier
subcritical history; the literal reverse-to-forward overlap at eta; the
exact activated suffix predicate; and the separate remaining central
geometry handled by the other lanes. No capture-time bracket is tightened
solely from these interface improvements.

## Proposed exact compression of the activated mixed suffix

The missing suffix predicate may now have a non-generic exact evaluator.
For its true shifted seed at index r, dangerous continuation implies
|E(D)|>min W_(r-1). The mixed comparison itself extends to any nonnegative
terminal signed gate a while the initial reference remains under the same
b^2+1 cap. Applying that comparison to an actual mixed PREFIX rules out
any intermediate m_t<=min V_(s-2), where s=r-t is the remaining length:
it would force |D|<=min V_(r-2), and square inversion plus W interlacing
would contradict the dangerous seed inequality.

Together with m_t<=min V_s, this two-clock corridor bounds EVERY original
mixed surplus by2k-1. The final update has a separate exact argument,
including negative signed mass before the terminal gate. Therefore every
positive-time actual mixed belief has two O(k)-cutset descriptions. The
canonical raw N(J) provides its exact initial state. Direct belief edges
use the maximal survivor B intersect E(B'), with exact image equality and
minimum useful inspection cost; no free inspection search is hidden.

This is written in even-mixed-suffix-two-clock-corridor.md for independent
attack. If accepted, it closes the specific activation-access predicate
inside an exp(O(b log b)) exact state graph on the remaining short even
boards, rather than an unrestricted area-exponential state enumeration.
No enumeration was launched. Its remaining obligation is careful global
assembly with the existing early, reverse and middle predicates. It is
not yet a proof that the canonical prefix always wins or a new numerical
capture bracket.

The mixed-suffix source has now passed root review and two independent
lane audits. The current hash is
fe37cc2c7400d1c3ece54dacf4e90ae4f1b00ba1c4a0d4ca1d056528af958684;
it explicitly retains normalized nesting and proper maximal survivors.
The final source also records the finite bound r<=b^2-c. The odd and
candidate receipts distinguish the universal ordinary argument from any
finite arithmetic diagnostics.

## Exact signed-gate assembly, pending audit

even-exact-gate-cutset-assembly.md combines the early, strict-middle,
genuine reverse and activated-suffix graphs for each T below constructive
P(c). It preserves literal colors, a=ell-r, exactly a-1 reverse edges,
and reference endpoint index ell-1. The actual splice is |S minus J|<=k;
its first inspection is exactly S minus J and its actual excess is
eta=|J minus S|. Reversing the stored inspections reaches a subset of
D=N(J_0), where the actual mixed suffix works by monotonicity. No future
suffix is fabricated from its size alone.

If this final composition passes independent review, it provides an exact
compressed signed-gate evaluator below P(c) on the whole stated even-width
low-excess range. It still does not prove every decision is negative, nor
does an arbitrary mixed signed-gate optimizer automatically give the old
prefix palindrome for capture: its literal small cohort can exceed its
signed mass. Exact capture assembly remains a separately stated objective.

The strict collar has now passed independent odd-lane review in
odd-review-even-strict-collar.json. The exact gate assembly has also
passed independent odd-lane review in odd-review-even-exact-gate-assembly.json,
pinning source6416b6563529a678837c635572932efa490aefad7d26e9786e15a16fcad0b7f6.
The review explicitly checks necessity, r=0, a=1, true colors, a-1 reverse
edges, and actual reconstruction into N(J_0) after exactly a solo updates.
Root is maintaining the integrated acceptance checkpoint.

## Beyond the signed-gate checkpoint: four-clock capture prefixes

Root derived a sharper target for exact capture assembly. If J=J(k) and
the existing constructive capture bound is at most2J+4, then every candidate
winning word can be split at its first forward signed-mass crossing<=k
into two actual prefixes of lengths in[J,J+3], separated by one central
inspection. Their literal forward/reverse endpoint intersection must have
size<=k. Complementary polarization and independent last-full normalization
preserve that intersection inequality. Thus exact endpoints at four genuine
clocks, rather than an arbitrary-state capture solver, suffice.

The first attempted extension used the real reverse allowed-set trajectory.
At four-clock slack its terminal reference can leave H, losing the earlier
one-room buffer. An O(1)-step post-cap boundary-growth argument looked
possible but introduced avoidable geometry. This route is retained as an
observation, not pursued as a new obligation.

The successful replacement is an arbitrary-terminal signed-late comparison.
Odd lane identified the exact raw-seed initializer: for z>=k, an arbitrary
raw D<=z<=b^2 is obtained in one real inspection from holes X subset D of
size min(|D|,z-k). Tied restart from(z-k,z-k) gives exactly
(z-rho(z),z-ceil_sqrt(z)) after that inspection. This initializes the actual
reverse seed at its genuine shifted clock, without any favorable phase or
new finite arithmetic base. Our receipt even-review-general-raw-seed.json
accepts the independent initializer source.

even-arbitrary-terminal-late-comparison.md now extends the exact capped
ordinary MAX bound to every terminal mass a in[0,H]. Odd independently
accepted it at hash087f55728040ef6f701c5e5466945db9fc4b779b25d564945ba2e84ad873313e.
Applying this bound to actual initial segments of the late tail gives the
needed backward mass corridor directly on the REAL forward states.

even-fixed-clock-slack-cutset-corridor.md proves the uniform result:
any normalized full-origin gate-k prefix of length T in[J,J+s-1] has every
total original survivor surplus at most(3s+1)k-1. At s4 the bound is13k-1.
The early and late parts have genuine s-clock corridors. The middle uses
the two-wall clamp[L,h-H-1], with every increment<=d for arbitrary
two-cohort histories. The actual clock-delay account gives lossR<=sd-1;
at mosts-1 nonpositive clamped steps force every below/above-wall excursion
to stay within sk rooms. This controls all actual middle surpluses without
strict progress, a solo middle, or a static orientation classification.

The fixed-clock source passed independent odd review at hash
fa62e428689f5c577cdcd46832c9d201113e8841e61505408470ba6d412a299b;
root and candidate have reported positive ordinary audits, with candidate
preparing a hash receipt. Bounded independent discriminants also passed:
261989 literal4x4 survivor/inspection variants, and80 relaxed scalar
excursion cases containing50584 reachable/coreachable edges. The first
test implementation consumed a seed generator twice and yielded vacuous
scalar closures; this was caught by inspecting zero edge counts, repaired
by materializing the seed list, and rerun. Only the corrected positive-
count result is recorded. The uniform theorem does not rely on the tests.

even-near-optimal-prefix-endpoint-recurrence.md records an exact normalized
endpoint recurrence using two literal cutset sets, true colors, and exact
erosion-image tests. Root will use the even simpler sound superset graph
which permits all physical paths inside the same cutset universe; the
normalization is then needed only to prove that some winning pair is
represented. Extra actual graph paths cannot fabricate a capture.

This is a structural exp(O(k log(wn))) endpoint compression, and
exp(O(b log b)) on the remaining short low-budget boards. The constant in
the cutset cap is large; at moderate widths the cap can exceed all array
edges. No practical large-width enumeration or fixed-size formula is
claimed. The exact full capture composition is being written and must be
independently audited before describing this as an exact capture evaluator.

Root's complete composition is now written in
root-exact-low-budget-even-capture.md. This lane independently accepted
the ordinary exact-evaluation theorem at hash
d7dbd37f0cdd1fe91e21b8d3b04e6cf2638800ffdee8c85774a5df498c7baeae,
with receipt even-review-exact-low-budget-even-capture.json. It covers
w=2b>=64, every n>=2b, and every k=b+d with1<=d<=b-1. The graph may
retain all actual physical paths in the bounded-cutset universe; only
necessity uses the normalized witnesses. Actual endpoint intersections
and exact reversed inspection reconstruction prove optimum, without
proving that the old scalar lower bound or corner construction is exact.

This closes the exact-evaluation interface on that complete family.
Its direct parameter inspection rule, efficient recurrence or bounded
numerical formula are not supplied. Other parity/budget families retain
their separately stated results and gaps. No large evaluation, Lean
update or publication change has occurred in this lane.

## Uniform budget extension through half the square scale

Parent next assigned the missing2b<=k<3b band and asked for a family
argument. The first route compared the old six-root/BAND9 clock with a
two-wall affine clock. It would cost a constant number of collar updates,
but introduced unnecessary dependencies. A fixed raw threshold removes
that comparison entirely and extends farther than the original band.

For every even width2b>=64, every n>=2b, and
2b<=k<=floor(b^2/2), put z=b^2-k+1, d=k-b. The first actual hole crossing
of z has target<=H=b(b-1), since its raw size is<=b^2. The LAST signed
mass crossing into <=z-1 has prior mass Y in[z,b^2], simply because one
update decreases signed mass by at most k. It exists because z>k.
These cuts preserve the genuine ordinary boundary comparisons.

The new necessary affine clock is

    J*=e0(z)+ell0(z;k)+ceil((h-2b^2+b)/d).

The supported ordinary physical head and tail at z, together with global
even-width backward MINIMUM progress d, construct a gate in J*+4 updates.
The genuine late span is at most d; endpoint collars plus this span cost
at most4d rooms. Thus full capture takes at most2J*+10 days. Both prefixes
in the literal capture split lie at one of ten genuine clock values.

The same corridor gives original surplus<=31k-1 on every update of every
normalized relevant prefix. One subtle old guard U-d>L need not hold at
quadratic k. It is unnecessary: any below-L excursion's final exit grows
by at most k, so its last below-L source is >=L+1-k; at mosts-1 earlier
clamp stalls give depth<sk. This also covers excursions already underway
at the initial cut and upper excursions continuing through the final cut.

The ordinary arbitrary-terminal comparison extends through k<=b^2:
the accepted tied theorem has no upper budget, and its exact raw initializer
still starts belowH. The reverse clip threshold b^2-k+1 is positive.
No stronger H-1 first-exit-buffer claim is imported at high budget.

Source even-medium-budget-ten-clock-extension.md is frozen at
f3b88ef69bca73ab992a34236cd02b90b7a6d7ce99b631817f16b6a35af100c0.
Candidate independently accepted it in candidate-review-medium-budget-
capture.md/.json. Root and odd lane reported positive ordinary review;
root is writing the integrated receipt. A wording issue was corrected
before pinning: the swapped physical pair's MINIMUM gains d per update;
each same-labelled coordinate need not do so. The proof only uses this
minimum assertion.

The graph is still exp(O(k log(wn))). In every linear-budget family on
short boards it gives exp(O(b log b)); near quadratic k it can degenerate
to the whole power set, and no speedup is asserted there. No finite
parameter table, large enumeration, formal source or public page changed.
Parent requested consolidation at this accepted bridge rather than a new
expansion above b^2/2; that larger range remains outside this lane's new
claim. Odd lane is separately adapting the medium-budget argument to odd
width using physical progress d-1 and a measured length-dependent slack.

## Root's final high-budget shortcut

After the consolidation request, parent explicitly reopened one bounded
audit: a global total-surplus account for high budgets. This avoids every
boundary/normalization complication. For ANY actual gate-k prefix of t
updates, total holes at its endpoint are at least h-k, so exact accounting
gives sum(original surpluses)<=(t+1)k-h. Every summand is nonnegative.

Use elementary gate lower clock A=ceil((h-k)/k) and actual physical prefix
upper clock P=ceil((h-k)/(k-B)), where B=ceil(w/2)<k<h. The authoritative
finite-board prefix maps in paper/sections/bridge-uniform-upper.tex have
global inverse cost at mostB, so their pair minimum grows by k-B and
full capture is constructed in U=2P+2 days. The actual optimal capture
split has both prefix lengths at mostU-1-A. Consequently every required
original surplus is at mostC=(U-A)k-h, without normalizing either word.

Algebra gives C<=2hB/(k-B)+3k. For b=floor(w/2)>=32 and
k>floor(b^2/2), this is less than9n+3k. The exact literal cutset graph
therefore covers this entire remaining high-budget range, at both width
parities, with exp(O((n+k)log(wn))) state complexity. The k>=h cases are
exactly two days until k>=2h, then one day. The quadratic-budget short
range can still contain the whole power set; this limitation is explicit.

The independent derivation is even-total-surplus-high-budget-capture.md,
submitted to parent and candidate for source review. This is a budget-
conservation theorem with a physically checked global width-cap upper
construction. It does not rely on the new tied-restart finite base, free
phases, phase incompatibility conjectures, or a mixed gate palindrome.

Candidate then simplified the same insight further: append the harmless
movement after the final capturing inspection. A complete winning T-day
word has total holes2h, so its total original surplus is at mostTk-2h.
With any physical upper bound U, every optimal intermediate state is
therefore in the cutset universe with capC*=Uk-2h. The exact graph can
seek the empty belief directly, with no gate lower clock, split, reversal
or normalization at all. The authoritative global width-cap construction
gives C*<=2hB/(k-B)+2k; for b>=32,k>b^2/2 the sharper direct denominator
estimate gives C*<=5n+2k. This lane independently checked that algebra,
the harmless final update, and equivalence of first empty belief with
capture (the rectangle has no isolated cells). The final source is
candidate-whole-word-surplus-capture.md; candidate is adding the exact
frozen physical-map citation and an unambiguous same-color two-day rule
before this lane pins its final acceptance receipt.

Final independent acceptance: candidate fixed the physical backward-map
citation and same-physical-color two-day rule. The source is frozen at
fead6e503f33bd6c74083e504975f09399c3e65aafa718a5c85c4b28a0afe4cb.
The receipt even-review-whole-word-surplus-capture.json independently
checks the full-word identity, literal empty-belief graph, physical width
cap, and sharper5n+2k bound. The earlier gate-prefix shortcut remains a
valid derivation but is superseded by this simpler complete-word theorem.
This closes the authorized high-budget audit; no further mathematical
search, publication edit, or formalization was started.

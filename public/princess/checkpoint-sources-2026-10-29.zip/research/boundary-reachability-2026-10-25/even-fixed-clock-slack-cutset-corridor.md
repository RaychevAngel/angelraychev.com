# Every near-optimal even-width gate prefix has bounded cutsets

25 October 2026. New ordinary theorem for independent attack. This retains
all literal intermediate shapes, both cohorts, activation and retreats.
It does not claim that a canonical corner strategy is optimal.

Let w=2b, n>=2b, b>=32, k=b+d, 1<=d<=b-1, h=bn, and

    L=(b-1)^2, H=b(b-1), A=H-d+1, U=h-H-1.

Use the genuine ordinary early pair E from (0,0) and the ordinary late
pair V=V^k from (k,k). Define

    e0(Q)=min{t:max E_t>=Q},
    ell0(Y)=min{t:max V_t>=Y},
    J=min_(A<=Q<=H, H+1<=Y<=H+d+1)
        [e0(Q)+ceil((h-Q-Y)/d)+ell0(Y)].             (S1)

Let a full-origin, nested, last-full-normalized physical prefix reach
signed mass at most k after T updates, where

    J<=T<=J+s-1, s>=1.                             (S2)

Then the sum of original survivor surpluses on EVERY update is at most

    (3s+1)k-1.                                    (S3)

In particular s=4 gives 13k-1 for every prefix of length J through J+3.
The accepted cutset theorem consequently encodes each individual cohort
hole set at every time by at most

    6((3s+1)k-1)+(b-1)*1_[n odd]                  (S4)

internal cut edges in the b-by-n matching array, and one base bit.

## 1. Physical accounting and the two actual cuts

Write Q_t for TOTAL holes in the two cohorts and m_t=h-Q_t for signed
mass. Let i_t<=k be useful inspections and sigma_t>=0 the sum of their
two ORIGINAL survivor surpluses. Then exactly

    Q_(t+1)-Q_t=i_t-sigma_t,
    m_(t+1)-m_t=sigma_t-i_t.                       (S5)

The original surpluses are nonnegative by a perfect matching. No solo
assumption is made in (S5). Every target individual hole set has dual
surplus no greater than the corresponding original survivor surplus.

Let e be the first time Q_e>=A. The accepted first-crossing bound gives

    A<=Q=Q_e<=H, Q_t<A for t<e.                    (S6)

Let v be the LAST index with m_v>H and m_(v+1)<=H. Put

    Y=m_v, Delta=v-e, ell=T-v.

The standard final-crossing inverse bound gives

    H+1<=Y<=H+d+1.                                (S7)

For clarity, this bound is independent of earlier excursions and applies
to both cohorts. If sigma>=b, (S5) gives Y<=H+k-b=H+d. If sigma<=b-1,
apply small/co-small separation to the two target hole sets, whose
individual dual surpluses are at most sigma_0,sigma_1. Both small would
give total target holes <=sigma_0^2+sigma_1^2<=L, impossible at target
mass <=H. If either is co-small, the signed target mass is at most
sigma_i(sigma_i+1)<=sigma(sigma+1). Therefore
Y=m_(v+1)+i_v-sigma<=sigma^2+k<=L+k=H+d+1.

We have Delta>=1 and ell>=1. Indeed at e the mass is at least h-H,
which exceeds H+d+1, while the terminal mass <=k is below H. After v,
all actual masses are <=H: otherwise reaching the terminal state would
create a later crossing, contradicting the choice of v.

## 2. A double clamp makes the middle loss nonnegative

Set C_t=min(U,max(L,Q_t)). For EVERY update one has

    C_(t+1)-C_t<=d.                               (S8)

If sigma>=b, the actual increment is at most d, and the monotone
1-Lipschitz clamp preserves that bound. Suppose sigma<=b-1. Apply
small/co-small separation separately to the two target hole sets.
If both are small, Q_(t+1)<=sigma_0^2+sigma_1^2<=sigma^2<=L and the
clamped increment is nonpositive. If either target hole set is co-small,
its complementary color has size at most sigma_i(sigma_i+1), so total
signed target mass is at most sigma(sigma+1). By (S5),

    m_t=m_(t+1)+i_t-sigma<=sigma^2+k<=L+k=H+d+1.

Thus Q_t>=U-d, and C_(t+1)-C_t<=U-(U-d)=d. This proves (S8) for
all actual histories, independently even of normalization. In particular
a jump across both clamp walls cannot defeat it. This same proof also
shows sigma>=b whenever L<Q_(t+1)<=U.

Both actual endpoints e,v lie strictly above L and at most U. Therefore

    R=d*Delta-(Q_v-Q_e)
     =Q+Y+d*Delta-h
     =sum_(t=e)^(v-1)[d-(C_(t+1)-C_t)] >=0.       (S9)

This proves Delta>=D0=ceil((h-Q-Y)/d) without assuming monotonicity.
The ordinary early and signed-late comparisons give e>=e0(Q) and
ell>=ell0(Y), respectively; the late cap applies because Y<=b^2.
Thus the three nonnegative INTEGER delays obey

    (e-e0(Q))+(Delta-D0)+(ell-ell0(Y))<=s-1.       (S10)

Indeed the endpoint expression in (S1) is at least J, and T<=J+s-1.
In particular

    R<=sd-1.                                      (S11)

## 3. Every early state lies in an s-clock corridor

For e>=s, (S10) implies e-s<e0(Q), hence Q_e>max E_(e-s).
For any s<=j<=e, if Q_j<=min E_(j-s), restart the ACTUAL future at j
under tie(Q_j,Q_j). All early counts remain <=H. The accepted arbitrary
tied-origin restart and monotonicity give Q_e<=max E_(e-s), contradiction.
Consequently

    min E_(j-s)<Q_j<=max E_j,       s<=j<=e.        (S12)

Each scalar maximum increases by at most k per step and every genuine
pair has spread at most k. Combining (S5) and (S12) on update j-1->j
gives sigma_(j-1)<=(s+1)k-1. For j<s (or the whole early segment if
e<s), Q_(j-1)<=k(j-1) gives sigma_(j-1)<=jk, which is smaller.
This controls both cohorts without an assumed solo early history.

## 4. Middle excursions are shallow even when R>=d

A nonpositive clamped increment costs at least d in (S9). Thus there
are at most s-1 such steps. Write epsilon_t=Q_t-C_t. We claim

    -sk<=epsilon_t<=sk,        e<=t<=v.            (S13)

For an excursion above U, the first entry rises by at most k by (S5).
Every subsequent step whose two endpoints stay above U has zero clamped
increment and hence is among the at most s-1 charged steps. Actual rise
is always at most k. The upper overhang is therefore at most sk.

Every excursion below L must return, because both endpoints are >L.
The final below-L source before return is at least L+1-d: its target
cannot jump above U, by the upper crossing bound and U-d>L, and its
target in (L,U] has original surplus >=b. Every earlier step within this
below-L excursion has zero clamped increment and actual rise at most k.
Its depth is consequently at most d-1+(s-1)k<sk. This proves (S13),
including excursions entered by a large retreat.

On any middle update put lambda_t=d-(C_(t+1)-C_t)>=0. Equations
(S5), (S9), (S11) and (S13) give

    sigma_t
      <= k-(C_(t+1)-C_t)+epsilon_t-epsilon_(t+1)
      <= b+lambda_t+2sk
      <= b+(sd-1)+2sk
      <= (3s+1)k-1.                               (S14)

No intermediate shape classification or orientation is used here. The
price for allowing all near-optimal retreats is a fixed constant in the
cutset bound, not the exclusion of any actual trajectory.

## 5. Every actual late state also lies in an s-clock corridor

Reindex the late word by t=0,...,ell, starting at mass Y, and let r=ell-t
be its remaining updates. Its usual signed-late upper comparison gives

    m_t<=max V_r.                                  (S15)

This is unclipped because t=0 has Y<=b^2 and t>=1 has m_t<=H.
We now use `even-arbitrary-terminal-late-comparison.md`, independently
reviewed, which allows any nonnegative terminal a<=H.

Whenever r>=s we have

    m_t>min V_(r-s).                               (S16)

For t=0 this follows from ell-s<ell0(Y). For t>=1, if (S16) failed,
put a=max(m_t,0)<=H. The ACTUAL first t updates of the late word form
a normalized suffix ending at signed mass <=a. The arbitrary-terminal
comparison, with Y<=b^2, and scalar monotonicity imply

    Y<=max V_t^a<=max V_(ell-s),

contradicting ell-s<ell0(Y). No surrogate endpoint shape is used.

For r>=s, (S15)--(S16), scalar increment <=k and spread <=k give
sigma_t<=k+max V_(r-1)-min V_(r-s)-1<=(s+1)k-1.
If ell>=s, at remaining time s the mass is at least k+1. Afterwards
it can decrease by at most k per update, so for 1<=r<s its lower bound
is k+1-(s-r)k. The next upper bound is max V_(r-1)<=rk, yielding
sigma_t<=sk-1. If ell<s, use m_t>=Y-tk>=1-tk and the same next upper
bound; this gives sigma_t<=(ell+1)k-1<=sk-1. Thus all late updates,
including those with negative signed mass, obey the early bound.

## 6. Literal cutset state space and exact scope

Each positive-time target cohort hole set has dual surplus <=sigma_t.
Apply the accepted matching-array cutset representation to obtain (S4).
At time zero the two hole sets are empty and require no cut edges.
This proves the announced bound for EVERY actual normalized prefix
satisfying (S2), including arbitrary physical activation time.

The number of literal pair states is exp(O(sk log(wn))) using the stated
cutset enumeration. For fixed s, low budget k<2b and short boards n=O(b),
this is exp(O(b log b)), rather than an unrestricted power-set state
space of size exp(Theta(b^2)). Every membership and transition test remains
a literal physical set computation. No large enumeration is launched here.

The conclusion is a compression theorem for all near-optimal full-origin
gate-k prefixes. To obtain capture time one must still combine their
ACTUAL endpoint sets using the accepted forward/reverse intersection
criterion, with actual clocks and complementary polarizations. The value
of a signed gate alone is not a capture theorem.

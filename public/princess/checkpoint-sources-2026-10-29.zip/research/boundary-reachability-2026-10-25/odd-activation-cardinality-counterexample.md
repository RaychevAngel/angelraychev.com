# A cardinality-permitted activation seed need not be physically clearable

25 October 2026. Elementary adversarial example; no numerical search.

This distinguishes exact access to a genuine terminal-quota boundary word from an activation seed described only by the necessary inequality |D|<=min V_r. That inequality must not be advertised as an exact physical terminal predicate.

Fix any integer budget k>=13, and put

    m=k+floor(k/4)+1.

Choose an even-area rectangle with width w>=4, feasible budget k>=floor(w/2)+1, and sufficiently large even length n>=max(w,4m). In cell coordinates choose the one-color interior set

    D={(2,4j+2): 0<=j<m}.

Every selected room has all four grid neighbors. The neighbor sets of distinct selected rooms are disjoint because their pairwise distances are at least4. Therefore ANY subset S of D has |N(S)|=4|S|.

After one inspection of at most k rooms, at least m-k=floor(k/4)+1 initial possibilities remain. After the mandatory movement there are consequently more than k possible rooms:

    |N(D minus I)| >=4(floor(k/4)+1)>k.

Thus NO one-update strategy sends this actual solo set D to a terminal set of at most k rooms; equivalently it cannot be guaranteed captured by those two inspection days.

However the ordinary backward pair initialized at terminal quota k has

    min V_1^k=2k-ceil_sqrt(k),

and m<=2k-ceil_sqrt(k) for every k>=13. One elementary check is floor(k/4)+1+ceil_sqrt(k)<=k: it holds for13<=k<=16 directly, and for k>=16 follows from ceil_sqrt(k)<=k/4+1, which gives a total at most k/2+2<=k. Hence D satisfies the cardinality permission |D|<=min V_1^k.

The numerical necessary seed is therefore STRICTLY weaker than a realizable suffix predicate, even on feasible rectangular boards and even for a one-update suffix. The issue is the actual spatial configuration, not a phase convention or a constant rounding error.

This example does not contradict any accepted necessity theorem: those never claimed all cardinality-permitted sets were attainable. It also does not obstruct using that relaxation in a lower-bound proof which excludes every permitted seed. It does obstruct calling the relaxed endpoint calculation an exact full-gate evaluator without a further physical argument.

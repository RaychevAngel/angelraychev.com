# A one-room buffer removes the remaining even reverse-cap band

25 October 2026. **Draft ordinary lemma for independent attack.** This uses
only frozen ordinary genuine-orbit continuation and the accepted enlarged
mixed cap. It does not depend on the new arbitrary-tied restart theorem.
No previous dated source is edited.

Write w=2b, n>=2b, h=bn, b>=32, k=b+d, 1<=d<=b-1, and H=b(b-1).
Let V^c be the genuine ordinary backward pair from (c,c), 0<=c<=k,
and W_j=V_(j+1)^c-(k,k). The proposed conclusion is that the actual
reverse endpoint in EVERY failed-prefix even-width join is unclipped:

    |J| <= max V_ell^c-k.                            (B1)

Consequently its true allowed-set account holds for all these d:

    delta_E+delta_J+eta+R <= g-1,                    (B2)

without the former additional reference guard max V_ell^c<b^2+1.

## 1. Genuine shifted initialization with the actual seed at most b^2

Suppose the actual shifted seed is J_0=Erosion(D), where

    |D| <= min V_r^c,       |D| <= b^2.             (B3)

Then q_0=|J_0|<=H and its initial genuine phase invariant is the one used
by the frozen shifted continuation, at exactly index r.

Indeed N(J_0) subset D. The small/co-small separator gives the ordinary
one-shot square inverse throughout |D|<=b^2:

    q_0 <= |D|-rho(|D|) <= b^2-b=H.

For a non-tiny nongood subcritical seed, its original raw surplus
|D|-q_0 is at least ceil_sqrt(q_0)+1; exact inversion gives
q_0<=|D|-ceil_sqrt(|D|), placing it below both W_r coordinates.
A critical-root seed obeys the same worse-phase bound, since its original
surplus is at least b and ceil_sqrt(|D|)<=b. A zero-good seed has its actual
geometric corner and phase, whose original profile places q_0 below the
matching W_r coordinate. No arbitrary shape is assigned a convenient phase.

For r>=1, tiny seeds are below both coordinates since W_r dominates the
ordinary zero-origin pair at r, whose minimum is at least nine. For r=0,
the exact first-quota theorem applies because |D|<=c<=k, including its
already proved tiny initial exception. The later mixing comparisons use
the SAME genuine W orbit and the actual shifted index r.

Thus the frozen shifted proof gives ordinary maximum control along every
subsequent actual erosion prefix which remains at most H. The former
condition max W_r<A=b^2-k+1 was only needed to DERIVE |D|<=b^2; here (B3)
supplies that physical fact directly. No clipped result is being treated
as an unclipped one without rechecking initialization.

## 2. The first exit above H is impossible below a reference maximum H-1

Assume an actual erosion continuation of that initialized seed has a
terminal genuine reference maximum at most H-1. The genuine maxima are
nondecreasing, so every earlier reference maximum is also at most H-1.
We claim every actual erosion count remains at most H, and therefore
obeys the ordinary maximum bound throughout.

If not, take the first update whose target q_new is at least H+1. All
preceding counts were at most H, so Section 1 and frozen continuation give

    q_prev <= M_prev <= H-1,

where M_prev is the genuine preceding maximum. Its actual raw allowed set
has size at most q_prev+k, hence

    q_new <= q_prev+k <= H-1+k=b^2+d-1 < b^2+b.

If its original raw surplus sigma were at most b-1, the actual dual set
would be small of size at most (b-1)^2 or co-small of size at least

    h-b(b-1) >= b^2+b.

Both alternatives contradict the displayed target range. Thus sigma>=b,
and exact quota accounting improves the bound to

    H+1 <= q_new <= q_prev+d <= H-1+d <= b^2-2.

On this target range ceil_sqrt(q_new)=b. Consequently q_new+b<=q_prev+k,
or equivalently q_new<=G(q_prev). The ordinary numerical maps satisfy
G(x)<=F(x)+1; the maximum of the next genuine pair is at least F(M_prev).
Therefore

    q_new <= G(M_prev) <= M_next+1 <= H,

a contradiction. This is the essential one-room buffer: it needs
M_next<=H-1 and does not assert the same statement at M_next=H.

## 3. Every failed even-width join supplies exactly that buffer

Use the actual cuts and notation of the accepted common-endpoint reduction:

    H+1 <= Y <= H+d+1,
    M_L=max V_ell^c,       delta_L=M_L-Y,
    delta_E+delta_L+R <= g-1,       1<=g<=d.

Hence

    M_L <= H+2d,
    max W_(ell-1)=M_L-k <= H-b+d <= H-1.           (B4)

The cut is before activation because Y>min V_ell^c. If activation occurs
with r remaining moves, it is genuinely later than this cut, so r<=ell-1.
The interlaced reference therefore gives

    min V_r^c <= max V_(ell-1)^c
               <= min V_ell^c < Y <= H+d+1 <= b^2.

The accepted enlarged mixed/activation cap says
min(|D|,b^2+1)<=min V_r^c. The preceding strict bound forces
|D|<=min V_r^c<=b^2, proving (B3) for the ACTUAL activation set D.
If activation never occurs, the real terminal set has |D|<=c<=k<=b^2,
and r=0 supplies the same initialization.

Apply Sections 1 and 2 to the real reverse erosion, whose final genuine
index is ell-1. Equation (B4) is its required buffer. This proves (B1).
The allowed-set union C=I union J containing the actual late source S is
unchanged. With

    delta_J=M_L-k-|J| >=0,       eta=|C minus S|,

the same exact union accounting gives delta_J+eta<=delta_L, proving (B2).
Also |J|>=Y-k>min V_ell^c-k, so this actual reverse endpoint is dangerous
at its precise genuine reference index, as required for a boundary-access
corridor.

## Scope and next interface

The former numerical band b^2+1<=M_L<=H+2d does not require an extension
of ordinary control to actual counts above H. The actual reverse word
cannot leave H, because its whole genuine reference lies at most H-1.

This removes that particular cap obstruction for EVERY b>=32,
1<=d<=b-1, and n>=2b in the failed-prefix reduction. It does not prove
arbitrary partial-state prefix optimality, resolve the remaining central
orientation transitions, or say that every cardinality-admissible seed
has a realizable future mixed suffix. Those assertions remain separate.

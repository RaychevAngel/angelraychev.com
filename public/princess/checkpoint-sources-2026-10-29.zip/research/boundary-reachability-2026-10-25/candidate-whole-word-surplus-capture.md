# Total neighborhood expansion in a complete winning word

25 October 2026. New ordinary identity. This strengthens and simplifies
the developing high-budget gate-prefix shortcut. It is independent of
ordinary boundary clocks, normalization, phase alignment, or reversal.

Let G be any finite graph with a perfect matching and N vertices. A
strategy starts with full uncertainty. On day t let B_t be its actual
pre-inspection belief, I_t subset B_t its useful inspections, S_t=B_t
minus I_t its survivor, and B_(t+1)=N_G(S_t). Set

    sigma_t=|N_G(S_t)|-|S_t| >=0.

The nonnegativity follows from the perfect matching: its partner map
injects S_t into N_G(S_t). The identity on every update is

    |B_(t+1)|-|B_t|=sigma_t-|I_t|.

For a winning T-day word, S_(T-1) is empty. Append the harmless movement
after this final successful inspection, so B_T is empty too. Telescoping
then gives the EXACT identity

    sum_(t=0)^(T-1) sigma_t
      = sum_(t=0)^(T-1) |I_t| - N
      <= Tk-N.                                      (1)

Thus if a physical construction guarantees capture by U days, every
update of EVERY optimal word has original surplus at most

    C=Uk-N.                                         (2)

C is nonnegative because any winning word must inspect at least N
useful positions in total, by the same identity. No one-color support,
partial-state monotonicity, or early/late cut has been assumed.

## Exact rectangle evaluator without a two-prefix interface

For an even-area rectangle, N=2h. Separate each survivor into its two
physical colors. Their neighborhoods lie in different colors, so their
two nonnegative original surpluses sum to sigma_t. For a one-color
survivor S and its target holes Y=V_opposite minus N(S), N(Y) is
disjoint from S. Thus |N(Y)|-|Y|<=|N(S)|-|S|. Each resulting hole
set has dual neighborhood surplus at most the corresponding original
survivor surplus. Consequently (2) and the accepted static cutset theorem
put every intermediate state of an optimal winning word in the literal
two-color cutset universe.

Use the exact physical hole edges already proved:

    Erosion(X_p union N(Y_(1-p)))=Y_(1-p),
    sum_p |N(Y_(1-p)) minus X_p|<=k.

Start at X_0=X_1=empty (full initial uncertainty). The terminal state
is X_p=V_p for both physical colors (empty belief). On a rectangle there
are no isolated rooms, so N(S)=empty implies S=empty. Hence reaching
this terminal after T graph updates is exactly capture within T
inspection days, including the harmless last movement convention.

Run exact shortest-path or layered reachability through U updates and
return the first terminal occurrence. Every graph path is physical,
and every intermediate state of an optimal word is present by (1).
This is therefore an exact value evaluator with optimal predecessor
inspections. It needs no gate-clock lower bound, normalized witnesses,
opposite polarizations, reversed prefix, or central intersection test.
Those are still essential in the stronger low-budget compression where
the global total bound alone would be too large.

## Explicit high-budget bound from the existing prefix construction

Let w<=n, wn=2h, B=ceil(w/2), and B<k<h. The accepted exact physical
backward prefix maps have costs bounded by B in either phase. Start
their paired threshold recurrence from (k,k). Each output increases
its swapped source input by at least k-B until clipping at h; therefore
the pair MINIMUM grows by at least k-B per update. After

    P=ceil((h-k)/(k-B))

updates both thresholds reach h. The physical meaning of these maps
supplies, for either initial cohort, a P-update solo word ending with
at most k rooms. Capture that cohort on its next inspection. Search
the other initial cohort afterward in the same way; it was not inspected
and remains full in its current physical color. This gives U=2P+2
inspection days.

The authoritative exact backward formulas are in
`../../paper/sections/bridge-uniform-upper.tex`, in the proof of
`prop:bridge-buffered-comparison`. The even-width inverse costs have
global cap b; the odd-width costs have caps b and b+1. These are actual
diagonal-prefix inverses, not arbitrary-shape lower bounds. The formulas
give the width-cap inequality globally; the additional buffered-comparison
hypotheses in that proposition concern comparison to a different lower
frontier and are not used here. At high budget k>b^2/2 with b>=32 even
its displayed k>=w premise is satisfied.

Using ceil(x)<=x+1 and x=h-k,

    C=Uk-2h
      <=2hB/(k-B)+2k-2kB/(k-B)
      <=2hB/(k-B)+2k.                              (3)

For b=floor(w/2)>=32 and k>b^2/2, both even and odd widths satisfy
h<=(b+1/2)n and B<=b+1. The elementary inequality

    2(b+1/2)(b+1)/(b^2/2-b-1) <=5

holds for b>=32: its cross-multiplied remainder is
b^2/2-8b-6>0. Therefore the explicit bound

    C<=5n+2k                                        (4)

is valid throughout this high-budget range. At even width the matching
array correction is at most b-1; at odd width use the rotated array and
correction n/2-1. The exact state exponent is O((n+k)log(wn)), with a
polynomial U factor and fixed powers for paired states and dense edges.

If k>=2h, capture takes one day. If h<=k<2h, inspect the SAME entire
physical checkerboard color on both days: the other initial cohort
moves into that color after the first unsuccessful day. Two days are necessary
because the initial set has more than k rooms. These cases do not use
the division in P.

The state exponent may include the entire power set near quadratic
budgets on short boards. This theorem is an exact representation and
algorithm, not a claim of practical speed, uniform equality of earlier
scalar brackets, a direct parameter inspection rule, or an O(1) answer.
No new large strategy enumeration or Lean verification is involved.

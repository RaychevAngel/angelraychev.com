# The medium-budget capture kernel at odd width

25 October 2026. New ordinary corollary for independent review. This uses the reviewed medium-budget actual cuts and all-state corridor, with a different physical middle speed and the rotated matching-array correction. It retains literal endpoint compatibility and does not assert that a scalar signed gate determines capture.

Let

    w=2b+1, n>=w even, b>=32,
    2b<=k<=floor(b^2/2), d=k-b,
    h=wn/2, H=b(b-1), z=b^2-k+1,
    N0=h-2b^2+b, D0=ceil(N0/d).

Let e0 be the first maximum hitting time of z in the genuine ordinary early pair from (0,0), and ell0 the first maximum hitting time of z in the ordinary late pair from (k,k). Define

    J*=e0+ell0+D0,
    B=5+ceil(N0/[d(d-1)]), s=2B+2.                    (M1)

Then an exact finite full-capture evaluator, with reconstructed optimal inspections, is obtained using the prefix clock interval

    J*, J*+1, ..., J*+s-1

and at most

    K=6((3s+1)k-1)+(n/2-1)                           (M2)

internal cut edges per color in the (n/2)-by-w matching array. Its time bound is

    (J*+s+1) exp(O((k+n)log(wn)))                     (M3)

up to polynomial board operations. In particular every linear budget k=O(b) on short boards n=O(b) has exponent O(b log b). At quadratic k the bound need not improve on area-exponential search; that limitation is part of the statement.

## 1. The actual boundary and slack arguments are parity-free

Use Sections1,2 and4 of the independently reviewed `even-medium-budget-ten-clock-extension.md` (source hash f3b88ef69bca73ab992a34236cd02b90b7a6d7ce99b631817f16b6a35af100c0). Their hypotheses are even area, b=floor(w/2), h>=2b^2 and the displayed budget range, not even width. Here z>k and 1<=z<=(b-1)^2.

Specifically, the first actual hole crossing of z has raw size at most b^2 and target Q in[z,H]. The last downward mass crossing of z-1 has source Y in[z,b^2], and every later mass is at most z-1<=H. The ordinary arbitrary-origin and arbitrary-terminal comparisons therefore give e>=e0 and ell>=ell0. The double clamp with walls (b-1)^2 and h-H-1 has gain at most d, and its endpoint increase is at least N0. Hence every actual gate-k word takes at least J* updates.

For any normalized gate-k prefix of length at most J*+s-1, the three nonnegative delays have sum at most s-1. The reviewed proof gives original total survivor surplus at most (3s+1)k-1 on EVERY update. Early and late states are in their actual s-clock corridors; middle excursions use total clamp loss at most sd-1 and rise at most k. Initial and terminal middle states may lie outside the clamp walls. No even-width critical geometry or hypothetical phase marker is used.

For clarity, the domain extension needed here is already checked in `odd-review-parity-boundary-extension.json`: tied restart applies to all even-area boards and all k>=max(13,b+1); the frozen enlarged signed-late cap applies through k<=b^2; the arbitrary-terminal proof uses the raw threshold b^2-k+1, not the separate low-budget H-1 buffer. Rotating the encoding does not alter any of these physical comparisons.

## 2. Physical construction with the explicit extra clock B

The ordinary early pair at e0 is an actual quadrant prefix head with maximum at least z: all preceding raw sizes are at most z-1+k=b^2. The ordinary late pair C at ell0 is likewise physically admissible: preceding inputs are below z<=H and final coordinates at most b^2. Its genuine span obeys

    r=span(C)<=ceil(ell0/2)<=ceil(b/2)<=d,

because each numerical minimum increases by at least d before crossing z<=b^2, and d>=b.

At odd width every finite-board backward prefix scalar map increases its incoming coordinate by at least d-1, up to clipping at h. Thus its PAIR MINIMUM increases by at least d-1 on each update. Since min C>=z-r, after

    Dmid=ceil((h-2z+r)/(d-1))

middle updates both actual backward phases are at least h-z. The exact antipodal prefix adjunction meets whichever actual early phase reached z. All colors and phases evolve under the physical swapped recurrence; there is no independent orientation choice in the middle.

Put delta=2k-b-2+r. Then h-2z+r=N0+delta and

    delta<=3d+b-2<=4d-2.

Using ceil(x+y)<=ceil(x)+ceil(y) and d>=b>=32 gives

    Dmid
       <=ceil(N0/d)+ceil(N0/[d(d-1)])+ceil(delta/(d-1))
       <=D0+ceil(N0/[d(d-1)])+5
       =D0+B.                                         (M4)

This is an actual solo signed gate-k strategy within J*+B updates. Its final capturing inspection can be applied to the first cohort, then the same construction applied to the still-full other cohort. The even side of the rectangle supplies a color-swapping reflection when needed. Full capture therefore occurs within

    2(J*+B)+2=2J*+s.                                  (M5)

## 3. Exact capture and complexity

The actual first gate-k crossing of an optimal capture word and full-word reversal give two actual gate-k prefixes of lengths in[J*,J*+s-1], whose sum is T-1 and whose literal endpoint intersection has at most k rooms. Separate normalizations preserve this property. Section1 puts every intermediate target hole set in the cutset universe (M2).

Use the exact physical hole edges, layered reachability and literal endpoint intersection test from `root-exact-low-budget-even-capture.md`. Replace its four clocks and cutset constant by (M1)--(M2), and use the rotated (n/2)-by-w matching array. Search capture times from 2J*+1 through 2J*+s. Every accepted pair reconstructs real inspections by taking its exact intersection and reversing the second stored word; every actual optimum has a represented witness. The least accepted time is consequently the true capture time.

The representation has exp(O((sk+n)log(wn))) states, up to a constant power for the two colors and transition scanning. Since d>=k/2 and d>=32,

    s<=14+2N0/[d(d-1)],
    sk<=14k+16h/k=O(k+n),                              (M6)

where h/k<=3n/4 follows from k>=2b and h=(b+1/2)n. This proves (M3). All lengths remain covered; no long-board exactness assumption is imported.

The graph may be impractically large, and at quadratic budgets its cutset bound can exceed the full edge set. No such large enumeration has been run. This is a new structured exact-evaluation theorem, not a completion of the fixed-size numerical-expression or direct optimal-inspection-rule goals, and not new Lean verification or a publication update.

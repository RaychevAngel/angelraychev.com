# A dangerous reverse seed compresses its entire activated mixed suffix

25 October 2026. New ordinary reduction, submitted for independent attack.
This proposes a genuine exact late-access interface, rather than replacing
the missing suffix by its necessary cardinality cap. No result is promoted
until the generalized mixed comparison and every clock shift are reviewed.

Write w=2b, n>=2b, b>=32, h=bn, k=b+d, 1<=d<=b-1,
H=b(b-1), and 0<=c<=k. Let the genuine late pair be

    V_0^c=(c,c),
    V_(s+1)^c=(k+V_s^c[1]-rho(V_s^c[1]),
                k+V_s^c[0]-ceil_sqrt(V_s^c[0])),
    W_j=V_(j+1)^c-(k,k).

Consider an ACTUAL activation pre-state (D, full), a normalized nested
permanently mixed r-update continuation to signed mass at most c, and the actual reverse
seed J=E(D). Assume

    r>=1, |D|<=min V_r^c<=b^2,
    |J|>min W_(r-1).                                  (M1)

The last strict inequality is supplied by the accepted tied-restart
corridor whenever this seed leads to a dangerous genuine reverse endpoint.
The reviewed cap-buffer theorem supplies the other inequalities for every
failed low-excess even join. Let m_t be the signed pre-inspection mass at
mixed time t, so m_0=|D| and m_r<=c. Define the total ORIGINAL survivor
surplus on update t by sigma_t. With useful inspections i_t<=k,

    m_(t+1)=m_t-i_t+sigma_t, sigma_t>=0.             (M2)

## 1. The mixed comparison permits arbitrary nonnegative terminal gates

The accepted enlarged mixed-boundary proof compares either physical corner
phase, started with any 0<=Z<=b^2+1, to a permanently mixed actual history
whose starting signed mass is at least Z. This same proof yields, for any
nonnegative integer terminal gate a and t updates,

    min(max(m_start,0),b^2+1)<=min V_t^a.            (M3)

Here V^a has the same ordinary recurrence with numerical seed (a,a).
Only a<=b^2 is needed below. To verify the extension, the actual reference
corner size never exceeds its initial Z: while above k, its survivor size
u=x-k is at most b^2+1-k=H-d+1<=H and both genuine surplus profiles are at
most b<k. The original enlarged mixed comparison therefore applies at
every positive reference update. It is independent of the chosen terminal
gate. At sizes x<=k the reference can be inspected completely. If an
actual signed mass becomes negative, the reference on that update must
already have cleared, so it still reaches any a>=0. Thus it reaches gate a
within t updates whenever the actual history does.

The ordinary backward recurrence bounds the initial sizes reaching that
gate in either fixed phase. If an inverse reference leaves the ordinary
window above b^2+1, the desired clipped bound is already tautological;
there is no extrapolation of an actual corner profile beyond its range.
For t=0, (M3) is immediate from m_start<=a. This proves (M3), retaining
the same actual proper-survivor hypothesis as the accepted mixed proof.

In particular, apply (M3) to every remaining mixed suffix. Since
min V_s^c<=min V_r^c<=b^2 for 0<=s<=r, clipping cannot conceal a larger
positive state, so

    m_t<=min V_(r-t)^c.                              (M4)

Negative actual signed mass causes no problem with this upper bound.

## 2. A two-clock lower corridor

For EVERY t with s=r-t>=2,

    m_t>min V_(s-2)^c.                              (M5)

Suppose instead m_t<=min V_(s-2)^c, and put a=max(m_t,0). The right side
is nonnegative, so a<=min V_(s-2)^c. Apply (M3) to the ACTUAL mixed prefix
of length t, from m_0=|D|<=b^2 to its state m_t<=a. Monotonicity of the
ordinary numerical recurrence, starting from the tied seed (a,a), gives

    |D|<=min V_t^a<=min V_(r-2)^c.                   (M6)

The case t=0 is the same displayed inequality without a prefix update.
The ordinary one-shot square inverse for |D|<=b^2 gives

    |J|<=|D|-rho(|D|)
        <=min V_(r-2)^c-rho(min V_(r-2)^c)
        <=max W_(r-2)<=min W_(r-1).

For the penultimate inequality, the G-type coordinate of W_(r-2)
applies x-rho(x) to one coordinate of V_(r-2), which is at least its
minimum. The final inequality is genuine W interlacing. This contradicts
(M1), proving (M5). No favorable seed phase has been chosen.

## 3. Every mixed update has original surplus at most 2k-1

For a source with s>=2 remaining updates, combine (M4),(M5) and (M2):

    sigma_t<=k+min V_(s-1)^c-min V_(s-2)^c-1<=2k-1. (M7)

The last step uses the exact numerical fact that a late minimum increases
by at most k in one update: the branch fed by the previous minimum has
value at most that minimum plus k.

For the final update, if r>=2 then (M5) at the penultimate source gives
m_(r-2)>c. Nonnegative surplus and quota k imply

    m_(r-1)>=c+1-k.

Since m_r<=c, equation(M2) yields sigma_(r-1)<=2k-1 too. This argument
permits m_(r-1) to be negative; it does not assume the gate is first hit
on the terminal day. If r=1, (M1) implies |J|>min W_0>=0, hence |D|>=1,
and sigma_0<=k+c-|D|<=2k-1. Thus(M7) holds for EVERY actual mixed update.

Each one-color actual target hole set has dual neighborhood surplus no
larger than its corresponding original survivor surplus, and hence at
most 2k-1. The accepted internal cutset theorem consequently represents
EVERY positive-time mixed belief using at most

    K=12k-6+(b-1)*1_[n odd]

cut edges per color in the connected b-by-n matching array, plus its
base membership bit. Complementing the one-color hole set represents
the belief itself with the same internal cut edges.

## 4. Exact activated suffix recurrence

Use the accepted canonical seed reduction: for a literal erosion seed J,
the least raw set is D_min=N(J), with E(D_min)=J. If any actual D with
erosion J has a mixed suffix, the SAME inspections work from D_min by
monotonicity; the larger partner and its properness remain unchanged.
Thus it is enough to start the mixed recurrence at (D_min,full). The
initial set is specified directly from J; no assertion about its own
positive-time cutset bound is needed.

At positive times enumerate the actual two-cohort beliefs whose two
one-color complements have at most K internal cut edges. Retain true
physical colors and actual fixed-reflection nesting, whether encoded
physically or in the folded representation.
Require the partner to be proper at every post-activation pre-state, as
it is in a last-full-normalized suffix. Retain (M4),(M5) when applicable
and original surplus at most 2k-1 on each edge.

There is an exact direct transition test between literal one-color
beliefs B and B' in opposite physical colors. Define

    S_max=B intersect E(B').

An inspection-and-movement update reaches EXACTLY B' if and only if

    N(S_max)=B'.                                    (M8)

Its least useful inspection cost is |B minus S_max|. Every realizing
survivor S must lie in S_max; if its image is B', then the image of
S_max contains B' and is contained in B', proving necessity. Taking
S=S_max proves sufficiency and the minimum cost. Apply this test to
BOTH cohorts and sum their costs, requiring the sum at most k. Under
folded nesting the maximal survivor pairs are nested, because erosion
is monotone. The first maximal larger survivor is proper because its
prescribed target larger belief is proper and N(full)=full; later
properness follows from the already proper source larger belief. Their
original surplus is no larger than that of any
realizing smaller survivor pair with the same targets.

Starting from (D_min,full), this layered graph at exact length r, with
terminal signed mass at most c, is therefore sufficient by literal
inspection reconstruction. It is necessary for every activated seed
satisfying(M1): canonical reduction preserves J, all initial numerical
bounds, and an actual suffix, while Sections1--3 put every resulting
positive-time state in the graph. This is an exact evaluator of the
activated predicate in the genuine dangerous-seed domain, not merely
an outer cardinality relaxation.

The r=0 entirely-solo terminal rule remains separately exact:
E(N(J))=J and |N(J)|<=c. For r>=1, the seed bounds and genuine danger
condition in(M1) must be retained. The recurrence is not asserted exact
for arbitrary unrelated seeds outside that domain.

## Complexity and remaining assembly

If the matching array has M=b(n-1)+(b-1)n internal edges, each color has
at most B=2*sum_(j=0)^K binom(M,j) cutset descriptions. Two-cohort states
number at most B^2. Literal transitions are polynomial-time set operations
once states are supplied. The horizon in(M1) is polynomially bounded:
while min V_s<=b^2, its next minimum increases by at least one, so
r<=b^2-c. Even enumerating all state pairs and all time
layers has exp(O(k log(bn))) complexity; on the remaining short boards
n=O(b), k<2b, this is exp(O(b log b)), instead of an area-exponential
power-set search. It is still large, and no such enumeration is launched.

If accepted, this supplies the actual missing mixed-suffix predicate for
the exact genuine-clock boundary and middle cutset recurrences. One must
still assemble their time indices, all cut predicates, actual endpoint
sets and reverse allowed-set inclusions into a single exact gate decision.
It does not itself establish that the canonical physical prefix always
wins that decision, a smaller universal numerical gap, a practical fast
algorithm, or an O(1)-operation expression.

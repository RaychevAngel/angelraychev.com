# Exact full-word reversal and complementary polarization at one inspection

25 October 2026. New ordinary interface lemma; submitted for independent review. No claim of a new rectangle capture-time value is made.

Let G be an undirected graph with no isolated vertices, and let an involutive automorphism sigma exchange its bipartition classes. Rectangles of even area have the accepted reflection involution. Fix budgets k_0,...,k_(T-1), and a word of inspections I_0,...,I_(T-1).

## 1. The exact cut is before an inspection, not between two moves

At an index t in [0,T-1], let F_t be the actual forward belief after t unsuccessful inspection-and-movement updates from the full graph, using I_0,...,I_(t-1). Let R_t be the analogous belief from the full graph using the reversed suffix I_(T-1),...,I_(t+1), thus after T-1-t updates. Both are sets of vertices at the SAME original day t, before its inspection.

The entire word wins if and only if

    F_t intersect R_t subset I_t.                         (S1)

A vertex outside I_t in the intersection has an avoiding walk from day0 to it and an avoiding reversed walk from day T-1 to it. Reverse the latter and concatenate; this is a whole evading princess walk. Conversely any evading walk gives such a vertex. This proof uses the original edge-walk game and includes the terminal inspection exactly once. There is no extra final move.

Consequently, two arbitrary full-origin inspection prefixes of lengths t and T-1-t can be spliced into a winning T-day word if and only if their endpoint intersection has size at most k_t. The central inspection is precisely that intersection; the second prefix is traversed in reverse inspection order. Prefix budgets are those of the corresponding original time slots.

## 2. Opposite polarizations preserve splice feasibility

Choose either physical color p at the cut. Apply the accepted alternating-polarization strategy theorem to the first prefix, choosing its initial favored color so that its endpoint is favored toward p. Apply it independently to the reversed second prefix, favoring the opposite color 1-p at its endpoint.

The new actual endpoints F'_t and R'_t satisfy

    F'_t subset C_p(F_t),
    R'_t subset C_(1-p)(R_t).

For each two-vertex sigma-orbit O,

    |C_p(F_t) intersect C_(1-p)(R_t) intersect O|
       = max(0, |F_t intersect O| + |R_t intersect O| - 2)
       <= |F_t intersect R_t intersect O|.

Summing gives |F'_t intersect R'_t|<=|F_t intersect R_t|<=k_t. Hence complementary polarized prefixes can always be spliced with the same horizon and budgets. The central inspection set changes; one does not claim it remains contained in the original I_t.

One can then apply last-full temporal normalization to EACH finite prefix independently, including its terminal pre-inspection endpoint in the choice of last-full time. This preserves that endpoint exactly and cannot increase any daily cost. Therefore every winning full word has a splice representation by two independently last-full-normalized, oppositely polarized, actual full-origin prefixes.

This is an endpoint statement. The normalized prefix words need not be the original word on either side, and their separate last-full times need not satisfy any ordering relation.

## 3. What this removes and what it does not

An exact evaluator based on these two actual prefix-reachability sets never needs to declare an arbitrary cardinality-admissible activation set attainable: every endpoint is physically reached from full uncertainty. This is a useful alternative interface to the one-sided signed-gate relaxation.

It does NOT yet give a compressed exact full-game evaluator. The new tied-restart theorem compresses boundary histories ending dangerously with total hole count at most H=b(b-1). A general splice endpoint instead has approximately half the board cleared and can lie far beyond that boundary. One must still prove that all relevant prefixes admit the compressed boundary/middle representation, or otherwise encode their permanent mixed suffixes exactly.

In particular, independent last-full normalization does NOT imply that the chosen cut precedes activation in both directions. The last-full times belong to separate transformed words. No fact proved above rules out an interval in which both transformed prefixes have already activated the larger cohort.

The precise missing geometric statement for a direct two-solo-prefix reduction is:

> For every rectangle and winning T-day constant-budget word in the only undecided candidate horizons, some pre-inspection cut admits the above splice with both normalized prefixes still solo at their endpoints (or with a separately specified bounded exceptional transition).

This is stronger than complementary polarization. The accepted nonrectangular Hall and seriality counterexamples rule out deriving it solely from the graph involution, nesting, and noncontraction. Rectangle geometry or a genuine deficit ledger is still necessary.

## 4. A rectangle counterexample to inferring activation order from the splice alone

Even on a rectangle, the two already-constructed normalized prefixes need not offer ANY cut before both activations. Take the2-by4 board, constant budget4, and the following three-day winning word, where each listed column means both of its rooms:

    day0: columns0,1;
    day1: columns1,2;
    day2: columns2,3.

After day0 and movement, the belief is exactly both rows in columns1,2,3. After day1 and movement, it is exactly both rows in columns2,3; day2 captures. The reversed word has the symmetric same property.

Reflect the two rows. Every belief and survivor above is a union of complete reflection pairs, so either alternating polarization leaves it unchanged. In both directions the last-full pre-inspection time is0. At the interior splice t=1, both prefix endpoints have proper larger cohorts. At t=0 or2, the nonempty-length prefix also has a proper larger cohort. Thus NO cut of these oppositely polarized and last-full-normalized words has both endpoint partners full.

This word is not optimal: the same board and budget can be captured in two days by inspecting one whole checkerboard color twice. Therefore this does not refute a minimum-horizon or candidate-horizon exchange theorem. It does refute any assertion that the required activation ordering is an automatic algebraic consequence of reversal, polarization, and last-full normalization, even for rectangles.

# Independent review: bounded cutsets throughout every fixed-slack prefix

25 October 2026. Accepted ordinary proofs for the two new sources
`even-arbitrary-terminal-late-comparison.md` and
`even-fixed-clock-slack-cutset-corridor.md`, together with the conditional
cut interface `root-four-clock-capture-interface.md`. Their accepted
domains and earlier cited proof dependencies remain explicit. No scalar
gate-palindrome sufficiency is inferred.

## Arbitrary bounded terminal comparison

The only new terminal range is k<=a<=H. For an actual raw solo terminal
or activation set D, write z=min V_r^a<Z=b^2+1. Monotonicity from a>=k
gives k<=z<=b^2. Choose an ACTUAL one-color hole subset X of D of size
min(|D|,z-k). Inspection D minus X costs at most k and gives exactly
E(D). Its initial count is at most z-k<=H, and its target count is at
most H by the accepted square inverse. Thus the arbitrary tied-origin
restart theorem applies to this actual added update and every later
reversed update before the first count reaches A=b^2-k+1.

The numerical first image of tie(z-k) is

    (z-rho(z), z-ceil_sqrt(z)) <= W_r.

Continue the SAME tied comparison, then use numerical monotonicity to
bound its subsequent pair by W_(r+i). No arbitrary unequal-seed physical
comparison is being asserted, and no clock is added to the original solo
word. The added update serves only to initialize a separately valid
comparison history.

If the initial erosion is already at least A, or a later first crossing
occurs, the reference maximum reaches A and the desired clipped bound
is thereafter tautological. A crossing target's raw size is at most
A-1+k=b^2, so the complete comparison history through that crossing
stays at most H. Literal reversal gives m<=k+|J_(ell-1)| and the exact
index identity k+max W_(t-1)=max V_t^a. The already-mixed branch uses
the independently reviewed mixed comparison. Zero moves, negative
initial signed mass, entirely solo suffixes and the a=k overlap are all
consistent. This proves the stated AT1.

## First and last cuts, without a solo assumption

I checked the first-crossing bound directly for TOTAL holes in both
cohorts. Immediately before Q first reaches A=H-d+1, the raw total
holes after inspection are at most A-1+k=b^2. If its target count
exceeded H, the original total surplus would be at most b-1. Both
small target-hole alternatives would give total count at most L;
a co-small component would have at least h-H>=b^2+b rooms, exceeding
the entire raw count. Both are impossible. Therefore Q_e<=H. This
justifies the early cut even if activation occurred before it.

For the last downward crossing of signed mass through H, original
surplus at least b gives source mass at most H+d. Otherwise the same
componentwise small/co-small dichotomy forces a co-small target hole
component, hence target signed mass at most sigma(sigma+1). Its source
mass is at most sigma^2+k<=L+k=H+d+1. Thus the claimed late interval
is valid. After this LAST crossing all masses remain at most H.

The initial cut mass h-Q_e is strictly larger than H+d+1, even on the
shortest square. The late cut is therefore strictly later, and its
remaining suffix is nonempty. Both clamp endpoints are inside (L,U],
where U=h-H-1. In fact U-d>=b^2>L throughout the stated domain.

## Universal double-clamp gain

Let C=min(U,max(L,Q)). If total original surplus sigma>=b, actual hole
gain is at most d, and the monotone 1-Lipschitz clamp preserves that
upper bound. If sigma<=b-1, apply small/co-small separation to EACH
actual target hole set with its own dual surplus bounded by its own
original survivor surplus. If both are small, Q'<=sigma^2<=L, so the
clamped gain is nonpositive. Otherwise one component is co-small,
giving m'<=sigma(sigma+1), even if the other component makes m' negative.
Consequently prior m=m'+i-sigma<=sigma^2+k<=H+d+1, and prior Q>=U-d.
Since U-d>L, prior C>=U-d while C'<=U. Again gain is at most d.

This argument includes arbitrary two-cohort intermediate shapes,
activation, retreat, and jumps across either wall. It also proves
sigma>=b whenever the TARGET lies in the strict interval (L,U].
Summing the nonnegative clamped losses gives the exact R in S9.
The three endpoint-clock delays are nonnegative integers summing to at
most s-1. The ceiling remainder is at most d-1, so R<=sd-1.

## Every excursion is controlled

There are at most s-1 nonpositive clamped steps, because each consumes
at least d from R. Above U, entry overshoot is at most k and every
subsequent step still above U is a zero clamped step. Actual increases
are always at most k, proving upper overhang at most sk.

Below L, an excursion must return before the final endpoint. A source
at most L cannot jump directly above U. If sigma>=b its rise is at
most d and L+d<U; if sigma<b and the target is co-small, the preceding
double-clamp proof instead forces source at least U-d>L. Both exclude
that jump. The return target is therefore in (L,U], with sigma>=b;
its last below-wall source is at least L+1-d. Every previous internal
step in the excursion has zero clamped gain and actual rise at most k.
There are at most s-1 such steps, so depth is at most
d-1+(s-1)k<sk. A large retreat upon entering the excursion is thus
bounded by its necessary later return; it was not silently excluded.

Writing epsilon=Q-C, the identity for original surplus gives

    sigma<=b+lambda+epsilon_source-epsilon_target
          <=b+(sd-1)+2sk<=(3s+1)k-1.

All losses share the SAME R. No repeated allowance for separate
excursions or pairs of states is introduced.

## Early and late corridors, including terminal negative mass

For j>=s, the early endpoint delay gives Q_e>max E_(e-s). If an actual
earlier count satisfied Q_j<=min E_(j-s), restarting that actual future
under its tied count would finish below max E_(e-s), a contradiction.
Every count in this restart segment remains at most H. Pair spread at
most k and scalar growth at most k then give original early surplus
at most (s+1)k-1. The first j<s updates use the direct bound Q_(j-1)<=
(j-1)k and require no negatively indexed reference.

In the late word, m_t<=max V_r is genuinely unclipped: its initial
mass is at most b^2 and every later mass at most H. If r>=s and
m_t<=min V_(r-s), set a=max(m_t,0). This lies in [0,H] for t>=1.
AT1 applied to the ACTUAL preceding late segment yields
Y<=max V_t^a<=max V_(ell-s), contradicting the endpoint clock delay.
The t=0 case is the delay inequality itself. This proves the lower
corridor without replacing the actual endpoint by an attainable scalar
shape.

When fewer than s moves remain, the earlier corridor gives mass at
least k+1 at remaining time s. The maximum loss k per update supplies
the stated lower bound even when it becomes negative. Combining it with
max V_(r-1)<=rk bounds all final surpluses by sk-1. If the entire late
word has ell<s moves, initial Y>=1 gives the same estimate directly.
No first-hit assumption at the terminal gate is used.

## Capture interface and exact acceptance boundary

The independently checked first gate-k cut in an optimal capture word
has actual signed mass between1 and k. Inclusion-exclusion at its
literal reversal cut therefore puts the opposite endpoint at gate k
too. If A is a necessary gate clock and capture is known possible by
2A+4 days, both prefix lengths lie in [A,A+3]. Opposite polarization
and separate last-full normalization preserve the intersection condition
and endpoints as claimed; a first-crossing property is no longer needed
after those transformations.

Consequently s=4 in the accepted corridor bounds every original surplus
of both relevant normalized prefixes by13k-1. Every positive-time cohort
hole set then has dual surplus at most that amount, proving the literal
cutset universe. This is a completeness theorem for the restricted
representation, not merely a collection of numerically admissible states.

The stated exp(O(sk log(wn))) representation bound follows from the
connected matching-array cutset encoding. For fixed s and n=O(b), k<2b,
it is exp(O(b log b)). Actual transition tests, normalization memory,
physical colors and the FINAL LITERAL ENDPOINT INTERSECTION still must
be retained in an implementation. A scalar gate convolution is not an
equivalent upper decision, as the connected counterexample recorded in
this directory demonstrates. No large enumeration, implementation of
the final evaluator, fixed-operation expression, or Lean proof was
performed by this audit.

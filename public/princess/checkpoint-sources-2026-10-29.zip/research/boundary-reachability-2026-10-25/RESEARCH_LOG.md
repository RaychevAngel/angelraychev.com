# Boundary reachability and physical front transitions — 25 October 2026

## Objective and frozen starting point

Continue toward matching physical upper and necessary lower bounds for every
rectangle `w<=n` and every feasible constant inspection budget. No expression
simplification before the bounds match everywhere. Preserve literal physical
sets, genuine indices, phase, and the common deficit account. Prior research
in `../phase-compatibility-2026-10-24/` is frozen for this pass.

Starting private commit: `0aea309`. Accepted global interval width is at most
3; all widths at least 64 have width at most 2. Exact subfamilies, including
the genuine-span-conditioned odd-width result, remain in force. These are
ordinary research results with the previously recorded verification coverage;
there is no new Lean claim in this pass.

## Parallel questions

- Exact reachability of literal early and reverse boundary shapes at their
  genuine clocks, without inventing shape markers from numerical capacities.
- Remaining front-to-corner and opposite-front transitions between actual
  consecutive critical middle moves.
- Independent restart comparison from an arbitrary actual shape under a
  tied numerical seed, potentially bounding all boundary states' cutsets.

## First findings and rejected routes

- A naive scalar-deficit telescope has the wrong nonexpansiveness direction:
  root-wall contraction can recover more than one unit of area deficit in a
  day. It is not a proof of a narrow boundary corridor.
- Inverse scalar capacity corridors can have quadratic width in the low
  excess regime; they do not by themselves give the desired small cutsets.
- A physical reverse word can lose cells relative to the actual old holes.
  Retaining that deficit, rather than asserting exact reversal, yields a
  useful new bound. Candidate proof and independent review are kept separately.

All improvements must be independently attacked before being included in the
accepted checkpoint. A conditional structural theorem is not automatically
a smaller capture-time interval, and a restricted state graph is not a
classification of all actual strategies.

## Completed first stage: actual boundary access and front transitions

The tied-origin restart passed a complete independent arithmetic replay:
78,874,764 reference-pair states and 61,562,872 dangerous target obligations,
with no failures. Its ordinary proof permits arbitrary actual starting
shapes under a tied numerical origin. This supplied a genuine one-clock
corridor through every early boundary state, not merely its endpoint.

The real reverse cap is now controlled throughout the even low-excess
range. A one-room reference buffer removes the former large-excess band.
The early collar's possible single lost unit is paid by a decrease of its
genuine final span; both collars and the middle retain one strict shared
credit account. The activated mixed suffix has its own two-clock corridor,
with all literal positive-time states encoded by small cutsets. These
pieces combine into an exact signed-gate decision below the canonical
prefix clock, without treating a numerical activation capacity as a
reachable shape.

Independently reviewed geometric arguments close the missing longitudinal
front-to-corner direction and opposite-longitudinal-front transition under
their stated low-loss guards. Square critical labels have a common corner
under their all-pairs hypotheses. An actual early ancestor core attaches
to its first critical boundary shape at the stated large-width threshold.
These are retained tools, not an assertion that all canonical prefix
strategies are optimal: real same-end tilt changes can beat a fixed-corner
prefix and already underpin the older long-board transport theorem.

## The decisive unification: bounded delay controls EVERY state

The next pass replaced separate shape classifications with one stronger
statement for the capture evaluator. In a normalized gate-k prefix only
s-1 clocks slower than the affine lower clock, every original survivor
surplus is at most (3s+1)k-1. Its proof keeps both cohorts, arbitrary
activation, retreats, and negative late signed mass.

The early proof uses tied restart. A new artificial physical seed
inspection extends the late comparison to arbitrary bounded terminal
mass at its exact clock. In the middle, clamp TOTAL holes between
(b-1)^2 and h-b(b-1)-1. Each clamped gain is at most k-b, even for
mixed histories. A near-optimal word can afford only s-1 nonprogress
steps. Excursions below the lower wall must return; excursions above the
upper wall must enter. This bounds their depth by sk and the original
surplus on every update, without asserting monotone real holes.

For low-budget even widths, every optimal full-capture word has a literal
splice into two gate-k prefixes at just four consecutive clock values.
The surplus theorem therefore covers every state of both witnesses.
An exact cutset graph with physical transitions, followed by a literal
endpoint-intersection test, determines capture time and reconstructs an
optimal word. The proof received three independent reviews. This extends
to a ten-clock medium-budget range with different actual cuts. A separately
reviewed odd-width extension keeps its length-dependent slack and the
rotated matching-array correction explicit.

This is mathematical unification of the exact-evaluation argument: the
common surplus theorem supplies the entire state graph. It does not erase
the independent geometric results or claim that the old inexpensive
numerical bounds now coincide. No large graph has been evaluated.

## Failed shortcuts and independent challenges

- Actual signed-gate clocks supply a valid all-budget-split capture lower
  bound, but their values do not determine endpoint overlap.
- A fastest gate-zero witness on 3 by 4 at budget5 is invariant under every
  rectangle symmetry; its self-reflection cannot be spliced within budget.
  Different endpoints achieve the true optimal capture time. Selecting a
  witness matters even when its gate time is optimal.
- A connected, matched bipartite nonrectangle with a color-exchanging
  involution has G(0)=4, G(1)=3 and capture time8, while the all-split lower
  expression gives7. A thirteen-state certificate independently verifies
  this. Matching, connectedness and polarization alone are insufficient.
- Opposite polarized endpoints have overlap equal to their signed mass sum
  plus two actual uncovered-hole terms. The exact evaluator retains those
  terms through literal sets; it never declares them zero by symmetry.
- A scalar diagnostic initially consumed a generator twice and gave a
  vacuous closure. This was caught, fixed, and rerun with positive state
  and edge counts. No theorem relies on that initial run.

## Evidence and present limits

New results are ordinary proofs with independent source-pinned reviews.
Only the specified finite arithmetic base is exhaustively computer checked;
small physical diagnostics remain diagnostics. There is no new Lean theorem
or compilation. Older dated sources, publication packages and public pages
remain unchanged. The results index gives the exact accepted parameter
ranges, computational costs and restart obligations.

The efficient global bracket remains at most3, at most2 for every width
at least64, and at most1 in the retained high-budget range. The new exact
graph can determine the day in its stated families, but may be enormous
or degenerate to the full power set. It has not established all-parameter
gap zero in the intended usable numerical theory. Direct optimal rules
and the final O(1)-operation expression remain open; no expression
simplification has begun.

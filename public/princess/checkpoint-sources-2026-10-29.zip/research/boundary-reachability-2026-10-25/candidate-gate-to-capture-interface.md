# Exact gate clocks: a valid lower bound and the missing endpoint exchange

25 October 2026. Independent ordinary arguments and bounded diagnostics.
No new rectangle capture-time equality is asserted.

## 1. The all-split lower bound is sound

Let a graph have 2h vertices, a perfect matching, and 1<=k<h. Write G(c)
for the actual full-origin minimum number of inspection-and-movement
updates needed to reach pre-inspection signed mass at most c. For every
winning T-day word,

    T>=max_{0<=c<k} [G(c)+G(k-1-c)].

I independently reviewed `root-gate-convolution-capture-bound.md`.
For finite A=G(c), B=G(k-1-c), assuming T<=A+B-1, the cut
a=min(A-1,T-1), b=T-1-a has a<A and b<B. Both nonnegative prefix
lengths therefore have signed endpoint masses at least c+1 and k-c.
Their literal endpoint intersection has at least k+1 rooms, impossible
for the single central inspection. The min in this cut definition matters
when T<A. Infinite gate clocks follow by arbitrarily large finite lower
bounds. Matching noncontraction also verifies G(0)>=G(k)+1: immediately
before a word's first zero gate, signed mass is at most k because one
update decreases it by at most k. The reverse inequality is not implied.

This proof is independent of rectangle geometry and of whether either
prefix is solo. It does not establish an upper bound from the same numbers.

## 2. An exact expression for the missing geometric defect

Choose a color-swapping involution and oppositely polarize two actual
prefixes. Identify its h pairs with a folded vertex set Q. Write the
first endpoint as (X,Y), Y subset X, where X is its favored physical
cohort, and the other endpoint as (U,V), V subset U, with the OPPOSITE
favored physical cohort. Let

    D=Q minus X, E=Q minus U,
    f=|X|+|Y|-h, g=|U|+|V|-h.

Their literal physical intersection satisfies the exact identity

    |F intersect R|
      = |X intersect V|+|Y intersect U|
      = f+g+|D minus V|+|E minus Y|.                 (C1)

Indeed |X intersect V|=|V|-|D intersect V|, and similarly for the
other term. Substituting f=|Y|-|D| and g=|V|-|E| gives (C1).

Thus the mass lower bound is attained precisely when the holes in each
favored cohort lie inside the other endpoint's smaller cohort:

    D subset V and E subset Y.                    (C2)

For a central quota k, equality of mass bounds is unnecessary; the exact
condition is that the two uncovered-hole counts in (C1) fit within
k-f-g. These are actual sets, not separately adjustable deficits. For
solo endpoints D=E=empty, the defect vanishes automatically. For mixed
endpoints this is additional information absent from G(c).

A useful rectangle exchange theorem would therefore select reachable
endpoints at the required times satisfying this cross-cover or its
allowed-defect version. It must preserve their clocks and budget and
cannot merely change a corner label. The new exact suffix graphs can
test (C1) on retained literal endpoints. Proving that suitable endpoints
always exist, or that every necessary optimum has endpoints in the
retained graph, remains a separate step.

## 3. A fastest rectangle gate witness need not pair with its own reflection

Use the 3-by-4 rectangle, coordinates (row,column), rows0..2, columns0..3,
and budget5. Inspect these two sets in order:

    I0={(0,0),(0,2),(1,1),(2,0),(2,2)},
    I1={(0,2),(1,1),(1,2),(1,3),(2,2)}.

After the first movement the actual belief is

    {(0,0),(0,2),(0,3),
     (1,1),(1,2),(1,3),
     (2,0),(2,2),(2,3)}.

The second inspection leaves exactly the four corner vertices. Their
neighborhood is

    F={(0,1),(0,2),(1,0),(1,3),(2,1),(2,2)}.

It has six rooms, so its signed mass is zero. This is a FASTEST zero-gate
witness: after only one update at least seven rooms survive the inspection,
and a perfect matching prevents their neighborhood having fewer than seven
rooms. Hence G(0)=2.

The set F is invariant under every automorphism of this nonsquare grid:
the identity, either axial reflection, and their product. Consequently
every reflected or rotated self-copy intersects F in all six rooms,
exceeding the central quota5. Horizontal reflection exchanges colors,
and F is already a union of its complete pairs; complementary alternating
polarization leaves F unchanged too. The obstruction is physical, not
an unnormalized endpoint artifact.

This does NOT refute a theorem selecting different gate-optimal witnesses.
The same board has capture time3: after one update, inspecting five rooms
of a single color leaves the other color full and two neighbors of one
corner in the inspected cohort. Take its opposite-favored reflected copy;
their intersection has four rooms, within quota5. Two days cannot suffice
because the first belief has at least seven rooms. The invariant endpoint
above is therefore a bad witness choice, not an optimal-capture obstruction.

## 4. Gate-convolution equality fails on matched bipartite graphs

Take the disjoint union of a six-vertex path 0-1-2-3-4-5 and three
independent edges, with budget1. It is a bipartite graph on12 vertices
with a perfect matching and a color-swapping involution. Here

    G(0)=6, but T=14,

so the all-split lower bound is12, strictly below the optimum.

For G(0), matching noncontraction shows that signed mass can decrease by
at most one per day. Its initial value is6, giving G(0)>=6. Inspecting
the six deterministic trajectories on the independent edges in six days
leaves just the whole path, of size6, proving equality.

Each initial parity cohort in the path requires at least FOUR useful
probes, even if arbitrary empty-inspection days are interspersed. It starts
with three possible vertices. Neighborhood never contracts, so clearance
with only three probes would require zero expansion on every update.
Before its first useful probe the cohort is still an entire color class.
In the class {0,2,4}, the only one-probe deletion with zero expansion is
removing4, which gives the next belief {1,3}. Both vertices are interior:
a further single probe leaves a degree-two singleton and expands, while
an empty inspection also expands the two-vertex belief. The other color
is symmetric, with its only zero-expansion deletion removing1. Thus
three probes cannot clear either cohort, regardless of interleaving.
The path needs at least8 probes. The three independent edges have six
different deterministic starting trajectories, each needing its own
probe. Total budget1 therefore requires at least14 days. Search the path
in its known eight-day word (1,2,3,4,4,3,2,1), then inspect the remaining
six edge trajectories; this attains14. Direct trajectory replay verifies
the displayed path word.

The obstruction uses disconnection. It does not refute the rectangle
convolution conjecture, nor a stronger theorem using connected grid
geometry. It does refute an argument based only on perfect matching,
color-exchanging symmetry and the exact gate clocks.

## 5. Bounded diagnostics and their limits

`candidate_gate_capture_diagnostic.cpp` independently searches literal
belief subsets, deleting the full useful quota and then taking the exact
open neighborhood. Extra useful inspections only shrink every later
belief, so full-quota transitions suffice for these minimum-time questions.
Earliest visitation is safe by the same monotonicity. No geometric or
count-profile relaxation is used.

All19 tested feasible rectangle/budget cases through4-by4 satisfy the
convolution equality, including3-by4 at budget2 and4-by4 at budget3.
The results and explicit bad self-pair witnesses are in
`candidate-gate-capture-diagnostic.jsonl`. These are bounded diagnostics,
not a uniform theorem. The search finished below its30-million-transition
per-instance cap in every case; no process remains running.

`candidate_generic_gate_capture.py/.json` independently confirms the
12-vertex obstruction (1,215 visited states,7,608 transitions). The same
bounded script found no obstruction among connected symmetric matched
double covers through four folded vertices. This negative evidence is
too small to support a connected-graph theorem. No broader graph or
rectangle enumeration was launched.

# The neutral early critical collar costs at most two extra loss units

25 October 2026. Proposed ordinary lemma for independent attack. This is
a genuine-history loss bound, not a new capture-time conclusion. It uses
the accepted failed-join account and ordinary genuine reference maps.

Write w=2b, n>=2b, b>=32, k=b+d, 1<=d<=b-1,

    L=(b-1)^2, H=b(b-1), A=H-d+1.

Use a failed-prefix normalized word, its actual early cut u, actual hole
counts Q_j, and genuine early pair E_j. Put M_j=max E_j and
delta_E=M_u-Q_u. The reviewed reduction gives

    A<=Q_u<=H,  0<=delta_E<=g-1<=d-1,
    Q_j<=H and Q_j<=M_j for 0<=j<=u.

Let tau be the FIRST genuine index with M_tau>L. It exists and tau<=u.
Clamp only the actual counts, C_j=max(Q_j,L), for tau<=j<=u. Then

    Lambda_E=sum_(j=tau)^(u-1) [d-(C_(j+1)-C_j)]
            <=delta_E+epsilon_d,                         (C1)

where epsilon_1=1 and epsilon_d=2 for d>=2. Every summand is a
nonnegative integer. In particular this is a sum over actual updates,
including retreats; no assumption of monotone actual boundary progress
is made.

## 1. Every clamped physical increment is at most d

If Q_(j+1)>L, its actual total original surplus is at least b. This is
the accepted small/co-small exclusion in the pronic boundary Q<=H.
Thus Q_(j+1)<=Q_j+k-b=Q_j+d<=C_j+d. If Q_(j+1)<=L, then
C_(j+1)=L<=C_j. Therefore C_(j+1)-C_j<=d in both cases.

## 2. The genuine maximum loses at most two units against affine drift

The ordinary maps are

    G(x)=x+k-rho(x+k), F(x)=x+k-ceil_sqrt(x+k),
    E_(j+1)=(G(E_j[1]),F(E_j[0])).

For tau<=j<u, monotonicity gives L<M_j<=M_u<=H+d-1.
Hence x=M_j has

    H<x+k<(b+1)^2,

so ceil_sqrt(x+k) is b or b+1, while rho(x+k)>=b. Thus

    M_j+d-1<=F(M_j)<=M_(j+1)<=G(M_j)<=M_j+d.       (C2)

The lower middle inequality is valid whichever coordinate realizes the
maximum: its outgoing branch is F or G, both at least F. If M_j<A,
then M_j+k<=b^2, so F(M_j)=G(M_j)=M_j+d, and (C2) is equality.
Consequently a one-unit loss can occur only at a source maximum M_j>=A.

For d>=2, let q count the updates from the first such source through u.
Each maximum increment is at least d-1, whence

    q(d-1)<=M_u-A<=2d-2.

So q<=2, and the total numerical loss

    c_E=d(u-tau)-(M_u-M_tau)

is at most two. All earlier updates have zero loss.

For d=1, the shared account gives M_u<=H and A=H. Any source maximum
at least A is therefore exactly H. Global interlacing and exact inversion
at a maximum greater than L give span E_j<=k-b=1. The only possible
one-step stall is the oriented pair (H,H-1) becoming (H,H); its next
image has maximum H+1. Neither (H,H) nor the other orientation
(H-1,H) can stall while the final maximum stays at most H. Thus c_E<=1.

## 3. The exact telescope retains the endpoint deficit

Because C_tau<=M_tau and C_u=Q_u,

    Lambda_E=d(u-tau)-(Q_u-C_tau)
            =delta_E+c_E+(C_tau-M_tau)
            <=delta_E+c_E.

This proves (C1). Notice that an arbitrary early reference span has not
been substituted by the final g. Only the actual endpoint deficit and
the exact affine-drift losses are used.

## 4. Reverse critical collars have no extra numerical loss

For the actual reverse boundary in the reviewed cap-buffer theorem,
write W_j for its genuine shifted pair on its actual index interval.
Its terminal maximum is at most H-1. If its maximum ever exceeds L,
start the collar at the first such index within the actual interval;
if the initial maximum already exceeds L, use that initial index.
Stop at the actual reverse endpoint. Use the same clamp max(Q_j,L).
If the terminal reference maximum is at most L, define Lambda_J=0.

Every source maximum in this collar is less than A. Otherwise (C2)
would put the next maximum at least A+d-1=H, contradicting its terminal
maximum at most H-1. Hence every reference maximum increment is exactly
d. The same telescope gives

    Lambda_J<=delta_J,                             (C3)

because the clamped terminal count is at least the actual terminal
count. Thus (C3) also holds if the actual reverse endpoint is at most L;
the terminal clamp then only improves the bound. A one-state collar has
Lambda_J=0 and causes no exception. This retains
the actual shifted initial index, rather than restarting a numerical
phase at zero.

## 5. One common account through both collars and the actual middle

Combine (C1),(C3), including the stated empty-collar convention, with the
independently accepted whole low-excess account

    delta_E+delta_J+eta+R<=g-1.

It follows that

    Lambda_E+Lambda_J+eta+R<=g-1+epsilon_d<=g+1.     (C4)

On updates whose actual source and target exceed L, each summand in
Lambda is exactly unused quota plus original surplus minus b. On an
update touching the clamp it is the stated nonnegative clamped loss;
it must not be relabeled as a literal original-surplus charge. Therefore
the controlled collar can be used for critical-transition reasoning only
with those exceptional clamp contacts explicitly retained.

This addresses the earlier concern that neutral F steps could have an
uncontrolled total age. Their number may still be large, but their shared
loss, including every retreat in the clamped accounting, is controlled
by the same endpoint budget up to at most two exact radial-wall units.
It does not supply a corner marker at tau, bound the entire earlier
subcritical ancestry, or turn the extra units into a zero-gap theorem.

# Independent audit of the medium-budget ten-clock capture theorem

25 October 2026. Ordinary review of
`even-medium-budget-ten-clock-extension.md`, covering w=2b, b>=32,
n>=2b, 2b<=k<=floor(b^2/2), with d=k-b. The corrected proof uses
growth of the MINIMUM of the swapped physical pair, not an unsupported
per-coordinate increase relative to its own previous value.

## Boundary ranges and ordinary comparison domains

The new threshold z=b^2-k+1 satisfies k<z<=L=(b-1)^2. The first actual
hole crossing of z has raw total at most b^2. If original total surplus
is at least b its target is at most H=b(b-1). If it is below b, small
target hole components have total at most L, while any co-small component
already has at least h-H>=b^2+b rooms and cannot fit that raw total.
Hence the crossing lies in [z,H], with all earlier counts below z.

The LAST mass crossing from above z-1 to at most z-1 exists since k<z.
Matching noncontraction bounds its preceding mass Y by z-1+k=b^2.
All later actual masses stay at most z-1<=H. At the early cut the mass
is at least h-H>b^2, so the late cut is strictly later; neither cuts
coincide nor a boundary move is lost.

The arbitrary tied-origin theorem has no upper bound on k. The large
raw initializer still starts at x-k<=b^2-k<=H; the small raw initializer
still lies in the accepted first-quota domain. For the arbitrary-terminal
late theorem the reverse clip b^2-k+1 remains positive. Before its first
crossing all raw counts are at most b^2, giving hole counts at most H.
For a<k the frozen enlarged signed-late theorem already permits k<=b^2;
for a>=k the actual one-inspection initialization applies unchanged.
Thus the early and late clocks at z are legitimate throughout the larger
budget interval, including its endpoint floor(b^2/2).

## The clamp and lower clock do not require their old interior endpoints

The small/co-small proof gives clamp increment at most d for
C=clip(Q,L,U), U=h-H-1, at every actual update. If its co-small branch
gives Q>=U-d, then C>=U-d even when U-d<=L. This is just monotonicity
of clipping and d>=0, not a hidden U-d>L hypothesis.

The new cuts can lie outside the two clamp walls. Nevertheless C_e<=H,
while C_v>=h-b^2 because Q_v=h-Y>=h-b^2 and both L and U allow that
lower bound. Thus C_v-C_e>=h-2b^2+b>0. The corresponding affine clock
D0 is necessary. Combined with actual boundary clocks it proves J*.
For a word in the s-clock window, the three nonnegative integer delays
sum to at most s-1, hence the SAME clamped loss R satisfies R<=sd-1.

## The physical upper construction has the claimed four-day allowance

Before e0, both ordinary early inputs are below z, so their raw quotas
are at most z-1+k=b^2. These are supported actual corner constructions;
the first target coordinates are at most H. The analogous ordinary late
inputs are below z<=L, where their corner costs agree with the finite
physical maps, and their terminal thresholds are at most b^2. The tail
therefore supplies a genuine physical pair C, not an arbitrary numerical
seed with a favorable phase.

Before reaching z, the ordinary late MINIMUM rises by at least d per
update. Hence ell0<=ceil(z/d)<=b. Its genuine spread bound gives
r<=ceil(ell0/2)<=ceil(b/2)<=d, and min C>=z-r. For the exact finite-board
even-width backward maps each output gains at least d from its source
input, clipped at h; therefore the pair's MINIMUM gains at least d.
After ceil((h-2z+r)/d) updates both phases are at least h-z and meet
the actual early phase by the exact antipodal adjunction.

The numerator difference from D0 is

    2k-b-2+r <= 3d+b-2 <= 4d-2.

The elementary ceiling-difference inequality then pays at most four
extra updates. This yields a genuine solo gate by J*+4 and whole-board
capture by 2J*+10, with final inspections counted separately.

## Every intermediate shape remains in the bounded universe

The early strict corridor uses Q_e>=z>max E_(e-s), following from
e-s<e0. Tied restart bounds each actual earlier segment. The late
corridor uses Y>=z>max V_(ell-s); actual later masses are at most z-1,
so the arbitrary-terminal comparison applies to every needed segment.
All final negative-mass cases are exactly those already checked in the
fixed-slack proof. These bounds cost at most (s+1)k-1 per boundary update.

For the middle, an upper excursion always has a first entry since
Q_e<=H<U; entry overhang is at most k and at most s-1 later plateau
steps add at most k each. A lower excursion always exits since
Q_v>=h-b^2>=b^2>L. Its last below-L point is at least L+1-k solely
by actual gain<=k, regardless of whether the return crosses the upper
wall too. At most s-1 preceding below-L plateau steps give depth<sk,
including an excursion already underway at e. Thus |Q-C|<=sk holds
at BOTH cuts and all intervening states without their former interior
assumption. The original surplus bound b+R+2sk<=(3s+1)k-1 follows.

For s=10 this is 31k-1 on every update. The previously reviewed literal
cutset graph consequently contains the two actual normalized optimal
prefixes in clocks J* through J*+9. Exact physical edges and their final
literal intersection test prove the stated optimum and reconstructed
word. No cardinality-only gate palindrome is substituted.

## Accepted conclusion and limitations

The ordinary theorem is valid on the stated entire medium-budget family.
Its exp(O(k log(wn))) state exponent gives exp(O(b log b)) on short
boards for linear budgets. Near k=b^2/2 it can be as large as the full
subset universe; the theorem correctly avoids an asymptotic speedup
claim there. No new large instance was evaluated, no direct parameter
inspection rule or bounded-operation expression was obtained, and no
new Lean or publication status follows from this review.

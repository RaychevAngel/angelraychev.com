"""Independent tiny-board check of literal matching/cutset identities.

This is diagnostic evidence for the ordinary proof, not a strategy search.
Both physical colors and both aspect orders are included. No imports from
the authors' model are used.
"""
import hashlib
import itertools
import json
from pathlib import Path


def check(ell, m, color):
    coords = [(2*i + ((color-y) % 2), y)
              for i in range(ell) for y in range(m)]
    other = {(2*i + ((1-color-y) % 2), y): i*m+y
             for i in range(ell) for y in range(m)}
    physical_images = []
    directed_images = []
    for v, (x, y) in enumerate(coords):
        phys = 0
        for dx, dy in [(1, 0), (-1, 0), (0, 1), (0, -1)]:
            z = (x+dx, y+dy)
            if z in other:
                phys |= 1 << other[z]
        i = v // m
        direct = 1 << v
        for yy in [y-1, y+1]:
            if 0 <= yy < m:
                direct |= 1 << (i*m+yy)
        ii = i + (1 if (color-y) % 2 else -1)
        if 0 <= ii < ell:
            direct |= 1 << (ii*m+y)
        assert phys == direct, (ell, m, color, v, phys, direct)
        physical_images.append(phys)
        directed_images.append(direct)
    edges = []
    for i in range(ell):
        for y in range(m):
            if y+1 < m:
                edges.append((i*m+y, i*m+y+1))
            if i+1 < ell:
                edges.append((i*m+y, (i+1)*m+y))
    minimum_slack = None
    maximum_cut = 0
    seen = set()
    for r in range(1 << (ell*m)):
        nr = 0
        for v, image in enumerate(physical_images):
            if (r >> v) & 1:
                nr |= image
        assert r & ~nr == 0
        boundary = nr & ~r
        sigma = nr.bit_count() - r.bit_count()
        cut = tuple(e for e, (u, v) in enumerate(edges)
                    if ((r >> u) ^ (r >> v)) & 1)
        bound = 6*sigma + (ell-1)*(m % 2)
        slack = bound-len(cut)
        assert slack >= 0, (ell, m, color, r, sigma, cut)
        minimum_slack = slack if minimum_slack is None else min(minimum_slack, slack)
        maximum_cut = max(maximum_cut, len(cut))
        key = (r & 1, cut)
        assert key not in seen
        seen.add(key)
        rowmask = (1 << m)-1
        for i in range(ell-1):
            a = (r >> (i*m)) & rowmask
            c = (r >> ((i+1)*m)) & rowmask
            bi = ((boundary >> (i*m)) & rowmask).bit_count()
            bj = ((boundary >> ((i+1)*m)) & rowmask).bit_count()
            assert (a ^ c).bit_count() <= 2*(bi+bj)+m % 2
    return dict(ell=ell, m=m, color=color, supports=1 << (ell*m),
                minimum_cut_bound_slack=minimum_slack, maximum_cut=maximum_cut)


def main():
    rows = [check(ell, m, color)
            for ell in range(1, 7) for m in range(2, 7)
            if ell*m <= 12 for color in [0, 1]]
    result = dict(status='all checks passed', cases=len(rows),
                  supports=sum(r['supports'] for r in rows),
                  rows=rows,
                  script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  proof_status='diagnostic only; ordinary proof is separate')
    output = Path(__file__).with_name('candidate-rotated-cutset-check.json')
    output.write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({k: v for k, v in result.items() if k != 'rows'}))


if __name__ == '__main__':
    main()

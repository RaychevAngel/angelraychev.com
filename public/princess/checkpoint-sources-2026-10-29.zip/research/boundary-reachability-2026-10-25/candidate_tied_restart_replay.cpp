// Independent arithmetic replay of the arbitrary tied-origin mixing base.
// Sorted multiway state merge; direct integer root tables; phase/root intervals.
// Does not include or invoke the author's discovery/checker implementation.
#include <algorithm>
#include <array>
#include <cassert>
#include <cstdint>
#include <fstream>
#include <functional>
#include <iostream>
#include <queue>
#include <string>
#include <vector>

using I = std::int64_t;
constexpr I LIMIT=2000000;
struct Pair { I x,y; };
std::vector<std::uint16_t> sq(LIMIT+1), pr(LIMIT+1), tr(LIMIT+1);

void roots() {
    I s=0,p=0,t=0;
    for(I z=0;z<=LIMIT;++z) {
        while(s*s<z) ++s;
        while(p*(p+1)<z) ++p;
        while((t+1)*(t+2)/2<=z) ++t;
        sq[z]=s; pr[z]=p; tr[z]=t;
    }
}
I small(Pair a) {return std::min(a.x,a.y);}
Pair step(Pair a,I k) {
    assert(a.x+k<=LIMIT && a.y+k<=LIMIT);
    return {a.y+k-pr[a.y+k],a.x+k-sq[a.x+k]};
}
I bad(I z,I k) {assert(z+k-1<=LIMIT);return z+k-1-pr[z+k-1];}
std::uint64_t pack(Pair a) {return (std::uint64_t(a.x)<<32)|std::uint64_t(a.y);}
Pair unpack(std::uint64_t a) {return {I(a>>32),I(a&0xffffffffULL)};}

int main(int argc,char**argv) {
    roots();
    I stop=argc>1?std::stoll(argv[1]):9900;
    std::string output=argc>2?argv[2]:"";
    I states=0,seeds=0,min_margin=1000000,max_steps=0;
    std::array<I,100> byroot{};
    std::array<I,2> byphase{};
    std::uint64_t state_digest=1469598103934665603ULL;
    for(I k=13;k<=stop;++k) {
        I ceiling=std::min<I>(99*99,(k-2)*(k-2));
        std::priority_queue<std::uint64_t,std::vector<std::uint64_t>,std::greater<std::uint64_t>> pending;
        for(I q=0;q<ceiling;++q) {
            Pair a=step({q,q},k);
            if(small(a)>=ceiling) break;
            pending.push(pack(a));
        }
        std::uint64_t previous=~std::uint64_t(0);
        while(!pending.empty()) {
            auto code=pending.top(); pending.pop();
            if(code==previous) continue;
            assert(previous==~std::uint64_t(0) || code>previous);
            previous=code;
            Pair a=unpack(code);
            ++states;
            state_digest=(state_digest^code)*1099511628211ULL;
            state_digest=(state_digest^std::uint64_t(k))*1099511628211ULL;
            if(a.x!=a.y) {
                I phase=a.x>a.y?0:1;
                I lo=small(a)+1, hi=std::min<I>(std::max(a.x,a.y),ceiling);
                I first=std::max<I>(4,sq[lo]);
                I last=std::min<I>(std::min<I>(99,k-2),sq[hi]);
                for(I r=first;r<=last;++r) {
                    I left=std::max<I>(lo,(r-1)*(r-1)+1);
                    I right=std::min<I>(hi,r*(r-phase));
                    for(I q=left;q<=right;++q) {
                        I deficit=r*(r-phase)-q;
                        I core=2*r-2-phase-2*tr[deficit];
                        if(phase==0 && q==(r-1)*(r-1)+1) core=std::min<I>(core,2*r-4);
                        assert(core>=1);
                        // After first common domination it persists: B(z)<=F(z)
                        // and monotonicity bound it by BOTH next pair branches.
                        I z=q, used=0; Pair reference=a;
                        while(used<core-1 && z>small(reference)) {
                            z=bad(z,k); reference=step(reference,k); ++used;
                        }
                        if(z>small(reference)) {
                            std::cout<<"FAIL k="<<k<<" pair="<<a.x<<","<<a.y
                                     <<" phase="<<phase<<" q="<<q<<" root="<<r
                                     <<" core="<<core<<" used="<<used<<"\n";
                            return 1;
                        }
                        ++seeds; ++byroot[r]; ++byphase[phase];
                        min_margin=std::min<I>(min_margin,core-1-used);
                        max_steps=std::max<I>(max_steps,used);
                    }
                }
            }
            Pair next=step(a,k);
            assert(next.x>=a.x && next.y>=a.y && pack(next)>code);
            if(small(next)<ceiling) pending.push(pack(next));
        }
        if(k%1000==0) std::cerr<<"budget="<<k<<" states="<<states<<" seeds="<<seeds<<"\n";
    }
    std::string report="{\n  \"status\": \"passed\",\n  \"maximum_budget\": "+std::to_string(stop)+
        ",\n  \"reachable_pair_states\": "+std::to_string(states)+
        ",\n  \"dangerous_seeds\": "+std::to_string(seeds)+
        ",\n  \"minimum_margin\": "+std::to_string(min_margin)+
        ",\n  \"maximum_steps_to_common_domination\": "+std::to_string(max_steps)+
        ",\n  \"ordered_state_digest\": \""+std::to_string(state_digest)+"\",\n  \"phase_counts\": ["+
        std::to_string(byphase[0])+","+std::to_string(byphase[1])+"],\n  \"root_counts_4_to_99\": [";
    for(I r=4;r<=99;++r) report+=(r==4?"":",")+std::to_string(byroot[r]);
    report+="]\n}\n";
    std::cout<<report;
    if(!output.empty()) {std::ofstream f(output);f<<report;}
}

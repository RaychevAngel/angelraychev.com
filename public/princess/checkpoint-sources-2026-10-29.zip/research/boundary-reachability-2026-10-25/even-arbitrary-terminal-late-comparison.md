# Ordinary late comparison with an arbitrary bounded terminal mass

25 October 2026. New ordinary proof for independent review. This extends
an accepted comparison; it does not yet assert an exact capture algorithm.
The exact seed construction below was identified independently by the odd
lane. All previous dated sources and accepted hashes are preserved.

Let w=2b, n>=2b, b>=32, k=b+d, 1<=d<=b-1, and put

    H=b(b-1), A=b^2-k+1, Z=b^2+1.

For any integer 0<=a<=H define the ordinary late pair

    V_0^a=(a,a),
    V_(j+1)^a=(k+V_j^a[1]-rho(V_j^a[1]),
               k+V_j^a[0]-ceil_sqrt(V_j^a[0])).

Consider any suffix of an actual nested, last-full-normalized history. If
its initial signed mass is m and its signed mass after t unsuccessful
inspection-and-movement updates is at most a, then

    min(max(m,0),Z) <= max V_t^a.                    (AT1)

The normalization and actual history are retained. This is not a claim
that an arbitrary partial state is equivalent to a solo state.

## 1. Inputs already proved

For a<=k, (AT1) is the accepted enlarged ordinary signed-late comparison.
We therefore prove the new case k<=a<=H. The accepted mixed comparison
already extends to every nonnegative terminal a<=b^2: its survivor
reference u=x-k remains at most H while x<=Z; both corner surplus costs
are at most b and the next reference is at most b^2. Only the stopping
threshold changes. Thus an actual permanently mixed r-update suffix,
including its activation inspection, satisfies

    min(max(m,0),Z) <= min V_r^a.                    (AT2)

We also use the accepted arbitrary tied-origin restart theorem through
hole count H. From any actual shape of total hole count x<=H, the pair
(x,x) bounds every continuation whose total hole counts remain <=H.
This theorem does not assign a matching corner phase to its initial shape.

The ordinary scalar maps are monotone. The V orbit is coordinatewise
nondecreasing and interlaced: the initial inequality min V_1>=a follows
from ceil_sqrt(a)<=b<k, and the monotone swapped recurrence propagates it.
All statements below only need the orbit before its maximum reaches Z.

## 2. Exact initialization by one actual inspection

Set W_j=V_(j+1)^a-(k,k); this follows the ordinary early recurrence

    Phi(x,y)=(y+k-rho(y+k), x+k-ceil_sqrt(x+k)).

Suppose a real solo terminal/activation set D satisfies

    |D|<=z=min V_r^a<Z.

Because a>=k and V is nondecreasing, k<=z<=b^2. Choose an actual one-color
hole set X contained in D of size

    |X|=min(|D|,z-k).

The other cohort is full. Inspect exactly D minus X. This uses at most k
inspections and creates exactly the hole set Erosion(D). Start the tied
restart comparison at this actual X, dominated by (z-k,z-k). Its first
numerical image is

    Phi(z-k,z-k)=(z-rho(z),z-ceil_sqrt(z)) <= W_r.   (AT3)

Here the inequality is coordinatewise because both coordinates of V_r
are at least z. The initial count z-k is at most b^2-k=A-1<=H. The
first target Erosion(D) has size <=H by the accepted exact square inverse
for raw sets of size <=b^2. Thus the artificial preceding inspection and
the REAL reversed continuation constitute a legitimate actual history
for tied restart. No full-origin accessibility of X is assumed or needed.

This is an exact-index initialization: it spends the one real update
which creates the seed and then compares the seed to W_r. It does not
add a clock to the solo word or replace W_r by a tied maximum.

## 3. Clipping preserves the real reverse word

If the actual suffix is already mixed, (AT2) proves (AT1). Otherwise
reverse its solo part, of length ell>=1, ending at an actual set D. If
activation follows, let r>=1 be the mixed remainder; (AT2) supplies
|D|<=min V_r unless that reference is already >=Z, in which case (AT1)
is immediate. If the suffix is entirely solo, take r=0 and |D|<=a.

Write J_0=Erosion(D) and follow the real reverse erosion updates
J_(i+1)=Erosion(J_i union I_i), with |I_i|<=k. Literal solo reversal gives

    m <= k+|J_(ell-1)|.                            (AT4)

If |J_0|>=A, the initialization (AT3) and restart give max W_r>=A, so
max V_(r+ell)>=k+A=Z and the desired clipped bound is automatic.
Otherwise consider this actual reverse word until its first target >=A.
Every such target has raw size at most A-1+k=b^2, hence hole count <=H.
Append these moves to the actual seed inspection in Section2. Tied
restart and (AT3) yield

    |J_i| <= max W_(r+i)

through the first crossing. At that crossing max W reaches A; afterwards
its monotonicity makes the A-clipped inequality automatic. Consequently

    min(|J_i|,A) <= max W_(r+i)                    (AT5)

for all relevant i. Combining (AT4)--(AT5) and r+ell=t gives

    min(m,Z) <= k+max W_(t-1) = max V_t^a.

The t=0 case is the terminal condition itself. Negative initial signed
mass is harmless because the left side of (AT1) is zero. This completes
the new a>=k case and hence all 0<=a<=H.

## 4. Exact intended use and limitations

The theorem can be applied to an ACTUAL initial segment of a normalized
late tail, taking a to be its nonnegative current signed mass. Thus it
supplies a lower mass corridor from an upper bound on that tail's clock
delay. Both the original terminal mass and the literal current endpoint
remain physical; no independently chosen phase or terminal shape appears.

This does not assert that every bounded-mass endpoint is reachable, or
that the full capture problem follows from a signed-gate value. Its role
is to bound the original surpluses of all states of a near-optimal prefix,
so a later exact endpoint evaluator can retain their actual sets.

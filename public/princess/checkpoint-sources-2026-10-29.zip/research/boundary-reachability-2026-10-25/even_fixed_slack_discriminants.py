"""Bounded independent discriminants for the fixed-clock clamp proof.

This is not a proof of the arbitrary-origin restart theorem. The first test
checks every pair of literal survivors on 4x4; the second uses an intentionally
larger scalar transition system to challenge the middle excursion argument.
"""
from collections import deque
from itertools import product
import json


def literal_clamp():
    w,n,b,d=4,4,2,1
    h=w*n//2;k=b+d;L=(b-1)**2;H=b*(b-1);U=h-H-1
    cells=[[(x,y) for x in range(w) for y in range(n) if (x+y)%2==p] for p in range(2)]
    indices=[{xy:i for i,xy in enumerate(cs)} for cs in cells]
    neigh=[]
    for p in range(2):
        ns=[]
        for x,y in cells[p]:
            mask=0
            for xx,yy in ((x-1,y),(x+1,y),(x,y-1),(x,y+1)):
                if (xx,yy) in indices[1-p]:mask|=1<<indices[1-p][xx,yy]
            ns.append(mask)
        image=[0]*(1<<h)
        for s in range(1,1<<h):
            bit=s&-s;image[s]=image[s^bit]|ns[bit.bit_length()-1]
        neigh.append(image)
    tests=0
    for a,c in product(range(1<<h),repeat=2):
        survivor=a.bit_count()+c.bit_count()
        target=neigh[0][a].bit_count()+neigh[1][c].bit_count()
        sigma=target-survivor
        q1=2*h-target
        for used in range(min(k,2*h-survivor)+1):
            q0=2*h-survivor-used
            clamp=lambda q:min(U,max(L,q))
            assert clamp(q1)-clamp(q0)<=d,(a,c,used,q0,q1,sigma)
            if h-q0>H and h-q1<=H:
                assert h-q0<=H+d+1
            tests+=1
    return tests


def scalar_excursions(b,n,d,s):
    h=b*n;k=b+d;L=(b-1)**2;H=b*(b-1);A=H-d+1;U=h-H-1
    cap=s*d-1
    clamp=lambda q:min(U,max(L,q))
    # Only actual growth<=k and the proved double-clamp gain<=d are used.
    # All possible drops are permitted, making this a stronger challenge.
    adj=[[] for _ in range(2*h+1)]
    back=[[] for _ in adj]
    for q in range(2*h+1):
        for z in range(min(2*h,q+k)+1):
            loss=d-(clamp(z)-clamp(q))
            if 0<=loss<=cap:
                adj[q].append((z,loss));back[z].append((q,loss))
    def closure(seeds,edges):
        initial=list(seeds);seen=set(initial);todo=deque(initial)
        while todo:
            q,r=todo.popleft()
            for z,cost in edges[q]:
                if r+cost<=cap and (z,r+cost) not in seen:
                    seen.add((z,r+cost));todo.append((z,r+cost))
        return seen
    forward=closure(((q,0) for q in range(A,H+1)),adj)
    reverse=closure(((q,0) for q in range(U-d,U+1)),back)
    reverse_min={}
    for q,r in reverse:reverse_min[q]=min(r,reverse_min.get(q,cap+1))
    checked=0;max_sigma=0;max_depth=0
    for q,r in forward:
        if r+reverse_min.get(q,cap+1)>cap:continue
        max_depth=max(max_depth,abs(q-clamp(q)))
        assert abs(q-clamp(q))<=s*k,(b,n,d,s,q,r)
        for z,cost in adj[q]:
            if r+cost+reverse_min.get(z,cap+1)>cap:continue
            sigma=k-(z-q)
            assert sigma<=(3*s+1)*k-1,(b,n,d,s,q,z,r,cost,sigma)
            max_sigma=max(max_sigma,sigma);checked+=1
    return dict(b=b,n=n,d=d,s=s,checked_edges=checked,max_sigma=max_sigma,max_depth=max_depth)


if __name__=='__main__':
    result={'status':'passed','literal_4x4_transition_variants':literal_clamp(),
            'scalar_relaxations':[scalar_excursions(b,n,d,s)
                for b in range(2,6) for n in (2*b,2*b+1)
                for d in range(1,b) for s in range(1,5)]}
    result['scalar_case_count']=len(result['scalar_relaxations'])
    result['scalar_edge_count']=sum(x['checked_edges'] for x in result['scalar_relaxations'])
    print(json.dumps(result,indent=2))

# Opposite longitudinal fronts cannot occur at consecutive critical moves

25 October 2026. New ordinary proof for independent review. This is a
conditional actual-history theorem under the reviewed failed-join ledger,
not a global capture-time result.

Let w=2b, n>=2b, b>=2, k=b+d, 1<=d<=b-1, L=(b-1)^2, H=b(b-1).
Use the actual solo middle from the 24 October credit lemma. Thus its
actual holes strictly increase, Q_u>=H-d+1, and the single shared credit
satisfies R<=g-1<d. Let j and j+r be consecutive critical moves with both
target beliefs at least H+2. Their actual post-inspection survivor sets
are S_j and S_(j+r). Assume both are longitudinal pyramids.

**Claim.** Their longitudinal ends agree.

## 1. Actual time and area retained

Each intervening noncritical move has original surplus at least b+1 and
costs at least one from R. Therefore

    r<=R+1<=d<=b-1.                                (1)

The literal holes immediately after the source critical move are

    A=H_(j+1)=V_opposite minus N(S_j).

They form a longitudinal pyramid facing the end opposite S_j. The exact
canonical neighborhood and reflected-complement formulas prove this even
with empty/clipped fibers; no replacement by a capacity maximizer is made.
The actual strict progress from the early endpoint gives

    |A|=Q_(j+1)>=Q_u+1>=H-d+2>=L+2.                (2)

The extra one in (2), beyond a generic size>L, is material below.

## 2. Erosion retains at least three cells of that actual pyramid

For any canonical pyramid X, subtract one from each cutoff, change color,
and canonically normalize empty fibers to obtain D(X). The slope condition
gives N(D(X)) subset X, so D(X) subset E(X). Its area loss is at most b:
only the b physical rows whose previous color starts at zero can lose a
cell. All other rows preserve area; clipping/empty rows only reduce loss.

Actual holes evolve by H_next=E(H union I). Consequently, immediately
before the target inspection at j+r, they contain the literal pyramid

    P=D^(r-1)(A).

There are r-1 erosions here, because A is already the post-movement hole
set at j+1. By (1)-(2),

    |P|>=L+2-b(r-1)>=L+2-b(b-2)=3.                 (3)

It faces the end opposite S_j and is in the target survivor's color.
Since P consists of actual holes, P intersect S_(j+r) is empty.

## 3. Same-end disjointness would allow at most two cells

An actual pyramid of size>L has at most two empty physical rows. Indeed,
if it had at least three, its occupied intervals of row lengths m_i would
each border an empty row and the cutoff slope gives area at most

    sum_i f(m_i)<=f(sum_i m_i)<=f(2b-3)=L,
    f(m)=floor((m+1)^2/4).

Here f is superadditive on nonnegative integers. This is the elementary
occupied-row collar argument, independent of any initial-fiber regularity.

If S_(j+r) faced the end opposite S_j, then it would face the SAME end as
P. Two pyramids of the same physical color facing the same end cannot
both occupy a row while remaining disjoint: their occupied fibers are
prefixes of the identical row path. Thus every occupied row of P would
be an empty row of S_(j+r). There are at most two such rows.

The same occupied-interval bound now gives |P|<=f(2)=2 (the board has
2b>=4 physical rows, so every occupied component has an empty neighbor).
This contradicts (3), proving the claim.

## Scope

The proof is uniform in length and budget within the failed-join ledger.
It needs no independently conjectured small span, no endpoint normalizing
move, and no analysis of intermediate shapes. The earlier opposite-front
transport inequality remains valid more generally, but the present
conditional history gives the stronger exclusion.

Together with the reviewed localized-label barriers and the new reversed
front-to-corner theorem, it would establish longitudinal end consistency
across every pair of consecutive interior critical moves at b>=128,
provided those descriptions use a longitudinal axis. Transverse-axis
pyramids at n=2b or 2b+1, boundary access, the last equality target, and
widths below the mixed-barrier threshold are not silently included.

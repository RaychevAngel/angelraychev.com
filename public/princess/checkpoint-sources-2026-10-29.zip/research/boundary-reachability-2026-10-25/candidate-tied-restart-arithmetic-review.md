# Independent replay of the arbitrary-tied-origin finite mixing base

25 October 2026. **Accepted finite arithmetic base.** This receipt does not
by itself accept the separate physical arbitrary-shape restart theorem.

The independent executable `candidate_tied_restart_replay.cpp` completed
the entire stated finite domain with:

* 78,874,764 distinct reachable ordinary pair states;
* 61,562,872 dangerous phase/target seeds;
* zero failed mixing obligations;
* minimum core-time margin zero;
* maximum required time to common domination 20.

The first two counts and minimum margin exactly match the author's checker.
The result is saved as `candidate-tied-restart-replay.json`; it also records
phase counts, a count for each root 4 through 99, and an ordered-state
digest. The hash receipt pins both implementations and outputs.

## Independent mechanisms

This implementation does not import or call the author's checker. It uses
three different arithmetic/enumeration mechanisms:

1. A sorted heap merges all increasing tied-origin trajectories. Duplicate
   states are removed at extraction by equality with the previous key.
   This replaces the author's unordered seen-set and discovery queue.
2. Square, pronic, and triangular roots are computed by exhaustive integer
   threshold tables, with no floating-point square root or correction loop.
3. Dangerous targets are generated in exact root intervals and in the
   unique leading phase, rather than iterating both phases and recovering
   the root separately for every target.

The explicit physical formulas for the reference update, bad branch, and
minimum raw core are necessarily shared mathematical specifications.
Computational independence does not mean substituting a different claim.

## Coverage of every finite arithmetic obligation

For each 13<=k<=9900 put cap=min(99^2,(k-2)^2). Every relevant positive-time
reference state is reached from a tie q0 with 0<=q0<cap. An origin at or
above cap is already above every relevant dangerous target, and the ordinary
invariant interval is inflationary. The first images of consecutive ties
are coordinatewise nondecreasing. Hence the seed loop may stop at the first
image whose minimum reaches cap.

Every retained state has its one exact successor inserted if the successor
minimum is still below cap. Componentwise monotonicity, and strict increase
of the packed lexicographic key, are asserted at EVERY processed state.
Thus a successor never precedes the state currently removed from the heap;
duplicates are consecutive when extracted. Induction proves that the heap
visits every required reachable state exactly once. No possible trajectory
is truncated while its minimum is below cap.

For a nontied pair, only its leading coordinate can support a dangerous
target q: min(pair)<q<=max(pair). The replay intersects that interval with
cap and with each exact root bin (r-1)^2<q<=r^2, for

    4<=r<=min(99,k-2).

It additionally enforces the true phase capacity q<=r(r-p). This is exactly
the source obligation, with neither extra phase assumptions nor omitted
targets. Tied pairs have no dangerous target.

The root bounds are complete: k>=13 puts every positive-time reference
minimum at least9, so roots at most3 cannot be dangerous. For roots at most
99, the first positive-time minimum k-ceil_sqrt(k)<r^2 is necessary, and
implies k<=r^2+r<=9900. The physical subcritical-root condition with feasible
budget implies r<=k-2. These justify the finite domain and cap; they are
not cutoffs chosen after observing successful tests.

## Exact target inequality and early stopping

For phase p, deficit delta=r(r-p)-q, use

    core=2r-2-p-2*mtri(delta),

and the additional minimum with 2r-4 in the specified rigid own-phase case.
Every visited dangerous seed has core>=1, asserted explicitly.
The replay checks common domination by time core-1. It may stop at the first
time this occurs because that property persists: if z<=min(x,y), then

    B(z)=G(z-1)<=F(z)<=F(x),
    B(z)<=G(y).

Thus early stopping proves the requested final-time inequality rather than
silently replacing it by a first-passage conjecture. A failure to dominate
by core-1 terminates with the complete budget/pair/phase/target witness.

All values are signed 64-bit integers; packed pair keys use 64-bit unsigned
integers. Root tables run through 2,000,000. The initial retained reference
maximum is below cap+k, and at most196 transitions add at most k, so every
lookup argument is below 9801+198*9900=1,970,001. Bounds are also checked
at runtime. Table roots themselves fit in16 bits. No overflow or floating
approximation enters the checked domain.

## Evidence boundary

This is an independently reproduced, complete finite arithmetic base for
the proposed uniform ordinary theorem. The analytic roots>=100 argument,
physical initialization, actual marker/corner retention, and boundary
interface require their separate ordinary source reviews. No physical
strategy enumeration, full-box capture result, Lean proof, or publication
update is inferred merely from the 61,562,872 successful inequalities.

# A literal cutset encoding with either board axis used for matching

25 October 2026. Ordinary geometric lemma, independently rederived from
actual coordinates. It needs no ordering of the two side lengths. The
accepted sources are `../supersession-even-states.md`, Lemma 1, and
`../phase-compatibility-2026-10-24/even-middle-cutset-compression.md`.
Their hypotheses already permit the rotation below; this note makes the
physical map and the resulting complexity explicit.

Let the board be P_(2ell) square P_m, with ell>=1 and m>=2. Let S be
ANY one-color set and sigma=|N(S)|-|S| its actual neighborhood surplus.
There is an injective encoding of S by one membership bit and at most

    K=6 sigma+(ell-1)*1_[m odd]                     (1)

internal cut edges of the ordinary ell-by-m array. Neither 2ell<=m nor
m<=2ell is assumed. Disconnected sets, holes, survivors, full sets and
empty sets are all allowed.

## Exact matching coordinates

Write physical coordinates as (x,y), 0<=x<2ell and 0<=y<m. Match
(2i,y) to (2i+1,y). For physical color p, array position (i,y) means
the unique room

    (2i+epsilon,y),  epsilon=(p-y) mod2.

Use the same array for the opposite color. A physical edge along the
matching pair becomes a loop. A horizontal physical edge becomes a
bidirectional array edge between (i,y) and (i,y+1). The remaining
vertical physical edges become array rungs, whose direction alternates
with y: for source epsilon=1 the extra edge goes from row i to i+1;
for epsilon=0 it goes from i to i-1. Changing physical color reverses
every rung. This lists ALL physical edges, including the truncated edges
at the board boundary.

If R is the array image of S, its physical neighborhood is therefore
exactly the image N_D^+(R). Loops imply R is contained in that image.
Thus B=N_D^+(R) minus R has cardinality exactly sigma. Write
B_i for its positions in row i and r_i=|B_i|, so sum r_i=sigma.

## Independent row charge, with the odd-column endpoint retained

For adjacent array rows i,j, let P be the column parity of rungs i to j
and Q its complement. Set A=R_i and C=R_j. Every point of
(A minus C) intersect P belongs to B_j intersect P.

Use the fixed horizontal matching (0,1),(2,3),... of the m-column path.
It covers Q except possibly one point, and that exception occurs only
if m is odd and Q is the majority parity. A matched point
z in (A minus C) intersect Q, unless already in B_j, has its partner
z' in (A minus C) intersect P or in B_i intersect P. Indeed horizontal
closure from A puts z' in A union B_i; if z' were in C as well as A,
horizontal closure from C would put z in C union B_j, a contradiction.
The matching is injective. Consequently

    |A minus C|
      <=2|B_j intersect P|+|B_i intersect P|
        +|B_j intersect Q|+epsilon_Q.

Reverse the row roles and rung parity to bound |C minus A|. Adding the
two inequalities gives

    |R_i symmetric_difference R_j|
      <=2(r_i+r_j)+1_[m odd].                     (2)

The two possible unmatched-parity exceptions sum to exactly one when
m is odd, not two. No assumption about row intervals, a clean region,
or the relative sizes ell,m appears in this argument.

## Cut count and exact reconstruction

Every horizontal undirected cut edge has an outside endpoint in B.
At most two such edges are incident to one outside point, so there are
at most 2 sigma horizontal cut edges. Vertical cut edges between i,j
are counted exactly by the left side of (2). Summing over all ell-1
row adjacencies uses each r_i at most twice, giving at most
4 sigma+(ell-1)*1_[m odd] vertical cut edges. This proves (1), including
ell=1 when there are no row adjacencies.

The array is connected. Given its cutset and the membership bit at a
fixed base vertex, membership toggles across exactly those edges.
Propagation reconstructs R uniquely; inconsistent cycles are rejected.
Thus, with

    M=ell(m-1)+(ell-1)m,

the number of sets of surplus at most C is bounded by

    2 sum_(j=0)^min(6C+(ell-1)*1_[m odd],M) binom(M,j).   (3)

An exact enumerator may reconstruct all consistent descriptions and
then compute the physical surplus and discard values above C. Or it may
keep the extra literal sets: exact physical transitions still ensure
soundness, while (1) ensures completeness of the desired low-surplus
subfamily. Physical color is retained when translating the array back.

## Odd width and even length

For w=2b+1 and n=2ell, rotating the physical rectangle puts its EVEN
side first. Apply the preceding theorem with m=w, even though 2ell may
be the longer side. The resulting matching array has ell rows and w
columns, and

    K=6C+ell-1,       M=ell(w-1)+(ell-1)w.          (4)

In particular C=O(b+n) yields exp(O((b+n)log(bn))) literal one-color
sets and the same asymptotic exponent for a fixed number of paired
states, transition pairs and endpoint pairs. If a near-optimal prefix
theorem gives C=O(sk), k=O(b), and s=O(1+n/b), its surplus contribution
is O(b+n), while the odd-column cut correction in (4) is O(n).
The claimed perimeter-sized exponent therefore still follows.

This is only the exact geometric representation. Bounds on every
surplus of relevant histories, their clock windows, and the exact
capture splice remain separate inputs. The rotation does not transfer
the even-width boundary-clock theorem to odd width, and does not claim
that any numerical hole count is an attainable physical set.

## Independent finite diagnostic

`candidate_rotated_cutset_check.py` reconstructs the physical neighborhood
directly from coordinates, without importing the matching-array model.
It separately checks the directed map, each adjacent-row charge bound,
the full cut bound and injectivity of the cutset encoding. All 39,448
supports in 34 color/shape cases with at most 12 rooms per color passed,
including both aspect orders. This supports the ordinary argument above;
it does not replace it and is not a capture-strategy computation.

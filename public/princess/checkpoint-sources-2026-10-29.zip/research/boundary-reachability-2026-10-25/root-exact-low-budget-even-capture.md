# Exact capture evaluator throughout the low-budget even-width family

25 October 2026. New assembly for independent review. This is an exact
finite evaluator with reconstructed optimal inspections. It is not a
fixed-size numerical expression, a practical runtime claim, or a proof
that a previously proposed corner construction is always optimal.

Let

    w=2b, b>=32, n>=2b, k=b+d, 1<=d<=b-1.

For EVERY rectangle and budget in this family, the evaluator below
determines the exact full-board capture time and an attaining inspection
word. In particular it includes all previously unresolved short lengths
2b<=n<=2b+2d-3. Both parities of n are included. Earlier exact simpler
evaluators remain available where their hypotheses hold.

## Inputs and the fixed clock window

Put h=bn, L=(b-1)^2, H=b(b-1). Define the ordinary early pair E and
late pairs V^c as in the accepted checkpoint. For 0<=c<=k define

    J(c)=min_(H-d+1<=q<=H, H+1<=y<=H+d+1)
          [e0(q)+ceil((h-q-y)/d)+ell0(y;c)],

where e0 and ell0 are the first MAX hitting times of the genuine E and
V^c orbits. Let A=J(k) and B=J(floor(k/2)). The previously proved
necessary and constructive bounds give

    L0=max(2A+1,2B),
    U0=min(2A+4,2B+3),
    L0<=T<=U0,   B in{A,A+1},   U0<=2A+4.          (1)

The reviewed four-clock capture interface proves that SOME optimal word
admits two actual full-origin gate-k prefixes of lengths a,b in
{A,A+1,A+2,A+3}, with a+b=T-1 and endpoint intersection of size at most k.
The prefixes can be oppositely polarized and last-full-normalized. These
changes are used only to prove existence of bounded-cutset witnesses.

## An exact literal state graph

Set C=13k-1 and

    K=6C+(b-1)*1_[n odd].                           (2)

For each physical checkerboard color, use the accepted b-by-n matching
array. Enumerate every internal edge cutset with at most K edges and
either base membership bit. Reconstruct its actual one-color set by path
parity, reject inconsistent edge patterns and deduplicate sets. A graph
state is a pair (X_0,X_1) of these literal HOLE sets, one in each actual
physical color. Its actual belief is the complement of their union.
The initial state has both hole sets empty.

For a proposed update to (Y_0,Y_1), the exact minimum useful inspection
cost on source color p is

    i_p=|N(Y_(1-p)) minus X_p|.

Retain the edge if and only if, for p=0,1,

    Erosion(X_p union N(Y_(1-p)))=Y_(1-p),
    i_0+i_1<=k.                                    (3)

The actual inspections are the disjoint union of the two sets counted
by i_p. Thus every edge is an exact physical update. This is the reviewed
hole transition formula applied to both cohorts, with their color change
retained. It handles empty or full component beliefs as well.

For simplicity this graph need not enforce nesting, last-full flags,
clamp restrictions or clock corridors. Extra paths are actual strategies
and cannot produce false positive captures. Those restrictions may be
used to reduce work only with their completeness arguments retained.

Starting from the empty holes, run layered reachability through A+3
updates and retain predecessor inspections. At each of the four indicated
times t retain all reachable beliefs F with signed mass |F|-h<=k.
Call the resulting exact restricted family R_t.

## Numerical answer and optimal word

For each integer q in [L0,U0], test whether there exist

    a,b in{A,A+1,A+2,A+3},   a+b=q-1,
    F in R_a, R in R_b,     |F intersect R|<=k.       (4)

Return the smallest successful q. Store witnesses. Use the reconstructed
a-update prefix for F, inspect exactly F intersect R, then use the
b stored inspections for R in reverse order. This is a q-day capture
word, by the exact avoiding-walk reversal/splice theorem.

## Why no winning strategy relevant to the optimum is lost

Take an actual optimal word. The four-clock interface produces two
oppositely polarized, separately normalized actual gate-k prefixes at
the indicated lengths, without increasing their endpoint intersection.
The independently reviewed fixed-clock-slack theorem applies to EACH
prefix with s=4. It bounds the sum of original survivor surpluses on
EVERY update by C, retaining both cohorts, activation, arbitrary retreats,
and negative terminal signed mass.

Each target cohort hole set has neighborhood surplus at most its
corresponding original survivor surplus, so its internal cutset has at
most K edges. The initial empty sets also belong to the graph. Therefore
both actual prefix paths occur in the graph. Each original transition
satisfies (3), even if its original inspections were not minimal. Their
endpoint pair passes (4), so the evaluator returns at most the true
optimum. Conversely, every accepted pair reconstructs a physical winning
word, so the returned value cannot be smaller than that optimum. This
proves exactness and optimality of the reconstructed inspections.

Crucially, this uses the literal intersection. No inference from signed
mass alone to compatible endpoints, no arbitrary mixed gate palindrome,
and no assumed fixed-corner normal form occur in the proof.

## Complexity and scope of the advance

The matching array has M=b(n-1)+(b-1)n internal edges. Each individual
hole universe has size at most

    D=2 sum_(j=0)^min(K,M) binom(M,j).

The two-color graph has at most D^2 states. Even a dense transition scan,
all A+3 layers, and all endpoint pairs have complexity

    (A+4) exp(O(k log(wn)))

up to polynomial board-size operations. The ordinary boundary clocks
and A have polynomial bounds from the existing constructions. In the
previously unresolved short range n=O(b), k<2b, the complexity is
exp(O(b log b)), rather than unrestricted exp(Theta(b^2)) belief search.
For moderate b the explicit K can exceed M; the asymptotic improvement
does not imply that these huge graphs are presently practical to enumerate.
No such large enumeration has been run for this result.

This closes an EXACT-EVALUATION gap on one complete parameter family.
It does not prove equality of the OLD scalar lower and corner-strategy
upper bounds. Their numerical ceilings remain valid until evaluation or
a stronger direct argument determines the day. Optimal inspections here
are reconstructed by finite optimization, not yet specified by a direct
parameter rule of the user's final completion criterion.

Other families, notably odd-width even-area boards and higher budgets,
retain their prior exact results and bounds. The final all-rectangle
O(1)-operation expression and direct optimal inspections remain open.
No new Lean formalization or publication update is claimed.

## Proof dependencies introduced in this pass

- `root-four-clock-capture-interface.md`: actual capture split and clocks.
- `even-fixed-clock-slack-cutset-corridor.md`: every intermediate shape.
- `even-arbitrary-terminal-late-comparison.md`: real late boundary clocks.
- `odd-general-raw-seed-tied-initialization.md`: exact arbitrary seed index.
- `odd-arbitrary-tied-boundary-restart.md`: arbitrary tied restart, with
  independently replayed complete finite arithmetic base.
- `odd-full-word-reversal-splice.md`: exact physical capture and reversal.

The cutset representation, ordinary gate lower bounds, and constructive
upper bounds are frozen dependencies from the previous accepted checkpoint.

"""Exact independent thirteen-state certificate for K(2,3) plus one loop."""
from collections import deque
import json

L, R, C, V = 0b01001, 0b10110, 0b01101, 0b11111
# L={0,3}, R={1,2,4}, C=L union {2}; loop at2.
adj = [R, L, L | (1 << 2), R, L]
def K(s):
    out=0
    for i in range(5):
        if s>>i&1: out |= adj[i]
    return out
types = [0,L,R,C,V]
states = [(x,y) for x in types for y in types if y&~x==0]
edges = {state:{} for state in states}
for x,y in states:
    for a in range(32):
        if a&~x: continue
        for b in range(32):
            if b&~y or b&~a: continue
            cost=(x^a).bit_count()+(y^b).bit_count()
            if cost>2: continue
            target=K(a),K(b)
            assert target in edges
            edges[x,y][target]=min(edges[x,y].get(target,3),cost)
dist={(V,V):0};q=deque([(V,V)])
while q:
    source=q.popleft()
    for target in edges[source]:
        if target not in dist:
            dist[target]=dist[source]+1;q.append(target)
remaining={(0,0):0};q=deque([(0,0)])
while q:
    target=q.popleft()
    for source in states:
        if target in edges[source] and source not in remaining:
            remaining[source]=remaining[target]+1;q.append(source)
assert len(states)==13 and len(dist)==13
assert dist[0,0]==8
assert [min(dist[x,y] for x,y in states if x.bit_count()+y.bit_count()-5<=c) for c in [0,1]]==[4,3]
# This potential is an ordinary finite lower certificate: each legal update
# decreases it by at most one, and the displayed source has potential8.
assert all(remaining[s]<=1+remaining[t] for s in states for t in edges[s])
out={'folded_edges':[[0,1],[0,2],[0,4],[1,3],[2,2],[2,3],[3,4]],
     'budget':2,'types':{'L':L,'R':R,'C':C,'V':V},'capture':8,'gates':[4,3],
     'states':[{'belief':list(s),'earliest':dist[s],'remaining':remaining[s],
                'edges':[{'target':list(t),'minimum_cost':cost} for t,cost in sorted(edges[s].items())]} for s in states]}
print(json.dumps(out,indent=2))

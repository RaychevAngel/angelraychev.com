# Square critical-label consistency: the exact extra step and its limit

25 October 2026. Independent interface analysis for the developing square global-orientation lemma. This note distinguishes a conditional combinatorial consequence from the remaining boundary phase attachment. It does not establish a new capture-time formula.

Let the board be2b by2b, b>=128, k=b+d, 2<=d<=b-1. In the genuine failed-prefix middle write H=b(b-1), total middle duration Delta, and the already accepted shared slack0<=R<d. The actual cuts satisfy Q>=H-d+1 and Y>=H+1. Since

    d*Delta=2b²-Q-Y+R,

we have

    Delta<=floor((2b-3)/d)+2
          =ceil((2b-2)/d)+1<=b.

Thus ANY two classifiable critical moves, not just consecutive critical moves, are separated by at most Delta-1<=b-1. The target equality m_next=H+1 remains excluded, exactly as in the frozen central duality statement.

## 1. Do not discard the dual side

The static theorem classifies S OR its actual dual A=V\N(S). A-localized does not imply S-localized. Keep signed orientation labels:

* If S is localized at corner C, its label is the singleton{C}.
* If A is localized at corner D, its survivor label is the singleton consisting of the antipode of D.
* If S is an actual pyramid facing a board edge e, its label is the two corners of e.
* If A is an actual pyramid, exact duality makes S a pyramid facing the opposite edge; use that actual survivor edge.

The rigid exceptions are controlled by genuine time order. Rigid A is impossible because actual hole counts strictly exceed L+1. A rigid S can occur only at the last classifiable critical move. Its dominant corner supplies the singleton label, but no later-source argument may discard its remote singleton.

## 2. Why pairwise geometric consistency would give ONE common corner

The already accepted localized/localized arguments depend on a separation bound r<=b-1, after obtaining that bound from consecutiveness. They therefore apply to arbitrary critical pairs in the present square interval. The reverse mixed A-localized to S-localized barrier gives opposite longitudinal ends. Rotate the SQUARE by90 degrees and apply the same barrier: the corners must differ in both axes, hence be exact antipodes. This is the necessary strengthening from end consistency to corner consistency.

A rigid TARGET survivor needs one explicit extension of the localized-to-localized proof: its full dominant (b-1)-triangle has exactly2b-1 missing cells from the own root-b outer envelope, rather than the2b-2 omission bound for a genuinely localized set of total size>L. The existing forbidden-cell count is strictly greater than2b-1, so the contradiction still holds. The front-to-rigid-target proof uses its stronger full dominant core. There is no rigid source with a later classifiable target.

One longitudinal mixed barrier needs a further arithmetic repair before dropping consecutiveness. Its old limiting case r=b-1 inferred d=b-1 from the consecutive-event bound r<=d, which is unavailable for arbitrary pairs. Instead use the genuine starting hole count Q_(j+1)>=H-d+2. A later localized hole set has area at mostb², hence the increase is at mostb+d-2. Strict progress plus the shared credit give, at r=b-1,

    increase>=r*d-R>=d(b-1)-(d-1)=d(b-2)+1.

This is larger by(d-1)(b-3)>0 for b>=4,d>=2. Thus the limiting case is impossible directly, with no r<=d assumption. All other cases use only r<=b-1 and the retained literal geometry.

The same rotation handles the two possible pyramid axes in mixed barriers. The new opposite-front exclusion applies to any pair with r<=b-1: its proof retains the actual source pyramid through r-1 erosions and never uses intermediate noncriticality once r is bounded. The reverse front-to-corner deficit proof also extends: its bound eta<=R+r is valid with intervening critical moves, and R+r<=2b-3 still holds.

These observations supply the following precise conditional conclusion: once each stated physical barrier is invoked with its retained actual side, the singleton/edge labels of every pair of critical events intersect.

A family of vertices and edges of the four-cycle of corners has the pairwise-intersection property only if it has a common vertex. If a singleton occurs, its vertex belongs to every label. If only edges occur, absence of opposite edges leaves at most two distinct adjacent edges, which have their common corner. Three distinct edges would contain an opposite pair. Hence the interior critical family has at least one common survivor corner.

This uses actual geometric barriers, not an arbitrary relabeling of a co-localized set as localized. The orientation label is an accounting device; the physical side, literal support and true color still have to be retained.

## 3. The common corner is not yet the needed boundary phase

If every interior event is a pyramid facing the same edge, the common label set is that entire edge. Its two corners have opposite checkerboard parity. The interior argument permits either fixed corner and does not identify which endpoint of the edge is selected by the actual early or late dangerous boundary history.

Even if the interior family has a unique common corner, it must still be attached to the literal boundary endpoints at their genuine elapsed times. An early endpoint is not automatically a critical localized/pyramid set. A late erosion seed is likewise not replaced by a canonical prefix because it has a nearby cardinality.

The new tied-restart corridor and compressed boundary recurrence make these attachments explicit finite reachability problems without omitting high-surplus intermediates. They do not themselves prove that the two endpoint phases agree. A further geometric exchange, exact join exclusion, or genuinely constructive compatible join is needed before concluding gap zero.

The d=1 case is not included in the total-time argument: then Delta may be2b-1. Its R=0 restriction is stronger in a different sense, but it does not silently imply the above all-pairs separation bound.

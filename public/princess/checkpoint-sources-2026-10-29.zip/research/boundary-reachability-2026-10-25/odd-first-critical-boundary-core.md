# A large real core survives to the first critical boundary shape

25 October 2026. Conditional ordinary geometric interface, submitted for independent review. This does not replace the exact boundary-access recurrence and makes no new capture-time claim.

Let w=2b, n>=2b, b>=8192, k=b+d with1<=d<=b-1, L=(b-1)^2, H=b(b-1). Follow an actual full-origin hole history Q_j<=H through a dangerous endpoint u, meaning Q_u>min E_u for its genuine ordinary pair. Suppose there is an actual update t<=u with

    Q_t>L,     original survivor surplus sigma_t=b.

Let s be the LAST ordinary zero-good event before u, with root4<=r<=b-1. Let t instead denote the first update AFTER s satisfying the displayed conditions. (The existence of such an update before u is a premise.) Then the literal hole set at t contains a parity-correct full corner ball of radius at least floor(b/16), centered at the actual corner of the ordinary good event s.

## 1. The age is charged only through true bad moves

A last zero-good event exists: from the full-origin zero state, tiny, B-bad and critical-root F updates preserve domination by BOTH ordinary coordinates, so a dangerous endpoint cannot occur without one. Its count q=Q_s must be dangerous itself. If it were below both coordinates, all later nongood updates would preserve that fact, contrary to the endpoint. Put e=q-min E_s>0.

Every update strictly between s and t is a true B-bad update. This includes a target with root b and original surplus at least b+1. A target with sigma=b but root below b is also B-bad. Tiny targets are impossible in this segment, as they reset both coordinates. The final update t uses F because its root is b and Q_t<=H. All subsequent updates through u are F or B (there are no later ordinary good events by the definition of s).

Thus if a=t-s, two-bad-step mixing implies

    a-1<2e,             a<=2e.                       (A1)

Otherwise the count would lie below both reference coordinates before t and remain so through u. This is NOT a bound on the entire age from s to u. In particular the later root-b collar can take order b/d moves.

## 2. Small ancestors cannot reach a critical-root target this soon

For r<100, the accepted finite mixing guard instead gives a<=core<=2r-2. Since k<2b,

    Q_t<=r²+(2r-2)k<=9801+392b.

At b>=1024 this is strictly below L, contradiction. Thus r>=100 in the stated domain.

For r>=100, the accepted analytic genuine-origin estimate e<=3r/4 combines with (A1) to give a<=3r/2. No zero-shape assumption beyond the actual full-origin reference is changed. Consequently

    Q_t<=r²+a*k<r²+3br.

If r<=b/4, the right side is at most13b²/16<L for b>=11. Hence

    r>b/4.                                          (A2)

The inequalities deliberately use total quota k rather than an assumed monotone actual count or an optimistic profile drift.

## 3. Retain the ACTUAL raw corner core

The ordinary zero-good theorem gives a real full corner core at s with radius at least2r-4-4sqrt(r), including its stated triangle-plus-singleton exception. Literal hole erosion preserves that core with radius decreased by at most one per actual update. At t its retained radius is therefore at least

    2r-4-4sqrt(r)-a
      >=r/2-4-4sqrt(r)
      >=b/8-4-4sqrt(b)
      >=b/16,                    b>=8192.

This proves the claimed ball, with its true color and corner. No favorable phase is chosen at t.

## 4. At this boundary target the actual HOLES can be described directly

The exact critical duality applies because Q_t>L and the survivor S has

    |S|=h-Q_t-b>=h-b²>=b²>L.

If the static classification describes S as localized, its capacity at mostb² forces n=2b, Q_t=H and |S|=b². Equality makes S the full own root-b corner triangle. Its exact dual holes are the full opposite-phase root-b corner triangle at the antipodal corner, of area H. The rigid survivor alternative is too small. If S is a pyramid, its exact dual is the opposite-facing pyramid. Therefore the actual holes at t themselves are localized/rigid or a genuine pyramid; there is no unclassified co-localized branch at Q_t<=H.

A localized or rigid hole description must have the ancestor's corner: two color-correct cells within distance three of the retained corner lie outside every different corner's root-b envelope, whereas a localized target has no such outlier and a rigid target allows at most one.

A pyramid hole description must face an edge incident to the retained corner C. Otherwise put its facing edge at x=0, with C at (N-1,0), where both physical dimensions N,M are at least2b. The retained ball contains the target-color point (N-1-epsilon,0), epsilon in{0,1}. Its actual prefix cutoff in row0 is at least x0=N-1-epsilon. The neighboring-cutoff slope then forces the physical same-color triangle x+y<=x0 in the first2b rows.

If x0>=2b-1, that triangle has at leastb² cells in either color. If x0=2b-2, necessarily N=2b and epsilon=1, so its color is the own color of (0,0), and the triangle has exactlyb² cells. (Larger x0 only increases this count.) All these cells lie on the board. Thus the actual pyramid has area at leastb², contradicting Q_t<=H<b². This argument applies to either pyramid axis, including the two short-board axes; it uses literal fiber cutoffs and not a compressed shape.

Therefore the actual hole description is attached to the inherited corner: a localized/rigid description has exactly C, and a pyramid's actual facing edge contains C. The corresponding survivor orientation has the antipodal corner/edge by the retained dual convention.

## 5. If there is no critical boundary shape, the endpoint still has a core

Assume additionally Q_u>L, as at the genuine early cut. If no actual sigma=b, root-b target occurs after s and through u, every intervening update is B-bad. Danger forces u-s<2e (and u-s<core-1 in the finite mixing alternative). Repeat Sections2--3 with t=u: the endpoint itself retains a full actual corner ball of radius at least floor(b/16).

Thus this branch supplies a literal inherited core even without a critical shape to classify. It does not say that the whole endpoint is localized or a pyramid, nor does it automatically carry the core through a subsequent long middle.

## Exact limits

The existence of a sigma=b target with Q>L before/equal the chosen boundary endpoint is an explicit premise. The first root-b crossing can have surplus greater than b; this lemma does NOT identify it as critical. If no critical shape occurs before u, Section5 supplies a retained endpoint core and the exact boundary recurrence remains available; an orientation description for the entire endpoint is not asserted. The all-width theorem, later critical-phase compatibility and final join still require their own arguments. This is ordinary proof work, not Lean coverage.

#!/usr/bin/env python3
"""Independent finite attack on actual pyramid primitives, not a proof by cases."""
from pathlib import Path
import hashlib
import json


def cells(heights, p, n):
    return {(i, y) for i, a in enumerate(heights) for y in range(n)
            if (i + y) % 2 == p and y <= a}


def neigh(a, w, n):
    return {(i + di, y + dy) for i, y in a
            for di, dy in ((1, 0), (-1, 0), (0, 1), (0, -1))
            if 0 <= i + di < w and 0 <= y + dy < n}


def bounds(i, p, n):
    first = (p - i) % 2
    return first - 2, n - 1 - ((n - 1 - first) % 2)


def extract(a, p, w, n):
    h = []
    for i in range(w):
        row = {y for x, y in a if x == i}
        lo, _ = bounds(i, p, n)
        height = max(row, default=lo)
        if row != {y for y in range(n) if (i + y) % 2 == p and y <= height}:
            return None
        h.append(height)
    return h if all(abs(x - y) == 1 for x, y in zip(h, h[1:])) else None


def paths(w, n, p):
    def go(out):
        i = len(out)
        if i == w:
            yield out
            return
        lo, hi = bounds(i, p, n)
        candidates = range(lo, hi + 1, 2) if not out else (out[-1] - 1, out[-1] + 1)
        for a in candidates:
            if lo <= a <= hi:
                yield from go(out + [a])
    yield from go([])


def main():
    count = 0
    rows = []
    for b in range(1, 7):
        w = 2 * b
        for n in (w, w + 1):
            local = 0
            for p in (0, 1):
                opposite = {(i, y) for i in range(w) for y in range(n)
                            if (i + y) % 2 == 1 - p}
                for hs in paths(w, n, p):
                    a = cells(hs, p, n)
                    ds = [max(bounds(i, 1-p, n)[0], h-1) for i, h in enumerate(hs)]
                    d = cells(ds, 1-p, n)
                    assert extract(d, 1-p, w, n) is not None, (b, n, p, hs, 'D-path')
                    assert neigh(d, w, n) <= a, (b, n, p, hs, 'D-erosion')
                    assert 0 <= len(a)-len(d) <= b, (b, n, p, hs, 'D-area')
                    na = neigh(a, w, n)
                    assert extract(na, 1-p, w, n) is not None, (b, n, p, hs, 'N-path')
                    dual = opposite - na
                    reflected = {(i, n-1-y) for i, y in dual}
                    reflected_p = (1-p+n-1) % 2
                    assert extract(reflected, reflected_p, w, n) is not None, (b, n, p, hs, 'dual-path')
                    occupied = sum(any(x == i for x, _ in a) for i in range(w))
                    if len(a) > (b-1)**2:
                        assert w-occupied <= 2, (b, n, p, hs, 'large-empty-rows')
                    if occupied < w:
                        assert len(a) <= (occupied+1)**2//4, (b, n, p, hs, 'occupied-rank-bound')
                    if w >= 4 and occupied <= 2:
                        assert len(a) <= 2, (b, n, p, hs, 'two-row-bound')
                    local += 1
            rows.append({'b': b, 'n': n, 'pyramids': local})
            count += local
    here = Path(__file__).resolve()
    output = {'status': 'all exact finite primitive checks passed', 'total_pyramids': count,
              'cases': rows, 'claim': 'Diagnostic self-attack only; ordinary proofs are authoritative.',
              'script_sha256': hashlib.sha256(here.read_bytes()).hexdigest()}
    here.with_suffix('.json').write_text(json.dumps(output, indent=2)+'\n')
    print(json.dumps(output, indent=2))


if __name__ == '__main__':
    main()

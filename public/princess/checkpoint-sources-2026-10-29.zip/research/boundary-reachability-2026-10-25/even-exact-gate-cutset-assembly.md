# An exact compressed decision for every faster even-width signed gate

25 October 2026. Proposed assembly for independent audit. It combines
reviewed literal recurrences; it does not claim a new closed expression,
that all these decisions are negative, or an exact full-board capture time.

Let w=2b, n>=2b, b>=32, k=b+d, 1<=d<=b-1, h=bn,

    L=(b-1)^2, H=b(b-1), A=H-d+1, 0<=c<=k.

Let P(c) be the known constructive physical prefix time to signed mass at
most c. Fix any integer T<P(c). The decision below is TRUE if and only if
some actual full-origin word reaches that signed gate in T unsuccessful
inspection-and-movement updates. The terminal gate is a pre-inspection
condition; no extra final capture inspection is being counted here.

All states are literal sets, with their actual colors retained. E_j is the
genuine zero-origin early pair; V_j^c is the genuine late pair; and
W_j=V_(j+1)^c-(k,k). Use the common cutset universe with

    K=12k-6+(b-1)*1_[n odd]

internal cut edges per one-color set, plus a base bit. Its matching array
has b rows and n columns. The prior cutset theorem reconstructs literal
sets from these descriptions; incompatible edge-bit assignments are rejected.

## 1. Times and actual cohort colors

Enumerate nonnegative integers e, Delta, ell with T=e+Delta+ell, and
e>=1, Delta>=1, ell>=1. Put v=e+Delta. Enumerate the initial smaller
cohort color p0 in{0,1}; at forward day t it is physical color p0+t mod2.
The other cohort remains full through all the explicitly solo segments.

Enumerate an activation remainder r with 0<=r<=ell-1 and set

    a=ell-r>=1.

There are a solo updates after day v, followed by r permanently mixed
updates. The case r=0 means the entire late word remains solo, with no
activation before its terminal gate.

The reverse seed J_0 is in physical color p0+T-r-1 mod2. Its reverse
orbit has a-1 edges, J_0,...,J_(a-1), and reference indices

    r,r+1,...,r+a-1=ell-1.

Each reverse step flips the physical color. Therefore the terminal
reverse set J=J_(a-1) has exactly the physical color p0+v of the actual
late solo belief S. These are the genuine indices, not reset clocks.

## 2. Exact early boundary

Use the accepted genuine-clock early recurrence from the empty hole set
through e actual updates. Its endpoint X has

    A<=Q=|X|<=H, Q>min E_e, Q<=max E_e,

and all earlier counts are below A. Its exact edge X0->X1 is

    E(X0 union N(X1))=X1,
    i=|N(X1) minus X0|<=k.                          (G1)

The inspections are exactly N(X1) minus X0. Retain its one-clock corridor
and count cap <=H, as in the accepted source. Every necessary intermediate
set belongs to the common cutset universe by the tied-restart theorem.
This is full-origin reachability at exactly e updates, not endpoint size
admissibility alone.

## 3. Exact actual middle

From X use Delta further solo hole updates of the same literal form(G1).
Every target has hole count greater than L and belief count greater than
H. Require each hole count to increase by an integer in[1,d]. Its final
hole set is X_v, and define its ACTUAL complementary belief

    S=V_(p0+v) minus X_v, Y=|S|,
    H+1<=Y<=H+d+1.

Retain the exact original-surplus charge on every edge. With its minimal
inspection cost i and source/target counts q,q',

    sigma=q+i-q',
    (k-i)+(sigma-b)=d-(q'-q).

Require sigma>=b. The total middle loss is

    R=Q+Y+d*Delta-h=sum[d-(q'-q)].                  (G2)

All necessary middle target sets have original surplus at most b+R<2b
and hence satisfy the common cutset bound. The accepted strict-middle
ledger proves completeness of these restrictions for any faster word,
including histories which originally attempted retreats. No static
critical-shape classification is needed for this exact graph.

## 4. Exact genuine reverse boundary and real terminal access

If r=0, choose an erosion-closed seed J_0 satisfying

    E(N(J_0))=J_0, |N(J_0)|<=c,

and set D=N(J_0). This is an exact arbitrary terminal one-color set rule.

If r>=1, choose a seed J_0 with D=N(J_0) satisfying

    E(D)=J_0, |D|<=min V_r^c<=b^2,
    |J_0|>min W_(r-1), |J_0|<=max W_r.

Use the independently reviewed mixed-suffix recurrence from
`even-mixed-suffix-two-clock-corridor.md` to require an ACTUAL r-update
permanently mixed word from (D,full) to signed mass at most c. Its positive-
time states use two literal cutset descriptions. Its exact one-cohort
belief edge B->B' uses the maximal survivor

    S_max=B intersect E(B'), N(S_max)=B',

and cost |B minus S_max|; the two costs sum to at most k. At activation,
the prescribed larger target belief is proper, so this maximal survivor
is proper too: otherwise N(full)=full would contradict that target.
Later properness follows already from the proper source larger belief.
Thus this transition minimization preserves the required activation and
permanently mixed conditions. The real terminal predicate is evaluated;
it is not replaced by |D|<=min V_r.

The reverse seed itself also lies in the common cutset universe. In the
activated case, |D|<=min V_r=min W_(r-1)+k and
|J_0|>min W_(r-1), so its dual surplus |N(J_0)|-|J_0| is at most k-1.
In the entirely solo case it is at most |D|<=c<=k. Thus no unbounded
seed family has been omitted from the state count.

Starting at J_0, follow exactly a-1 literal erosion edges(G1), at reference
indices r through ell-1 and the physical colors in Section1. Every actual
count is at most H. Retain the genuine upper comparison and the one-clock
lower corridor on continuation states. For r>=1 retain the displayed
initial strict corridor; for r=0 use the exact first-quota initial rule,
including its tiny-seed allowance from the reviewed source.

At the reverse endpoint J require

    |J|>min W_(ell-1), |J|<=max W_(ell-1).

The accepted reverse-cap buffer supplies this unclipped range for every
necessary witness, with no former large-d exception.

## 5. The literal splice and common numerical account

Retain the actual splice condition

    |S minus J|<=k.                                  (G3)

Choose the first late inspection I_v=S minus J. Then its allowed set is

    C=I_v union J=S union J,
    eta=|C minus S|=|J minus S|.

Put M_E=max E_e, M_L=max V_ell^c and

    delta_E=M_E-Q, delta_L=M_L-Y,
    delta_J=M_L-k-|J|,
    g=min(span E_e,span V_ell^c).

Retain the proved necessary filters

    delta_E,delta_L,delta_J,R,eta>=0,
    1<=g<=d,
    delta_E+delta_L+R<=g-1,
    delta_E+delta_J+eta+R<=g-1.                       (G4)

One may also retain the reviewed incompatible-leader parity test, with
the actual Delta and chi=(w+n-2) mod2. These are pruning conditions, not
substitutes for the literal reachability and splice tests.

Notice that(G3) is exactly delta_J+eta<=delta_L, by substituting the
definitions. In particular eta is an ACTUAL set intersection/excess,
not an independently allotted geometric error.

## 6. Necessity

Given any faster physical full-origin gate word, apply the accepted
finite-prefix polarization and last-full normalization. Its actual early
and late cuts give e,Delta,ell,Q,Y and the shared account(G4). Since
Y>min V_ell^c, the late cut precedes activation, so all early and middle
states and the next a solo updates have the prescribed single-cohort form.

The tied-restart corridor puts every early and reverse intermediate set
in the cutset universe. The middle strict-loss theorem does the same for
every middle target and proves(G2) and the positive increments. Actual
reverse erosion gives an endpoint J and allowed set I_v union J containing
S, hence(G3). Replacing I_v by its useful subset S minus J can only
decrease cost and allowed-set excess.

At its real activation, let the actual smaller set be D_old. Replace it
for the isolated suffix test by D=N(E(D_old)). This preserves the seed
J_0 and can only decrease the smaller future belief under the SAME mixed
inspections. The larger partner is unchanged. The canonical-seed and
two-clock mixed-suffix theorems therefore put an actual suffix into the
exact mixed state graph. In the no-activation case use |D|<=c instead.
Thus every faster physical word yields a TRUE decision.

## 7. Sufficiency and explicit inspection reconstruction

A TRUE decision supplies actual early and middle inspection sets by(G1).
At day v use I_v=S minus J, so the surviving smaller belief is contained
in J. Reverse each stored reverse-edge inspection set and use it in the
corresponding original solo slot. The following direct inclusion proves
the timing and attainability.

For a reverse edge J_t->J_(t+1), let its stored inspection be
I_t^rev=N(J_(t+1)) minus J_t. Then

    N(J_(t+1)) subset J_t union I_t^rev.

After the first late movement, the actual belief is contained in N(J).
At the next solo day remove I_(a-2)^rev; the remaining belief is then
contained in J_(a-2). Movement puts it in N(J_(a-2)). Continue backward
through the stored edges. After exactly a solo updates the actual smaller
belief is contained in N(J_0)=D. If a=1, this is simply the first movement
from S intersect J_0 into N(J_0), with no reverse edge to traverse.

The partner has stayed full throughout. If r>=1, apply the reconstructed
mixed word from (D,full). Monotonicity lets it work from the actual smaller
subset of D, with exactly the same quotas and r further updates. If r=0,
the actual smaller terminal belief already has size at most |D|<=c.
In either case the full-origin signed gate is reached in

    e+Delta+a+r=T

actual updates. Thus a TRUE decision cannot be a false positive caused
by unattainable boundary phases or a fictitious activation seed.

## 8. Evaluation, complexity, and the capture-time boundary

Searching these exact decisions for 0<=T<P(c), with P(c) itself as a
known attainable fallback, determines the exact minimum SIGNED-GATE time
and reconstructs a corresponding word. For n=O(b), k<2b, the cutset
families and their two-cohort products have exp(O(b log b)) descriptions.
All time indices are bounded by the constructive P(c), which is polynomial
in the short-board parameters using existing constructions. Literal edge
tests and the splice use polynomial-time set operations. Thus even the
unoptimized finite state graph assembly retains exp(O(b log b)) complexity.
No such full enumeration has been launched here.

This is a genuine exact parameter-dependent physical evaluator, not an
O(1)-operation formula or a proof that the prefix clock P(c) is always
optimal. If a decision is TRUE it gives a real faster gate word; if all
decisions are FALSE it proves P(c) optimal for that instance. A uniform
symbolic answer to those decisions remains stronger information.

Finally, exact arbitrary signed-gate times do NOT automatically give exact
full-board capture time by the old prefix palindrome. A mixed gate of
signed mass c may have a larger literal small cohort than c; reflecting
its endpoint need not leave only 2c common rooms. Any use in the final
capture objective must separately prove the appropriate literal endpoint
intersection/strategy assembly. The accepted full-word reversal splice
is a possible interface, not a completed argument here.

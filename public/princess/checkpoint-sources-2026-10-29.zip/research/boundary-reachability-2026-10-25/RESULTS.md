# Rectangle capture: exact shape reachability and capture composition

25 October 2026. Accepted private research continuation from commit `0aea309`.
Read this file for current status; dated drafts retain their original wording.
Acceptance and exact source versions are recorded in the independent reviews.

## What changed, and what did not

This pass supplies a uniform way to retain the ACTUAL shapes of relevant
strategies and test the ACTUAL endpoint overlap. It closes the former
boundary-access and mixed-endpoint compatibility obligations inside new
restricted exact evaluators. Optimal inspections can be reconstructed from
their paths. This is stronger than a cardinality relaxation with an unresolved
physical realization step.

The important complexity improvement is from enumeration exponential in
board AREA to a cutset representation with a smaller exponent in the ranges
specified below. Finite games were already generically computable. Where a
new cutset cap exceeds the whole matching graph, the new evaluator can
degenerate to that generic power-set computation; that is not counted as
a new solution of the numerical classification problem.

No large new capture graph has been evaluated. In particular, this pass
does NOT prove that the existing inexpensive lower and upper bounds coincide.
Their accepted uniform ceilings remain:

- Every rectangle and feasible budget: gap at most3.
- Every width at least64, all lengths and feasible budgets: gap at most2.
- The retained budget range k>=3 floor(w/2): gap at most1.
- All older exact families, including odd-by-odd and the exact transport
  and minimum-budget results, remain in force.

The final O(1)-operation answer and direct parameter-only optimal inspection
rule remain open. Expressions were not simplified. New results are ordinary
proofs and independently reviewed arithmetic, not new Lean formalizations.

## The main theorem: small clock delay bounds every physical state

Write w=2b, h=bn, k=b+d with b>=32 and 1<=d<=b-1. Let J be the
accepted ordinary-boundary/affine-middle necessary signed-gate-k clock.
For ANY nested, last-full-normalized actual prefix of length J,...,J+s-1 reaching
that gate, the original survivor surplus on EVERY update is at most

    (3s+1)k-1.

Both cohorts, activation, retreats and negative terminal signed mass are
included. Early and late states obey genuine clock corridors. In the middle,
total holes are clamped between (b-1)^2 and h-b(b-1)-1. The clamped
gain never exceeds d. At most s-1 nonprogress steps are affordable, and
actual excursions have depth at most sk. This is the history-dependent
inequality that controls the entire word without classifying every critical
front individually.

The accepted literal cutset representation converts the surplus bound to
an exact state universe. Transitions reconstruct the true inspection sets.
Two reachable prefix endpoints are joined only when their literal
intersection fits the central budget.

Main proof: `even-fixed-clock-slack-cutset-corridor.md`.
Independent reviews: `candidate-review-fixed-clock-corridor.json`,
`odd-review-even-fixed-clock-corridor.json`, and
`root-review-compressed-capture-interfaces.json`.

## Exact evaluator coverage and costs

### Even width, low budgets

For EVERY w=2b>=64, n>=w and b+1<=k<=2b-1, an optimal word admits
two actual gate-k prefixes at one of four consecutive lengths J,...,J+3.
The surplus cap is13k-1. The exact literal endpoint evaluator reconstructs
an optimal capture word throughout this family, including all formerly
unresolved short lengths 2b<=n<=2b+2(k-b)-3.

Its cost is polynomial in the clock times times exp(O(k log(wn))).
On the remaining short boards this is exp(O(b log b)), rather than the
generic exp(Theta(b^2)) state space. Explicit constants are large; the
asymptotic statement is not a practical runtime promise.

Main source: `root-exact-low-budget-even-capture.md`.
All three independent lanes accepted this assembly.

### Even width, intermediate budgets

For EVERY w=2b>=64, n>=w and

    2b<=k<=floor(b^2/2),

new actual cuts give a necessary clock J_* and a physical solo construction
within four updates. Ten possible prefix clocks suffice, and every required
original surplus is at most31k-1. The same exact graph reconstructs an
optimal capture word. Cost remains exp(O(k log(wn))) apart from polynomial
clock/board factors. This is particularly useful for linear budgets; it can
degenerate to the full state space when k is quadratic in width.

Source: `even-medium-budget-ten-clock-extension.md`; independent candidate,
odd and root reviews are recorded.

### Odd width, even length

For w=2b+1, b>=32, every even n>=w and 2<=d=k-b<=b-1, let

    D=1+ceil((h-2b(b-1)+d-2)/(d(d-1))), s=2D+2.

The exact capture evaluator uses s consecutive prefix clocks and original
surplus cap (3s+1)k-1. Rotating the matching array adds the necessary
n/2-1 cut-edge correction. When d,d-1>=b/8, its cost is polynomial
in the clocks times exp(O((b+n)log(wn))). All lengths remain covered;
s is NOT a uniform constant as n grows. For small d the bound may be
uninformative; retain the older sharper exact natural-range results.
The minimum-budget d=1 case retains its existing exact theorem.

For EVERY 2b<=k<=floor(b^2/2), analogous actual cuts and

    s=12+2ceil((h-2b^2+b)/((k-b)(k-b-1)))

give the exact evaluator with cost exp(O((k+n)log(wn))) apart from
polynomial factors. The same quadratic-budget limitation applies.

Sources: `odd-affine-slack-capture-compression.md` and
`odd-medium-budget-capture-compression.md`; both have independent candidate
reviews, with separate boundary-parity and rotated-cutset audits.

### Higher budgets, both even-area parity families

A simpler invariant suffices here. For a complete T-day winning word,

    sum original_surplus = sum useful_inspections - wn <= Tk-wn.

Given a constructive upper bound U, each intermediate one-color HOLE set
in an optimal word has dual surplus at most C=Uk-wn. An exact cutset graph can search directly from
full belief to empty belief; no gate splitting or phase join is needed.

For b=floor(w/2)>=32, k>b^2/2 and k<h=wn/2, the existing physical
prefix construction gives C<=5n+2k. Thus exact evaluation costs
exp(O((n+k)log(wn))) apart from polynomial factors. At k>=h the known
answers are elementary: two days for h<=k<wn, one day for k>=wn.
On short boards with quadratic budgets the representation can again be
the entire power set; no computational advantage is claimed there.

Main source: `candidate-whole-word-surplus-capture.md`. It supersedes the
more complicated high-budget prefix assembly as the MAIN argument; those
intermediate notes remain preserved as research history.

## Complete domain reconciliation

Together with prior minimum-budget and odd-by-odd results, these structured
exact methods span every feasible budget at every width at least64. The
previous infeasibility/infinity classification remains unchanged. This does not
mean every instance has acquired a useful closed numerical answer: the
optimization may still be enormous or no smaller than generic search.
Smaller widths retain all previous exact statements and the global gap3
bracket. No parameter range is dropped, and no generic computability result
is substituted for the user's final completion criterion.

The practical comparison against the starting checkpoint is therefore:
no smaller GLOBAL cheap-bracket ceiling was proved; a whole family of
unrealized boundary/terminal predicates was replaced by exact physical
state recurrences, with genuine sub-area complexity in stated ranges.

## Geometric results retained without inflating the main proof

The reverse-cap band and collar-credit gaps are closed. Actual early and
activated late access have exact compressed recurrences. New physical
barriers exclude the previously missing longitudinal front-to-corner and
opposite-front transitions under their low-loss hypotheses. Square critical
labels have a common corner under the stated all-pairs guard; a large actual
boundary core attaches to its first critical shape under the explicit
b>=8192 hypothesis.

These results remain proved tools with their own limitations. The new
all-state surplus theorem makes their separate classification unnecessary
for the main exact-evaluation argument. That is mathematical unification
of the proof route, not deletion of achievements or a claim that every
boundary phase has a simple geometric description.

## Independent attacks, evidence and artifact boundary

The tied restart uses a complete finite arithmetic base independently
replayed over78,874,764 reference states and61,562,872 dangerous targets.
Small literal-state diagnostics check transition conventions and challenge
shortcuts; they are not unbounded-parameter evidence.

A fastest zero-gate witness on3x4 at k5 fails every reflected self-splice.
A connected matched bipartite nonrectangle with color symmetry has
G(0)=4,G(1)=3,T=8 although scalar gate convolution gives7. These
counterexamples explain why literal endpoint overlap remains in the proof.

All new sources, review receipts, counterexamples and failed routes are
in this directory. Public release `bbab144073e765c42f973ee0159cc573afe08541`,
the manuscript/PDF downloads and the83 canonical Lean sources remain
unchanged. No new compilation, deployment or formalization claim is made.

Restart with `CHECKPOINT.md`; the chronological account is `RESEARCH_LOG.md`.

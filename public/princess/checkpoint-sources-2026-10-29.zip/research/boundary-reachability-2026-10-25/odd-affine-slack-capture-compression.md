# Exact odd-width capture through a perimeter-sized state representation

25 October 2026. New ordinary derivation for independent attack. The graph below retains literal physical sets and their intersection. Its new claim is exact evaluation with a restricted state universe, not equality of the older scalar bounds, a practical enumeration, a direct closed inspection rule, or an O(1)-operation formula.

Let

    w=2b+1, n>=w even, b>=32, k=b+d, 2<=d<=b-1,
    h=wn/2, H=b(b-1), A0=H-d+1.

Use the genuine ordinary early pair E from (0,0), and late pair V from (k,k), with the conventions of the accepted boundary theorems. Write e0(Q), ell0(Y) for their first MAX hitting times. Define

    J=min_(A0<=Q<=H, H+1<=Y<=H+d+1)
        [e0(Q)+ceil((h-Q-Y)/d)+ell0(Y)],
    D=1+ceil((h-2H+d-2)/(d(d-1))),
    s=2D+2.                                                    (O1)

Then every instance in this stated family has an exact full-capture evaluator and reconstructed optimal inspections using literal hole cutsets of size

    K=6((3s+1)k-1)+(n/2-1)                                    (O2)

per physical color. The running-time bound is

    (J+s+1) exp(O((sk+n) log(wn))),                             (O3)

apart from polynomial board operations. In particular, whenever d and d-1 are at least b/8, it is

    (J+s+1) exp(O((b+n) log(wn))).                              (O4)

Thus every length is retained. For n=O(b) this is exp(O(b log b)); for arbitrary length the exponent is controlled by perimeter rather than area. The fixed-slack corridor below is not assumed to have an absolute constant s on arbitrarily long boards.

## 1. The ordinary affine clock remains necessary at odd width

The first actual early crossing and the last actual late crossing use exactly the same ranges A0<=Q<=H and H+1<=Y<=H+d+1 as in `even-fixed-clock-slack-cutset-corridor.md`. Its double clamp

    C_t=min(h-H-1,max((b-1)^2,Q_t))

has increment at most d on every physical update. The proof only uses the even-area matching, floor(w/2)=b, the small/co-small inverse inequalities, and h>=2b^2. All hold here. If original total surplus is below b, either both target hole sets are small, making their total at most (b-1)^2, or a co-small target forces the source to the upper clamp boundary. Thus a faster central growth cannot bypass the clamp. No even-width critical-shape classification is used.

The early ordinary comparison is already stated for every even-area rectangle. The signed late comparison, including the new arbitrary-terminal extension and raw-seed initializer, also uses only these even-area hypotheses. Its root inverse, cap b^2, tied restart through H, actual solo reversal, and proper mixed survivors do not distinguish the parity of w. Consequently e>=e0(Q), ell>=ell0(Y), and the actual middle has at least ceil((h-Q-Y)/d) updates. Therefore J is a lower bound for every actual full-origin signed gate-k time.

This is a deliberately weaker middle clock than the retained pronic/three-corner evaluator. Weakness is measured by D; it is not silently identified with that stronger evaluator.

## 2. A physical gate within D updates of the affine lower clock

Choose a minimizing Q,Y in (O1), and put e=e0(Q), ell=ell0(Y), N=h-Q-Y>0. The actual finite-board forward prefix pair at time e dominates the ordinary E_e in each labelled coordinate. Hence one ACTUAL forward phase has at least Q holes.

The actual finite-board backward prefix pair from the tied terminal seed (k,k) likewise dominates the ordinary V_ell, up to harmless clipping at h. Its maximum is at least Y. Its maps are monotone and each scalar map increases its input by at least d-1 until clipping: their physical neighborhood costs are globally at most b+1. Starting from a tied seed, the pair is coordinatewise nondecreasing. These two facts imply that after ONE additional physical update its minimum is at least the preceding maximum. Indeed the next coordinate receiving the old maximum is at least that maximum by inflationarity; the other coordinate is at least its own old value, which was the maximum. Thus at time ell+1 both actual backward phases are at least Y.

After another ceil(N/(d-1)) physical backward updates both phases are at least h-Q, or have already clipped to h. The exact antipodal two-front adjunction therefore meets whichever forward phase reached Q. There is no new phase choice or corner reset at the middle cut. It supplies a physical solo signed gate-k word of at most

    e+ell+1+ceil(N/(d-1))

unsuccessful inspection-and-movement updates. The terminal seed is k itself; no final capturing inspection is included in this gate clock.

For real x>=y, ceil(x)-ceil(y)<=ceil(x-y). Also N<=h-2H+d-2. Therefore

    1+ceil(N/(d-1))-ceil(N/d)
       <=1+ceil(N/(d(d-1)))<=D.                              (O5)

Writing P for this actual solo gate-k clock gives P<=J+D. The accepted sequential solo construction then captures the whole board in at most 2P+2 inspection days, so

    T<=2J+2D+2=2J+s.                                         (O6)

The argument uses d>=2 exactly for positive guaranteed physical progress d-1. The minimum-budget d=1 family retains its earlier separate exact theorem.

## 3. Every relevant optimal prefix has bounded original surplus

The exact capture split from `root-four-clock-capture-interface.md` generalizes verbatim: if the actual gate-k time is at least J and T<=2J+s, an optimal word has two actual full-origin gate-k prefixes of lengths

    J<=a,b<=J+s-1, a+b=T-1,                                (O7)

with literal endpoint intersection at most k. Use the first pre-inspection mass crossing into [1,k]; perfect-matching noncontraction gives the positive lower endpoint. The reversed endpoint has signed mass at most k-1 by inclusion-exclusion. Both prefixes therefore need at least J updates. Opposite polarizations and separate last-full normalization preserve the endpoint intersection condition and the clocks.

For each such normalized prefix, the proof of `even-fixed-clock-slack-cutset-corridor.md` gives

    original total survivor surplus <=(3s+1)k-1              (O8)

on EVERY update, with both cohorts retained. Here is the scope check rather than an assumed parity extension:

* Its actual cuts, nonnegative clamp loss, and endpoint delay sum use only the matching, small/co-small inverse and h>=2b^2.
* Its early s-clock lower corridor is the arbitrary tied-origin theorem, already proved for all even-area rectangles, applied to actual histories below H.
* Its middle excursion depth is bounded by sk using rise<=k and total clamped loss<=sd-1; it does not classify critical fronts or use a physical width-b construction.
* Its late s-clock lower corridor uses the arbitrary-terminal late comparison for an actual initial segment of the normalized late word. The new raw-seed initializer is an artificial physical preceding inspection followed by the real reverse history; it works with either width parity. All cap, first-exit and mixed comparisons are the same floor-width inverse inequalities.
* The scalar spread<=k, increment<=k and exact time indices are independent of board width parity.

Hence (O8) holds without replacing actual intermediate shapes by numerical capacities. Negative signed late masses and both-sided retreats remain covered.

## 4. Rotate the matching array and retain exact endpoint intersections

Since n is even, pair physical rows along this side. Each color becomes an (n/2)-by-w matching array. The static cutset theorem is valid for every rectangular matching array without an aspect-ratio restriction. Since w is odd, its parity correction is n/2-1. Each target hole set has dual surplus at most its corresponding original survivor surplus, proving (O2).

Enumerate internal cutsets of size at most K, each with one base membership bit; reject inconsistent cycle parities and reconstruct the literal hole sets. Pair the two physical colors. An edge from holes (X0,X1) to (Y0,Y1) exists precisely when

    i_p=|N(Y_(1-p)) minus X_p|,
    Erosion(X_p union N(Y_(1-p)))=Y_(1-p),  p=0,1,
    i_0+i_1<=k.                                               (O9)

These conditions are exact physical updates, not an optimization over arbitrary inspection subsets. Extra graph paths outside the normalization or clock corridors are harmless because they remain actual physical paths. Starting from empty holes, retain layered reachability and predecessor inspections through J+s-1 updates. At each t in [J,J+s-1], retain endpoints of signed mass at most k.

For q from 2J+1 through 2J+s, accept precisely when two retained endpoints F,R at a,b in this clock range obey a+b=q-1 and |F intersect R|<=k. Return the first accepted q. Reconstruct the first prefix, inspect F intersect R, and reverse the second stored inspection word.

Necessity follows from (O7), the true intermediate surplus bound (O8), and exact graph transitions. Sufficiency follows from literal full-word reversal/splice. The returned time is therefore the actual optimum and the stored word attains it. No scalar gate palindrome or cardinality-only compatibility inference is used.

The matching array has O(wn) internal edges. Its cutset universe has at most 2 sum_(j<=K) binomial(O(wn),j) sets. Even dense scanning of pairs, all layers, and all final intersections gives (O3). From (O1),

    s<=6+2h/[d(d-1)].                                          (O10)

If d,d-1>=b/8 and k<2b, this implies sk=O(b+n), proving (O4). The natural-guard complement d>(b-8)/4 has these inequalities for b>=32. Thus the new representation covers this entire complement uniformly in length; the old exact natural-range result may still be preferred where available. For n<=Cb, the explicit bound s<=6+192C follows from h<=3bn/2.

No graph of this scale has been enumerated here. K can exceed the total edge count at moderate parameters, so the asymptotic compression is not a promise of practical runtime. The result closes an exact-evaluation interface, while the user's final bounded numerical expression and directly specified optimal inspections remain open.

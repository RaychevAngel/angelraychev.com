# The exact activation predicate belongs to the erosion seed

25 October 2026. Ordinary reduction, proposed for independent review.
This is a reduction of the remaining late-boundary interface, not its
solution. The raw-set observation was suggested independently by the odd
lane. No earlier dated source is edited.

Let G be the board graph with its two color classes. Write N for open
neighborhood and E(D)={v:N(v) subset D} for erosion into the other class.
If D is one color and J=E(D), then

    N(J) subset D,                E(N(J))=J.                   (1)

Indeed the inclusion is the definition of erosion. It gives E(N(J))
subset E(D)=J. Conversely every neighbor of a point of J belongs to N(J),
so J subset E(N(J)). Thus N(J) is the unique least raw set with erosion J.

Fix a budget word, an elapsed length r, and a terminal signed gate c.
The initial belief has one cohort equal to D and the other cohort full.
An r-update continuation satisfies the gate if its final total belief has
size at most h+c, where h is the size of one color class. Requiring that
the first move is activation means that the full cohort has a proper
survivor on that first move; if desired, require the same properness on
each later move. These requirements concern the full-partner history.

For any erosion-closed literal seed J, the following are equivalent:

1. Some raw set D with E(D)=J has such a continuation.
2. The canonical raw set D_min=N(J) has such a continuation.

The implication 2=>1 takes D=D_min and uses (1). For 1=>2, start the
smaller cohort at D_min subset D and use exactly the same inspections.
At every later time its belief is a subset of the original smaller
belief, by monotonicity of deletion and neighborhood. The full partner
has exactly the same history. Thus daily quotas, elapsed time, activation
properness, and every later partner-properness constraint are preserved,
and the final signed mass can only decrease. If the original history was
nested after a fixed folding reflection, the smaller subset remains
nested in the unchanged larger cohort as well.

An additional raw cardinality cap |D|<=B changes neither direction:
the canonical set is no larger. Therefore the exact late-seed predicate
can be written without an existential raw shape:

    E(N(J))=J,
    |N(J)|<=B,
    Gate_r(N(J), full; budget word, c, activation conditions). (2)

The last line is essential. It is an actual physical continuation
predicate, not the scalar inequality |N(J)|<=min V_r^c. The scalar
mixed-boundary theorem supplies a necessary condition, not its converse.

## What this removes and what remains

The exact reverse boundary recurrence needs to carry only J, its true
color and genuine reference index, and the predicate in (2). It need not
carry an additional arbitrary activation raw set D with the same erosion.
Once a suffix from N(J) is known, its literal inspections concatenate with
the reverse recurrence: the latter depends on D only through E(D)=J.
For an entirely solo terminal suffix the gate is simply |D|<=c, so (2)
reduces to E(N(J))=J and |N(J)|<=c, already an exact terminal seed rule.

This does not evaluate the activated predicate uniformly, prove that all
cardinality-admissible J are attainable, or establish a smaller capture
gap. In particular, replacing its final line by a newly named operation
would merely hide the unresolved optimization. A useful next theorem
must either provide an exact compressed evaluator for that line or prove
that the current outer seed family cannot create a false faster full-board
join. Both would retain the physical phase and the shared loss account.

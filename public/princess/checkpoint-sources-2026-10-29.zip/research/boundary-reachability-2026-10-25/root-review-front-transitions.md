# Independent review: physical reverse deficit and front transitions

25 October 2026. Root ordinary-proof review. Accepted within the exact
hypotheses of the reviewed sources. This is not Lean verification and does
not independently assert a smaller full-game capture interval.

## General reversal inequality

Reviewed `candidate-reversed-middle-deficit.md` line by line against the
actual update `H_(t+1)=E(H_t union I_t)`. The reverse update is correctly
`Z_(s+1)=N(Z_s) minus I_(l-s)`, and ends inside `H_(j+1)`, not `H_j`.
The removed inspections retain their original colors and quotas; any now
useless inspections may simply be omitted. The inequality

    eta_(s+1)<=eta_s+sigma_(l-s)-sigma(Z_s)

has the required direction. The surplus bootstrap is noncircular:
`|Z_s|>=(b-2)^2+1` and `h-|Z_s|>H` follow from the already proved bound at
time s; small/co-small separation then forces surplus at least b-1 before
the next estimate is used. The first reverse hole set contains the literal
final survivor. There are exactly r-1 later erosions. Thus

    |H_(j+1) intersect E^(r-1)(S_l)|
      <= r + sum_(t=j+1)^l (sigma_t-b)

is accepted when that right side is at most 2b-3 and the stated middle
guards hold. Endpoint dual equality is unnecessary for this general version.

## Remaining mixed front-to-corner direction

Reviewed `candidate-reversed-middle-front-corner.md`. In the genuine charged
block the omitted reverse cells are at most R+r<=2b-3. The actual raw
localized core loses at most r-1 radius; subtracting r in the proof is a
valid conservative choice. The matching-row representation uses one real
cell in each longitudinal column and row-pair, so the first j cells of
matching row j lie within distance 3j of the specified corner.

Independently expanded the tent count. If ell_j<=j-1, its maximum area is
less than L+1 by `2+j(b-2-2j)` for the stated j range. The overlap lower
bound `M(M+1)/2`, M=floor((b-3-4sqrt(b))/3), exceeds 2b-3 for b>=128:
the proof's conservative polynomial is
`25b^2-2504b+3712`, positive at 128 and increasing thereafter. This counts
literal same-color intersections, not only matching-coordinate distances.
The final old dual is at the opposite longitudinal end and has area>L.
The contradiction is valid. The new mixed barrier is accepted for b>=128.

## Opposite longitudinal fronts

Reviewed `candidate-opposite-longitudinal-front-exclusion.md` independently.
The material strict count is `Q_(j+1)>=L+2`, because the source move occurs
after the early cut and every middle increment is positive. The target
inspection is preceded by r-1 erosions, not r. Hence its actual holes
contain a same-end canonical pyramid of area at least

    L+2-b(r-1)>=L+2-b(b-2)=3.

A target pyramid of area>L has at most two empty physical rows, using the
stated superadditive interval count. A disjoint same-end pyramid can occupy
only those rows and has area at most f(2)=2, even if they are separated.
Canonical D has area loss at most b and is contained in actual graph
erosion; image regularity is not needed. All these arguments are valid
under the explicit literal-pyramid hypotheses for b>=2. The source does
not infer small-b critical classification merely from this extension.

The ordinary proof is uniform. The separate finite physical primitive
check is diagnostic evidence, not the justification for extrapolating.

## Consequence and boundary of the result

Together with the frozen localized and other mixed barriers, the two new
lemmas establish longitudinal end consistency across consecutive interior
critical moves for b>=128 whenever their actual critical descriptions use
a longitudinal axis. They do not supply boundary access, transverse-axis
compatibility, terminal equality, arbitrary small-width cases, or a global
gap-zero theorem. Frozen general transport inequalities retain their wider
scope outside this particular failed-join history.

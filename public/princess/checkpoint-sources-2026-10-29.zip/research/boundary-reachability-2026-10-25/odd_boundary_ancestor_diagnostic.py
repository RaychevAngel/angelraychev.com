"""Bounded discriminant only: no-new-good boundary ancestor age.
An upper envelope admits every history after its last ordinary good event.
This is NOT a physical construction or a universal inequality certificate.
"""
from math import isqrt
import json

def cs(x): return isqrt(x-1)+1 if x else 0
def rho(x):
 r=isqrt(x)
 return r if r*(r+1)>=x else r+1
def tri(x):return (isqrt(8*x+1)-1)//2
def step(e,k):return(e[1]+k-rho(e[1]+k),e[0]+k-cs(e[0]+k))
worst=None; tested=0; rows=[]
for b in (32,48,64,96,128,192,256):
 for d in sorted(set([1,2,3,4,b//8,b//4,b//3,b//2,2*b//3,b-2,b-1])):
  if not 1<=d<b:continue
  k=b+d; L=(b-1)**2; H=b*(b-1); A=H-d+1
  E=[(0,0)]
  while min(E[-1])<H:E.append(step(E[-1],k))
  local=None
  for u,e in enumerate(E[:-1]):
   if u==0:continue
   for p in range(2):
    for q in range(max(1,e[1-p]+1),min(e[p],L)+1):
     r=cs(q)
     if r<4 or q>r*(r-p):continue
     core=2*r-2-p-2*tri(r*(r-p)-q)
     if p==0 and q==(r-1)**2+1:core=min(core,2*r-4)
     z=q
     for t in range(u+1,len(E)):
      f=z+k-cs(z+k)
      z=min(H,f if f>L else z+k-1-rho(z+k-1))
      if z<=min(E[t]):break
      if z>=A:
       tested+=1; item={'b':b,'d':d,'u':u,'t':t,'q':q,'r':r,'p':p,'core':core,'age':t-u,'retained':core-(t-u),'span':max(e)-min(e)}
       if local is None or item['retained']<local['retained']:local=item
       if worst is None or item['retained']<worst['retained']:worst=item
  if local:rows.append(local)
print(json.dumps({'evidence':'bounded numerical envelope diagnostic only','dangerous_endpoint_candidates':tested,'worst':worst,'rows':rows},indent=2))

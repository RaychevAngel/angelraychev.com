# Independent square-label audit, with the nonconsecutive repair

25 October 2026. Accepted ordinary conditional actual-history theorem.
Reviewed source: `odd-square-label-interface-audit.md`. The board is
2b by 2b, b>=128, k=b+d, 2<=d<=b-1, under the genuine failed-prefix
middle ledger. No full-board capture-time improvement follows by itself.

## Duration and one shared account

With Q>=H-d+1, Y>=H+1 and R<=d-1, the exact identity
d*Delta=2b^2-Q-Y+R gives

    Delta<=floor((2b-3)/d)+2<=b.

Thus any two classifiable critical moves have separation r<=b-1,
regardless of their intervening critical/noncritical pattern. Also
R+r<=2b-3. The entire word still has the one original R; no extra
allowance is created for each pair. This supplies precisely the two
inputs used in the geometric and reversed-deficit arguments.

## A real gap found and repaired before acceptance

The frozen mixed barrier C did use more than r<=b-1: at its exceptional
case r=b-1 it inferred d=b-1 from the consecutive bound r<=d. That
inference is invalid for arbitrary critical pairs. The revised square
source now explicitly replaces it. Actual source holes are at least
H-d+2, while localized target holes have at most b^2 cells. Their
increase is therefore at most b+d-2. The actual word over r=b-1 updates
has increase at least d(b-1)-R>=d(b-2)+1. The difference is
(d-1)(b-3)>0. Consequently r=b-1 is impossible in this mixed case,
and the frozen r<=b-2 geometric proof applies. No remaining use of
r<=d or intervening noncriticality is needed.

## Checking all signed label pairs

Choose any one actual critical classification at each event; retain
whether it describes S or A, its actual color, and its literal shape.

* Two S-localized descriptions have the same corner by forbidden-cell
  reachability. Two A-localized descriptions have the same corner by
  actual retained holes. Their signed singleton labels therefore agree.
* S-localized then A-localized forces antipodal corners. In the reverse
  order, the accepted mixed core argument forces opposite ends in either
  coordinate axis: rotate the square and apply it again. This also gives
  antipodal corners and hence equal signed singleton labels.
* A localized description and a literal front have intersecting labels.
  Each of the four temporal/physical-side possibilities is one of the
  three frozen mixed barriers (with the repair above) or the new reversed
  front-to-corner theorem. Rotate the square to use the actual front's
  own axis. The latter theorem requires R+r<=2b-3, supplied above.
* Two fronts on the same axis cannot face opposite edges, by retaining
  at least three cells of the old actual dual pyramid through r-1
  erosions. A target of size>L has at most two empty rows, which cannot
  contain those three cells. Fronts on different axes have adjacent
  edge labels, so their labels intersect without a further shape claim.

Rigid A is impossible because its size is L+1 whereas actual critical
target holes are at least L+2. Rigid S can occur only at the last
classifiable event, so it never supplies a source in a nonempty pair.
For S-localized to rigid S, the target's dominant triangle omits 2b-1
cells from its root-b envelope; the forbidden-cell count is strictly
larger than 2b-1. A remote singleton cannot repair this omission. For
front to rigid S, the target's full dominant core is larger than the core
used in the accepted reversed-deficit proof. The other rigid target
mixed case was already explicit in the frozen localized-barrier proof.

Thus all chosen singleton/edge labels pairwise intersect. The elementary
vertex/edge Helly fact on the four-cycle is valid: a singleton forces its
vertex into all labels; otherwise absence of opposite edges allows at
most two distinct adjacent edges. There is one common physical corner.
For no critical events the assertion is vacuous and any corner may be
chosen. No arbitrary relabeling of a co-localized set is involved.

## Exact boundary of acceptance

This is interior critical-label consistency for squares in the displayed
range. It does not attach that common corner to the actual early or late
boundary phase, treat the excluded last equality target, cover d=1,
cover b<128, or transfer to 2b by (2b+1). In particular an edge-only
family leaves its two opposite-parity corners available. An exact capture
or a free change of boundary phase cannot be inferred. No Lean coverage
is added.

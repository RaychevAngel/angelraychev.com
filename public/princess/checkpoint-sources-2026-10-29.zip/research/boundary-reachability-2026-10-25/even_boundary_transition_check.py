#!/usr/bin/env python3
"""Independent finite check of exact erosion transitions and seed inversion.

The reference enumerates every raw inspected superset D, then minimizes
the actual number |D-X| of inspections. It does not use the asserted
minimal-superset transition criterion while producing reference answers.
This checks only the finite transition algebra, not tied restart or a
universal capture-time statement.
"""
from hashlib import sha256
import json
from pathlib import Path


def check(w, n, color):
    cells = [(i, j) for i in range(w) for j in range(n)
             if (i+j) % 2 == color]
    other = [(i, j) for i in range(w) for j in range(n)
             if (i+j) % 2 != color]
    index = {v: i for i, v in enumerate(cells)}
    neighbors = []
    for i, j in other:
        mask = 0
        for di, dj in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            v = (i+di, j+dj)
            if v in index:
                mask |= 1 << index[v]
        neighbors.append(mask)
    size = 1 << len(cells)
    full = size-1
    erosions = [sum(1 << j for j, mask in enumerate(neighbors)
                    if mask & ~raw == 0) for raw in range(size)]
    neighborhood = [0] * size
    for target in range(1, size):
        bit = target & -target
        neighborhood[target] = (neighborhood[target ^ bit]
                                | neighbors[bit.bit_length()-1])
    infinity = len(cells)+1
    seed_cost = [infinity] * size
    for raw in range(size):
        target = erosions[raw]
        seed_cost[target] = min(seed_cost[target], raw.bit_count())
    for target in range(size):
        required = neighborhood[target]
        proposed = (required.bit_count() if erosions[required] == target
                    else infinity)
        assert proposed == seed_cost[target], (w, n, color, "seed", target)
    realized_pairs = 0
    for current in range(size):
        minimum = [infinity] * size
        available = full ^ current
        extra = available
        while True:
            target = erosions[current | extra]
            minimum[target] = min(minimum[target], extra.bit_count())
            if extra == 0:
                break
            extra = (extra-1) & available
        for target in range(size):
            required = neighborhood[target]
            proposed = ((required & ~current).bit_count()
                        if erosions[current | required] == target
                        else infinity)
            assert proposed == minimum[target], (w, n, color, current, target)
            realized_pairs += proposed < infinity
    return {"width": w, "length": n, "initial_color": color,
            "transition_pairs_checked": size*size,
            "realizable_transition_pairs": realized_pairs,
            "seeds_checked": size}


def main():
    root = Path(__file__).resolve().parent
    results = [check(w, n, color)
               for w, n in ((4, 4), (4, 5)) for color in (0, 1)]
    source = root / "even-genuine-clock-boundary-access.md"
    output = {"status": "passed", "checks": results,
              "total_transition_pairs": sum(r["transition_pairs_checked"] for r in results),
              "source_sha256": sha256(source.read_bytes()).hexdigest(),
              "checker_sha256": sha256(Path(__file__).read_bytes()).hexdigest(),
              "scope": "Exact finite transition/seed minimum-cost identities only; no tied-restart or full-game inference."}
    (root / "even-boundary-transition-check.json").write_text(json.dumps(output, indent=2)+"\n")
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()

#include <algorithm>
#include <bit>
#include <cstdint>
#include <functional>
#include <iostream>
#include <vector>
using namespace std;

// Independent bounded physical-state diagnostic. Each state is a literal
// pre-inspection belief, not a cardinality or a compressed geometric shape.
int main() {
  const vector<pair<int,int>> boards={{2,2},{2,3},{2,4},{2,5},{2,6},{3,4},{4,4}};
  for (auto [w,n]:boards) for(int k=w/2+1;k<w*n/2;++k) {
    const int N=w*n,h=N/2,full=(1<<N)-1;
    vector<unsigned> adj(N),nb(1<<N);
    for(int x=0;x<w;++x)for(int y=0;y<n;++y){
      int i=x*n+y;
      if(x)adj[i]|=1u<<(i-n);if(x+1<w)adj[i]|=1u<<(i+n);
      if(y)adj[i]|=1u<<(i-1);if(y+1<n)adj[i]|=1u<<(i+1);
    }
    for(unsigned s=1;s<=unsigned(full);++s){auto bit=s&-s;nb[s]=nb[s-bit]|adj[countr_zero(bit)];}
    vector<int> dist(1<<N,-1),gate(k,-1),front{full},parent(1<<N,-1),shot(1<<N,-1);dist[full]=0;
    uint64_t transitions=0;bool stopped=false;int time=0,capture=-1;
    while(!front.empty()&&capture<0&&!stopped){
      vector<int> next;
      for(int B:front){
        int mass=popcount(unsigned(B))-h;
        for(int c=0;c<k;++c)if(mass<=c&&gate[c]<0)gate[c]=time;
        if(popcount(unsigned(B))<=k){capture=time+1;break;}
        vector<int> bits;for(int i=0;i<N;++i)if(B>>i&1)bits.push_back(i);
        auto visit=[&](unsigned removed){
          if(++transitions>30000000){stopped=true;return;}
          unsigned target=nb[B^removed];
          if(dist[target]<0){dist[target]=time+1;parent[target]=B;shot[target]=removed;next.push_back(target);}
        };
        auto choose=[&](auto&& self,int p,int left,unsigned removed)->void{
          if(stopped)return;if(!left){visit(removed);return;}
          for(int q=p;q<=int(bits.size())-left;++q)self(self,q+1,left-1,removed|(1u<<bits[q]));
        };
        choose(choose,0,k,0);
        if(stopped)break;
      }
      front.swap(next);++time;
    }
    int bound=-1;
    if(all_of(gate.begin(),gate.end(),[](int z){return z>=0;})){
      bound=0;for(int c=0;c<k;++c)bound=max(bound,gate[c]+gate[k-1-c]);
    }
    cout<<"{\"w\":"<<w<<",\"n\":"<<n<<",\"k\":"<<k
        <<",\"capture\":"<<capture<<",\"gate_convolution_lower\":"<<bound
        <<",\"transitions\":"<<transitions<<",\"stopped\":"<<(stopped?"true":"false")
        <<",\"gates\":[";
    for(int c=0;c<k;++c)cout<<(c?",":"")<<gate[c];
    cout<<"]";
    int bad=-1,badc=-1,badint=-1;
    for(int c=0;c<=k/2&&bad<0;++c)if(gate[c]>=0)for(int s=0;s<=full;++s)
      if(dist[s]==gate[c]&&popcount(unsigned(s))<=h+c){
        int best=N;
        for(int tr=0;tr<(w==n?2:1);++tr)for(int fx=0;fx<2;++fx)for(int fy=0;fy<2;++fy){
          unsigned transformed=0;
          for(int x=0;x<w;++x)for(int y=0;y<n;++y)if(s>>(x*n+y)&1){
            int xx=tr?y:x,yy=tr?x:y;
            if(fx)xx=w-1-xx;if(fy)yy=n-1-yy;
            transformed|=1u<<(xx*n+yy);
          }
          best=min(best,popcount(unsigned(s)&transformed));
        }
        if(best>k){bad=s;badc=c;badint=best;break;}
      }
    if(bad>=0){
      vector<int> shots,beliefs{bad};int p=bad;
      while(parent[p]>=0){shots.push_back(shot[p]);p=parent[p];beliefs.push_back(p);}
      reverse(shots.begin(),shots.end());reverse(beliefs.begin(),beliefs.end());
      cout<<",\"bad_fastest_self_pair\":{\"c\":"<<badc<<",\"endpoint\":"<<bad<<",\"min_automorphic_intersection\":"<<badint<<",\"inspections\":[";
      for(size_t i=0;i<shots.size();++i)cout<<(i?",":"")<<shots[i];
      cout<<"],\"beliefs\":[";for(size_t i=0;i<beliefs.size();++i)cout<<(i?",":"")<<beliefs[i];cout<<"]}";
    }
    cout<<"}"<<endl;
  }
}

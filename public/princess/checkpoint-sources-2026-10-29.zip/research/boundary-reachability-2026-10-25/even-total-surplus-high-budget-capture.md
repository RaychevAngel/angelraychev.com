# Exact high-budget capture from a global surplus account

25 October 2026. Independent derivation and audit of the root shortcut.
This does not use the new boundary restart theorem, normalization,
corner ancestry, or a phase-compatibility conjecture.

Let w<=n have even area2h, put b=floor(w/2), B=ceil(w/2), and assume

    B<k<h.

Define the explicit integers

    A=ceil((h-k)/k),
    P=ceil((h-k)/(k-B)),
    U=2P+2,
    C=(U-A)k-h.                                    (H1)

Then exact full capture is decidable, with an optimal inspection word
reconstructed, in a literal two-color cutset graph whose individual hole
surpluses are bounded by C. The state representation is particularly
useful at high budgets. If b>=32 and k>floor(b^2/2), then

    0<=C<=9n+3k.                                  (H2)

For both width parities, using the even side to define the matching array,
the corresponding graph complexity is

    (U+1) exp(O((n+k) log(wn))).                   (H3)

No practical runtime, old scalar-bound equality, direct parameter rule,
new Lean verification or fixed-size numerical capture formula is claimed.

## 1. A physically justified upper clock

The frozen exact finite-board diagonal-prefix inverse formulas are stated
in `paper/sections/bridge-uniform-upper.tex`, in the proof of Proposition
`prop:bridge-buffered-comparison`. At even width2b their inverse costs
have the form min(low root,b,far root); at odd width2b+1 their exact
backward maps are

    G0(x)=min(h,k+x-min(rho(x),b,ceil_sqrt(h-x))),
    G1(x)=min(h,k+x-min(ceil_sqrt(x),b+1,1+rho(h-x))),

with G0(h)=G1(h)=h and a crossed update. These are PHYSICAL prefix maps,
not the necessary unconstrained isoperimetric comparator. Thus at either
width parity each scalar output exceeds its source input by at least
k-B until clipping at h. The pair MINIMUM therefore gains at least k-B.

Starting from the tied terminal quota(k,k), after P backward updates
both physical capacities are at least min(h,k+P(k-B))=h. This supplies
a genuine solo gate-k word of P updates in either initial phase. One
final inspection captures that cohort. Applying the two solo searches
sequentially gives full capture in U=2(P+1) inspection days.

The source width cap is global, including both corner regimes, the
central region and the final update into h. No assumption x<=b^2 or
k<=b^2 is present. This is the only geometric input to the upper clock.

## 2. A global account bounds every intermediate original surplus

For ANY actual full-origin prefix, let Q_t be total holes after t updates,
i_j<=k useful inspections on update j, and sigma_j the sum of its two
original survivor surpluses. A perfect matching gives sigma_j>=0, and

    Q_(j+1)-Q_j=i_j-sigma_j.

Hence a prefix ending at the signed gate k satisfies

    Q_t>=h-k,
    sum_(j<t) sigma_j=sum_(j<t)i_j-Q_t
       <=tk-(h-k)=(t+1)k-h.                       (H4)

Each sigma_j is nonnegative, so the SAME bound applies to every
individual update. This includes arbitrary retreats, both cohorts and
all intermediate signed masses. There is no normalization premise.
Also Q_t<=tk proves that every gate-k prefix needs at least A updates.

## 3. Capture supplies exactly the required prefix horizon

Take an optimal T-day capture word, with T<=U. Its first signed-mass
crossing into <=k has actual mass in[1,k], since each update decreases
mass by at most k. Let a be the prefix length at that pre-inspection
cut. Its literal forward endpoint F and the full-origin endpoint R of
the reversed remaining inspection word satisfy

    |F intersect R|<=k.

By inclusion-exclusion, the reverse endpoint has signed mass at most
k-(|F|-h)<=k-1. Thus both prefixes are gate-k words and their lengths
a,c obey

    A<=a,c<=U-1-A,
    a+c=T-1.                                       (H5)

For either actual prefix, (H4) bounds EVERY original surplus by
((U-1-A)+1)k-h=C. Each positive-time target hole set has dual surplus
at most its corresponding original survivor surplus, so its individual
dual surplus is also at most C. The initial holes are empty.

Notice that C>=0: P>=A, so U-A>=A+2, while (A+1)k>=h. No negative
cutset budget or empty optimum search is hidden in the construction.

## 4. Exact physical graph and optimal inspections

For an even side2r and other side s, use its r-by-s matching array and
the accepted cutset theorem: one-color dual surplus<=C requires at most

    K=6C+(r-1)*1_[s odd]

internal cut edges, plus one membership bit. Enumerate those cutsets,
reconstruct actual literal sets and reject inconsistent edge assignments.
Pair the two physical colors as hole states(X0,X1).

The exact source-to-target edge rule is

    I_p=N(Y_(1-p)) minus X_p,
    Erosion(X_p union N(Y_(1-p)))=Y_(1-p), p=0,1,
    |I_0|+|I_1|<=k.                                (H6)

It reconstructs precisely the physical inspection I_0 union I_1.
Layered reachability begins with both hole sets empty and retains
predecessors through U-1-A updates. Retain the gate-k endpoint beliefs
at times A through U-1-A. For each candidate capture day q in[2A+1,U],
test pairs of retained endpoints F,R whose times sum to q-1 and whose
literal intersection has size<=k. The first success is the exact optimum.

Indeed (H5) and the total-surplus bound put some actual optimal pair in
the graph. Conversely every graph path is physical, and a successful
endpoint pair gives the first prefix, a central inspection of F intersect R,
and the reverse of the second prefix's inspections. Exact avoiding-walk
reversal proves capture in q inspection days. No matching of signed
numbers is substituted for the actual endpoint intersection.

The graph permits all physical histories inside this universe. There
are no nested/cohort-activation flags and no reliance on the finite
arithmetic base of the boundary-restart theorem.

## 5. The high-budget bound and its useful range

Using ceil(x)<=x+1 and ceil(x)>=x in (H1),

    C <=2k(h-k)/(k-B)+5k-2h
       =2hB/(k-B)-2k^2/(k-B)+5k
       <=2hB/(k-B)+3k.                            (H7)

When k>floor(b^2/2) and b>=32, k>b^2/2 and k>=2B. Therefore

    2hB/(k-B)<=4hB/k
      <4(2b+1)(b+1)n/b^2
      =(8+12/b+4/b^2)n<9n.

This proves (H2). If w is even take r=b,s=n; the parity correction is
at most b-1<=n. If w is odd, n is even; rotate and take r=n/2,s=w,
whose correction is n/2-1. Thus K=O(n+k) in both cases.
The matching array has O(wn) internal edges. Dense graph transitions,
time layers and final endpoint pairing take a fixed power of its cutset
universe, proving (H3) up to polynomial board operations.

If n=O(b) and k is quadratic in b, this estimate can include the whole
power set and is not an asymptotic improvement. At long lengths with
k+n small relative to wn, it is a meaningful restricted state universe.
The theorem is an exact evaluator, not a claim that all large graphs
have already been evaluated or that their optimization is a closed formula.

Finally the excluded k>=h range is elementary: if h<=k<2h, inspect
one complete color on day1 and that same physical color on day2 after
the compulsory move. This captures in two days, and one day is impossible
because k<2h. If k>=2h, inspect the full board on day1. These statements
also preserve the game's movement and simultaneous inspection convention.

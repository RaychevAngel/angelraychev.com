# Independent interface lane: 25 October 2026

## Aim and inherited limits

Investigate a genuine-history reduction sufficient to close the remaining all-parameter capture-time gap. Old dated sources remain frozen. No publication, manuscript, PDF, or Lean edits are made. The useful target is not another fixed-width example: it is control of ALL actual boundary intermediates and a sound interface to the late mixed suffix.

## 1. Why the simple backwards count corridor failed

The exact inverse of the ordinary G map provides a necessary per-time count floor when propagated back from a dangerous endpoint. The even lane found this too weak: at b=512,d=1 it permits original surplus64,775, on the order of b². A proposed deficit which could recover at most one per step is also false at root-wall contractions. These are mathematical failures of those potentials, not failures of implementation.

## 2. Arbitrary physical tied-origin restart

The more useful comparison restarts the SAME actual remaining word under a tied numerical seed at its current TOTAL count. The initial physical shape is arbitrary; no initial corner or core is assigned. Only later positive-time original-zero-good targets acquire actual geometric markers.

The large-root algebra carries through because the drift estimate strengthens from u*v<r² to u*v<r²−q0. The genuinely new finite obligation is every positive-time pair reachable from EVERY nonnegative tied origin, not just zero and one-quota origins.

The complete finite domain roots4..99 and k13..9900 was checked by odd_tied_seed_mixing.cpp. It traversed78,874,764 pair states and61,562,872 dangerous phase/target seeds, with no failed mixing inequality; minimum core-time margin0. Candidate peer independently replayed the entire domain using ordered heap merging, integer root lookup tables and root-interval target generation, reproducing both counts. The physical initialization/reset argument and analytic large-root extension were independently audited by the even lane. The exact proof/source hashes are in their receipts.

This yields a one-clock corridor before any dangerous endpoint:

    min E_(j−1)<Q_j<=max E_j.

Consequently every original intermediate surplus is at most2k−1. This replaces the missing all-boundary-intermediates premise of the compressed cutset access recurrence. It does NOT imply that arbitrary unequal numerical seeds are physically meaningful, and it does NOT extend ordinary control beyond H=b(b−1).

The source is odd-arbitrary-tied-boundary-restart.md. Root's final acceptance remains separately recorded; this log does not alter a hash-reviewed source merely to update its status.

## 3. Exact boundary access versus terminal attainability

The even lane writes the exact boundary recurrence. The physical transition from one-color holes X to Y is characterized by

    |N(Y) minus X|<=k,
    Erosion(X union N(Y))=Y.

All dangerous early intermediates lie in the accepted O(k)-cutset universe, giving a genuinely compressed exact early endpoint evaluator.

For reverse activation, a cardinality constraint |D|<=min V_r is only a necessary condition for the actual future mixed suffix. The elementary sparse-interior counterexample in odd-activation-cardinality-counterexample.md makes this distinction explicit. That particular counterexample does not pass the stronger dangerous-seed erosion corridor, so it is not a counterexample to a hypothetical theorem using all those extra hypotheses. The exact continuation predicate remains necessary unless those stronger hypotheses are proved to imply it.

A useful state reduction: for a closed erosion seed J=E(D), its minimal raw representative D_min=N(J) is contained in D and has the same erosion. Monotonicity makes existence of an allowed suffix from some such D equivalent to existence from D_min, when the other cohort and remaining quota word are retained. This can eliminate the extra raw-set variable but not the suffix predicate itself.

## 4. Reverse clipping obstruction actually removed

Independently attacked and accepted even-reverse-cap-one-room-buffer.md. A failed even-width join has genuine reversed reference maximum at mostH−1 for ALL1<=d<=b−1. The actual activation seed has size at mostb². A first erosion exit aboveH would have original surplus at leastb, because both the small and co-small alternatives at lower surplus are excluded. Its target is at most G(previous)<=next-reference-MAX+1<=H, contradiction.

Thus the formerly uncovered reverse-cap band is removed without extending the ordinary theorem to arbitrary large actual states. Receipt odd-review-even-reverse-cap.json pins the exact source. This is genuine scope enlargement of a physical interface, not a claim that the full capture-time gap has vanished.

## 5. Full-word reversal: useful exact interface, insufficient automatic solo claim

At a pre-inspection cut, a winning word is equivalent to two actual full-origin prefix endpoints F,R with |F intersect R|<=k. The first prefix runs forward and the other backward. Complementary polarizations decrease overlap orbit by orbit, and independent last-full normalizations preserve their respective endpoints. This is proved in odd-full-word-reversal-splice.md with exact inspection/movement indices.

The advantage is that no arbitrary activation set is declared attainable. The unresolved issue is that a useful full-game splice normally occurs well beyond the ordinary boundary collar; exact prefix reachability there still includes a permanent mixed suffix.

The ordering of the two activation times is NOT supplied by these normalizations. A2-by4,k4 three-day sweep of complete column pairs0,1 then1,2 then2,3 is winning and fixed by either row-reflection polarization; both directions activate at time0, so no cut has two solo endpoints. This word is nonoptimal, and therefore does not refute an optimal/candidate-horizon exchange theorem. It does rule out a purely algebraic inference from the normalization operations alone.

## Current unresolved dependencies

* Exact or safely dominated activation suffix reachability, beyond the necessary raw cardinality and erosion corridor.
* Complete genuine front/corner transition exclusion in the common middle slack budget; root and candidate lanes own that work.
* If using the full-word alternative, a rectangle-specific optimal-horizon argument that reduces its two actual prefix endpoints to the compressed boundary/middle classes. A generic two-solo-prefix assertion is false on other Hall graphs and is not proved on rectangles.

No new fixed-width searches or expression simplification were performed. The only large computation is the complete finite arithmetic base required by the uniform tied-restart theorem.

## 6. Boundary attachment discriminant: split the true age at the critical root

The remaining common-corner/phase attachment suggested a specific alternative to the rejected final-span age bound. After the last subcritical zero-good event, every later subcritical target is B-bad, whereas a root-b target uses F. The actual age can therefore be long only in the final critical bin, whose area width is b-1. Preserve both pieces rather than charging all age to final gap.

The bounded diagnostic odd_boundary_ancestor_diagnostic.py uses the exact numerical upper envelope of a no-new-good continuation:

    T_ng(x)=F(x) if F(x)>L, otherwise B(x), clipped at H.

It starts only from genuine ordinary dangerous good seeds, with their true phase, root, raw defect and core. It stops once the envelope lies below both genuine reference coordinates. Every surviving endpoint in the head band is a necessary numerical possibility, not an attained physical history.

Across b in{32,48,64,96,128,192,256} and representative d spread throughout1..b-1, it found521 such endpoint candidates and no exhausted ancestor core. The smallest retained radius was35 at b32,d10. For d1 the true age can be b-1 even when final span is tiny: b128 has core252 and age127, retaining125. Thus the diagnostic reproduces the old age obstruction while suggesting the actual core still survives with room to attach an orientation.

This is evidence for pursuing a uniform retained-radius inequality using B mixing plus genuine critical-bin transit. It is NOT a proved bound, a new exact family, or a reason to replace the exact boundary recurrence by a guessed marker. A proof would need to control the ancestor's own gap and root, including histories which enter the critical bin and then retreat; the monotone envelope covers such retreats only as an upper bound.

## 7. Later in this pass: the activation predicate is now compressed exactly

The earlier unresolved predicate in Sections3 and5 has a new solution at the algorithmic-interface level. The even lane's even-mixed-suffix-two-clock-corridor.md extends the actual permanently mixed comparison to arbitrary nonnegative terminal gates. Genuine reverse-seed danger then forces a two-clock signed-mass corridor throughout its activated suffix. Every original surplus is at most2k-1, including the final step when the penultimate signed mass can be negative. Both cohort complements therefore have O(k) cutsets at every positive time.

I independently checked the generalized comparison, all V/W shifts, canonical seed replacement, and exact maximal-survivor transitions. Receipt odd-review-even-mixed-suffix-corridor.json records acceptance. This turns the actual activated predicate into an exact compressed finite graph in its genuine dangerous-seed domain. It does NOT yet prove that the graph has no faster-than-prefix join or improve the global numerical gap. Complete early/middle/late gate assembly remains required.

## 8. First-critical core attachment: analytic draft

The diagnostic in Section6 led to odd-first-critical-boundary-core.md. Before the first actual original-surplus-b target above L, all updates after the last ordinary good ancestor are B-bad, even if they already enter root b with larger original surplus. Hence age<=2e, not the much longer total collar age. The known e<=3r/4 bound and crude quota growth force the ancestor root r>b/4; small roots are separately excluded by the complete finite mixing guard. At b>=8192 a literal radius floor(b/16) core survives.

If that first critical target lies before/equal the early cut, its holes have area<=H and can themselves be classified. Any survivor-localized alternative is only the square/full-triangle equality, whose dual is explicitly localized. Literal pyramid fibers facing away from the inherited corner would force at leastb² cells, contradicting Q<=H. This attaches the first critical hole description to the true inherited corner.

If no such critical boundary shape occurs, the same calculation leaves a core at the dangerous endpoint itself. This is geometric information, not a classification of that endpoint or permission to assume its later orientation. The source is submitted to root for independent attack and remains a draft.

## 9. Square all-pairs orientation audited with repairs

The complete square middle has Delta<=ceil((2b-2)/d)+1<=b when d>=2. This allows applying geometry to every pair of classifiable critical moves. Signed dual-corner labels and edge labels are necessary; a co-localized survivor is not mislabeled as localized. Pairwise consistency and the elementary vertex/edge Helly property of the four-cycle yield a common interior corner.

Independent candidate review caught one real hidden use of consecutiveness in a frozen mixed barrier: r=b-1 had implied d=b-1 via r<=d. The new proof instead compares actual hole increase<=b+d-2 to the shared-credit lower bound d(b-2)+1, with strict difference(d-1)(b-3). Rigid target envelopes were also handled explicitly. The repaired source and acceptance are odd-square-label-interface-audit.md and candidate-review-square-labels.md/.json. A common interior corner still does not by itself attach both boundary phases, especially when all fronts share an edge with two possible corner endpoints.

## 10. Exact gate assembly independently accepted

The even lane has now joined early genuine reachability, actual middle cutsets, the unclipped reversed boundary and exact activated suffix into one physical signed-gate decision. I checked all actual colors, e/Delta/ell and r/a indices, literal late splice, minimal-cost reverse inspections and subset reconstruction. Receipt odd-review-even-exact-gate-assembly.json pins the source. This closes the earlier assembly obligation at the exact evaluator level. It does not prove all faster decisions false or turn arbitrary mixed signed gates into capture palindromes.

The strict collar strengthening is independently accepted in odd-review-even-strict-collar.json. Its sole possible reference loss is final and lowers the endpoint span, so one common loss budget remains strictly below d through both collars and the actual middle. The reverse collar remains a separate word.

Root proposed a valid new use of exact signed-gate clocks: if G(c) is the true minimum full-origin gate time, full-word reversal gives T_capture>=max_{0<=c<k}(G(c)+G(k-1-c)). For any alleged shorter capture, choose a splice with both prefix lengths below the corresponding G clocks; their signed masses sum to at least k+1, forcing more than k common rooms. This requires no mixed-endpoint palindrome. The exact general construction matching this lower convolution remains open.

## 11. General raw seeds and near-optimal capture prefixes

A new exact initializer removes the apparent restriction that the terminal quota must be at most k. For a raw set D of size at most z<=b² with z>=k, the numerical first-quota pair is literally the ordinary image of the tie(z-k,z-k). Choose artificial actual holes X subset D of size min(|D|,z-k), inspect D minus X, and the actual result is E(D). The arbitrary tied restart applies to this legitimate one-update history. Smaller z uses the already certified first-quota theorem. The complete source is odd-general-raw-seed-tied-initialization.md, independently accepted by the even lane.

Using this initializer, the even lane proved ordinary signed-late comparison for every terminal a in[0,H]. My independent receipt odd-review-even-arbitrary-terminal-late.json checks the genuine raw cap, first crossing of A, actual shifted index and final clipping. This supplies the exact comparison needed for actual late segments ending at their current signed mass.

The subsequent fixed-clock theorem is a larger advance than another corner-only phase exclusion. For every normalized gate-k prefix of length J(k) through J(k)+3, ALL original surpluses are bounded by13k-1. Early and late histories lie in four-clock corridors. The middle uses a double clamp, allowing actual retreats: its total loss is below4d, so excursions outside the clamp last at most four moves and have O(k) depth. Both cohorts at every positive time therefore have O(k) cutsets, even when activation occurs in the middle. I independently accepted the complete argument in odd-review-even-fixed-clock-corridor.json.

Root's exact capture cut uses two actual gate-k prefixes in precisely those four clock values, with their literal intersection tested. Combining the new all-state compression with this splice should give an exact exp(O(b log b)) capture evaluator on the remaining short even-width low-budget boards. The final state-graph assembly still requires review; no scalar gate palindrome is being inferred.

This redirected effort is justified by a correction to the geometric target: some faster-than-canonical P gates really exist, as the accepted long-board tilt transport attains J<P. Therefore an attempt to exclude every such gate would be mathematically wrong. A future geometric simplification must characterize which tilt changes are physically feasible, not assume canonical P is always optimal. The literal endpoint evaluator preserves that freedom.

## 12. Exact even capture assembly accepted; odd perimeter extension drafted

I independently accepted root-exact-low-budget-even-capture.md in odd-review-root-exact-even-capture.json. The literal graph may include extra physical paths; normalization is used only to prove that a true optimum has a witness among its bounded-cutset states. Two actual endpoints, their exact times and their intersection reconstruct the winning word. This establishes exact evaluation and an attaining word for every even width 2b with b>=32 and every low budget b<k<2b, including both length parities. It does not equate the old scalar clocks or supply the final direct closed strategy.

For odd width the constant-slack affine comparison fails over arbitrary length: the necessary affine rate d can exceed the guaranteed physical rate d-1, and the resulting loss grows with length. Rather than suppress that loss, odd-affine-slack-capture-compression.md keeps it explicitly as D=1+ceil((h-2H+d-2)/(d(d-1))). A single genuine physical update aligns both late phases; the following d-1 progress meets the actual forward phase. This proposes P<=J_aff+D and hence a 2D+2-clock window for the two optimal capture prefixes.

The all-state corridor argument is parity-free at even area. Rotating the matching array does incur the additive n/2-1 cutset term, which is retained explicitly. When d is a positive linear fraction of b, the resulting graph exponent is O((b+n)log(wn)), controlled by perimeter rather than area, for EVERY length. For n=O(b), it is O(b log b). This is potentially more useful than seeking a nonexistent all-high-d long-board exact theorem: the previously located odd long-board theorem still has its natural budget guard. The new draft is being independently attacked by the candidate lane (physical alignment and time accounting) and even lane (scope of the corridor and late comparison). No graph computation or publication claim is made.

The general raw-seed initializer also extends past k<2b: its core proof only needs k>=max(13,b+1), z<=b². The arbitrary-terminal late comparison then extends through k<=b² because A=b²-k+1 stays positive and its first-crossing raw size is exactly bounded by b². This extension does NOT use or extend the separate H-1 first-exit-buffer corollary, whose low-budget guards must be retained. The even lane is using this distinction for its higher-budget corridor.

## 13. Odd low-budget compression accepted; medium interval extended

The odd affine-slack theorem is independently accepted in candidate-review-odd-affine-capture.md/.json, with a separate even-lane parity receipt and an independent rotated-encoding derivation. The exact physical tail alignment uses the progressive pair plus scalar inflationarity; it does not incorrectly assume each fixed coordinate gains d-1 under a swapped update. Once both phases are at Y, their minimum gains at least d-1 per update. All stated ceilings and exact gate/capture indices were checked.

The scope has two distinct layers. The graph construction is exact throughout the displayed d>=2 low-budget family. Its structural compression is meaningful uniformly when d is a positive linear fraction of b, giving exponent O((b+n)log(wn)); at smaller d or moderate parameters K may cover the whole graph, so generic computability must not be counted as completing the full mathematical box. Existing natural-range exact strategies remain preferable where applicable.

I independently accepted even-medium-budget-ten-clock-extension.md at hash f3b88ef...100c0 in odd-review-even-medium-budget.json. New actual threshold z=b²-k+1, with z>k, provides early Q<=H and late Y<=b² cuts for every 2b<=k<=floor(b²/2). The middle clamp lower bound uses only its endpoint range, not a critical-shape classification. The genuine late span pays at most four extra physical updates at even width, producing a ten-clock optimal-prefix corridor. The proof explicitly permits excursions already underway at the first middle cut or still underway at the last cut.

Its odd-width corollary is odd-medium-budget-capture-compression.md. Replacing d by the physical d-1 minimum gain costs B=5+ceil((h-2b²+b)/(d(d-1))) extra updates. The same actual lower cuts and all-state corridor then yield s=2B+2, rotated cutsets and exact literal endpoint reconstruction. Since d>=k/2, sk=O(k+n), uniformly over all lengths. This is being independently reviewed; at quadratic budgets its state bound may again equal the area power set. No large graph run or publication was made.

The odd medium corollary is now independently accepted in candidate-review-odd-medium-capture.json, pinning fc821190f73c98ce1b8e02161a79a3da02b7ef12cf7f80934de95df415ac4ed1. The audit checked the physical d-1 bridge, exact s-clock window, rotated parity term, literal endpoint graph, and sk<=14k+16h/k. This is an ordinary proof acceptance, not a large graph execution or formal verification.

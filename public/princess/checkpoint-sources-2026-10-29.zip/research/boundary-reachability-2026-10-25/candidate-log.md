# Independent candidate lane, 25 October 2026

## Starting obstruction

The 24 October checkpoint excluded three of four mixed longitudinal
front/localized transitions, but not survivor front -> localized survivor
at the opposite end. Opposite-front/front transitions had only a transport
inequality. Literal boundary endpoint access was also unfinished.

## New history inequality and the last mixed direction

First tried exact reversal of the actual word. Exact reversal is unjustified:
N(H_next) can be a proper subset of H union I during an excess-surplus move.
The useful correction was to retain the missing allowed cells explicitly.
The reverse word Z_next=N(Z) minus I stays inside actual old holes. The
middle size guards force its own surplus at least b-1, which gives
eta_s<=sum(excess)+s. The bootstrap remains above (b-2)^2 because the
shared account has R+r<=2b-3.

This yields the general actual-set inequality in
`candidate-reversed-middle-deficit.md`. It does not need exact endpoint
duality. Applying it to the last mixed direction retains a localized
corner core and at most2b-3 missing cells from the actual old dual pyramid.
A matching-row tent estimate shows that any pyramid of size>L intersects
that same-end core in more than2b-3 cells for b>=128. Root independently
checked the proof. Source: `candidate-reversed-middle-front-corner.md`.

## Opposite-front transitions: a shorter argument supersedes this attack

Initially considered a space-time row-boundary charge, because static
endpoint transport can be vacuous when r is nearly b. Before pursuing it,
the actual erosion indexing revealed a simpler obstruction. The source
dual pyramid has area at least L+2, and only r-1 erosions occur before the
target inspection. At least three cells therefore remain. An opposite
target pyramid of size>L has at most two empty physical rows; a disjoint
same-end retained pyramid fits only in those rows and has area at most2.
This contradiction is uniform for b>=2, all lengths and low budgets under
the actual failed-join ledger. Root independently checked it.

Source: `candidate-opposite-longitudinal-front-exclusion.md`. The independent
primitive checker exhausted52,374 actual canonical pyramids, including
small b, and found no failure in D/N closure, complement orientation,
one-step area loss, or empty-row counts. This is diagnostic support for
the ordinary proof, not a width-by-width strategy classification.

## Complete independent arithmetic replay for boundary restart

Root reassigned this lane to the finite base in the odd lane's arbitrary-
tied-origin restart theorem. Built a genuinely separate C++ implementation
using sorted heap merging, integer root tables, and exact root intervals.
All78,874,764 reachable states and61,562,872 dangerous seeds passed; counts
match the author's implementation exactly. Minimum margin0, maximum common-
domination time20. Detailed coverage, proof boundary, hashes and commands
are in `candidate-tied-restart-arithmetic-review.md/.json`.

This accepts the complete finite arithmetic obligation only. Root and other
lanes own the separate analytic/physical restart and boundary-access proofs.

## Remaining limits

Longitudinal end consistency is now supported by the mixed and front/front
lemmas in the stated domains. It does not by itself provide an attainable
endpoint from a numerical capacity, classify transverse-axis rotations on
n=2b or2b+1, handle the last central equality target, or close small-width
interfaces below the mixed bound. On a square, a corner triangle may face
two adjacent edges simultaneously; assigning one free end label would
discard real geometry. Any transverse treatment must retain actual shapes
or an honest edge/corner incidence structure.

No earlier dated source, website, manuscript, or Lean source was changed.
No numerical-expression simplification was attempted. No process remains
running after the finite replay.

## Square all-pairs orientation and exact splice reviews

The total middle duration on a square is at most b when d>=2. Thus the
earlier pair barriers can control arbitrary critical pairs, not only
successive ones, but one hidden use of consecutiveness needed repair.
Frozen mixed barrier C used r=b-1 to infer d=b-1 from r<=d. Arbitrary pairs
do not satisfy that implication. The stronger actual starting hole bound
Q_source>=H-d+2 repairs it: the possible increase to localized holes is
at most b+d-2, while r=b-1 forces at least d(b-2)+1, larger by
(d-1)(b-3). The author incorporated this explicit repair before acceptance.

The square theorem now has independent ordinary acceptance in
`candidate-review-square-labels.md/.json`: for b>=128 and 2<=d<=b-1,
the actual signed singleton/edge labels of every classifiable interior
critical event share one physical corner. The review checks all actual
survivor/dual combinations, both square axes and rigid target exceptions.
This is not a boundary phase theorem. In particular an edge-only family
still admits two opposite-parity common corners, and d=1, the one-longer
rectangle, smaller b and the last equality target remain outside scope.

Also independently accepted the full-word reversal/splice interface in
`candidate-review-full-word-splice.md/.json`. Its cut is before one
inspection; opposite alternating polarizations cannot increase the
endpoint intersection, and independent last-full normalization preserves
both literal endpoints. The actual 2-by-4 counterexample correctly shows
that these operations alone do not imply simultaneous solo activation.
This exact physical interface is useful without claiming a compressed
evaluator or a new capture-time bound.

## Accepted exact activated mixed-suffix evaluator

Independently audited `even-mixed-suffix-two-clock-corridor.md` and saved
`candidate-review-mixed-suffix-corridor.md/.json`. The review derives the
arbitrary nonnegative terminal-gate comparison from the exact zero-clipped
reference and integer inverses, checks every shifted index in the strict
two-clock corridor, and covers the final update even when actual signed
mass is negative. Every original update then has surplus at most2k-1.

The canonical seed N(J) preserves the actual partner history; maximal
survivors give an exact transition test with minimal useful quota while
retaining nesting and activation properness. Both positive-time cohort
beliefs fit the literal cutset universe. The genuine seed bound also gives
r<=b^2-c, so the time layers are polynomial. The author added explicit
nesting and horizon statements before the hash-pinned acceptance.

Separately spot-checked the developing whole-gate assembly's new timing
and splice interfaces: exactly a-1 reverse edges reconstruct exactly a
solo updates; initial/final physical colors agree; G3 is exactly its
literal deficit/excess inequality. Its seed also fits the cutset universe:
activated danger and |D|<=min V_r imply |D|-|J|<=k-1, while the entirely
solo case gives at most k. Root owns the full assembly review and the
older universal cut-selection theorem. This note does not promote a
global capture-time result from an exact signed-gate evaluator.

## Gate values alone do not provide a compatible capture splice

Independently accepted the necessary gate convolution in
`candidate-gate-to-capture-review.json`: on a graph with a perfect
matching, T>=max_(0<=c<k)[G(c)+G(k-1-c)]. The cut is truncated at T-1
when necessary, and the zero-gate shift uses matching noncontraction.

For oppositely polarized folded endpoints F=(X,Y), R=(U,V), write
D=Q minus X and E=Q minus U, with signed masses f,g. The exact identity

    |F intersect R|=f+g+|D minus V|+|E minus Y|

shows the missing geometric condition. Gate masses alone do not cover
the two actual missing portions. A 3-by-4 budget5 example already has
a fastest gate-zero endpoint that cannot be paired with any reflected
self-copy, although other endpoints attain optimal capture. Endpoint
selection cannot be skipped.

A bounded diagnostic found a stronger connected nonrectangle obstruction:
the bipartite double cover of K(2,3) with one loop on the three-vertex
side, budget2. It has a perfect matching and a color-swapping involution,
yet G0=4, G1=3, capture8, while the gate convolution is7. The independent
13-state certificate lists every normalized transition and a decreasing
integer potential proving the lower bound; literal physical BFS agrees.
The source and reproducible receipt are
`candidate-connected-gate-obstruction.md` and
`candidate-connected-gate-review.json`. This is not a rectangle
counterexample; it identifies exactly why generic matching, nesting and
reflection do not suffice. The broad diagnostic was stopped once this
discriminator was obtained. No process remains running.

## Accepted compression of every near-optimal prefix and exact capture

The arbitrary-terminal late comparison and fixed-slack cutset theorem
passed independent ordinary review in
`candidate-review-fixed-clock-corridor.md/.json`. I rederived the total
two-cohort early crossing, the late last-crossing bound, and the universal
double-clamp inequality. All middle excursions use one shared loss R.
In particular a deep retreat below the lower wall is bounded by the
necessary return, not assumed absent. The late lower corridor retains
actual terminal masses, including negative ones, through the exact
arbitrary-terminal comparison. For s=4 every update of a relevant
normalized gate-k prefix has total original surplus at most13k-1.

This closes the intermediate-shape completeness obligation. The ordinary
exact endpoint and capture assembly passed a separate independent audit
in `candidate-review-exact-even-capture.md/.json`. For all
w=2b>=64, n>=2b, b+1<=k<=2b-1, a literal O(k)-cutset state graph contains
both normalized prefixes of some optimal capture word, each of length
J(k) through J(k)+3. Its erosion transitions are necessary and sufficient
physical updates. Exact-time reachability and the actual endpoint
intersection test reconstruct an optimal winning word.

The parent implementation-free theorem uses a larger graph without
normalization flags; this is safe because every extra path is a physical
strategy. Normalization is required only to prove that an optimal pair
of witnesses fits the cutset universe. The resulting family evaluator
has exp(O(b log b)) complexity in the previously unresolved short-board
range, versus unrestricted exp(Theta(b^2)) subset search. Constants can
be huge and no new large board has been evaluated. This is an exact
optimization/reconstruction theorem, not equality of the old scalar
bounds, not direct inspections specified from parameters, and not an
O(1)-operation formula. No new Lean or public artifact claim is made.

## Rotated geometry and extension audits

Re-derived the exact cutset encoding with either board axis used for the
perfect matching. No aspect-ratio assumption occurs in the physical map
or row-charge proof. For odd width w=2b+1 and even length n=2ell, the
literal ell-by-w array has cut bound 6 sigma+ell-1. The additive term is
O(n), rather than O(b), and must be retained. The source and receipt are
`candidate-rotated-cutset-encoding.md` and
`candidate-rotated-cutset-review.json`. A separate coordinate-only finite
diagnostic checked 39,448 supports across 34 color/shape cases, including
both aspect orders, without importing the authoritative array model.
All map, row-charge, cut-bound and injectivity checks passed.

Accepted the odd-width affine-slack capture theorem in
`candidate-review-odd-affine-capture.md/.json`. Its one-step physical
alignment uses scalar inflationarity AND progression of the swapped
pair; subsequent minimum growth d-1 pays its explicit slack D. The
result keeps all lengths and has the perimeter exponent in the stated
high-excess range. The correct asymptotic slack is O(1+n/b), not
O(1+n/b^2), since h is of order bn. The exact general-s proof keeps the
larger exponent for smaller excess. The review does not silently identify
the weaker affine clock with the older stronger pronic evaluator.

Accepted the medium-budget even-width extension in
`candidate-review-medium-budget-capture.md/.json`: 2b<=k<=floor(b^2/2),
b>=32, all n>=2b. The new cutoff z=b^2-k+1 exceeds k and supports the
actual early and late comparisons. The double-clamp argument survives
U-d<=L, and the new middle cuts may lie outside the clamps. Entry/return
with generic physical growth<=k controls these endpoint excursions.
One wording correction was necessary before acceptance: the swapped
physical pair's MINIMUM gains d, not necessarily each coordinate relative
to itself. Its four-update construction allowance and ten-clock exact
endpoint evaluator then follow with every original surplus<=31k-1.

These remain exact finite-optimization and reconstruction results with
precise domains and complexity bounds. They do not evaluate the old
scalar bracket uniformly, specify direct optimal inspections from the
parameters, or meet the final O(1)-operation criterion. No large graph
execution, public edit, new Lean theorem, or expression simplification
was performed in this extension audit.

## Odd medium budgets and a simpler whole-word high-budget invariant

Accepted the odd-width medium-budget corollary in
`candidate-review-odd-medium-capture.json`. Its physical middle speed
is d-1; the displayed extra ceiling pays exactly that denominator change.
The bound sk<=14k+16h/k gives O(k+n) cut complexity over its entire
medium interval, with explicit degeneration near quadratic budgets.

Root then proposed bounding total surplus along each gate-k prefix. I
independently verified that proposal and found a stronger simplification
using a COMPLETE winning word. Append the harmless move after its final
empty survivor. Actual belief size telescopes from2h to0, yielding

    sum ORIGINAL survivor surpluses
      =sum useful inspections-2h <=Tk-2h.

Every optimal intermediate target consequently has dual surplus at most
C=Uk-2h for any known physical capture upper bound U. The literal cutset
graph can now run directly from full uncertainty to empty belief within
U updates. No gate lower clock, split, polarization, normalization,
reversal, or endpoint intersection is needed for this high-budget theorem.
The stronger low-budget results still need their local corridor arguments.

The clean source is `candidate-whole-word-surplus-capture.md`. With the
authoritative global physical backward prefix cap B=ceil(w/2), one has
U=2ceil((h-k)/(k-B))+2 for B<k<h, and

    C<=2hB/(k-B)+2k.

For b=floor(w/2)>=32 and k>b^2/2 this is at most5n+2k. The source gives
the elementary constant check and cites the exact physical maps in
the manuscript. Independent review corrected two wording hazards before
pinning: growth applies to the swapped pair's MINIMUM, and the direct
two-day strategy for h<=k<2h inspects the SAME physical color on both
days. This is not a new all-rectangle closed formula: graph evaluation
and strategy reconstruction remain necessary, and the cutset universe
may be the full power set at quadratic budgets on short boards.

# A controlled reverse history and a general overlap inequality

25 October 2026. Extracted ordinary lemma. Its proof is the surplus bootstrap
in `candidate-reversed-middle-front-corner.md`, without the pyramid or
localized endpoint specializations. Submitted for independent review.

On a 2b-by-n board, n>=2b, put L=(b-1)^2, H=b(b-1), h=bn. Consider a real
one-cohort subword with post-inspection survivors S_t, useful inspections
I_t of size i_t, actual holes H_t, and survivor surplus sigma_t. Assume
through the relevant interval that

    |H_t|>=L+1,  h-|H_t|>H,  sigma_t>=b.

Let l=j+r with r>=1, and write

    E0=sum_(t=j+1)^l (sigma_t-b).

Suppose E0+r<=2b-3. Define the literal reverse post-inspection word

    Z_0=H_(l+1),
    Z_(s+1)=N(Z_s) minus I_(l-s), 0<=s<r.

Then

    Z_s subset H_(l+1-s),
    eta_s:=|H_(l+1-s) minus Z_s|
       <= s + sum_(t=l-s+1)^l (sigma_t-b).          (1)

The word is physically valid with the same daily budget as the original.
It is a conditional word from the stated literal initial set, not a new
full-origin strategy. It can omit actual holes at its endpoint; (1) retains
the entire bound on that omission instead of assuming exact reversal.

## Proof

Symmetry of adjacency gives N(H_(t+1)) subset H_t union I_t. Since I_t
is useful it is disjoint from H_t. Thus the first inclusion in (1)
propagates. Under the induction hypothesis and E0+r<=2b-3,

    |Z_s|>=L+1-(E0+s)>=(b-2)^2+1,
    h-|Z_s|>=h-|H_(l+1-s)|>H.

Small/co-small separation forces sigma(Z_s)>=b-1. For t=l-s, use
Q_(t+1)=Q_t+i_t-sigma_t and removal of at most i_t cells from N(Z_s):

    eta_(s+1)<=eta_s+sigma_t-sigma(Z_s)
              <=eta_s+(sigma_t-b)+1.

This closes the induction from eta_0=0. Notice that surplus of the
CURRENT Z_s is bounded before deriving eta_(s+1); no future estimate is
assumed in this bootstrap.

## Uniform geometric consequence

Write E(X) for physical graph erosion into the opposite color. The first
reverse pre-inspection holes contain S_l, since N(H_(l+1)) is disjoint
from S_l. Reverse inspections only add holes. Thus after r-1 subsequent
updates the final reverse holes contain E^(r-1)(S_l). Combining with (1)
gives the necessary actual-set inequality

    |H_(j+1) intersect E^(r-1)(S_l)| <= E0+r.       (2)

No endpoint equality N(H_(l+1))=V minus S_l is needed: ordinary dual
inclusion suffices. Exact critical duality is useful only when the endpoint
sets are subsequently identified as particular actual pyramids or cores.

For a genuine failed-join middle and consecutive critical moves,
E0<=R and r<=R+1<=d<=b-1, so E0+r<=R+r<=2b-3. Formula (2) is then a
uniform necessary history inequality with all geometric information and
the one shared credit retained. It does not claim that the bound is sharp
or that every pair satisfying it has a real middle word.

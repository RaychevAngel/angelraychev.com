# An ordinary boundary restart from an arbitrary physical shape

25 October 2026. **Candidate theorem for independent physical and arithmetic review.** The new assertion is a genuinely arbitrary physical starting shape with a TIED numerical seed. It is not the previously proved genuine-origin or shifted-first-quota theorem. No result is promoted merely from the successful arithmetic run below.

## Theorem R: arbitrary shape, tied numerical origin

Let w<=n have even area, w>=2, b=floor(w/2), H=b(b-1), and k>=max(13,b+1). Start with ANY two-cohort physical belief, whose total holes number q0 in [0,H]. Inspect at most k rooms per day with arbitrary subsequent choices and retreats. Assume every actual hole count through the time under consideration is at most H.

Set

    R0=(q0,q0),
    R_(t+1)=(G(R_t[1]), F(R_t[0])),
    G(x)=x+k-rho(x+k),
    F(x)=x+k-ceil_sqrt(x+k),
    B(x)=G(x-1).

Then the proposed conclusion is

    Q_t <= max R_t.

At every positive-time zero-good target, meaning original total survivor surplus r=ceil_sqrt(Q_t) with 4<=r<=b-1, the target's ACTUAL dominant cohort/corner phase p obeys Q_t<=R_t[p]. No initial corner, cohort, core, or attainability of q0 by an earlier full-origin word is assumed.

## 1. Numerical properties valid for every tied origin

Because q0<=H<k(k-1), the ordinary invariant interval applies. F and G are nondecreasing, 1-Lipschitz and inflationary there, and satisfy

    F(x)<=G(x)<=F(x)+1,   G(x-1)<=F(x).

The first pair dominates its tie seed. Monotone iteration therefore makes each coordinate nondecreasing. Inflationarity gives global interlacing

    min R_(t+1)>=max R_t.

The usual oriented-gap induction starts with span0, giving span R_t<=ceil(t/2). Also R_t dominates the ordinary zero-origin pair at the SAME elapsed time. None of these claims assumes an initial physical marker.

At a dangerous zero-good target q, put r=ceil_sqrt(q), e=q-min R_u. Interlacing implies max R_u<=G(min R_u), so e<=k-r by exact inversion. While min R_j<r², its drift is at least

    v=k-ceil_sqrt(r²-1+k).

Since it starts at q0>=0, u*v<r²-q0<=r² whenever v>0. Together with e<=ceil(u/2), the calculation in the frozen `lower-zero-good-mixing-large-roots.md` proves e<=3r/4 for r>=20, with NO zero-origin hypothesis. The raw-core bound Rcore-1>=2r-4-4sqrt(r)>=3r/2 therefore pays the two-bad-step mixing for every r>=100.

The two-step mixing identity itself is valid for ANY reference pair obeying the update:

    B²(x)<=min H_k²(x-1,x-1),
    B^(2e)(q)<=min R_(u+2e).

Thus the large-root part of the new restart theorem is analytic and uniform.

## 2. Complete finite arithmetic obligation for roots4..99

A dangerous positive-time seed has min R_u<q<=r². Since R_u>=R_1>=(k-ceil_sqrt(k),k-ceil_sqrt(k)), necessarily

    13<=k<=r²+r<=9900.

For fixed k, put cap=min(9801,(k-2)²). A tied origin q0>=cap has no such dangerous future. For every integer 0<=q0<cap, generate its first ordinary image, then close the resulting pair set under the ordinary update while the minimum is below cap. Duplicate pair states can be merged because the desired mixing assertion depends only on the pair, budget, phase and target, not on which tied origin reaches it or its elapsed time. Monotonicity makes all omitted later states vacuous.

For every retained pair (x0,x1), each phase p, and every integer

    x_(1-p)<q<=min(x_p,cap),
    4<=r=ceil_sqrt(q)<=min(99,k-2),
    q<=r(r-p),

use the exact physical minimum raw core

    core=2r-2-p-2mtri(r(r-p)-q),

also taking the minimum with 2r-4 if p0 and q=(r-1)²+1. Verify by direct integer iteration that

    B^(core-1)(q)<=min H_k^(core-1)(x0,x1).

The executable checker `odd_tied_seed_mixing.cpp` completed this ENTIRE finite parameter domain, with exact integer corrections to every square/pronic/triangular root:

    78,874,764 reachable ordinary pair states;
    61,562,872 dangerous phase/target seeds;
    zero failed mixing inequalities;
    minimum core-time margin 0.

Its output is `odd-tied-seed-mixing-result.txt`. This is a finite arithmetic base for a uniform theorem, not a sample of widths, boards or physical strategies. A separate independent implementation/review remains required before acceptance.

## 3. Physical initialization and induction

At time0 the actual total q0 is below BOTH tied coordinates. No shape assumption is needed. Before the first good event, each nontrivial subcritical nongood step obeys B and each critical-root target obeys F, exactly as in the frozen ordinary boundary theorem. Either map is bounded by both appropriate incoming branches when the source is below both coordinates. Tiny targets are also below both, since min R_1>=k-ceil_sqrt(k)>=9.

The first good target therefore uses its own ACTUAL incoming phase and is controlled in that coordinate. Its original-surplus concentration and raw core are physical facts of that target, independent of the initial shape.

Between subsequent consecutive good events, the frozen proof applies verbatim:

* the same cohort/corner follows its actual alternating phase;
* a different cohort/corner cannot occur before the actual previous core erodes;
* the analytic/finite mixing guard puts the count below BOTH phases before such a change;
* tiny targets reset both coordinates;
* a critical-root target with Q>(b-1)² preserves MAX via F, and interlacing places both reference coordinates above (b-1)² on the following day, so all later subcritical targets are trivially controlled.

The initial arbitrary physical set is never assigned a core or a canonical endpoint. Only positive-time good targets are assigned the cores supplied by their actual original-surplus theorem. This proves Theorem R conditional on independent acceptance of the stated finite arithmetic base.

## 4. Consequence: a full boundary history stays in a one-clock corridor

Let E_j be any genuine ordinary early/first-quota/shifted reference pair, obeying the same update and interlacing. Consider an actual boundary word Q_0,...,Q_e, all at most H, for which the accepted comparison gives Q_j<=max E_j and whose final state is DANGEROUS:

    Q_e>min E_e.

For every 1<=j<=e, Theorem R implies

    Q_j>min E_(j-1).                                  (R1)

Indeed if Q_j<=min E_(j-1), restart the actual future word at Q_j with numerical tie(Q_j,Q_j). Its upper pair after e-j moves is coordinatewise at most E_(e-1). Therefore Q_e<=max E_(e-1)<=min E_e, a contradiction. This is a restart comparison of the same actual future word. It does not bound the age of a last-good ancestor or assume that a low deficit cannot contract at root walls.

For each genuine move j, original total surplus satisfies

    sigma_j <=Q_(j-1)+k-Q_j
             <=k+span E_(j-1)-1<=2k-1.             (R2)

Here the last bound follows from interlacing and max E_t<=G(min E_t)<=min E_t+k; at a genuine initial seed the span is at most1. Every actual one-color dual hole surplus is no larger than the original total surplus. Thus EVERY intermediate hole set in such a dangerous boundary word, not just its final endpoint, has surplus at most2k-1 and admits the accepted O(k)-cut-edge representation.

The exact endpoint-reachability and shifted-seed constructions using(R1)--(R2) are delegated to the even lane. This note does not silently extend the restart theorem beyond Q<=H, beyond its numerical interval, to an arbitrary unequal seed, or to a freely chosen physical partial-state phase.

## Research significance and limits

If independently accepted, this repairs the specific missing boundary-access interface in the compressed middle evaluator: arbitrary early/reversed shapes cannot hide in an unbounded-surplus prefix that later reaches a dangerous endpoint at its genuine clock. It is stronger than a bound only on last-good ancestors and uses a different invariant. Whether the resulting joined evaluator can remove every full-board gap still depends on actual late-cap/activation and middle interfaces; those are not assumed here. No Lean or public artifact is changed.

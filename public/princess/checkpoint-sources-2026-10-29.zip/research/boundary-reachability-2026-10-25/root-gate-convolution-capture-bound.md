# All-budget-split lower bound from actual signed-gate times

25 October 2026. Ordinary proof, independently challenged by the odd and
candidate lanes. This is a capture lower bound, not a claim that arbitrary
mixed gate endpoints admit a matching palindrome construction.

Let an undirected bipartite graph have a perfect matching and 2h vertices.
Use constant daily budget 1<=k<h and full initial uncertainty. Rectangles
of even area meet these hypotheses. For an integer c>=0, let G(c) be the
least number of unsuccessful inspection-and-movement updates after which
the actual full-origin belief B has signed mass |B|-h<=c. Infinity is
allowed. G is an actual physical minimum, not a numerical capacity bound.

If T is the minimum number of inspection days guaranteeing capture, then

    T >= max_(0<=c<k) [G(c)+G(k-1-c)].                 (1)

The same lower bound remains valid with any proved lower evaluators in
place of either G. It must be combined by maximum with earlier necessary
bounds; no claim that it dominates all earlier bounds is needed.

## Exact inspection-cut argument

Suppose a winning word has T days, and fix c. Put A=G(c),
B=G(k-1-c). Both are positive because initial signed mass h exceeds k.
First suppose they are finite. If T<=A+B-1, choose

    a=min(A-1,T-1),     b=T-1-a.

Then a,b>=0, a<A, b<B, and a+b=T-1. Let F be the actual belief after
the first a updates. Let R be the actual belief from full uncertainty
using the last b inspection sets in reverse order. Both are at the same
pre-inspection cut of the original word. Minimality of the gate clocks
implies

    |F|-h >= c+1,    |R|-h >= k-c.

Therefore |F intersect R|>=|F|+|R|-2h>=k+1. The middle inspection has
at most k rooms, so the exact reversal/splice lemma supplies an evading
walk. This contradicts capture and proves (1). If a gate clock is infinite,
the same argument works at any finite proposed horizon by replacing that
clock by an arbitrarily large finite lower bound.

There is no assumption that F or R is solo, that a gate endpoint is a
canonical corner, or that cardinalities determine their intersection.

## Zero-gate relation: the direction actually proved

The perfect matching gives |N(S)|>=|S| for every survivor set S. Thus
signed mass decreases by at most k in any actual update. A word first
reaching gate zero at update r has mass at most k just before that last
update. Consequently

    G(0) >= G(k)+1.                                  (2)

Here G(0)>=1 because h>0. The reverse inequality does NOT follow:
a mixed endpoint with signed mass <=k can still contain more than k
actual rooms. An extra inspection does not automatically reach mass zero.

Using c=0 in (1) together with monotonicity and (2) recovers
T>=2G(k)+1. For odd k, c=(k-1)/2 also gives
T>=2G(floor(k/2)). For even k the split around k-1 is asymmetric;
retain the separately proved symmetric final-inspection bound rather
than infer it from this convolution alone.

## Relation to the new exact gate evaluator

The exact cutset assembly evaluates G(c) for 0<=c<=k on the stated
even-width low-budget range, using the known attainable P(c) as fallback
and deciding every smaller horizon. Substitution into (1) therefore gives
a concrete stronger candidate necessary evaluator there, without a new
physical-game assumption. It uses k budget splits and is not an O(1)
numerical expression. No full evaluation at a previously unresolved
rectangle, nor a smaller uniform gap ceiling, is claimed in this note.

The general sufficient condition is still the literal one:
two actual prefix endpoints can be spliced if their intersection has at
most k rooms. Their signed mass sum is only a lower bound on this
intersection. Proving equality of the relevant lower and constructive
upper bounds remains the capture problem.

# Exact literal endpoints for every four-clock even gate prefix

25 October 2026. Proposed consequence of the independently reviewed
fixed-clock cutset corridor. This is a physically exact endpoint evaluator,
not merely a signed-value evaluator or a proposed canonical-shape rule.

Keep w=2b, n>=2b, b>=32, k=b+d, 1<=d<=b-1 and the genuine scalar lower
clock J=J(k) from `even-fixed-clock-slack-cutset-corridor.md`. Set

    C=13k-1,
    K=6C+(b-1)*1_[n odd].

For every t in{J,J+1,J+2,J+3}, the recurrence below returns EXACTLY the
literal terminal belief pairs of normalized, full-origin, t-update words
whose signed terminal mass is at most k. A predecessor chain supplies the
inspection sets. The literal endpoints, rather than only their masses,
are available for a subsequent forward/reversed-suffix capture test.

## 1. Literal states, colors and normalization

Let V_p be physical color class p. For each p enumerate the exact universe
U_p of one-color sets whose dual surplus is at most C, using the accepted
matching-array cutset encoding with at most K internal cut edges and a
base bit. Reconstruct actual membership and reject inconsistent cut bits
or surplus>C. Thus U_p is finite and contains every needed positive-time
cohort hole set by the fixed-clock theorem. It also contains the empty set.

Track initial cohorts i=0,1. At time j, cohort i occupies physical color
i+j mod2. A state stores literal hole sets X_i in those respective colors;
its beliefs are B_i=V_(i+j mod2) minus X_i. A fixed color-exchanging board
reflection tau is retained, as in the accepted polarization theorem.
For either choice mu of permanently smaller initial cohort, impose

    B_mu subset tau(B_(1-mu)).

Also store whether activation has occurred. Before activation the larger
belief is full. After activation it is proper at every subsequent time.
Equivalently, a source with proper larger belief may never have a full
larger target; a source with full larger belief may either remain full or
have its first proper target. This is exactly the last-full normalized
class used in the corridor theorem. It does not impose a shape on either
cohort, a bound on activation time, or monotonicity of either mass.

At j=0 the only hole pair is (empty,empty), and activation has not occurred.
Repeat the recurrence for each of the two choices of mu; the same fixed
reflection can be used throughout each run. If another polarization
convention is required by a later splice, run that explicitly fixed
convention as well rather than silently changing a state label.

## 2. Exact edge test and reconstruction

Given literal source X_i and proposed opposite-color target Y_i, define

    I_i=N(Y_i) minus X_i.

This cohort transition is physically exact if and only if

    Erosion(X_i union N(Y_i))=Y_i.                 (E1)

The total useful inspection cost is

    |I_0|+|I_1|<=k.                               (E2)

Keep the edge precisely when both (E1) identities, (E2), the target
cutset memberships, nesting, and the activation flags hold. The two I_i
lie in distinct physical colors, so their sizes add without overlap.

Necessity of (E1)--(E2) follows from N(Y_i) being contained in the actual
raw holes X_i union I_i^old. Taking the minimal raw enlargement preserves
the exact erosion image. Conversely, inspect exactly I_0 union I_1;
then (E1) gives exactly the prescribed next pair. Hence every accepted
edge has an explicit physical inspection and every real edge between
stored literal states is retained with no larger daily quota.

The flag test also preserves the relevant post-inspection properness at
activation. If the next larger belief is proper, a full larger survivor
is impossible because N(full)=full. Later the proper source belief already
forces a proper survivor. Before activation, any inspection of the full
partner which creates no holes may be omitted; the minimal edge rule does
so automatically. Thus this edge minimization does not introduce a false
normalization class.

## 3. Layers and terminal extraction

Construct reachable layers through time J+3 by the exact edges. At each
requested time t retain those states satisfying

    |B_0|+|B_1|-h<=k.                              (E3)

No early/late cut is selected by the implementation. No reference phase,
scalar endpoint slack, or activation cardinality proxy replaces the
literal state tests. Cuts and four-clock corridors occur only in the
completeness proof that makes the state universe small enough.

Soundness is immediate by following the stored physical inspections:
every returned state is attained from full uncertainty in exactly t moves
and satisfies (E3). For completeness, take any normalized full-origin word
of that length reaching (E3). Its time is in[J,J+3], so the accepted
fixed-clock theorem bounds every original surplus by C. Every positive-
time target cohort hole set therefore has dual surplus<=C and lies in
the enumerated universe. Its real transition is retained by (E1)--(E2),
with the same nesting and last-full flags. Induction over its actual
history places its EXACT terminal pair in the requested layer.

The recurrence can include additional reachable states at intermediate
times which never occur on a terminal near-optimal gate word. This does
not affect exactness: they are still actual physical states, and only
actual terminal pairs satisfying (E3) are returned. Necessity uses the
corridor only for the paths which must be present.

## 4. Complexity and remaining capture assembly

The matching graph has M=b(n-1)+(b-1)n edges. One cohort universe has at
most 2 sum_(r<=min(K,M)) binom(M,r) descriptions; two-cohort states and
pairs of consecutive states multiply a fixed number of such factors.
Literal tests are polynomial in board size, and the horizon is J+3.
Consequently a direct implementation takes

    (J+4) * exp(O(k log(wn)))

time, with the same exponential factor in memory if every predecessor is
retained. For k<2b and n=O(b), this is exp(O(b log b)). The constants in
the exponent are not claimed small. This is a structural reduction from
arbitrary subsets, not evidence that a large-width enumeration is cheap.
No large enumeration has been launched.

The result returns actual endpoint families, so the separate exact
full-word reversal test can check their intersections at a central
inspection. The parent capture assembly must still show that every
candidate optimal capture word has BOTH normalized prefix lengths among
the four retained clocks and that complementary polarizations preserve
the required endpoint intersection. Those are separate physical inputs;
this note does not substitute gate mass for the intersection condition.

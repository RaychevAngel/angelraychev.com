# Any bounded raw erosion seed embeds in a tied restart

25 October 2026. New ordinary interface, submitted for independent review. This is an exact physical initialization argument, not a new assertion about an arbitrary seed's favorable phase, capture time, or expression complexity.

Let w=2b, n>=2b, b>=32, k=b+d, 1<=d<=b-1 and H=b(b-1). Use

    G(x)=x+k-rho(x+k), F(x)=x+k-ceil_sqrt(x+k),
    R(x0,x1)=(G(x1),F(x0)).

Let D be any actual one-color set with |D|<=z<=b², and J=E(D) its literal erosion. Define

    I(z)=(z-rho(z), z-ceil_sqrt(z)).

For every actual subsequent erosion word whose hole counts stay at most H, its count after t further updates is at most

    max R^t(I(z)).                                  (I1)

The physical colors are retained; (I1) is a maximum comparison. It does not assert a freely chosen matching phase or shape.

## 1. The case z>=k is one artificial physical move from an allowed tie

Set q0=z-k>=0. Since z<=b²,

    q0<=b²-k=H-d<=H.

Choose an actual subset X of D with |X|=min(|D|,q0). Regard X as a one-color initial hole set with the other cohort full. This is an arbitrary physical initial state, explicitly allowed by the accepted tied-restart theorem. Inspect exactly D minus X. Its size is at most k, since either X=D or

    |D minus X|=|D|-q0<=z-(z-k)=k.

The resulting literal hole set is E(D)=J. Append the given actual continuation. The numerical pair starting tied at |X| is dominated by the pair tied at q0. After the first update the latter pair is exactly

    R(q0,q0)=(z-rho(z),z-ceil_sqrt(z))=I(z).

The accepted arbitrary tied-origin theorem and monotonicity now give (I1). The artificial initial state and its first update satisfy the same H cap: |X|<=H and the accepted square one-shot bound gives

    |J|<=z-rho(z)<=b²-b=H.

Only the subsequent real counts need the stated cap premise. No earlier attainability of X from full uncertainty is claimed or needed.

## 2. The case z<k uses the already reviewed true first quota

Here the actual raw set D can be inspected from the empty hole state with first quota at most z. The accepted first-quota theorem initializes the exact pair I(z), including its tiny-seed exception, and proves (I1) along actual continuations staying at most H. This is precisely its original domain 0<=z<=k; no new arithmetic case is introduced.

## 3. Arbitrary terminal quotas and genuine shifted indices

Let a>=0 and form the ordinary backward pair

    V_0^a=(a,a),
    V_(j+1)^a=(k+V_j^a[1]-rho(V_j^a[1]),
                k+V_j^a[0]-ceil_sqrt(V_j^a[0])),
    W_j^a=V_(j+1)^a-(k,k).

Suppose an actual shifted raw seed obeys

    |D|<=z=min V_r^a<=b².

Then I(z)<=W_r^a coordinatewise, by monotonicity of x-rho(x) and x-ceil_sqrt(x). Applying (I1) gives, after t actual continuation updates,

    |J_t|<=max W_(r+t)^a,                           (I2)

as long as all these actual counts stay at most H. Thus arbitrary terminal a does not require extending the old finite first-quota arithmetic beyond a<=k: large raw quotas are images of nonnegative tied origins, and smaller raw quotas already lie in the old domain.

If the terminal genuine reference maximum is at most H-1, the reviewed first-exit proof from even-reverse-cap-one-room-buffer.md applies verbatim. It uses only (I2) before the first exit, the scalar relation G<=F+1, and the actual raw count bound. Consequently the entire real continuation stays at most H and (I2) is unconditional on those later counts in that buffered range.

## Limits

The endpoint bound |D|<=min V_r^a<=b² must come from the actual terminal or mixed suffix under investigation; it is not granted automatically for an arbitrary word. Without the reference H-1 buffer, extending the actual continuation past H remains a separate question. This lemma alone does not establish a global signed-late inequality for every terminal a, compressed full-capture evaluation, or a smaller universal capture-time gap.

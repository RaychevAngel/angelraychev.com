"""Small independent literal graph BFS; no geometric or numerical relaxation."""
from collections import deque
from itertools import combinations
import json


def evaluate(adj, k):
    n = len(adj)
    h = n // 2
    full = (1 << n) - 1
    nb = [0] * (1 << n)
    for s in range(1, 1 << n):
        bit = s & -s
        nb[s] = nb[s ^ bit] | adj[bit.bit_length() - 1]
    dist = {full: 0}
    q = deque([full])
    gates = [None] * k
    capture = None
    edges = 0
    while q:
        b = q.popleft()
        t = dist[b]
        mass = b.bit_count() - h
        for c in range(k):
            if mass <= c and gates[c] is None:
                gates[c] = t
        if b.bit_count() <= k:
            capture = t + 1
            break
        bits = [i for i in range(n) if b >> i & 1]
        for inspected in combinations(bits, k):
            s = b ^ sum(1 << i for i in inspected)
            target = nb[s]
            edges += 1
            if target not in dist:
                dist[target] = t + 1
                q.append(target)
    lower = None if any(g is None for g in gates) else max(
        gates[c] + gates[k - 1 - c] for c in range(k))
    return dict(capture=capture, gates=gates, lower=lower,
                visited=len(dist), transitions=edges)


def from_edges(n, edges):
    adj = [0] * n
    for u, v in edges:
        adj[u] |= 1 << v
        adj[v] |= 1 << u
    return adj


results = []
edges = [(i, i + 1) for i in range(5)] + [(6, 7), (8, 9), (10, 11)]
results.append(dict(name="P6 plus three disjoint matching edges", edges=edges,
                    budget=1, **evaluate(from_edges(12, edges), 1)))

# Symmetric adjacency matrix with diagonal ones gives a connected bipartite
# double cover, a fixed color-swapping involution, and a specified perfect
# matching. This is a bounded abstract discriminator, not a rectangle search.
for h in range(2, 5):
    pairs = list(combinations(range(h), 2))
    for mask in range(1 << len(pairs)):
        folded = [(i, i) for i in range(h)] + [pair for j, pair in enumerate(pairs) if mask >> j & 1]
        ed = [(i, h+i) for i in range(h)]
        for i, j in folded[h:]:
            ed += [(i, h+j), (j, h+i)]
        adj = from_edges(2*h, ed)
        seen = {0}
        todo = [0]
        for v in todo:
            for u in range(2*h):
                if adj[v] >> u & 1 and u not in seen:
                    seen.add(u); todo.append(u)
        if len(seen) != 2*h:
            continue
        for k in range(1, h):
            r = evaluate(adj, k)
            if r["lower"] is not None and r["capture"] != r["lower"]:
                results.append(dict(name="connected symmetric matched double cover", folded=folded,
                                    edges=ed, budget=k, **r))

print(json.dumps(results, indent=2))

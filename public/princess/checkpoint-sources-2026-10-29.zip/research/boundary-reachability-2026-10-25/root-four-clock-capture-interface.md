# Capture reduces to two gate-k prefixes within four clock values

25 October 2026. Exact ordinary interface. The final cutset-compression
claim is explicitly separated from the proved cut and time bounds.

Consider an even-area rectangle of area 2h, budget 1<=k<h. Suppose A is
a proved lower bound for the actual full-origin signed gate-k time, and
a physical construction captures in at most 2A+4 inspection days.
The accepted low-budget even-width bounds have these properties with
A=J(k), w=2b, b>=32, n>=2b, k=b+d, 1<=d<=b-1.

Every optimal capture word has an exact splice representation by two
actual full-origin prefixes of lengths a,b satisfying

    A<=a,b<=A+3,   a+b=T-1,                         (1)

whose endpoints both have signed mass at most k, and whose literal
intersection has at most k rooms. They can be chosen oppositely polarized
and separately last-full-normalized. Their mixed endpoints are retained;
this assertion does not turn either endpoint into a solo state.

## Proof

Follow an optimal winning T-day word, T<=2A+4. Let j be the first
pre-inspection time at which its signed mass is at most k. Initially it
is h>k. Just before the final capture inspection its total belief has
size at most k, so this crossing exists with 1<=j<=T-1.

A perfect matching ensures neighborhood noncontraction, so each update
decreases signed mass by at most k. The preceding mass was greater than
k; therefore the actual mass m at time j obeys 1<=m<=k. The forward
prefix has reached gate k, giving j>=A.

The exact reversal/splice lemma bounds the intersection between this
forward endpoint F and the reversed-suffix endpoint R by k. Inclusion-
exclusion gives

    (|F|-h)+(|R|-h)<=|F intersect R|<=k.

Thus |R|-h<=k-m<=k-1. The reversed suffix, of length T-1-j, has also
reached gate k and hence has length at least A. Setting a=j and
b=T-1-j proves both upper bounds A+3 in (1).

Opposite alternating polarizations cannot increase endpoint intersection.
Last-full normalization can then be applied to each prefix, including
its endpoint. It preserves that endpoint and its elapsed time. Both
prefixes still satisfy the gate-k upper condition; the forward one need
not retain its original first-crossing property after these changes.
This property was used only to prove (1), not assumed of the transformed
words.

## Exact endpoint decision and the remaining compression obligation

Let R_t^p be the family of ACTUAL full-origin gate-k endpoints reachable
at precisely t updates by a last-full-normalized word, with favored
polarization p at its endpoint. An exact capture decision in the known
interval is

    exists a,b in[A,A+3], a+b=T-1,
           F in R_a^0, R in R_b^1, |F intersect R|<=k.          (2)

Necessity is above. Sufficiency inspects exactly the intersection between
the two stored prefixes and reverses the second inspection word. This
constructs a real T-day winning strategy with its actual endpoints and
daily quotas.

Enumerating arbitrary beliefs to implement (2) is already generic finite
game computability, and is NOT the research advance asserted here. The
specific remaining obligation is to show that every relevant normalized
prefix of length J(k),...,J(k)+3 admits an exact restricted representation
with O(k) cut edges at all stages. The new dangerous-boundary recurrence
only treats histories faster than the canonical P(k), and cannot simply
be substituted for R_t^p. The fixed four-clock range identifies the
required extension precisely. If that compression is proved, (2) retains
literal mixed endpoint compatibility and can close the capture evaluator
without an unsupported scalar gate palindrome.

No all-parameter gap-zero conclusion, new numerical example, or new Lean
coverage is asserted in this interface note.

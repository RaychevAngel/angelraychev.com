# Independent audit of odd-width affine-slack capture compression

25 October 2026. Accepted ordinary derivation in
`odd-affine-slack-capture-compression.md`, on its stated domain
w=2b+1, n>=w even, b>=32, k=b+d, 2<=d<=b-1. This acceptance retains
the named previously reviewed floor-width inverse, ordinary-boundary,
tied-restart, polarization, and exact physical prefix dependencies.

## Physical construction and the amount of slack

For minimizing endpoints Q,Y, put N=h-Q-Y>0. The genuine forward
physical pair dominates its ordinary early pair and therefore has an
actual phase attaining Q. The genuine backward physical pair from the
tied seed (k,k) dominates its ordinary late pair, with harmless clipping
at h, and has maximum at least Y.

I checked the alignment carefully. For a swapped map Phi(x,y)=(f(y),g(x)),
progression Phi(C)>=C and scalar inflationarity f(z),g(z)>=z together
imply min Phi(C)>=max C. If x>=y, g(x)>=x follows from inflationarity,
while f(y)>=x follows from progression of the FIRST coordinate. The
argument is symmetric when y>=x. One cannot replace this reasoning by
the false assertion that a swapped coordinate always gains d-1 relative
to its own previous value.

After that alignment both coordinates are at least Y. The actual global
width caps on the backward scalar costs are b and b+1, so each scalar
map gains at least d-1 until clipping. The MINIMUM consequently gains
at least d-1 per subsequent update. After ceil(N/(d-1)) such moves
both phases reach h-Q. The accepted physical antipodal adjunction now
meets the actual early phase without assigning a free phase at the cut.
These steps establish the stated solo gate word, not only a numerical
majorant.

The arithmetic slack is exact. For integers N>0,d>=2,

    ceil(N/(d-1))-ceil(N/d) <= ceil(N/(d(d-1))).

Also Q>=H-d+1 and Y>=H+1 give N<=h-2H+d-2. Thus the constructed gate
clock is at most J+D with the displayed D. Sequential capture costs
at most2(J+D)+2=2J+s, where s=2D+2. The same exact first-gate reversal
cut as before then puts both optimal prefixes in [J,J+s-1].

## Scope of the floor-width boundary arguments

The arbitrary tied-origin theorem is already stated for every even-area
rectangle, with b=floor(w/2). It bounds total holes in arbitrary actual
initial shapes below H and does not depend on an even transverse side.
The new large raw-seed initialization only chooses a one-color subset
X of an actual D and makes one actual inspection; its numerical first
image is a tied recurrence image. Its square inverse and first-exit
guards use b,H and the even-area capacities, rather than an even-width
pyramid construction. Thus the extension of the arbitrary-terminal
late comparison does not require a parity-specific seed assumption.

The double-clamp proof is likewise unchanged. Surplus below b puts each
target hole component in its small/co-small alternative. Both small
components have total at most (b-1)^2; one co-small component puts the
source above U-d, where U=h-H-1. The geometric inequalities used at
both clamps follow from h>=2b^2 and d<=b-1, with extra room at odd width.
The excursion proof, shared R<=sd-1, early tied restart, and late
arbitrary-terminal lower corridor are algebraic once those physical
premises are established. No even-width critical-front classification
or monotonicity of the actual history was used. Hence the bound
(3s+1)k-1 applies to every intermediate original surplus of both actual
normalized prefixes.

This is not a claim that the stronger pronic middle evaluator equals
the affine lower clock J. The potentially length-dependent difference
is deliberately paid by D and s. The proof retains that payment in
the state-universe exponent.

## Literal encoding, time layers and capture

The rotation is independently proved in
`candidate-rotated-cutset-encoding.md`: using the EVEN length n=2ell as
the paired axis gives an ell-by-w matching array, regardless of aspect
order. Its cut bound is 6C+ell-1 because w is odd. This additive term
cannot be replaced by b-1. Actual physical colors determine the rung
directions and are retained when mapping back.

The proposed edge is exactly the previously checked neighborhood/erosion
adjunction edge, with correct physical color swap and minimum useful
quota. Extra unnormalized graph paths remain physical strategies. The
optimal normalized witnesses are present at ALL intermediate times by
the surplus bound. Exact-time layers retain their literal endpoints,
and the central test is their actual intersection, not the sum of signed
masses. The physical reverse-word argument gives precisely a+b+1 days.
Necessity and sufficiency therefore prove the exact minimum and an
attaining reconstructed word in the stated range.

## Complexity and limits

The state exponent is O((sk+n)log(wn)). In the displayed high-excess
range d,d-1>=b/8, h=O(bn) gives s=O(1+n/b), and therefore
sk=O(b+n). The scaling is NOT s=O(1+n/b^2). The draft uses the correct
perimeter conclusion. Its explicit bound s<=6+2h/[d(d-1)] and, when
n<=C0 b, s<=6+192C0 also check out.

For smaller d the exact evaluator and its larger stated exponent remain
valid, but the perimeter exponent is not claimed by this proof. The
minimum-budget d=1 case remains outside this construction, and earlier
exact natural-range results retain their own precise hypotheses. This
is finite optimization and reconstruction; no direct inspection formula,
fixed-operation numerical expression, equality of old scalar bounds,
practical large graph execution, or new Lean verification is asserted.

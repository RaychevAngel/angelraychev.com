# One protected central-cut rule for all higher subquadratic budgets

29 October2026. Ordinary interface theorem candidate for independent
review. It generalizes the2b..3b shifted cut, without a new width cutoff.
It does not prove the remaining joint endpoint intersection.

Let b>=2, w=2b+1, n even>=2b+2, h=wn/2, U=h-b(b+1), Z=h-b²,

    2b<=k<b(b+1),  0<=c<=k.

Put j=floor(k/b), so2<=j<=b, and define

    B0=b²-(j-1)b+2,
    s=min{t:min C_t>B0},                         (H1)

using the genuine capped zero-origin pair C. Every actual history
through s is in the strict collar and satisfies its three projected
comparison bounds. Every alleged signed gate T<P(c) has T>s and a
protected actual reverse suffix at this SAME cut. If scalar comparison
does not already rule it out, the actual one-cohort shared-deficit ledger
applies, with endpoint masses at least2 and with both endpoint reference
maxima plus k beyond b².

## 1. Forward protection uses only the global span invariant

Let E=b-1, the already proved global span upper bound, not a computed
maximum. Before s,

    max C_t<=B0+E.

Since k< (j+1)b and k is integral,

    B0+E+k <= b²+3b < b²+3b+1 <= Z.             (H2)

Thus every last available input through s is strictly below Z. The
joint small/co-small separator and projected strict-collar induction
protect every actual history through this cut. The actual histories may
retreat or use both cohorts; neither feature is discarded here.

The crossing satisfies min C_s<=G_k(B0). Its inverse subtraction is
capped at b because B0+k>=b²+b+2. Therefore

    M=max C_s<=B0+k-b+E=b²-jb+k+E+2<U.           (H3)

The last inequality uses k< (j+1)b and U>=b²+2b+1.
Moreover

    h-k-M >= b²+(j+3)b-2k-E-1
           >=B0-E-1 >=2.                       (H4)

Here B0>=b+2 since j<=b. The terminal gate requires at least h-c>=h-k
holes. Equation(H4), together with monotonicity of C, excludes every
terminal time through s. Hence a faster actual gate has T=s+r with r>=1.

## 2. The reverse preceding-index guard

Failed physical-prefix adjunction implies

    max V_r<h-min C_s.

Since min C_s>=B0+1, integrality gives

    max V_r<=Z+(j-1)b-4.

Every backward update increases its maximum by at least k-b-1,
which is at least(j-1)b-1. Consequently

    max V_(r-1)<=Z-3<Z.                         (H5)

This is precisely the finite-horizon signed reverse guard. No assumption
that the FINAL reverse maximum is below Z is required.

The actual source and reverse erosion therefore have their unclipped
bounds and real allowed-set excess. If the scalar maximum sum is too
small, the candidate is impossible. Otherwise failed cross-phase sums
give the same unique leader and a single shared deficit/excess ledger.
The mixed MIN bound excludes activation at the cut, so its two physical
histories belong to the same original cohort.

## 3. Endpoint masses and the uniform travel allowance

The actual early holes exceed min C_s>B0. The actual reverse erosion is
at least h-k-M, hence at least B0-E-1 by(H4). Thus each actual endpoint Q
satisfies

    Q>=B0-E-1>=b²-jb+2,
    Q+k>=b²+2.                                 (H6)

In particular the terminal capped wall in the genuine last-cheap age
ledger is crossed, even when Q itself is substantially below b². A
localized last-cheap root cannot be1: a root-one dangerous seed cannot
survive a bad update, whereas every endpoint here has mass at least2.

For b>=4096 the same finite arrival estimate applies for ALL k>=2b.
In the proof of `root-dependent-arrival-span.md`, at b the denominator
ratio is bounded by

    [1+k/(2b)]/(k-b)<=2/b<1/8,

and the ratio at0 is at most1/8. The error bracket has
y=k/(k-r)<=2, so its contribution is below24/7<12. Thus localized and
critical-front span allowances7/b and8/b hold throughout this entire
higher-budget range, retaining genuine initial quotas.

For the bad-travel lower bound, replacing an endpoint in(H6) by b² costs
at most

    (jb-2)/(k-b) <= j/(j-1) <=2

updates, since the unperturbed denominator k-sqrt(x) is at least k-b
throughout the omitted interval. The normalized half-age allowance is
therefore at most1/b, uniformly in j, including j near b.

Accordingly the same necessary normalized LP constraints attach to actual
localized seeds for the WHOLE domain2<=lambda=k/b<b+1, with span17/(2b),
wall7/(2b), travel1/b and0<=gamma<=1. This is only a numerical
relaxation statement. A fixed positive retained-radius margin need not
hold uniformly as lambda grows, especially when finite errors become
comparable to the few available boundary updates.

## Scope and remaining issue

The higher-budget physical interface is now uniform; it is not necessary
to introduce a new cut formula for each linear-budget band. The remaining
work is numerical/geometric rejection of its actual endpoint pairs, or
a sharper optimal construction where appropriate. Budgets at or above
b(b+1) require their existing direct/large-budget treatment; the retained
exact high-budget theorem starts at b(b+1)+1, so the single endpoint
k=b(b+1) is not silently absorbed here.

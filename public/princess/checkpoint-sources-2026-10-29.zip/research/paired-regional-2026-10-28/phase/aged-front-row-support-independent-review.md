# Independent review: original-area support of aged fronts

29 October2026. Reviewed `../root/aged-front-row-support.md`. Accepted
as an ordinary geometric lemma, conditional on its stated actual-front,
same-color and same-end hypotheses. No capture equality follows without
the separate protected-cut and age attachment.

For a row cutoff a_x, f_x=a_x+2 gives the exact parity-dependent cardinality
floor(f_x/2). Lowering all cutoffs by t yields a contained erosion marker;
empty rows are truncated, and extra far-boundary survivors only help.
An empty marker row has f_x<=t+1. The one-Lipschitz cutoff condition bounds
every occupied row by t+1 plus its path distance to the empty rows.
For a component of length l, that distance sum is at most l(l+1)/2,
including a component touching a transverse boundary. Combining components
only enlarges this upper bound. This proves(R1), including p=0; the p=w
case is correctly separated.

After an additional2z erosions the physical color is unchanged. A row
still occupied by both markers then had at least z+1 shared same-color
prefix cells before those additional erosions. Distinct rows contribute
distinct cells. Thus(R3) follows without a set compression or a duplicated
defect allowance.

I independently recomputed the finite corollary. With z=floor(b/20),
the original-area lower bound and t+2z+1<=7b/10+16 give

    4A-2w(t+2z+1)>=(6/5)b^2-(367/5)b-24.

Subtracting (21b/20)(21b/20+1) gives
(39/400)b^2-(1489/20)b-24, positive for every b>=4096.
Hence each marker has more than21b/20 occupied rows after the extra
erosion, giving more thanb/10-1 common rows. Multiplication by
z+1>b/20 yields more thanb^2/200-b/20>b-1 shared cells.

This argument preserves original front area and its actual age. It
does not license replacing an arbitrary old front by a younger front or
moving the actual common cut without checking both physical histories.

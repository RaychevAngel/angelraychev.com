# An analytic higher-budget corridor, with no fixed linear upper cutoff

29 October 2026. Ordinary proof for independent review. This note uses
the reviewed all-higher-budget protected cut and the already reviewed
actual ancestor/overlap lemmas. It proves no claim about the remaining
larger budgets, smaller widths, or even widths.

Let

    b>=4096, w=2b+1, n even>=w+1,
    3b<=k<=floor(b²/20), 0<=c<=k.

Then the actual full-origin signed gate clock equals the physical
compatible-prefix clock P(c). Consequently the full capture time is

    T_k(w,n)=P(k)+P(floor(k/2))+1,

with the already defined explicit prefix/palindrome optimal inspections.
The numerical P recurrence is retained; this is not an O(1) formula or
a Lean-formalization claim.

## 1. A sharper finite arrival correction valid for every k>=2b

Use the notation and integral J_k(r) in
`root-dependent-arrival-span.md`. For b>=4096, k>=2b and r<=b, the
denominator ratio in that proof is at most1/8. Indeed at zero it is
(1+sqrt(k))/k<=1/8, and at b it is at most

    [1+k/(2b)]/(k-b)<=2/b<=1/8.

The derivative argument there puts the maximum at an endpoint. The
error estimate is therefore, with 1<=y=k/(k-r)<=2,

    J_k(r)-2b Phi_lambda(r/b)
      <=(8/7)[3(y-1)-2log y]
      <=(8/7)[3-2log2]<=40/21<2.                 (C1)

Here lambda=k/b and Phi_lambda(x)=lambda log(lambda/(lambda-x))-x.
The bracket is increasing on[1,2], and log2>=2/3 follows from the first
positive term of the atanh series for log((1+z)/(1-z)) at z=1/3.

Thus a localized genuine seed of root r has reference span

    span<=b Phi_lambda(r/b)+2,                   (C2)

and the global critical-front version has span<=b Phi_lambda(1)+3.
These follow respectively from span<=J/2+1 and global span<=J/2+2.
They include arbitrary genuine first quotas and do not introduce a
physical restart. No asymptotic remainder is suppressed.

## 2. Each localized ancestor retains a large radius

Take the actual common cut from `all-higher-budget-central-cut.md`.
Suppose a faster gate exists. The scalar contradiction may already
exclude it. Otherwise the accepted one-cohort shared ledger supplies
last-cheap ancestors, real current phase/end alignment, numerical
endpoint deficits delta_i, allowed physical intersection eta, and
positive integral g, with

    delta_1+delta_2+eta<=g-1.

For a localized ancestor put x=r/b, beta=age/(2b), gamma=g/b and
d_i=delta_i/b. The exact no-cheap mixing bound and(C2) imply

    beta<=Phi_lambda(x)+5/(2b)-gamma+d_i
         <=Phi_lambda(x)+3/(2b).                 (C3)

The second inequality uses the strict, shared deficit inequality;
even when the other deficit and eta vanish, d_i<=gamma-1/b.
The actual endpoint bound of the protected-cut note loses at most two
updates relative to b² in the bad-travel integral. Thus

    beta>=Phi_lambda(1)-Phi_lambda(x)-1/b.        (C4)

These two inequalities hold separately for every localized ancestor at
this cut, including the rigid dominant triangle. They use actual age
and genuine quota initialization. If the endpoint itself is an initial
seed, age zero causes no change to the inequalities.

Combining(C3)--(C4),

    2 Phi_lambda(x)>=Phi_lambda(1)-5/(2b).

The positive series

    Phi_lambda(x)=sum_{j>=2} x^j/[j lambda^(j-1)]

shows Phi_lambda(x)<=x² Phi_lambda(1) for0<=x<=1 and
lambda Phi_lambda(1)>=1/2. With mu=k/b²=lambda/b, this gives

    x²>=1/2-5/[4b Phi_lambda(1)]
       >=1/2-(5/2)mu>=3/8>9/25.                 (C5)

Hence x>3/5. For lambda>=3, x-Phi_lambda(x) is increasing in x on[0,1],
since its x derivative is1-x/(lambda-x)>=1/2. It is also increasing
in lambda. The elementary alternating-log upper bound

    log(5/4)<=1/4-(1/4)²/2+(1/4)³/3=43/192

therefore gives, for each localized marker,

    x-beta>=6/5-3log(5/4)-3/(2b).

For two localized markers,

    x_1+x_2-beta_1-beta_2>=169/160-3/b>21/20,   (C6)

because b>=4096>480. Their actual retained radii are at least
2b(x_i-beta_i)-4, with raw missing-cell counts at most2b-2 each.
The already reviewed exact same-end triangle lens in
`exact-dense-triangle-common-cut.md` now gives an intersection greater
than both raw defects plus eta. Explicitly its triangular index is at
least ceil(b/20-3), whose triangular number exceeds5b-5 at b>=4096.
Thus two localized ancestors are impossible.

## 3. Full-front alternatives are covered by the actual protected cut

The protected cut uses j=floor(k/b), B0=b²-(j-1)b+2 and first min C_s>B0.
Its reference maximum obeys M<=b²-jb+k+b+1<=b²+2b. A genuine early
full-front ancestor has mass at least L+1=b²-2b+2. Since each reference
update gains at least k-b-1>=2b-1, its age a satisfies

    a(2b-1)<=4b-2,

so a<=2. The actual retained front consequently has area at least
b²-4b+1, stronger than the reviewed young-front premise b²-15b-5.

For a localized partner, Section2 alone gives x-beta>1/2 at b>=4096,
hence its retained radius is greater than b-4 and in particular at
least b/10-4. The opposite-compression overlap estimate in
`../regional/intermediate-early-front-late-triangle.md`, Section3,
therefore excludes this mixed branch with the same raw-defect and eta
allowance. No new normalized certificate is used for this step.

If the late ancestor is an old full front, use the actual adaptive cut
in `../regional/adaptive-cut-near-late-front.md`: move to within

    v0=ceil((3b-3)/(k-b-1))<=2

updates of that real ancestor. The forward cut only moves later, so
min C remains greater than B0. If the full v0 steps are used, the
reverse minimum reaches b². Failed physical adjunction then gives the
forward guard, while the other failed cross sum gives

    max V_r<=Z+(j-1)b-4,
    max V_(r-1)<=Z-3.

Thus both previous-index guards still hold at the adaptive cut. Its
actual forward endpoint exceeds B0 and the reverse endpoint exceeds
b² (or this is the original cut), so the travel allowance(C4) remains
valid. Normalize the history only once, retaining its actual activation
and recomputing the shared deficit at the new cut. If the new early
ancestor is localized, the young-front/triangle argument just given
applies with the two names exchanged.

The remaining alternative consists of two actual full-front ancestors.
Use the guard-interval midpoint clamping in
`../regional/balanced-protected-front-cut.md`. The distance from either
birth to that interval is at most ceil((3b-4)/(k-b-1))<=2. Both original
cut endpoints satisfy Q+k>b² by the higher-budget cut, which is the
precise terminal-wall premise used by its one-wall variation argument.
The genuine critical-front spans are at most b Phi_lambda(1)+3.
For lambda>=3 this is less than3b/5+3. The same exact shared-age
calculation hence balances both actual ages below3b/5+7, stronger
than the reviewed row-support overlap hypothesis3b/5+15.

The retained original fronts intersect in more than b-1 cells by
`../root/aged-front-row-support.md`; the new cut allows at most b-1.
This is the final contradiction. It is not necessary that these
retained original fronts remain the last cheap ancestors at the new
balanced cut.

## 4. Scope of the assembly

All alternatives of the accepted last-cheap shape classification have
been excluded at actual protected common cuts. This proves the gate
equality in the opening statement and then the existing full-capture
formula and construction. The relevant dependencies are the actual
projection/coherence envelope, signed reverse comparison, genuine span
and bad-age ledger, higher-budget cut, raw triangle lens, front/triangle
overlap, and balanced-front row-support overlap. None is replaced by a
finite sample or by an independently restarted reference orbit.

The upper endpoint is quadratic in b, so this extends far beyond any
fixed linear-budget band. The range k>floor(b²/20), including the
remaining endpoint k=b(b+1), is not settled by this note. Existing
separate exact results there remain in force.

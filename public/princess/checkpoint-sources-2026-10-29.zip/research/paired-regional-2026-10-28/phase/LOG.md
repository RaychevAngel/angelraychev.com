# Phase lane research log — 29 October 2026 UTC

## Objective

Uniform capture-time equality for rectangles; current lane investigates necessary phase-aware reachability and terminal compatibility. Ordinary proof tools and computations remain distinct from tighter capture bounds. No public or formal artifacts edited.

## 06:49–07:00 UTC: source recovery and target selection

Read the accepted 24–25 October result/restart files and the actual last-good age ledger, odd critical classification, genuine-span argument, and first co-small update argument. The enormous eventual threshold comes from a sufficient all-time span inequality, not an observed game transition. The exact common-cut ledger is already stronger than separate span bounds.

Chosen first falsifiable target: a necessary strict-collar phase automaton retaining actual last-good phase and remaining physical core. Good moves use the correct own/opposite incoming profile; nongood moves spend one extra surplus; cores erode one radius per update; a new good identity cannot replace a surviving core before it disappears. This model is intended to avoid a global small-span premise. Its scalar counts are a relaxation, not yet an exact game representation. A counterexample path against canonical clock domination will reveal missing information.

Source dependencies: `research/phase-dependencies-2026-10-24/lower-critical-core-or-frontier.md`, `lower-capped-critical-continuation.md`, `lower-first-quota-ordinary-boundary.md`; `research/phase-compatibility-2026-10-24/odd-physical-last-good-age-ledger.md`.

## 07:00–07:53 UTC: necessary phase transfer and high-budget physical interfaces

Implemented a strict-collar phase/core relaxation, including root-by-root rigid singleton exceptions, parity-aware radius dominance, the unusable-origin charge, and capped first-quota seeds. Independent review caught the initially uncapped seed in the diagnostic; corrected it. The scalar original prototype passed96 sampled `(b,k,c)` cases for b=12,16,32,64 and various k through4b, but these are diagnostics, not physical certificates.

The optimized `core_phase_window.cpp` keeps only counts above the smaller genuine reference coordinate, collapsing everything below it into one permissive no-core state. Each update uses suffix minima. A sweep of all12<=b<=100, b+1<=k<=4b and c in{0,1,floor(k/2),k} passed59,808 parameter triples on the shortest even length. This was an unpinned exploratory run; do not treat it as an authoritative certificate or all-length theorem. The quotient itself enlarges reachability, so its success is useful evidence for the phase/core abstraction.

Proved and independently reviewed candidate tools: high-budget strict-collar continuation for k>=3b; seed-age common-cut overlap for3b<=k<=4b; and a forward first-co-small interface when k+E<=4b-1. Root supplied the independently reviewed signed reverse interface without A>L. Their assembly initially exposed a real gap: when k>3b, the predecessor of a co-small good event can be below both reference coordinates and have no dangerous retained ancestor. Root's direct dual-support observation repairs this: complementing the neighborhood of the actual own survivor yields either a full far-diagonal radius2b triangle or a proper far-end full front. The new `high-budget-exact-gate-assembly.md` was independently accepted by the compression lane after color-alignment and mixed-lemma radius-cap clarifications. It establishes exact canonical gates/capture for b>=512,3b<=k<=floor(15b/4), all even lengths and all terminal quotas; no Lean or public update.

A proposed earlier cut t=s-1 would have avoided the co-small step, but it repeats an old failed route: failed adjunction then bounds the reverse reference only below Z+O(k), whereas the actual reverse theorem is clipped at Z. This failure is recorded rather than hidden.

Root suggested an interior boundary center for a full front. `interior-front-core.md` proves an actual radius >=b-4 core at the maximal majority fiber, with literal erosion persistence and changed-identity exclusion. Compression independently checked it and corrected one harmless strict/weak intermediate inequality. This doubles the former corner-only critical persistence scale. New `two-b-phase-continuation.md` uses it to prove strict-collar matched-phase necessity for all k>=2b,b>=512 with elementary span estimate2E<=11b/12+13/2<b-5. Its common-cut consequence is NOT claimed; the larger span does not automatically satisfy the old overlap hypotheses.

Next priority: retain the optimized low-budget transfer, seek a genuine uniform proof or a useful full-domain computational certificate, and coordinate with root rather than turn the newly resolved linear-budget band into a separate project.

## 07:53–08:45 UTC: phase persistence replaced by an exact regional invariant

Compression proved the integral span estimate for k>=ceil(7b/4), b>=512; I assembled `seven-quarter-phase-continuation.md`, extending the two-b continuation tool. The low-budget all-length quotient diagnostic passed all728,997 triples b12..128, b+1<=k<ceil(7b/4), every first quota0..k, in30.5267 seconds. Receipt `core-phase-all-length-b12-128.json` pins the source; this remains an arithmetic relaxation diagnostic, not a physical theorem.

A substantially faster route then superseded the entire strict-collar persistence campaign. Regional proposed deleting one longitudinal boundary to obtain an odd-by-odd subboard. Root and regional independently paired opposite-end subboards across the TWO physical cohorts, which aligns their majority/minority phases while retaining the true shared inspection quota. The resulting Z0,Z1 shadow inequalities hold for arbitrary actual shapes and histories; I independently checked the exact complement thresholds, zero cost, capped subadditivity, inverse maps, physical quota disjointness, and genuine indexing in `paired-projection-independent-review.md`.

The only attachment issue was whether every minimum-original-surplus target is wholly retained by one Z. `minimal-surplus-phase-coherence.md` resolves it uniformly: own-piece surplus a and opposite-piece surplus t have total capacity a²+t(t−1), which is at most(a+t−1)² when both phases occur. This contradicts the current root bin. The weaker critical fiber argument works also for b1,2,3 and needs no occupied-origin or dominant-component assumption. Root and regional independently accepted this proof.

Assembled `uniform-strict-collar-envelope.md`: for EVERY b>=1, every even n>=2b+1, arbitrary prescribed quotas, and arbitrary genuine initial data satisfying the three invariants, Q<=max W and Zp<=Wp propagate while actual Q<U. Good events use the exact retained projection; all other events pay the minority cost. This removes all previous strict-collar width, budget, tiny-root, core lifetime, and global span hypotheses. It is a necessary-history theorem, not yet a capture-time equality.

Root then used the ACTUAL Z coordinates of J0=E(D) to initialize a shifted reverse history. I independently accepted `../all-budget-projected-signed-reverse.md` and saved `all-budget-reverse-independent-review.md`. The strict mixed comparison works for b>=2 by the integer bound q<=U+b−1<U+2b−2, so signed reverse necessity now covers every b+1<=k<Z with no old natural-range guard. The real solo reversal, activation set, and allowed-set excess are preserved.

The remaining phase obstacle is now localized at the first co-small/common cut, rather than spread across every earlier step. `projected-first-co-small-branches.md` gives a direct all-budget full-front branch: its original survivor contains every own-end boundary cell, so disjoint old holes are retained entirely by the needed projection. For an own localized critical survivor, its exact missing-triangle area zeta equals the co-small overshoot, and at most zeta+1 old boundary holes can carry the phase mismatch. The genuine +1 corner cannot be wished away. This identifies an unpaid reachability debt; no full crossing theorem is asserted.

## 08:45–10:20 UTC: exact regional costs, false invariants, and a uniform two-update theorem

Derived `three-region-quota-elimination.md`: the exact minimum availability for both overlapping odd subboards and the two end-wall paths is a maximum of four affine terms. Regional independently accepted the algebra. Added `complement-dual-quota-elimination.md`, incorporating the genuine complement survivor and full-wall alternatives. A subtle correction is essential: conditional dual coherence can leave TWO availability intervals, so combining two colors cannot blindly take the maximum of their minimum costs and a new total floor. The note preserves both intervals and the subsequent cheap-wall endpoint filter. Finite integer attacks passed126,784 basic elimination cases and30,000 randomized exhaustive dual cases; these are algebra diagnostics.

The tempting history-wide linear wrong-wall and correct-wall deficit invariants failed in the six-region relaxation. In particular9x10,k7 has a relaxed maximum-mass state with the entire wrong wall at zero reference deficit. This does not refute the physical theorem, but it rules out proving it from those weak count constraints. The replacement `minimal-surplus-wall-capacity.md` applies ONLY at actual minimum-original-surplus events: a localized root-r support with defect delta has at least r-mtri(delta) own-wall cells, or r-1-mtri(delta) opposite-wall cells. Root and regional independently accepted the static statement, including the tiny roots. No invalid history-wide strengthening is retained.

Regional found a relevant half-budget fake at15x16,k53,c26: the count relaxation allows two updates, while physical prefixes require three. Its actual cheap endpoint requirements are a root7 triangle with defect3 and a root5 triangle with defect4. Their exact same-end lens has10 cells, exceeding the total defect7. `exact-dense-triangle-common-cut.md` packages the general retained-radius lens with actual times, defects and one shared allowed-set excess; fixed-seed age allocation does NOT improve by moving the common cut, because the sum of ages stays fixed.

`two-update-own-phase-obstruction.md` turns this example into a theorem for EVERY odd width and even length, b+1<=k<Z and arbitrary terminal0<=c<=k. The complete two-update signed-gate criterion is

    h<=k+max(I0(k)+I1(c), I1(k)+I0(c)).

Only the incompatible maximum/maximum equality remains after the scalar bound, and a convex root/defect inequality forces more canonical overlap than both defects can remove. Full-front alternatives collide on the whole own wall. A SEPARATE mixed-history argument forces a full partner, so no solo residual is substituted for an actual signed gate. Root and regional independently accepted the obstruction, the compatible physical-prefix construction, and the full-capture consequence: if k<Z and P(floor(k/2))<=3, both required true gate clocks equal their canonical clocks and T=P(k)+P(floor(k/2))+1. This adds a uniform all-width family with canonical capture time at most7, not a global zero-gap claim.

`good-to-sensitive-cut-barrier.md` extends the convex obstruction to an arbitrary common cut whose early holes are genuinely cheap and dangerous, and whose same-phase own survivor is cheap and sensitive. The early raw defect need not be small. Opposite/opposite cheap cuts are also excluded without an additional sensitivity premise. A literal9x10,k19 pair demonstrates why NONSENSITIVE own/own cuts must remain allowed: holes15 and survivor11 are disjoint, with neighborhoods19 and15. Its inverse phase pair is tied. Root agrees that this is a legitimate transition to transport through, not another case to forbid.

## 10:20–11:00 UTC: genuine credit ancestry and a uniform finite ancestor window

Regional proved `sensitive-credit-ancestry.md`: an actual update exceeding its minority inverse comparison must spend all quota at exact minimum original surplus, and must be a sensitive own triangle with defect<=r-1 or a critical full front. Integer credit tokens can be propagated through any minority-map supersolution, in particular min W. Nonsensitive events can transport a numerical credit and refresh actual geometry even though they cannot create the credit. Root found a concrete scalar expired-birth example b10,k19; its numerical path can be realized by fixed-end prefixes with nonsensitive cheap refreshes. Therefore tracking only the original sensitive birth is insufficient.

The exact no-refresh map is B_c(Q)=I0(max(0,Q+c-1)). The two-step contraction was already present in the24October last-good ledger; its rediscovery is not a new result. The new `uniform-signed-span-and-bad-age.md` proves a GLOBAL signed reference invariant for all b>=2,k>=b+1 and every first quota c: v>=I0(u)+1 and u>=K1(v)+2, where K1 caps the square-root subtraction at b. It includes exactly one explicit transient b2,k3,c2,(u,v)=(1,2). Root independently checked the main root-bin algebra and caught a small-origin induction gap; the direct k-dependent repair is now included.

Consequently every actual dangerous localized seed of root r has mismatch<=r-1, without a width or tiny-root certificate, even when the numerical reference maximum exceeds b². Its bad suffix has length at most2r-3. More generally every dangerous state has a genuine last-cheap ancestor within2b-3 updates, independent of n,k,c. Shifted reverse initialization remains physical: if its initial erosion is not cheap, it is below both genuine reference coordinates. The exact surviving triangle defect and the retained front mass q-ab-ceil(a/2) are still required; a nonnegative enclosing radius alone is NOT a nonempty core or an overlap theorem.

The immediate research target is a joint last-cheap ancestor certificate using this O(w) window, exact bad-map filtering, real phase transport, exact triangle/front overlap, and the shared endpoint deficit. Root and regional continue independent support-signature/cap approaches. No new Lean coverage, public artifact changes, or global capture-gap reduction is claimed; the accepted global ceiling remains3.

## 11:00–12:20 UTC: all-budget cuts and a certified localized join

Regional and root replaced the remaining co-small crossing interface by a
finite-horizon reverse theorem and a uniform protected-cut existence
argument. Every candidate faster than the compatible-prefix gate now has
an actual common cut whose PREVIOUS forward and reverse inputs are below
the cap, even when the final reverse reference exceeds it. I independently
checked the cut-existence arithmetic and the mixed-history exclusion. This
removes an interface obstruction for every feasible k<Z; uniform rejection
of the actual endpoint pair is still required.

`endpoint-near-cheap-shared-deficit.md` proves directly at a dangerous
endpoint that its original surplus is at most b+1 plus its numerical
deficit. For central endpoints the two geometric excesses and the same
allowed-set eta total at most g+1. The shifted initial erosion has the
stronger b-plus-deficit bound. Compression's independently checked
component-stability lemma then limits satellites, but a near-cheap
transverse front shows why this alone cannot fix a longitudinal end.

`root-dependent-arrival-span.md` derives a genuine-index arrival integral,
combined with root and interlacing bounds on the seed span. Regional's
complementary bad-travel integral supplies the opposite time inequality.
Using their SAME shared endpoint deficit, rather than independent ages,
reduces a localized common-cut obstruction to a three-variable normalized
feasibility inequality. Root eliminated the residual linear program and
certified the normalized21/20 radius margin with exact directed-integer
logarithm bounds. I independently reviewed and replayed this certificate.

The finite arrival correction is at most12 on5b/4<=k<=2b,b>=64.
Root's second certificate keeps span17/(2b), wall7/(2b), and travel2/b
errors and retains the same21/20 margin for every b>=4096. Its1399-node
tree was independently replayed. The exact integer lens already beats
both raw defects and eta at b4096: j=ceil(b/20-3)>=202,
tri(j)>100j+295>=5b-5. The complete conditional physical assembly is
`intermediate-budget-localized-join.md`. It excludes two localized actual
last-cheap ancestors across this full budget interval and every length;
it is not a full capture theorem.

A full front at the EARLY central-cut endpoint is necessarily young:
age<=13, leaving a literal pyramid of area at least b²−15b−5. Regional
uses this with the same robust certificate to handle an early front and
late localized ancestor; I checked its finite LP attachment. An OLD late
front is the remaining branch in this intermediate-budget analysis.
The coarse scalar constraints can allow that old front's retained body
to disappear; treating a front as a localized triangle would be invalid.

The old Oct24 exact GF/FG discrepancy proof already resolves genuine
spans at a very large width threshold. I reread it before exploring a
weaker affine-span target. Persistent gap growth requires alternating
interiors of the square/pronic bands with the current gap as a margin;
the main resonance is near root k/2. A useful new bound must exploit
genuine orbit position or cumulative cancellation, not merely an
arbitrary interlaced pair. No improved uniform affine-span theorem is
claimed. The global capture-gap ceiling remains3, and no public or Lean
artifact has been changed by this lane.
## 12:20–13:00 UTC: all-budget exact capture at large odd width

The old late-front obstruction was removed by retaining original row
profiles and moving to a protected cut balancing the actual front births.
The row-support theorem forces overlap from their original areas even
when a coarse retained-area estimate would be too weak. I independently
reviewed both the geometry and the actual protected midpoint construction.
This completed the dyadic intermediate-budget assembly. The existing
natural-range theorem overlaps it, giving every b+1<=k<=2b at b>=4096.
A separately certified shifted cut extended this to2b..3b.

`all-higher-budget-central-cut.md` then replaced band-by-band interfaces
by one rule for every2b<=k<b(b+1): with j=floor(k/b), cross
min C>b²-(j-1)b+2. Both previous-index guards survive, all actual endpoint
masses remain positive, and Q+k>b² supplies the precise final-wall
premise. Root independently accepted this interface.

`analytic-higher-budget-corridor.md` proves exact gates throughout
3b<=k<=floor(b²/20), uniformly over even length and every terminal quota.
For k>=2b the finite arrival-integral error is less than2, not12.
Together with the STRICT shared deficit and the actual bad-travel
inequality, this forces each localized seed root above3b/5. A short
analytic logarithm bound gives the same21/20 retained-radius margin,
without another numerical interval certificate. Early/adaptive front
ages are at most2; balanced original fronts cover the remaining branch.
Root and regional independently accepted the argument.

For the remaining tailceil(b²/20)<=k<=b(b+1), the actual terminal quotas
k and floor(k/2) suffice. Root's genuine-index lower masses, full-board
clock sum and shared-age bound reduce two localized ancestors to924 fixed
signatures, independent of the board parameters. Its rational certificate
proves retained normalized radius sum at least11/10. I independently
reviewed the physical indexing and replayed every signature exactly.
The root source now includes the harmless first-pair orientation and
half-quota-rounding clarifications from that review.

`quadratic-tail-front-attachment.md` supplies all other tail branches.
The genuine global span is at most12, so all last-cheap ages are at most23.
Every localized root is at leastb/7, including an actual initial reverse
half-quota target. Retained triangles have radius at leastb/4, and retained
fronts have area at leastb²-25b-10. The reviewed front/triangle and original
front/front overlap inequalities have generous margins. Root, regional
and compression independently accepted this attachment.

The complete assembly is
`large-odd-width-all-budget-exact-capture.md`: every odd widthw>=8193,
every evenn>=w, and EVERY budget has an exact answer and explicit optimal
inspections. The new prefix-clock formula applies throughk=b(b+1);
the earlier explicit high-budget formula is retained above that threshold,
without asserting an unproved identity between the two evaluators.

Separately, compression's protected-cut/one-step-interlacing argument
proved P(c)-1<=truegate(c)<=P(c) for all odd widths and feasible budgets.
Combined with the retained even-width bound and the checked small-even
receipt, the WHOLE rectangle domain now has gap at mostTWO, down from3.
I independently reviewed the new odd-gate comparison, not the historical
small-even certificate generation.

The global gap-zero objective remains unresolved. The new exact large
odd-width theorem does not close smaller odd widths or even widths, and
does not replace the accepted recurrence by an O(1) expression. No Lean,
manuscript, website, PDF or public release was edited by this lane.

## 13:00-14:50 UTC — even physical interfaces, no global gap change

Source audit prevented a false milestone: both missing longitudinal
critical directions were already proved on25October at b128. The new
shorter direct arguments and genuine span bound are useful, but not a
new b128 longitudinal closure. I independently accepted the regional
final |S|=L classification/longitudinal attachment, including the old
rigidH+2 to finalH+1 one-step case and its two remote neighbors.

New `corner-hole-pyramid-entrance.md` constructs a specified pyramid
of sizeq+d in ONE real update from any actual q-hole subset of its
critical corner envelope, H-d<=q<=H. Compression independently accepted
it;9,120 literal words pass, including5,700 empty-fiber targets. This is
an arbitrary-raw-set entrance. The chosen existing ordinary prefix
(`prefix_height`, outer layer from x>=c) is ALREADY a strict pyramid;
old prose about a3-jump does not apply to that chosen construction.
Regional subsequently strengthened the whole reachable arrival cone,
so I stopped duplicating that work.

`raw-corner-tilt-transport.md` specializes root's physical time-trajectory
packing to exact F_b(t)=b²-triangular(max(0,b-1-floor(t/2))). It keeps
post-inspection timing and subtracts no fictitious raw defect.40,590
literal column sums pass. Compression independently accepted it. Its
one-longer all-pair corollary is a uniform label constraint, not an
arrival-phase or capture theorem.

`one-longer-critical-label-consistency.md` extends the common interior
critical corner to both pyramid axes on2b by2b+1,b128,d>=4, including
finalH+1 and the previous rigid source. Parent independently accepted.
`final-critical-pyramid-empty-rows.md` proves the equality-sized critical
pyramid still has at mostTWO empty rows and extends the square common
critical label through the final target, b128,d>=2. Parent accepted.
These are actual interior labels; a front edge may still retain both
corner phases, so they do not resolve the boundary phase join.

`backward-sensitive-ancestor-interface.md` attaches regional sensitive
ancestor demands to the ACTUAL normalized solo suffix, retaining every
activation index r and its real D. A reversed erosion J_j contains the
actual POST-inspection survivor at dayT-r-j-1. Thus a sensitive seed's
raw envelope has zero outside-target exception at that true clock.
Propagated markers have the stated cap-minus-retained-mass exception.
Root independently accepted. This rejects the tempting but invalid
shortcut of applying normalized full-origin late capacity to an
arbitrary synthetically padded allowed-source set.

A further root/phase derivation genuinely strengthened that interface:
`shifted-ordinary-pronic-cap.md` replaces the shifted erosion capA by the
fullH=b(b-1), and the normalized signed-late cap byH+k. If currentmaxW<H,
its precedingmaxW<A because F(A)=H; oldcapA controls every predecessor,
last raw input<=b² givesactualtarget<=H, and the already proved physical
H-boundary induction covers the final step. Shifted initialization is
checked separately. Root independently accepted. Consequently the real
reverse bound and SINGLE shared deficit account are now unclipped for
ALL low-excess1<=d<=b-1, removing the former high-d residual cap band.
The backward-sensitive API was updated with this accepted stronger guard.

` sensitive-ancestor-same-clock-lens.md` (filename without leading space)
packages exact actual forward/reverse marker lenses, including eta when
the reverse allowed set is larger than the actual survivor. On2b by
(2ell+1), own seed rootsmF,mR and even totalageaF+aR are incompatible if
triangular(mF+mR-ell-1-(aF+aR)/2)>deltaF+deltaR+eta. It retains actual
corner alternatives and does not assert that such seeds always exist.
The64by65,k48,c24 scalar cuts41/6/39 are excluded for EVERY activation:
forwardroot31 atday39 defect4, reverseendpointroot31 atday47 defect14,
eta0, exact minimumlens325. Regional independently replayed all39
activation branches and both physical colors. This selected cut is an
illustration, not a new full parameter classification.

Current new candidate for review:
`first-critical-boundary-corner-anchor.md`. A first σ=b critical target
q>L BEFORE the early cut can be attached to the last true subcritical
good corner using the accepted exact core-mixing theorem. All preceding
intermediate steps are B-bad, so a parity-correct livecore persists;
criticalsmall-side area<=H rules out opposite-facing pyramids because
any farwallcontact costs at leastb(b+1). The actual corner also matches
the numerical leader through subsequent boundary F steps. Remaining
issues are explicit: no such critical event before the cut, and a
pyramid edge still has two endpoints. Neutral critical F steps cannot be
charged as B-bad elapsed time. An earlier unguarded radius-one/front
claim was withdrawn: larger tilted pyramids may contain the far core.
The precise static contact cost is M_b(R)=b²+b+bR-floor((R+1)²/4).

Global proved capture ceiling remainsTWO. No new public, manuscript, PDF
or Lean changes were made in this lane.

## 15:06 UTC -- Actual cone tilt independently accepted

Reviewed regional U1--U7 and the pronic overlap/credit identity. Independent
all-cell replay of all285 inspections captures atday285 with quota48;
1,254 literal tail checks confirm erosion/root formulas. No uniform lower
claim: matching285lower is separately pending review. Fixed-prefix gate
optimality is false, so future phase arguments must permit physical tilt.
See cone-gate-independent-review.md and cone_gate_independent_audit.json.

## 15:07 UTC -- Matching285 lower independently accepted

All common-cut clocks for a141-update quota48gate on64×93 reduce to four
pairs, each with impossible negative total shared deficit. Independent
integer certificate plus matching noncontraction/all-split lower prove
T>=285. Together with independent literal upper, T_48(64,93)=285. This
is a structural discriminator and new construction validation, not a
uniform gap0 assertion.

## 2026-10-29 final research receipts

Direct canonical middle interpolation and flexible first-tail attachment independently accepted. Actual raw profiles close the102x124k72 residual with206-update half gate and exact413-day capture; independent full413-shot replay and205-gate lower check saved. Paired-raw-boundary sufficient criterion independently accepted with R0=R intersect U refinement and explicit overlap charge.

Proper-root arbitrary equal-clock arrival is FALSE:12x12k7,root5def3canonical sensitive target22 cannot arrive at own-leading clock8. Complete888030-subset predecessor check gives minimumshadow26 instead of allowed25; independently recreated by root. Actual10-update arrival replay saved. This makes exact boundary reachability an essential part of any uniform synthesis theorem. No new mathematical search after this checkpoint; no Lean or public release changed.

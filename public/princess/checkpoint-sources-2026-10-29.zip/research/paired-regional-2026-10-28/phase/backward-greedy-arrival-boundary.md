# A precise limitation of fixed-corner backward greedy arrival

29 October 2026. Bounded exact falsification of an unrestricted normal-form
claim. This does NOT refute a theorem restricted to strictly subcritical roots.

On6 by6 with quota4, take the own-corner root3 target at C=(0,5)

    K={(0,1),(0,3),(0,5),(1,2),(1,4),(2,3),(2,5)}.

It has seven cells, minimum shadow surplus3, and is a canonical pyramid
in the transverse orientation. Its actual containment arrival from the
full physical-color-0 cohort is five updates. The exact hole path is

    [0,9,75,31,63,439]

in physical-color row-major masks. An independent literal replay verifies
that every transition uses at most4 probes and produces exactly the next
hole set. Earlier matching-color clock3 has total-hole upper bound5, so
five is optimal; no exhaustive-state inference is needed for this lower.

Now use the deterministic backward construction that repeatedly replaces
a target by the |N(target)|-4 nearest-to-C cells of its neighborhood, using
one of the four fixed tie orders x, -x, |x-y|, -|x-y| in local coordinates.
Every one takes seven updates after correct alignment with the initial
physical color. Thus even minimizing over those four tie orders does not
make fixed-corner backward greedy universally optimal.

The independent complete image-state graph on this board checks124
canonical raw targets. It finds six such failures; ALL have root3=b.
The full own nine-cell triangle has greedy clock9 versus actual clock7
as another critical-root failure. Files:
canonical_greedy_arrival_falsifier.cpp/.json. The probe also computes
exact earliest CONTAINMENT via the superset-min transform, not merely
exact-target distance.

The distinction is material. At critical root, the shadow can reach an
additional physical board corner, and an optimal earlier history can
use that corner. The fixed-corner nearest-cell rule can discard it.
A proper-root statement m<b may evade this mechanism, but it needs its
own proof and is not established by this small-board diagnostic.

A promising uniform theorem should either retain the earlier corner/
orientation state explicitly, or prove the needed proper-root reachability
family. It should not claim every raw minimum-surplus shape is freely
reachable: the separate two-axis-tip counterexample remains valid.

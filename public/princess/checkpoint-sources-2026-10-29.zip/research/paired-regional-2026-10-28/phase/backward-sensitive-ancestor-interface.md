# Sensitive ancestors of a real backward allowed-source history

29 October 2026. Ordinary interface theorem, submitted for independent
review. This applies the regional sensitive-ancestor criterion to the
actual solo portion of a normalized signed-gate word. It does not replace
its mixed suffix by a fictitious solo terminal set.

## 1. Scope and actual reverse indices

Use the accepted even-area ordinary boundary regime:

    b=floor(w/2)>=32,  max(13,b+1)<=k<=b^2,
    h=wn/2,  0<=c<=k,  A=b^2-k+1, H=b(b-1).

Let a normalized full-origin word reach signed gate c at real
pre-inspection clock T. At an earlier clock v, suppose its actual signed
mass is Y and

    Y>min V_ell^c,   M=max V_ell^c < H+k,
    ell=T-v.                                           (B1)

The ordinary signed-late theorem, including activation, implies that
clock v is genuinely solo. Let the actual later activation clock be
T-r; if no activation occurs before T, put r=0. Thus

    0<=r<=ell-1,    a=ell-r>=1.

Let D be the actual smaller-cohort pre-inspection set at clock T-r.
For r=0 it is the actual terminal solo set. The mixed/activation
comparison and (B1) give, without clipping,

    |D|<=min V_r^c.                                    (B2)

Write the genuine solo states from v through T-r as S_0,...,S_a=D,
and their actual inspections of this cohort as I_0,...,I_(a-1).
These are the original inspections, each of size at most k. Define

    C_0=D,
    J_j=E(C_j),
    C_(j+1)=I_(a-1-j) union J_j,       0<=j<a.           (B3)

Then J_(j+1)=E(J_j union I_(a-1-j)) whenever j+1<a. There has been no
restart at a chosen set of size c. The actual activation set D, the
remaining mixed duration r, and all solo quotas are retained.

The genuine shifted-erosion theorem gives

    |J_j|<=B_j:=max V_(r+j+1)^c-k,   0<=j<=a-1.         (B4)

Indeed the new independently accepted `shifted-ordinary-pronic-cap.md`
gives clipping threshold H, while (B1) and monotonicity imply
B_j<=M-k<H throughout. Its signed-late cap H+k also supplies the
unclipped activation bound (B2). This strengthens the earlier version
of this interface, whose guard M<b^2+1 used the accepted old cap A from
`research/phase-dependencies-2026-10-24/lower-shifted-seed-continuation.md`.
It is not an arbitrary-state late-capacity assertion. In the actual
low-excess even-width join, M<=H+2d<H+k automatically, so every
1<=d<=b-1 now satisfies the guard.

At the initial physical clock v,

    S_0 subset C_a=I_0 union J_(a-1),
    |J_(a-1)|>=Y-k.                                    (B5)

A sharper lower requirement is allowed when a coupled deficit ledger
supplies one. A signed deficit must not be replaced by an independently
chosen favorable reverse phase.

## 2. The post-inspection interpretation removes an extra quota loss

For every 0<=j<a put

    d_j=T-r-j-1=v+a-j-1.

At this REAL day the actual post-inspection survivor R_(d_j) obeys

    R_(d_j) subset J_j.                                (B6)

Proof: backward induction gives S_(a-j) subset C_j. Since
N(R_(d_j))=S_(a-j), every existing neighbor of a point of R_(d_j) lies
in C_j. Hence R_(d_j) subset E(C_j)=J_j. This also proves the induction
S_(a-j-1) subset I_(a-j-1) union J_j=C_(j+1).

Consequently a spatial upper envelope on J_j is an upper envelope on
an ACTUAL survivor, at a known original clock. No k-cell inspection set
needs to be added to the envelope, and no allowed-set excess eta needs
to be charged. If instead one uses the pre-inspection set C_(j+1),
its extra inspection cells must of course be retained.

## 3. Backward demands and sensitive seeds, including j=0

Let Psi_j(q) be a proved nondecreasing lower bound on the neighborhood
size of a q-cell support in the physical color of J_j over the actual
range permitted by (B4). Start with a proposed endpoint requirement
ell_(a-1), at least max(0,Y-k), and work backward through the genuine
reverse word:

    ell_(j-1)=max(0,Psi_j(ell_j)-k),  1<=j<a.           (B7)

Actual useful quotas may replace k, strengthening the test. If any
ell_j>B_j the activation branch is impossible. Otherwise define the
availability upper bounds

    U_0=min V_r^c,
    U_j=B_(j-1)+k,                   j>=1.             (B8)

For any index s in 0,...,a-1 and integer 1<=m<b, if

    ell_s>m(m-1),
    U_s-ell_s<=m,
    U_s<h-m^2,                                        (B9)

then the ACTUAL reverse set J_s is contained in an own-corner triangle
T_m(C), of radius 2m-2, and has raw defect at most

    delta_s=m^2-ell_s.                                (B10)

The corner C belongs to the own corners of the actual physical color
of J_s. This is a geometric phase at its real clock d_s; it is not a
freely chosen scalar phase.

For s>=1 this is the proof of
`regional/sensitive-ancestor-regional-demand.md` with the availability
bound (B8). For s=0 use N(J_0) subset D and |D|<=U_0. The same finite
corner dichotomy applies, with one-shot availability surplus |D|-|J_0|, which bounds the
neighborhood surplus of J_0 from above.
The guard U_s<h-m^2 excludes the co-small branch. Capacity m^2 and
ell_s>m(m-1) force exactly one own component; splitting components or
using an opposite component has capacity at most m(m-1). A smaller
surplus cannot have this size. Thus J_s itself lies in T_m(C), including
at the genuine shifted initial seed. No empty-origin hypothesis is
needed for this local proof.

Under the usual subcritical boundary range one may use
Psi_j(q)=q+ceil(sqrt(q)), provided its original-surplus/co-small guard
has been verified from the actual bounds. The statement deliberately
permits any valid Psi rather than silently assuming an own-phase
shadow profile for an unlabelled set.

## 4. Retained markers give genuine late spatial exceptions

At every later reverse index j>=s the exact erosion-defect lemma gives

    |E^(j-s)(T_m(C)) minus J_j|<=delta_s.               (B11)

Write M_(s,j,C)=E^(j-s)(T_m(C)). For any proposed target envelope R in
the physical color of J_j,

    |J_j minus R|
      <=B_j-max(0,|M_(s,j,C) intersect R|-delta_s).     (B12)

By (B6) this also bounds |R_(d_j) minus R|. In particular, choosing R
to contain the retained triangle gives exceptional mass at most
B_j-|M_(s,j,C)|+delta_s, clipped below at zero. At the sensitive seed
itself the stronger containment J_s subset T_m(C) gives exactly ZERO
outside-envelope exception. Do not replace that zero by its weaker
propagated cardinality estimate.

Several actual ancestors may be combined using union/intersection
occupancy inequalities, paying each raw defect once; arbitrary sums of
individual marker occupancies would double count overlap. Any allowed
corner choices must be compatible with the same real word.

## 5. Attachment to the physical trajectory packing inequality

Suppose a forward actual hole marker at pre-inspection clock i supplies
a lower source prefix for the actual belief, with at most delta_F
exceptional missing source cells. Let j be a reverse index with d_j>=i,
and let (B12), or the exact seed containment, bound the actual survivor
at day d_j by a target prefix with at most delta_R extra cells.

Apply `root/column-trajectory-transport.md` to t=d_j-i moves. The
inspections occur at the REAL days i,...,d_j, so the post-inspection
version of the necessary inequality is

    sum_x packed_paths_x <= (t+1)k+delta_F+delta_R.     (B13)

For t=0 the packing is simply the number of source cells outside the
target envelope, all of which must be inspected that day. For t>=1 use
the exact parity-aware path formula. One may replace (t+1)k by the sum
of actual allocated cohort quotas. This is a lower-bound test; no
claim of sufficiency or optimal arbitrary-state transport is involved.

To exclude an alleged full-origin gate, retain EVERY feasible activation
index r and every actual phase/corner alternative. Rejection of one
chosen r or one chosen corner is not a full-game contradiction. The
construction above provides necessary spatial clauses for each branch;
a common temporal or Boolean consistency argument may combine them.

This interface is valid throughout its stated ordinary-cap regime,
including arbitrary retreats. It does not remove that cap, prove that
the sensitive test always fires, or establish a new capture-time gap.
No new Lean coverage is claimed.

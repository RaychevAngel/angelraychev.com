# Nine-hour rectangle-capture investigation: results

29 October 2026. Research window: 06:49:49–15:49:49 UTC
(28 October 23:49:49–29 October 08:49:49 Pacific).
Starting source commit: `a385f04`.

**The uniform proved gap has decreased from three days to two. Global
gap zero has not been proved.** The final fixed-size numerical expression
has not been pursued ahead of that prerequisite. All prior accepted exact
regimes remain available; the new results below supplement them.

The game and quantifiers are unchanged: every rectangle `w <= n`, every
constant feasible budget `k >= floor(w/2)+1`, full initial uncertainty,
simultaneous inspections, and compulsory movement after an unsuccessful
day. The one-cell and other retained degenerate cases keep their earlier
conventions. A computational fixture is never treated as a classification
of its surrounding family.

## 1. A two-day constructive bracket on the whole domain

For every odd width `w=2b+1`, every even `n>=w`, and every feasible budget,
the actual compatible-prefix gate clock `P(c)` and the unrestricted signed
gate lower clock `g(c)` satisfy `P(c)-1 <= g(c) <= P(c)` (with the natural
zero truncation). The proof retains the actual physical cut and phase.
With `p=P(k)` and `q=P(floor(k/2))`, the retained gate identities give

    max(2p-1, 2q-2) <= T_k(w,n) <= min(2p+2, 2q+1),
    q in {p,p+1}.

The displayed bracket has width two. The earlier exact high-budget and
small-width cases are retained where they are stronger.

The earlier even-width source assembly already supplied a two-day bracket
at the small widths, and the earlier large-even-width theorem supplies it
above them. We checked the seven pinned source hashes and 1,650 records
behind that retained small-width assembly. The old three-day exceptions
were odd widths 47 and 61; the new all-odd-width theorem removes both at
once. Together with the retained odd-by-odd exact joint evaluation, this
establishes the **whole-domain two-day ceiling**. It does not establish
that every unresolved instance actually needs both days of uncertainty.

Proof: [odd-width uniform bracket](compression/odd-width-uniform-two-day-gap.md).
Retained-source audit: [small-even audit](compression/retained-small-even-gap-two-audit.json).

## 2. Exact capture for every budget at every odd width at least 8,193

Let `w=2b+1`, `b>=4096`, and let **every even** `n>=w` be allowed. Put
`h=wn/2` and `B=b(b+1)`.

* `k<=b`: capture is impossible, by the retained feasibility theorem.
* `b+1<=k<=B`: the exact answer is
  `T_k(w,n)=P(k)+P(floor(k/2))+1`, with the actual optimal
  prefix/palindrome inspections.
* `B+1<=k<h`: the earlier exact high-budget numerical formula applies.
* `h<=k<2h`: the answer is two days; `k>=2h`: one day.

This is all budgets and all lengths in the stated width/parity domain,
not an eventual-in-length assertion. The low and middle budgets are
evaluated by the physical prefix recurrence, so this is **not** the final
O(1)-operation expression. The quadratic tail needs only the two terminal
quotas appearing in the capture formula; it does not claim exactness for
every auxiliary terminal quota.

The proof combines uniform cut/phase/overlap arguments with exact
directed-integer and rational auxiliary certificates, independently
replayed. The 924-signature tail certificate is a finite mathematical
reduction, not a numerical sample of rectangles.

Full statement, high-budget formula, proof dependencies, and exact guards:
[all-budget large-odd-width theorem](phase/large-odd-width-all-budget-exact-capture.md).

There is also a genuinely additional band at smaller widths:
`b>=512`, `w=2b+1`, every even `n>=w`, and
`3b<=k<=floor(15b/4)` have exact physical gates and capture. This is not
subsumed by the preceding result when `512<=b<4096`.
[Band assembly](phase/high-budget-exact-gate-assembly.md).

## 3. A fixed-corner upper construction is not always optimal

We constructed and independently replayed an actual full-board strategy
showing

    T_48(64,93) = 285.

The earlier fixed-corner prefix construction gives 286. Thus a universal
proof that the old prefix upper bound is always optimal would be false.
The improvement changes the boundary shape and joins a reflected tail at
the same real clock; it preserves the physical phase and every daily quota.

The 142-update solo gate admits two independently implemented versions:
an explicit cone plus two-inspection bridge, and a direct 62-update middle
interpolation between a 41-update head and a 39-update tail. The solo
gate yields the 285-day palindrome, replayed from all 5,952 initial rooms.
A separate four-clock lower-bound audit proves 285 is necessary.

Proof/review: [285-day result](reviews/root-tilted-capture-285-review.md),
[independent lower review](phase/tilted-capture-285-lower-independent-review.md).
Literal evidence: [bridge replay](compression/long_middle_gate_literal_replay.json),
[direct replay](phase/direct_pyramid_middle_literal_replay.json).

This example matters because it decides the direction of the general
research: some remaining uncertainty must be removed by improving the
upper construction, rather than strengthening a lower bound up to a
universally optimal fixed-corner prefix. It is not presented as sufficient
progress on its own toward all-parameter coverage.

## 4. General reachability and lower-bound interfaces

These tools are uniform in their stated parameters. Their hypotheses
remain part of their statements; none is silently a normal-form theorem
for every optimal history.

**Exact middle transfer for fixed actual canonical endpoints.** Given a
genuinely reached canonical hole set `X`, a compatible canonical allowed
tail `Y`, and a real middle duration `Delta`, define the surviving old
holes `D^Delta X` and the available numerical credit. Under the stated
regularity and area guards, the overlap test is necessary and sufficient
for a transfer with the specified drift bound. The successful direction
constructs legal inspections. It avoids an artificial final bridge.
[Direct transfer theorem](phase/direct-pyramid-middle-transfer.md).

**Flexible cones and actual short bridges.** A genuine arrival can reach
an entire interval of canonical shapes at the same area and clock. A
matching/cover criterion then supplies a real two-inspection bridge. The
criterion retains the one exposed root and its forced cover cost. Earlier
heads on a common affine-credit plateau dominate later heads, so imposing
the lower-bound cut as the construction's entry time is unnecessarily
restrictive. [Cone and bridge criterion](regional/explicit-cone-bridge-gate-criterion.md),
[arrival cone](regional/constructive-pyramid-arrival-cone.md).

**The reverse bound reaches the full pronic cutoff.** The shifted reverse
bound now remains valid through `H=b(b-1)`, instead of the smaller
`b^2-k+1` cutoff, in its explicit even-width low-budget range. This removes
the previous high-budget-residue clipping obstruction from that interface.
It does not remove endpoint compatibility.
[Pronic-cap theorem](phase/shifted-ordinary-pronic-cap.md),
[review](reviews/root-pronic-cap-review.md).

**Genuine creator clocks and shared phase.** A required excess token has
a true sensitive creator in the actual history. Its mass is the unique
first preimage of that token under the suffix recurrence; its physical
phase is restricted by the ordinary matching branch. Multiple surviving
tokens have strictly ordered creator clocks. These facts prevent choosing
a favorable shape, time, and phase independently.
[Creator theorem](regional/unique-mass-sensitive-creator-domain.md),
[review](reviews/root-creator-domain-review.md).

**Regional history tests.** Backward demand, actual forward/reverse
attachment, same-clock lenses, trajectory packing, and shared layer
profiles give necessary constraints on complete histories. The same
missing cells and the same unused quota must be used consistently across
all constraints. A satisfying necessary model is not a physical strategy.
[Regional demand](regional/sensitive-ancestor-regional-demand.md),
[reverse attachment](phase/backward-sensitive-ancestor-interface.md),
[same-clock lens](phase/sensitive-ancestor-same-clock-lens.md),
[creator compatibility](regional/ancestral-corner-constraint-certificate.md).

Additional accepted geometric interfaces cover the last critical target,
short-board common-corner labels, and empty-row limits. They improve the
proof tools but do not independently change the universal time ceiling.
The prior October 25 front/front and front/corner results were correctly
identified as retained results, not credited again as new discoveries.

## 5. An adversarial test produced another genuinely reachable improvement

A structured diagnostic covered 170 prescribed parameter cases using
either an ancestry lower certificate or a genuine cone construction. A
subsequent adversarial test deliberately searched beyond them and stopped
at a residual case on `102 by 124`, budget 72, terminal quota 36, testing
a 206-update gate against the old 207-update prefix gate. Three possible
scalar cuts survive. All-token creator ordering and pairwise lenses do
not reject them. Searching earlier genuine heads and tails also does not
make the known interpolation constructions succeed.

We then retained the actual layer defects across several ancestors. The
resulting integer witnesses suggested non-prefix boundary shapes. Those
shapes turned out to be physically reachable at their required clocks.
An actual 72-update head, 61-update direct middle, and 73-update suffix
give the 206-update solo gate. Its palindrome captures the full board
in 413 days. Independent literal replay and a separate four-clock lower
audit establish

    T_72(102,124) = 413.

This is the second verified failure of universal old-prefix optimality.
The role of the selected case was to expose and test the general route:
shared raw-layer constraints can suggest useful boundary shapes, but
those shapes still need actual arrival and suffix certificates. A feasible
relaxation is never promoted directly to a strategy.

Evidence: [adversarial diagnostic](compression/ancestral_cone_random_adversarial.json),
[all-token residual](compression/positive_credit_all_token_diagnostic.json),
[direct transfer residual](compression/direct_interpolation_positive_credit_probe.json),
[shared-layer relaxation](root/joint_ancestor_layer_probe.json),
[actual 413-day word](compression/raw_notch_gate_102_replay.json),
[independent replay](phase/raw_notch_413_independent_replay.json),
[independent lower audit](phase/raw_notch_413_lower_clock_audit.json).
The root also ran a separate bit-grid verifier, importing no discovery
code, on both 285-day words and the 413-day word:
[standalone replay receipt](root/verify_complete_words.json).

## 6. What remains between the two-day bracket and gap zero

The unresolved issue is **uniform compatibility of boundary shapes with
their actual arrival times and the shared budget**. The clean middle
transfer theorem does not assert that arbitrary favorable boundary shapes
can be created by the required earlier day.

The next decisive theorem must either construct a sufficiently rich
family of boundary shapes at their actual clocks, or prove that the
apparently favorable alternatives violate a shared history constraint.
It must retain all budgets, all lengths, every activation case, and both
physical phases. A larger collection of successful individual fixtures
would not establish this theorem. In particular, the now-resolved
102-by-124 diagnostic is evidence for a method, not a universal closure.

A final exact falsifier rules out another overly broad arrival claim.
On `12 by 12`, budget 7, a 22-cell one-sided notch in an own root-5
triangle is strictly subcritical (`5<6`). The scalar own-leading bound
reaches 22 at update eight, but this particular target cannot arrive then.
It would require a 20-cell predecessor inside a specified 27-cell
neighborhood with shadow at most 25. Two independent exact enumerations
of all 888,030 predecessors give minimum shadow 26. Thus even proper-root
raw profiles cannot be assigned their scalar leading clock freely.
[Independent predecessor check](root/verify_proper_root_predecessors.json).
This does not rule out a paired existence theorem selecting different
profiles, nor does it by itself refute greedy optimality within a suitably
restricted proper-root class.

## 7. Evidence and artifact boundary

New mathematical results here have ordinary proofs and independent agent
reviews. The stated finite certificates have reproducible exact checks;
literal strategy replays independently check the original grid game.
Diagnostic floating-point integer optimization is used only to find and
recheck feasible necessary-model witnesses, not to certify impossibility.

**No new Lean coverage is claimed.** The 83 retained Lean source files,
canonical manuscript, public website, PDFs, and download releases have
not been modified during this research window. This directory is the
private research checkpoint. Existing public claims must not be inferred
to include these new results until a separate synchronization and review.

This pass performs mathematical research and records it. It does not
reopen the parked higher-dimensional or varying-budget projects, and it
does not weaken the final closed-form completion criterion.

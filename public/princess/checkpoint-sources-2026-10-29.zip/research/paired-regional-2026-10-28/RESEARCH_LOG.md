# Research log: paired compression and regional lower bounds

## 2026-10-28 23:49 Pacific — start

The user authorized nine hours and specifically selected paired compression,
regional lower bounds, and phase-aware reachability. Read the 25 October
checkpoint and results; repository was clean at a385f04. Baseline is 3/2/1
as specified in PLAN.md. No new mathematical result at initialization.

Set up three complementary lanes and a same-thread continuation safeguard.
All provisional mathematics and experiments go below this directory. The
old combined proof artifacts and public release remain untouched.

## 2026-10-29 00:20 Pacific — first round and source reconciliation

Recovered and independently checked the existing odd-cylinder operator.
Its opposite-end application gives an exact paired regional-overlap
recurrence whenever a side is odd, but this is a consequence of prior work,
not a newly solved rectangle family. The existing square compression is
also relevant; unequal even-by-even boards remain the operator obstruction.

The regional lane derived an exact nonnegative row/run/vertical-incidence
decomposition of physical expansion. Independent exhaustive checks cover
74,420 one-color supports and 362,972 row identities. The root separately
checked the proof. Independent row-cardinality minima are much too weak on
even rows because their cheap endpoints conflict between adjacent rows.

A two-day interval replacement conjecture failed, including equal daily
caps, interval exterior beliefs, target containment, and interval envelopes.
The 4x6,k3 fixture is preserved and independently replayed. None of the
36 containment failures in that finite audit occurs on an optimal remaining
path. Thus whole-history or optimum-only replacement is still viable; a
local theorem preserving arbitrary exterior states is not.

Simple downward comparator networks do not provide an even-rectangle
operator. Their sparse-corner and co-sparse-corner failures suggested a
corner-distance distribution constraint. On 4x6, the lexicographically
selected pyramid satisfying all four corner-ball overlap inequalities
exactly reproduces the old successful finite CSP map. This is a promising
finite diagnostic, not a uniform theorem. It is being attacked on additional
shapes before investing in a general proof.

The phase lane drafted a necessary core/phase transfer with an explicit
one-hole charge for an incompatible change immediately after an occupied
origin. It also found an elementary high-budget span estimate that may
replace a huge discrepancy threshold inside the strict odd-width collar.
The root checked its numerical inequalities; physical dependencies and
exit/overlap obligations remain under review. No smaller capture-time gap
has yet been established. Root review: reviews/root-first-round.md.

## 2026-10-29 01:05 Pacific — accepted general range and stronger tools

The high-budget odd-width assembly has passed independent ordinary review:
for b>=512, every even n>=2b+1, and 3b<=k<=floor(15b/4), every signed
gate has its physical prefix clock P(c), and full capture is
P(k)+P(floor(k/2))+1 with the existing physical inspection construction.
This is an exact recurrence-based family, not a new global gap ceiling.
The global cheap brackets remain3/2/1 in the baseline ranges. The assembly
is phase/high-budget-exact-gate-assembly.md; its source dependencies and
independent review are preserved separately. No new Lean coverage.

Two geometric/interface improvements made this possible. A critical
full front contains a board-truncated ball centered at an interior point
of the near boundary, of radius at least b-4. This roughly doubles the
previous persistence radius; it is used for phase, not silently as a
corner-centered overlap marker. The signed reverse argument now clips at
A=Z-k without the unnecessary A>L restriction. At a co-small good crossing,
the actual dual support supplies its own strong opposite-end marker;
this repairs the safe-predecessor branch that had no dangerous ancestor.

Separately, a complement-dual adjunction lemma proves that any legitimate
monotone cardinality-preserving neighborhood compression also compresses
the reverse history, and the paired endpoint intersection cannot increase.
It also handles compatible time-dependent operators. This is a reusable
proof tool; the unequal-even-rectangle operator remains unconstructed.

An elementary discrete-to-integral travel bound now proves strict-collar
matched-phase necessity for every k>=ceil(7b/4), b>=512, all genuine first
quotas. Root checked the integral, logarithm estimate, and subcritical
core comparisons; a small explanatory arithmetic clarification was sent
to the author. This supersedes the new2b continuation special case. It
does not automatically extend the exact capture family: common-cut
overlap and late interfaces still have their own guards.

The compression diagnostics falsified static corner-CDF selection in6x6
despite success in4x6 and4x8. Adding fixed-pyramid overlaps does not repair
monotonicity. Fixed-exterior local interval surgery and a universal future
endpoint are also false; all counterexamples retain their exact scope.
The lanes are pivoting toward global paired replacement, physical
transport, and anchored regional loss. In particular phase changes may
pay for simultaneously maintaining two fronts, a cost omitted by the
generic one-unit bad-step charge. Induced odd-subrectangle projections
are being investigated as a way to retain this shared-budget cost.

## 2026-10-29 01:43 Pacific — phase comparison without a width cutoff

The paired odd-subboard projection theorem and minimal-original-surplus
coherence have passed independent ordinary reviews. For every odd width
2b+1, b>=1, every even length, and arbitrary inspection quota words, the
two actual aligned regional counts satisfy their alternating capped
shadow inverses. Together with the actual total hole count, these give
the three-invariant strict-collar envelope without any width, span,
core-lifetime, or occupied-origin guard. The scalar comparison follows
because a minimum-surplus target has a genuine matching regional phase;
every other nonempty target pays the stronger minority cost. This is
mathematical unification, not a regrouping of old special cases.

The root's independent literal attack checked4,342,844 regional shadow
inequalities over the listed finite boards, all passing. The theorem
itself has an ordinary proof, independent of this finite evidence.

The same actual regional invariants initialize the signed reverse word
directly. The independently accepted all-budget projected reverse
theorem now applies for b>=2, b+1<=k<Z=h-b², all terminal quotas. It
removes the old width, core, and natural-budget guards from this reverse
interface. Both results remain necessary-history statements: they do
not assert joint attainability or endpoint intersection.

The global cheap capture bracket remains gap3, with its existing gap2
and gap1 refinements. The common-cut geometry and first co-small
localized crossing still require work. A full-front crossing is now
phase-controlled directly because the old holes omit its entire near
boundary. A localized critical survivor leaves a genuine boundary debt
of at most its missing-triangle area plus1; discarding that1 is invalid.

A quick exact diagnostic of the disconnected odd-rectangle plus omitted
boundary-path relaxation loses4 days at width3 and8 days at width5 at
minimum budget. No larger campaign is warranted; cross-interface or
simultaneous overlapping-region information is essential.

## 2026-10-29 02:47 Pacific — terminal gates distinguish useful refinements

The six-region relaxation keeps both end columns and the interior in
each physical color, all regional shadows, and one shared daily quota.
Its overlapping odd-subboard constraints and wall-path constraints are
both necessary in the tested low-budget histories. Exact E1 elimination
removes the three-region quota-allocation search. Complement duality
adds the same phase-coherence requirement to the original survivor.
The root independently checked 4,212,096 literal regional inequalities.

Two attractive history-wide wall inequalities failed in the count
relaxation. In particular 9x10 at k7 permits a maximal projected count
with the wrong wall occupied. These are counterexamples to the proposed
relaxed invariants, not physical strategies. No proof of those assertions
should be attempted without a materially stronger state. The accepted
minimum-surplus wall-capacity lemma instead constrains only actual
cheap events; it retains a triangular-defect wall bound and handles
small roots and rigid singleton splits explicitly.

All 1,057 sampled solo completion clocks (odd widths 3 through 15,
lengths w+1 and 2w+2, all feasible budgets through h) matched the literal
reflected-prefix construction under the strengthened regional model.
All 92 full mixed capture cases on 3x4, 5x6, and 7x8 also matched.
These are finite evidence only. Intermediate maxima need not match:
7x8,k12 admits a relaxed two-update mass18 versus prefix17, but both
finish with the same remaining budget. We do not make exact partial
maxima an additional completion obligation.

The more relevant half-budget gate audit found 15x16,k53,c26: a relaxed
two-update endpoint has94 holes instead of prefix93, so it passes a
gate the prefix misses. Its proposed cheap supports have sizes46 and21,
roots7 and5, and defects3 and4. The actual same-end localized containing
triangles overlap in10 cells, exceeding the combined defect7. A critical
full-front alternative fills all8 own-wall cells and is also incompatible
with the later support's forced wall occupancy. Thus this false terminal
gate is excluded by real common-cut geometry. This identifies a useful
missing condition, rather than another harmless intermediate discrepancy.

The exact distributed-defect erosion identity from October24 already
preserves the original triangle defect through arbitrary intervening
updates. It must be used directly instead of discarding most of the
region and retaining only a full inner core. The outstanding uniform
task is to combine actual ages, shared quota excess, and exact overlap
at a common cut so that every too-fast word receives such a contradiction.

In the even-width lane, exact row-prefix shadow defects have now been
identified cell by cell. Oppositely oriented zero-growth rows force a
spatial interface charge at least their symmetric difference. The
proposed bound min(d_left,d_right)<=sigma-b+1 survives the finite audit
but is still a conjecture; same-budget temporal matching of defects
and savings is a separate, unresolved theorem.

The global cheap bracket remains gap3. The accepted new exact linear-
budget family and the all-b strict-collar/reverse interfaces are retained.
No new Lean coverage or publication has occurred in this research pass.

## 2026-10-29 03:35 Pacific — exact short gates and sharp static geometry

The two-update signed-gate decision is now proved for every odd-width,
even-length rectangle, k<Z and every terminal c<=k. The sole ambiguous
MAX/MAX equality forces actual dense own triangles at the same end;
the board-area inequality forces their exact intersection to exceed
their combined defects. A separate mixed-survivor argument excludes
rescuing the gate by inspecting both original color cohorts. Root
independently reviewed the proof and the trimmed opposite-prefix
construction. Hence full capture is exact whenever the two canonical
gates are at most three updates (canonical full capture at most seven
days). This is a uniform new family, not global closure.

The same convexity argument excludes an arbitrary own good-to-sensitive
own good common cut, and an opposite/opposite good common cut, under
the natural budget inequality. A real nonsensitive own/own cut is
compatible and must not be excluded by a stronger false conjecture.

Root proved exact static packing for two adjacent-corner raw triangle
supports: disjoint representatives of the desired sizes exist exactly
when their combined defects cover the triangular lens. A constructive
order-ideal partition proves sufficiency; 20,000 random cases checked
the construction. Thus static triangle information alone cannot improve
that obstruction. Any remaining improvement must use actual history.

Root also obtained an exact static front/triangle overlap evaluator for
all widths, lengths and color parities. A proper partial overlap forces
all front heights below R+w-3, independently of length. A finite row
recurrence computes the maximum area at each overlap in O(w^4) time
and O(w^3) rolling memory. Independent literal enumeration checked
155,761 front paths across 162 cases. This is an exact geometric tool,
not an O(1) capture expression or a reachability theorem.

A sensitive numerical phase advantage has an actual minimum-surplus
creator. However its original triangle need not remain nonempty while
the advantage survives: b10,k19,first seed15, seven minority updates
lead to89 while the genuine pair is(88,90). This defeats a tempting
creator-lifetime shortcut even relative to min W. Nonsensitive cheap
events can refresh its geometric support. The exact no-refresh map
is instead I0(Q+k-1), because every such actual update has original
surplus at least f0+1. A bounded scalar diagnostic checked 2,318,450
possible seeds without finding a no-refresh survivor beyond its raw
radius; this is evidence only, and the precise uniform inequality is
now the next target.

The even-width lane clarified bottom-root deletion for physical pyramid
images, but source review showed that the principal regularity result
and the fixed-word counterexample were already known. They are
rederivations and failure shields, not new results. The genuinely open
positive-excess compression and temporal exchange issues remain.

No canonical manuscript, website, PDF or Lean source has been changed.
The global uniform cheap gap remains at most three.

## 2026-10-29 04:26 Pacific — uniform phase windows and genuine access costs

The genuine capped pair now satisfies a uniform signed-span invariant for
all b>=2 and feasible k. A dangerous localized seed of root r has phase
advantage at most r-1; the opposite-leading case has r-2 apart from one
explicit tiny seed. Root review found and repaired a small-coordinate
preservation error. Together with the already proved October24 two-bad-
step contraction, this bounds the age of every actual last-cheap ancestor
by2b-3, and by2r-3 in the localized case. The old one-wall history ledger
therefore has no remaining small-root or width guard. The contraction
itself was rederived, not a new result.

A uniform physical central cut is now available on odd-width/even-length
boards for b+1<=k<=2b+1. Last-full normalization and the actual mixed
signed bound establish the one-cohort attachment at a failed adjunction;
this cannot be replaced by freely choosing a cohort for a rigid set.
The new exact last-cheap-pair necessary evaluator retains actual quota
words, all possible seed types, original triangle defects, front erosion,
and ONE shared allowed-intersection budget. It rejects all candidate
pairs in the deliberately chosen9x10,k7,33x34,k25, and257x258,k208
fixtures. Uniform rejection is still open; these are not coverage claims.

Root and the regional lane found a stronger reverse interface. It is
enough that the PREVIOUS backward reference lies below Z: all actual
reverse erosions then stay in the collar, even when the final allowed-
source bound exceeds Z. The mixed cap extends to X=k+Z-3, and its minimum
coordinate is automatically strictly below X, including b2. This removes
an artificial corridor failure in33x34,k62; at the balanced cut both
actual scalar capacities already total less than the board. A uniform
existence proof for such a cut is now under examination.

The even-width lane proved a real boundary-access distinction on6x6,k4.
A seven-cell own-corner triangle missing both axis tips first becomes
reachable (even as a subset of actual holes) on day7, while another raw
shape with the same mass and surplus is reachable on day5. Two independent
literal state evaluators agree. At day4, every reachable six-hole source
has a compulsory corner outside the target's neighborhood, making five
new inspections necessary. Thus mass/root/defect and neighborhood closure
do not determine physical access. The result motivates regional ancestry
charges; it does not disprove an optimal paired normal form.

A central component stability estimate bounds satellite mass by the
square of surplus excess when a component exceeds the small collar.
However a transverse full front on the shortest odd-by-even board has
only one surplus unit above the longitudinal minimum. Static near-cheap
stability therefore cannot force a longitudinal orientation. Current work
keeps orientation changes and their actual access/exit costs explicit,
and will test constructive shortcuts as well as stronger lower bounds.

No canonical Lean/manuscript/site/PDF files have changed. Global cheap
gap remains at most3; the accepted new exact families and uniform proof
interfaces are retained without claiming complete rectangle closure.

## 2026-10-29 04:34 Pacific — all-budget protected-cut interface closes

The new finite-horizon reverse interface yields a uniform cut-existence
theorem. For every odd width2b+1 (b>=2), even length, feasible k<Z, and
terminal quota c<=k, EVERY deadline faster than the physical prefix
clock admits a cut at which the actual forward history and actual
reverse erosions stay in their strict comparison collars. The proof
uses threshold times a,q, the uniform span<=b-1, and the simple bound
min C_(a+1)>=Z-2b; physical prefix subsolutions then force P<=a+q+1.
Root independently reviewed all indices and the actual mixed/solo
attachment. The separate first-co-small transition analysis is therefore
not needed to establish this full-origin gate interface. This is a
mathematical consolidation, not just a regrouping of statements.

The remaining odd-width problem is now genuinely endpoint compatibility
inside that common-cut framework. The new arrival-time integral gives a
root-dependent bound on the genuine phase span, keeping arbitrary first
quotas and actual shifted indices. Root checked the finite inequality;
its asymptotic normalized expression is only a guide for the next shared-
radius estimate. No universal pair rejection or global gap improvement
has yet been proved.

## 2026-10-29 05:55 Pacific — global two-day bracket and exact large-width corridor

Independent review accepted the all-odd-width gate bracket P(c)-1<=g(c)<=P(c).
It uses the protected physical cut and one genuine interlacing step, not
an unproved compression normal form. Together with the existing terminal
quota identities it gives a two-day full-capture bracket at every odd
width, every even length, and every feasible budget. A read-only audit of
the older October23 authoritative assembly verified seven pinned hashes
and 1650 small-even-width budget/parity records: those retained even-width
results already have a two-day ceiling. The only older gap-three residue
families were odd widths47 and61, both covered by the new theorem. Combined
with the retained large-even-width theorem and odd-by-odd exact evaluator,
THE WHOLE-DOMAIN GAP IS NOW AT MOST TWO, rather than three. No gap-zero
claim is made.

The localized shared-radius certificate was strengthened with explicit
finite errors and independent exact-integer replay. A dyadic bridge from
79b/64 joins the older natural low-budget range with no integer hole.
The remaining full-front issue was resolved by moving the actual protected
cut toward the midpoint between the two real front births. An original-
area row-support bound, independently reviewed by all three lanes, then
forces too much actual overlap. The clamped-cut proof keeps physical time,
cohort, color and a newly recomputed allowed intersection; it does not
reset either history. These arguments establish exact signed gates for
b>=4096, w=2b+1, every even n>=w and every b+1<=k<=3b, uniformly over all
terminal quotas c<=k. The capture value is P(k)+P(floor(k/2))+1, with the
retained explicit prefix/palindrome inspections. The earlier accepted
new-turn band b>=512,3b<=k<=floor(15b/4) remains available.

The higher-budget central cut now has one formula for all2b<=k<b(b+1),
all b>=2 and all lengths. Root checked its previous-index reverse guard,
endpoint masses and constant travel loss. This closes an interface, not
the remaining endpoint compatibility theorem. The next direction uses
sharper arrival-span constants and the actual shared deficits, aiming at
one broad subquadratic corridor and then a bounded boundary-history tail.

The regional lane proved that static raw-triangle defect subtraction is
sharp. A literal6x6,k4 reachability obstruction survives aggregate target/
exterior counts but is detected by diagonal-layer demands. Thus the next
lower-bound tool must retain where a missing tip was manufactured over
time; another static mass/root/defect inequality cannot supply that cost.
The compression lane is testing whether coupled terminal quotas or a real
central splice can remove a second day globally. Simultaneous scalar
ambiguities for both quotas exist, so it cannot assume one quota exact.

No canonical manuscript, website, PDF or Lean file has changed. All new
claims are ordinary proofs or explicitly described finite certificates;
no new formal coverage or O(1) evaluation is claimed.

## 2026-10-29 06:23 Pacific — every budget at large odd width; source-audit correction

The large-odd-width theorem now covers EVERY feasible budget and every
even length at b>=4096 (w>=8193). The analytic corridor3b<=k<=floor(b²/20)
uses a sharper genuine arrival error below2 and the strict shared deficit
to force each localized root above3b/5. The remaining quadratic tail is
handled by genuine seed indices: both localized indices are at most21,
and the TWO clocks' full-board scalar fit reduces the proof to924 fixed
rational inequalities, each independently replayed. Their retained-radius
margin is11/10, sufficient for the literal lens. All dangerous tail
ancestors are at most23 updates old, so the full-front alternatives are
also excluded. Onlyc=k andfloor(k/2) are needed in this tail; no stronger
all-c assertion is made. The old exact high-budget theorem completes
k>=b(b+1)+1. This is genuine all-budget/all-length coverage at every odd
width>=8193, while retaining the recurrence and actual optimal inspections.
It does not solve even widths or all smaller odd widths.

A source audit corrected an attempted new-even-coverage claim. We had
consulted the October24 gap list; the October25 checkpoint had already
proved the longitudinal front/front and missing front/corner barriers,
and a controlled reverse-deficit theorem. Those rederivations are NOT
new achievements. The stronger genuine even endpoint span g<3b/5+7 is
a new uniform numerical tool; it may shorten arguments or lower a
conditional threshold, but the already accepted b>=128 longitudinal
consistency result must retain its earlier credit. The user was told
this correction immediately. Future work now uses the October25 current
boundary/terminal/transverse gap list.

The regional lane supplies a uniform necessary diagonal path-shadow
history recurrence. Each local table has a four-bit path scan with six
bounded count counters, O(w^7) work/O(w^6) storage. The global history
state count remains uncontrolled. It detects the raw6x6 target's ancestry
obstruction, whereas aggregate target/exterior/corner counts and a linear
weighted relaxation do not. Its purpose is to keep the actual cost of
creating missing layers, not to rename an exponential optimization as a
closed answer. The small target also now has an ordinary saturated-seed
ancestry proof. Static raw defect subtraction remains sharp.

The global computable constructive bracket remains at most two days wide.
No new Lean coverage, public release or O(1) simplification has occurred.

## Later window — genuine reverse cap and inherited creators

The shifted reverse bound was extended to the full pronic cutoff H=b(b-1).
The proof uses the actual earlier boundary induction and its last inverse
step; it does not pad a partial reverse set into a fictitious full-origin
history. This removes the previously smaller A=b²-k+1 interface cutoff
for the even low-budget regime. Independent review accepted the argument.

New sensitive-ancestor tests preserve actual forward holes, reverse
allowed survivors, activation indices, and physical days. Excess tokens
have unique mass preimages at their genuine creator clocks. The ordinary
matching branch fixes a permitted phase, and several surviving excess
tokens have strictly ordered births. Necessary corner/trajectory/lens
constraints now share these actual creators. They must not be read as
sufficiency: feasible creator assignments are not yet inspection words.

Critical-endpoint geometric refinements were accepted, including the
final H+1 target, one-longer-board common-corner labels, and the two-empty-
row limit. The new statements retain their explicit size and budget
guards. Previously established front attachment results retain their
October25 attribution.

## Later window — fixed-prefix optimality is false

A physically constructed tilted gate on64×93, budget48, reaches terminal
quota24 in142 updates although the fixed-corner prefix takes143. Its
142-update solo word yields285-day full capture by the valid solo
palindrome. A full literal replay from all5952 rooms checked every quota
and the first empty state. A separate physical implementation reproduced
it. A four-clock common-cut calculation independently proves the matching
285 lower bound. Therefore T48(64,93)=285, while the old fixed-prefix
upper construction gave286.

This changes the universal research target. Proving all old prefix gates
optimal would be false in the low-budget even-width range. Genuine shape
flexibility is necessary; the large-odd-width theorem has different scope
and is not contradicted.

The construction was generalized to a whole reachable cone of canonical
endpoints and an exact matching-cover bridge criterion. It retains a
possible exposed root and the quota required to cover it. An earlier head
on the same affine-credit plateau has a smaller surviving old front and
dominates a later head. Restricting the construction to the lower-bound
pronic cut was an unnecessary obstruction. Literal96×97,budget50 gate516
provides a second concrete check of the earlier-head mechanism.

## 2026-10-29 08:15 Pacific — direct transfer and an adversarial residual

The two-inspection bridge can be avoided under a clean exact endpoint
criterion. For an actual canonical hole head X and a compatible canonical
allowed tail Y, the target Z=Y\D^Delta X is canonical. Under the specified
area/regularity guards, the overlap fitting the shared middle credit is
necessary and sufficient for a transfer with the specified drift bound.
The existing physical interpolation theorem constructs all Delta updates.
This is an exact conditional middle theorem, not a statement that every
full-board optimum uses canonical boundary endpoints.

The direct theorem independently constructs the64×93 gate with41 head,
62 middle and39 tail updates, and its285-day full capture word was
replayed. Thus the upper improvement does not depend on an unverified
two-step splice.

A prescribed170-case diagnostic found165 ancestry rejections and5
constructive cone successes. A subsequent adversarial seeded diagnostic
stopped at case264:102×124,k72,c36, proposed gate206 against prefix207.
There are three scalar cuts, all e75/ell73/Delta58, with shared gap2.
They survive all-token creator order and pairwise lenses. The strongest
case has a28-cell lens and exactly19+9 raw defects. Earlier actual heads,
tails, direct interpolation, and one-shot tail freedom do not immediately
close it. The lesson is that a successful finite diagnostic does not
justify a universal complementarity theorem.

Root added a necessary shared raw-layer model retaining the same defect
profiles across several creators. It is still feasible for the selected
assignments; rounded integer witnesses were checked against every model
constraint. One row has actual allowed overlap1 while the diagnostic
tests the stronger zero-overlap subcase; it remains feasible, and no
exclusion claim is made. This is not a solver-based impossibility proof.

Crucially, compression then constructed all three suggested FORWARD
root50 notch profiles by their actual required clock72, using backward
neighborhood construction and literal forward replay. So those shapes
cannot be rejected merely because the ordinary prefix puts all defects
on an outer layer. Current work is testing a genuine reverse suffix and
the direct middle transfer with these new reachable heads. A cumulative
surplus/leakage identity tracks the one unit of slack in their four-step
root49-to-root50 transition; it is a proof tool, not a contradiction.

## 2026-10-29 08:28 Pacific — the raw-layer witness becomes an actual word

The102×124 diagnostic is now resolved constructively and optimally:
T72(102,124)=413. The actual head reaches a root50 triangle with a19-cell
distributed notch in72 updates. A61-update direct middle reaches a2562-
cell allowed belief. A71-cell inspection leaves the genuine2491-cell
reverse notch, followed by its actual72-update suffix to36 survivors.
This is a206-update solo gate. The center has72 rooms; its solo palindrome
gives413-day full capture. Compression recorded every inspection; phase
independently replayed every day with separate grid semantics.

The lower audit tests a205-update quota72 gate. Only four scalar clock
pairs need consideration, and every total shared allowance is minus9.
Thus G72>=206, matching noncontraction gives G0>=207, monotonicity gives
G71>=206, and the retained all-split capture lower bound gives413.

This is a successful lower-to-upper synthesis loop, not a whole-domain
proof. The broad normal-form question remains: can every unresolved
full-board horizon be decided by a sufficient family of genuinely
reachable raw boundary profiles and the exact central transfer rule?
No proof of that exhaustiveness or of greedy arrival optimality exists.
The whole-domain guaranteed gap remains two; no numerical simplification
was started.

## 2026-10-29 08:43 Pacific — final independent challenges

A fresh standalone bit-grid verifier, importing no discovery code,
replayed both285-day constructions and the413-day construction from the
full boards. Every quota passed and the first empty states were exactly
the claimed capture days. Source hashes are retained in its receipt.

The generalized raw-pair upper criterion now allows positive inherited
overlap, paid by the actual first-tail quota. Its regular rank-fill
family has an explicit row-occupancy repair count; no arbitrary endpoint
selection or extra movement is hidden. Its necessary inputs are actual
head and suffix words, canonicality, phase, area, and regularity.

The final challenge refuted an overly broad proper-root arrival claim.
On12×12,k7, a22-cell own root5 one-sided notch has scalar leading clock8,
but would need a20-cell predecessor inside its27-cell neighborhood with
shadow≤25. Phase enumerated all888030 predecessors; root independently
rebuilt all neighborhood unions with exact integer masks. Both find
minimum26. So not every proper sensitive profile arrives at its scalar
clock. A separate6×6 critical-root example refutes unrestricted fixed-
corner greedy optimality. Neither result refutes the narrower needed
existential paired-boundary reduction.

The remaining research should either prove such a quota-preserving paired
normal form, with exact arrival evaluation for its chosen profiles, or
strengthen the necessary history model until it is equivalent to a
constructive test. A normal form for actual physical histories and
completeness of today's necessary relaxation are different claims. The
current relaxation has not been proved complete. Its sensitive profiles
have small raw-defect partition descriptions, which are promising state
variables, but enumerating those partitions alone is not a solution.

The final source audit caught and repaired a genuine guard issue in the
12×12 counterexample: an older ordinary envelope assumed k>=13. The
proof now projects onto the induced11×12 subboard and invokes the NEW
all-b/all-quota strict-collar envelope. A perfect matching keeps its
first seven projected states below the strict cutoff36. This proves the
needed LOCAL bounds18 and20. The20-cell predecessor and its neighborhood
both lie wholly inside that subboard, so the exact local enumeration
applies without assuming a bound on holes outside it. Root independently
checked this repair. No old minimum-budget hypothesis was silently dropped.

# A finite-horizon signed reverse bound past the fixed clipping level

29 October 2026. Root ordinary proof candidate, for independent review.
This strengthens an interface, not a capture classification. No Lean
coverage or public release is claimed.

Let w=2b+1, n even>=w+1, b>=2, h=wn/2, U=h-b(b+1), Z=U+b,
b+1<=k<Z, and 0<=c<=k. Use the genuine capped backward pair

    V_0=(c,c),
    V_(j+1)=(k+I0(V_j[1]), k+I1(V_j[0])),
    W_j=V_(j+1)-(k,k).

Put X=k+Z-3. For a t-update signed suffix with t>=1 assume

    max V_(t-1)<Z.                                      (F1)

Then every actual last-full-normalized source reaching signed gate c
obeys the UNCLIPPED bound

    m_source<=max V_t.                                  (F2)

If it is already in the permanently mixed suffix, the stronger right
side min V_t applies. The case t=0 is simply the actual gate condition.

## 1. Mixed comparison with a larger safe clipping level

Use the same actual signed survivor accounting as Section3 of
`all-budget-projected-signed-reverse.md`. Start either comparison phase at
0<=x<=min(max(m,0),X). If x<=k, its next comparison is zero. Otherwise
u=x-k and phi_p(x)=u+f_p(u). For an actual mixed update its signed
post-inspection survivor mass q satisfies q>=m-k>=u. When q>=phi_p(x),
nonnegative original surplus suffices. Otherwise

    0<q<phi_p(x)<=X-k+b+1=U+2b-2.

The accepted mixed small-boundary and strict mixed central profiles
therefore give the required original surplus f_p(u), exactly as in the
previous proof. This establishes both phase comparisons, including the
activation update whose two post-inspection survivor supports are proper.
The comparison value never increases because k>=b+1, so the same safe
cap remains valid throughout the suffix. Hence an r-update mixed suffix
reaching c has

    min(max(m,0),X)<=min V_r.                            (F3)

No claim about arbitrary mixed states beyond X is used.

## 2. Every actual reverse erosion remains in the strict collar

Suppose the normalized source has a>=1 solo updates before its final
mixed suffix of r=t-a updates, where r may be zero if no activation
occurs. By(F3), its actual smaller activation cohort D satisfies
min(|D|,X)<=min V_r. Since r<=t-1, coordinate monotonicity and(F1) give
min V_r<Z<=X. Thus |D|<=min V_r<Z. If r=0 instead use the actual terminal
set |D|<=c. The existing one-shot projection proof supplies

    J_0=E(D),   |J_0|<U,
    |J_0|<=max W_r,  Z^p(J_0)<=W_r[p].

Reverse the actual solo inspection sets as in the accepted allowed-set
construction:

    C_0=D, C_(i+1)=I_(a-1-i) union E(C_i), J_i=E(C_i).

Before any later reverse erosion J_i, i>=1, the available set has size at
most max W_(r+i-1)+k=max V_(r+i). For all i<=a-1 this is at most
max V_(t-1)<Z. Every erosion of a set of size <Z has total holes <U,
by the accepted joint small/co-small separator (and perfect matching).
Thus ALL actual compared reverse states remain in the strict collar.
The three projected inequalities propagate at every step, yielding

    |J_(a-1)|<=max W_(r+a-1)=max V_t-k.

The original actual source is contained in C_a, and therefore

    m_source=|S|<=|C_a|<=k+|J_(a-1)|<=max V_t.

This is an actual, unclipped solo conclusion, with the real allowed-set
excess retained. There is no invented reverse prehistory.

For an already mixed source a=0, use(F3) and the strict bound in the
next section. This proves(F2).

## 3. The mixed branch is automatically unclipped, including b=2

Monotonicity and(F1) give

    min V_t<=k+I1(Z-1)=k+U-2<X=k+U+b-3.

Indeed ceil_sqrt(Z-1)>=b+1, since n>=2b+2 gives
Z-1>=b^2+3b. The last strict inequality is b>=2. Thus the MIXED
minimum-coordinate bound from(F3) is strictly below its clipping level,
and gives m_source<=min V_t. The solo branch already gave its actual
unclipped source estimate directly. No extra max V_t<X guard is needed;
it would unnecessarily lose a b=2 endpoint. Regional independent review
identified this simplification.

## 4. Common-cut use

At a proposed cut, a forward strict-collar reference C_s can be certified
through s whenever its last available input satisfies

    max C_(s-1)+k<Z.

Monotonicity supplies the same certificate at all earlier updates.
If the remaining suffix has t updates satisfying(F1), both actual sides
now admit their genuine capped bounds even if max V_t>=Z. If a failed
cross-phase adjunction forces m_source>min V_t, the actual
cut cannot be in the mixed suffix; the one-cohort attachment follows as
before. In the solo case the real reverse endpoint and its projections
are available for the joint-deficit/ancestor geometry.

Example: w33,n34,k=c62, h561,U289,Z305, at forward cut5 and remaining
suffix5, C4=(201,201),C5=(247,246),V4=(263,263),V5=(309,308),X364.
Both finite-horizon guards hold (263<305). Actual early holes are at most
247 and any source of the remaining5-update suffix has at most309 cells.
Their sum556<h561, so the proposed10-update signed gate is impossible.
The older fixed clip at Z did not establish this because max V5>Z.
This example is an interface diagnostic, not a separate research target.

## Boundary

The guard max V_(t-1)<Z remains. This theorem does not cross an arbitrary
actual co-small erosion, prove physical/capped agreement at all later
indices, or exclude every phase-compatible ancestor pair. Its role is to
avoid declaring a co-small gap solely because the terminal reverse bound
exceeds Z although every actual erosion used in reaching it is still
strictly inside the collar.

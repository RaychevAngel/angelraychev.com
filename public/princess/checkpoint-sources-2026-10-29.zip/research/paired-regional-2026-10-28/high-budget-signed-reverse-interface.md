# High-budget shifted erosion and signed reverse necessity

29 October 2026. New ordinary proof candidate. Depends on the independently
reviewed strict-collar theorem in phase/high-budget-phase-continuation.md.
Submitted for independent attack. No capture-time equality follows alone.

Let w=2b+1, n even and n>=w, h=wn/2, b>=512. Let

    3b<=k<Z,  Z=h-b^2,  d=k-b,
    U=h-b(b+1), A=Z-k=U-d>0, L=(b-1)^2,
    0<=c<=k.

Define the genuine capped backward pair

    V_0=(c,c),
    V_(j+1)[0]=k+V_j[1]-min(rho(V_j[1]),b),
    V_(j+1)[1]=k+V_j[0]-min(ceil_sqrt(V_j[0]),b+1),
    W_j=V_(j+1)-(k,k).

This W is exactly the genuinely capped first-quota pair in the new strict
collar theorem. Both V and W are coordinatewise nondecreasing. The claim
below does NOT require A>L.

## 1. Shifted actual-set initialization

Fix r>=0 and an actual one-color set D with |D|<=min V_r. Set J_0=E(D),
and let J_(i+1)=E(J_i union I_i) for arbitrary inspections |I_i|<=k.
Then

    min(|J_i|,A)<=min(max W_(r+i),A)                 (R1)

for every i, including excursions outside the collar.

If max W_r>=A, the assertion is immediately true at all later times. Assume
max W_r<A. Then V_(r+1)=k+W_r has maximum strictly below Z. Monotonicity
gives |D|<=min V_r<Z without any inversion or an A>L assumption.

For r=0 this is a genuine first-quota erosion and the strict-collar theorem
supplies its initial invariant; use the clipping argument below to continue.
For r>=1 write M=|D| and q=|E(D)|. Its original one-shot surplus is M-q:
the original survivor is the complement of D in its physical color class,
whose neighborhood is the complement of E(D).

If q<=L, it is already below U. If q>L and M-q<b, the accepted subcritical
small/co-small separator would force q>=U+2b>M, impossible because M<Z=U+b.
Hence q>L implies M-q>=b and q<=M-b<U. Initialization is therefore actually
inside the strict collar for every shape D.

The strict-collar original-surplus classification now applies. A good
target q has its actual end/cohort phase p and the corresponding capped
incoming cost. Since BOTH entries of V_r are at least M, inverting that
cost bounds q by W_r[p]. A nongood nontiny target has one extra unit of
original surplus, so it is below BOTH entries of W_r. Tiny q<=9 is also
below both: r>=1 gives min W_r>=k-b-1>=2b-1. Thus in particular q<A.

Continuation uses the actual core of this initial good target, if any, at
the genuine reference index r. The new high-budget proof's positive-time
subcritical estimate uses min W_u>=u(k-b-1), and its critical estimate uses
the genuine global span. Both apply at u=r+i. Neither requires a physical
history before J_0. Its initial radius is an actual subset of E(D); subsequent
erosion persistence is physical. At r=0 retain the sensitive-origin special
case from the first-quota theorem. Therefore the matched-good and scalar
maximum statements continue while all actual counts remain below U.

## 2. Safe clipping when A is below the critical root bin

Suppose a history starting below A first reaches A on an update from an
old count at most A-1. Its raw target accounting gives

    Qnew+sigma<=A-1+k=U+b-1.

If Qnew<=L, it is below U already. If Qnew>L, a surplus sigma<b would
again require a co-small component of size at least U+2b, contrary to the
raw bound. Thus sigma>=b and Qnew<=U-1. The strict-collar theorem is valid
through this first crossing, so the reference maximum has reached A too.
Every subsequent clipped assertion is tautological by reference monotonicity.
Before that crossing use the strict-collar statement directly. This proves
(R1), and also its genuine first-quota version. If the initial reference
already reaches A, there is nothing to prove; otherwise the preceding
initialization puts the actual state below A.

The dichotomy Qnew<=L or Qnew>L is essential: one cannot claim sigma>=b
merely from Qnew>=A when A<=L.

## 3. Permanently mixed suffixes dominate both capped phases

Retain the existing last-full normalization of an actual finite gate word.
Let m be its signed mass (belief size minus h). On a permanently mixed
suffix both post-inspection survivor cohorts are proper, including the
activation inspection. The two necessary residual maps are zero for x<=k,
and otherwise, with u=x-k,

    phi_0(x)=u+min(ceil_sqrt(u),b),
    phi_1(x)=u+min(1+rho(u),b+1).

Their inverse thresholds are exactly V. Start either phase with
0<=x<=min(max(m,0),Z). To propagate x'<=max(m',0), let q be the actual
signed survivor mass, so q>=m-k>=u when x>k. If q>=x', nonnegative total
original surplus suffices. Otherwise

    0<q<x'<=Z-k+b+1=U+b-d+1
             <=U-b+1<U+2b-2=h-b(b-1)-2.

For q>=L, the accepted strict mixed central barrier gives original surplus
at least b+1, enough for both capped costs. For q<L, the accepted mixed
small-boundary profile gives both ordinary costs, hence both capped costs.
Thus either initial phase is controlled. A mixed r-update suffix reaching
gate c consequently has min(max(m,0),Z)<=min V_r.

This is the same physical comparison as the previous signed-late proof;
the larger k only decreases the upper endpoint of the nontrivial q interval.
No extension of the mixed geometric barrier is being assumed.

## 4. Reverse the actual solo segment

For any normalized source with t remaining updates to signed gate c,

    min(max(m_source,0),Z)<=max V_t.                  (R2)

If it is already in the permanently mixed suffix, Section3 is stronger.
Otherwise suppose activation follows a solo updates, with r=t-a>=1
updates from its pre-state through the gate. Let D be the actual smaller
cohort at activation. Section3 gives min(|D|,Z)<=min V_r. If min V_r>=Z,
(R2) is trivial. Otherwise |D|<=min V_r<Z.

Reverse the real solo word: C_0=D and C_(i+1)=I_(a-1-i) union E(C_i).
Put J_i=E(C_i). For a>=1 the actual source S is contained in C_a, so
|S|<=k+|J_(a-1)|. Apply (R1) at its actual reference index r+a-1:

    min(|S|,Z)
      <=k+min(|J_(a-1)|,A)
      <=k+max W_(r+a-1)
       =max V_t.

At a=0 Section3 applies directly. If no activation occurs before the gate,
use the actual terminal set of size at most c and the genuine first-quota
version instead. A zero-update suffix is immediate. This proves (R2).

## What is and is not supplied

This supplies the shifted actual initialization and clipped signed reverse
necessity throughout 3b<=k<Z, b>=512. In the proposed common-cut range
3b<=k<=floor(15b/4), A is positive on every allowed board. A<=L causes no
gap after the explicit first-crossing dichotomy above.

At a common cut where failed physical adjunction gives backward maximum
<Z, the already established physical/capped backward agreement applies.
Then max W<A, so (R1) is unclipped at the actual reverse endpoint. The
allowed-set surplus and shared-deficit ledger must still be retained;
this note does not replace the separate overlap proof or forward cut.
No new Lean coverage, release, or uniform gap-zero claim is made.

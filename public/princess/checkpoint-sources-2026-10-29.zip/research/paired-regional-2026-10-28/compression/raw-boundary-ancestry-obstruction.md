# A raw corner target with a genuine full-origin ancestry obstruction

29 October 2026. Independently replayed finite evidence, not a uniform
classification theorem. This invalidates universal endpoint accessibility
from cardinality, phase, raw minimum surplus and closure alone.

On the 6×6 board, inspect at most four cells per day. Start with one
full physical-color-0 cohort. Coordinates range from zero to five.
At an odd clock its holes lie in physical color 1.

Let Y be the radius-four own-color triangle based at (0,5), minus BOTH
axis tips (0,1) and (4,5):

```
Y={(0,3),(0,5),(1,2),(1,4),(2,3),(2,5),(3,4)}.
```

It has seven cells, neighborhood size ten, minimum raw surplus three,
and `E(N(Y))=Y`. Its exact arrival time is seven updates. More strongly,
**no actual hole superset of Y is reachable at clock five**; earliest
containment also occurs at clock seven.

At clock four, the maximum possible number of holes is six. However,

```
max_(actual clock-four hole states X) |X intersect N(Y)| = 5.
```

Consequently containing Y on the next update requires at least
`|N(Y)|-5=5` inspections, exceeding the budget four. This argument uses
containment, not the potentially irrelevant demand for equality with Y.
Every six-hole state at clock four contains at least one of the two
physical-color-0 board corners (0,0),(5,5), and N(Y) omits both corners.
This gives a particularly simple interpretation of the lost overlap.

For comparison, the same triangle minus (3,4),(4,5) has seven holes,
the same physical phase/corner and raw surplus, but is reachable in five
updates. This faster shape is also a pyramid in the transverse axis.
Thus the example specifically tests front-to-corner/tilt ancestry.

## Exact evidence and replay

`raw_boundary_access_probe.cpp` constructs all 4,468 actual image/hole
states of each color and computes arrivals in two independent ways:

1. the exact hole transition using erosion and minimum useful shots;
2. literal enumeration of all inspected subsets of the current belief,
   followed by the physical neighborhood update.

All distances agree. A superset-min transform on all 2^18 color masks
checks earliest containment independently of exact-target equality.
`raw_boundary_access_probe.json` stores the results and witness paths.
With physical-color row-major masks, the slow target is 2486, and a
same-corner fast target is 439. Witness hole paths are

```
slow: [0,0,2,38,15,55,2358,2486]
fast: [0,9,75,31,63,439].
```

`raw_boundary_corner_charge.json` independently enumerates the 529
literal clock-four states and its 24 maximum-cardinality states. All
24 hit the preferred corner pair.

The probe also checks 4×6, 4×8 and a second 6×6 budget, as recorded in
the JSON; no all-parameter conclusion is inferred from them.

## What this says about the next theorem

For any target hole set Y, not necessarily one color, exact containment
at time t is equivalent to

```
max_(actual holes X at t-1) |X intersect N(Y)| >= |N(Y)|-k.   (2)
```

Necessity follows because N(Y) must lie in old holes plus inspected
cells. Conversely inspect N(Y) outside X; then erosion contains Y.
Thus the critical quantity is backward-region occupancy on the **full
board**, with the inherited common budget, rather than the isolated
arrival of an arbitrarily chosen raw partition.

A tempting induced-subboard replacement is invalid: removing exterior
edges creates free boundaries. `young_region_probe.py/.json` shows that
on the induced 17-cell region `Y union N(Y)`, all ten target-shadow
cells can become holes by clock four; the true full-board maximum is
only five. Even the full corner triangle of radius five has this defect.

The first targeted general inequality should therefore retain exterior
shadow demand and phase-sensitive mandatory corner/core occupancy.
The example does not yet justify a full outer-partition classification:
here one mandatory corner already explains the obstruction.

# A smaller area threshold for physical pyramid interpolation

29 October 2026. Ordinary lemma and proof, awaiting independent review.
This strengthens the occupancy step in
`research/phase-compatibility-2026-10-24/candidate-even-pyramid-interpolation-extension.md`.
It does not by itself establish an optimal orientation-changing history.

## 1. Canonical paths and predecessor repair

Work on any `W by N` board, `W,N>=2`; **no ordering of the two side lengths
is required**. A canonical pyramid of physical color `p` consists in row
`i` of all sites `0<=y<=a_i` of parity `p-i`, where the empty cutoff is
`(p-i mod 2)-2`, the upper cutoff is the largest allowed board coordinate,
and adjacent cutoffs differ by exactly one.

Write `D(Y)` for the opposite-color canonical predecessor obtained by
lowering each cutoff by one and clipping at its new empty floor. Write
`f` for the opposite-color canonical path having one cell in every row.
The full occupancy repair is

    C_full(Y) = max(D(Y),f).

Let `E` be the number of empty rows of Y and let `D` be the number of
rows of target parity zero that contain at least two cells of Y.
Then the exact row count is

    |C_full(Y)|-|Y| = E-D.                         (1)

Indeed an empty target row gains one cell. A target-parity-zero row
with at least two cells loses one. A target-parity-zero singleton and
each nonempty target-parity-one row retain their cardinalities.

### Smaller repair threshold

If `|C_full(Y)|>|Y|`, then

    |Y| <= floor((W+1)^2/8).                       (2)

If Y is empty this is immediate. Otherwise put `m=max_i |Y_i|`.
By (1), `E>D`, so at least one row is empty. Follow the cutoff path from
a row of length m to an empty row. Along that path each positive row
length `1,...,m-1` occurs at least twice: decreasing a row length is
possible on only one of the two alternating row-parity transitions.
The path also contains at least `m-1` target-parity-zero rows of length
at least two. Consequently

    D>=m-1,       E>=m,                            (3)
    sum over occupied rows i of (m-|Y_i|)
        >=2(1+...+(m-1))=m(m-1).                  (4)

There are `W-E` occupied rows. Therefore

    |Y| <= m(W-E)-m(m-1)
         <=m(W+1-2m)
         <=(W+1)^2/8.

This proves (2). Clipping at the far wall can only decrease row lengths;
the argument uses an existing path from a maximum to an empty row and
does not require an infinite strip or `N>=W`.

The bound is deliberately sufficient, not sharp. Exact finite path
evaluation in `pyramid_occupancy_threshold_probe.py` for widths 2 through
40 finds a maximum near `W^2/9`; that empirical sharper expression is
not used in this proof.

## 2. Physical interpolation on arbitrary aspect ratios

Assume now `WN` is even. Set `H(W)=floor((W+1)^2/8)` and `c=ceil(W/2)`. Let X,Y be canonical
pyramids toward the same end, with physical colors differing by `T mod 2`.
Suppose

    |X|>=|Y|>H(W),
    |X|-|Y| <= (k-c)T,       k>=c,
    Y subset N^T(X),
    N(D(Y))=Y.                                    (5)

Then there is an actual budget-k word of exactly T updates taking X
to Y. For T=0 the hypotheses force X=Y, so assume T>0.

This is the earlier physical interpolation proof with its occupancy
estimate replaced by (2). Details are retained to make the dependency
and actual-game claim explicit.

For any canonical pyramid U, `N(U)` is canonical and its cutoff is at
most `a_U+1`. An empty row may require deleting a spurious isolated
bottom cell; no equality with a translated path is assumed. A canonical
target Z satisfies `N(D(Z))=Z` exactly when each occupied target-parity-
zero row has an adjacent occupied target-parity-one row. Every canonical
pyramid that is itself an actual neighborhood has this property.
These are the previously proved local regularity facts, valid also
when `N<W` because both board dimensions are at least two.

Put `U_t=N^t(X)`. Choose nonincreasing integer areas `q_t` from `|X|` to
`|Y|`, decreasing by at most `k-c` on each step. Construct backwards,
starting from `Z_T=Y`. For target `Z=Z_(t+1)`, define

    B=min(U_t,f),       C=max(D(Z),B).              (6)

Here minima and maxima act on canonical cutoffs. The inclusion
`Z subset N(U_t)` gives `D(Z) subset U_t`, so `C subset U_t`.
Moreover C has exactly the occupied rows of U_t. Since
`C subset C_full(Z)` and `|Z|>H(W)`, (2) gives

    |C|<=|Z|=q_(t+1)<=q_t<=|X|<=|U_t|.           (7)

The last inequality uses a perfect matching of the even-area rectangle.
The same construction extends to an odd-area rectangle if one imposes
the additional condition

    q_t <= |N^t(X)| for every t.                   (8)

Alternatively retain (8) uniformly as an explicit hypothesis, which
is automatic on every even-area rectangle. It is also sufficient to
choose any nonincreasing q_t satisfying (8) and
`q_t-q_(t+1)<=k-c`, in place of the aggregate decrement condition.

Single-cell rank interpolation between ordered canonical paths supplies
`C subset Z_t subset U_t` with area q_t. Since Z_t and U_t occupy exactly
the same rows, Z_t is regular for `t>=1`. At t=0, equal area and inclusion
force `Z_0=X`; regularity of X is not needed.

Inspect `Z_t minus D(Z_(t+1))`. The remaining survivor set is exactly
`D(Z_(t+1))`, and its neighborhood is exactly the next target. The
number of shots is

    |Z_t|-|D(Z_(t+1))|
      <=q_t-q_(t+1)+ceil(W/2)<=k.                 (9)

Thus every transition is physical, uses the actual per-day quota, and
preserves the specified endpoints and clock.

## 3. Relevance to transverse transport

On an odd-width, even-length board `(2b+1) by (2b+2j)`, a transverse
pyramid has `W=2b+2j`. Its guaranteed decrement capacity in this lemma
is `k-(b+j)`. The rule therefore allows positive progress whenever
`j<=k-b-1`, and constant-area transport when `j=k-b`.

For the shortest even length `2b+2`, the old transposed sufficient
threshold was `b^2`; the new one is `floor((2b+3)^2/8)`. In particular
for b>=8 every central target of size greater than `(b-1)^2` passes the
new repair threshold. The construction does not require pretending
that the transverse board has its shorter dimension first.

This provides a rigorous possible edge in an orientation-state
construction. A complete gap-zero application still needs reachable
entry and exit endpoints, exact propagation containment, shared clocks
and quotas, and the appropriate final paired overlap or bridge. Those
interfaces have not been proved here.

Independent ordinary review: the phase lane accepted the complete proof,
including the maximum-to-empty row argument, arbitrary aspect ratio,
regularity, rank interpolation, matching expansion and daily quota.
Independent literal implementation `pyramid_interpolation_replay.py`
constructed and replayed 3,289 admissible words across ten board shapes;
863 used W>N and 18 had targets below the previous sufficient threshold.
This is not Lean coverage and not a proof that these edges yield an
optimal full-board strategy.

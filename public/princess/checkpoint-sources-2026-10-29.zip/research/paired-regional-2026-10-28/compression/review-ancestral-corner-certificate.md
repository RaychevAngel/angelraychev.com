# Independent review of the ancestral corner certificate

29 October 2026, 14:38 UTC. Reviewer: compression lane.

Accepted as an ordinary **conditional necessary-history theorem**:

- `regional/ancestral-corner-constraint-certificate.md`;
- `regional/anchored-path-packing.md`;
- the attachment supplied by `phase/backward-sensitive-ancestor-interface.md`.

The review checked the actual physical interfaces, rather than treating a
backward allowed set as a freely restarted solo history.

1. G2 compares seeds in the same directed erosion history. Erosion preserves
   a raw missing-cell bound, so only the earlier defect is charged. Different
   seeds may have different corners; their variables are not identified.
2. At a common real day, the backward allowed set contains the actual
   post-inspection survivor. It need not be disjoint from the actual forward
   holes. G3 correctly retains the excess `eta`, and G4 charges this excess
   once, in addition to the two raw defects.
3. G5 starts at a pre-inspection state and ends at a post-inspection survivor.
   Thus `t` movements use `t+1` inspection layers. Both endpoint-exception
   signs are correct. Intermediate physical states are unrestricted.
4. Backward seeds retain their genuine activation duration `r`, one-shot
   availability at index zero, and actual real-day conversion. The stated
   ordinary-cap and co-small-exclusion guards remain necessary hypotheses.
5. Each actual seed has one Boolean reused in all clauses. All feasible
   activation and physical-phase branches must be rejected. A copied-variable
   or freely reset phase premise is not present.
6. Same-end one-dimensional packing with positive duration is exactly the
   minimum of the source size, target size, and the smaller path parity size.
   Zero duration correctly uses literal intersection instead.

No claim is made that the graph always rejects a faster gate, that a surviving
graph is realizable, or that the relevant sensitive ancestors always exist.
Those remain the main mathematical obligations. This review does not add Lean
coverage.

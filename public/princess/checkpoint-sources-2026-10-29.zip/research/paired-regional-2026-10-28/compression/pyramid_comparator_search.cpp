#include <algorithm>
#include <bit>
#include <cstdint>
#include <iostream>
#include <random>
#include <tuple>
#include <vector>
using namespace std;
struct Edge{int lo,hi,x,y,dx;};
int main(int argc,char**argv){int w=argc>1?atoi(argv[1]):4,n=argc>2?atoi(argv[2]):6,h=w*n/2; if(h>20)return 2;
 vector<pair<int,int>> vs[2];int ix[20][30];for(int x=0;x<w;++x)for(int y=0;y<n;++y){int p=(x+y)%2;ix[x][y]=vs[p].size();vs[p].push_back({x,y});}
 vector<unsigned> N[2];vector<Edge>E[2];for(int p=0;p<2;++p){int H=vs[p].size();N[p].resize(1u<<H);vector<unsigned>adj(H);for(int i=0;i<H;++i){auto[x,y]=vs[p][i];for(auto[xx,yy]:vector<pair<int,int>>{{x-1,y},{x+1,y},{x,y-1},{x,y+1}})if(xx>=0&&xx<w&&yy>=0&&yy<n)adj[i]|=1u<<ix[xx][yy];if(y)for(int dx:{-1,1})if(x+dx>=0&&x+dx<w)E[p].push_back({ix[x+dx][y-1],i,x,y,dx});}
 for(unsigned s=1;s<N[p].size();++s){unsigned b=s&-s;N[p][s]=N[p][s^b]|adj[countr_zero(b)];}}
 vector<vector<unsigned>> ALL[2];
 for(int mode=0;mode<64;++mode){vector<unsigned>C[2];for(int p=0;p<2;++p){auto es=E[p];sort(es.begin(),es.end(),[&](Edge a,Edge b){auto key=[&](Edge e){int X=(mode&1)?-e.x:e.x,Y=(mode&2)?-e.y:e.y,D=(mode&4)?-e.dx:e.dx;if(mode&8)X+=((mode&16)?e.y:-e.y);if(mode&32)return tuple{X,Y,D};return tuple{Y,X,D};};return key(a)<key(b);});C[p].resize(N[p].size());for(unsigned s=0;s<C[p].size();++s){unsigned z=s;bool change=true;while(change){change=false;for(auto e:es)if((z>>e.hi&1)&&!(z>>e.lo&1)){z^=(1u<<e.hi)|(1u<<e.lo);change=true;}}C[p][s]=z;}}
 ALL[0].push_back(C[0]);ALL[1].push_back(C[1]);
 int fails=0,pfirst=-1;unsigned sfirst=0,lfirst=0,rfirst=0;for(int p=0;p<2;++p)for(unsigned s=0;s<C[p].size();++s){unsigned l=N[p][C[p][s]],r=C[1-p][N[p][s]];if(l&~r){++fails;if(pfirst<0){pfirst=p;sfirst=s;lfirst=l;rfirst=r;}}}
 cout<<"{\"w\":"<<w<<",\"n\":"<<n<<",\"mode\":"<<mode<<",\"failures\":"<<fails<<",\"first\":["<<pfirst<<","<<sfirst<<","<<lfirst<<","<<rfirst<<"]}"<<endl;
 }
 int best=1000000;vector<pair<int,int>>bestpairs;
 for(int m0=0;m0<64;++m0)for(int m1=0;m1<64;++m1){int failures=0;for(int p=0;p<2;++p){auto&cp=ALL[p][p?m1:m0];auto&cq=ALL[1-p][p?m0:m1];for(unsigned s=0;s<cp.size();++s)failures+=(N[p][cp[s]]&~cq[N[p][s]])!=0;}
  if(failures<best){best=failures;bestpairs.clear();}if(failures==best)bestpairs.push_back({m0,m1});}
 cerr<<"mixed_best="<<best<<" pairs=";for(auto[a,b]:bestpairs)cerr<<a<<","<<b<<" ";cerr<<endl;
 for(int t0=0;t0<=h;++t0)for(int t1=0;t1<=h;++t1){vector<unsigned>C[2];for(int p=0;p<2;++p){C[p].resize(N[p].size());int t=p?t1:t0;for(unsigned s=0;s<C[p].size();++s)C[p][s]=ALL[p][popcount(s)<=t?1:4][s];}
  int nf=0,mf=0;for(int p=0;p<2;++p)for(unsigned s=0;s<C[p].size();++s){nf+=(N[p][C[p][s]]&~C[1-p][N[p][s]])!=0;for(int v=0;v<h;++v)if(!(s>>v&1))mf+=(C[p][s]&~C[p][s|(1u<<v)])!=0;}
  if(nf==0||mf==0)cerr<<"hybrid "<<t0<<","<<t1<<" N="<<nf<<" mono="<<mf<<endl;
 }

 mt19937 rng(20261029);int random_best=1000000;
 for(int trial=0;trial<2000;++trial){vector<unsigned>C[2];vector<Edge>ee[2];for(int p=0;p<2;++p){auto es=E[p];shuffle(es.begin(),es.end(),rng);ee[p]=es;C[p].resize(N[p].size());for(unsigned s=0;s<C[p].size();++s){unsigned z=s;bool change=true;while(change){change=false;for(auto e:es)if((z>>e.hi&1)&&!(z>>e.lo&1)){z^=(1u<<e.hi)|(1u<<e.lo);change=true;}}C[p][s]=z;}}
  int nf=0;for(int p=0;p<2;++p)for(unsigned s=0;s<C[p].size();++s)nf+=(N[p][C[p][s]]&~C[1-p][N[p][s]])!=0;
  if(nf<random_best){random_best=nf;cerr<<"random "<<trial<<" N="<<nf;for(int p=0;p<2;++p){cerr<<" p"<<p<<":";for(auto e:ee[p])cerr<<e.lo<<","<<e.hi<<";";}cerr<<endl;}
  if(!nf)break;
 }

}

# Independent review: high-budget shifted erosion and signed reverse

29 October 2026. Ordinary review, not Lean verification.
Source reviewed: `../high-budget-signed-reverse-interface.md`.
Dependencies checked against the earlier signed-late proof and the new
high-budget strict-collar proof. No new capture-time equality is inferred.

I find the argument sound in its stated range
`b>=512`, `3b<=k<Z=h-b^2`, and `0<=c<=k`.

1. For a one-color D with M cells, its full-cohort-complement survivor
   has h-M cells and neighborhood h-|E(D)| cells. Thus its ORIGINAL
   surplus is exactly M-|E(D)|. No replacement by the possibly smaller
   dual hole surplus has occurred.
2. If max W_r<A=Z-k, then max V_(r+1)<Z. Monotonicity gives M<=min V_r<Z.
   This is enough to initialize physically; A>L is not needed.
3. If the initial erosion q>L had original surplus at most b-1, the
   small/co-small separator would require q>=h-b(b-1)=U+2b>M.
   Otherwise q<=M-b<U. The q<=L branch is below U because even the
   shortest board has U=(b+1)^2>L.
4. Both entries of V_r bound M. Inverting the actual own/opposite incoming
   cost gives the correct coordinate W_r[p], while a nongood event has
   one additional surplus and is below both. For r>=1 the genuine lower
   drift puts both W_r entries at least 2b-1, handling tiny q.
5. Continuation from an actual E(D) at index r does not invent an earlier
   physical history. The core is present in that actual set. Its radius
   and the numerical reference index provide all inputs needed by the
   high-budget proof's mixing argument. That argument uses the genuine
   orbit and its elapsed index, not a reconstructed geometric past.
6. At the first crossing of A, the raw upper bound is U+b-1. If the new
   count is at most L it is still below U. Otherwise a surplus below b
   would force the co-small floor U+2b, impossible; hence the new count
   is at most U-1. This proves clipping even when A<=L.
7. The permanently mixed comparison uses the same established geometric
   interval as the old signed-late theorem. Here its nontrivial survivor
   mass is less than U+b-d+1<=U-b+1, strictly below U+2b-2. Higher k
   only shrinks that interval. The activation inspection is included
   because properness is required AFTER inspection.
8. The two-phase mixed bound is an inverse-threshold statement, giving
   min V_r, not just max V_r. It therefore supplies the actual activation
   set bound needed for shifted initialization.
9. The reverse recurrence is literal adjunction of the actual solo word.
   The last union bound gives
   min(|S|,Z)<=k+min(|J_(a-1)|,A), and the index identity is
   k+W_(r+a-1)=V_(r+a)=V_t. The no-activation case correctly uses the
   genuine first-quota instance; zero remaining updates are immediate.

The source's limits are accurate: this is a clipped necessary comparison
for a normalized actual history. It does not construct the forward/common
cut, justify arbitrary endpoint labels, or prove a capture-time equality.

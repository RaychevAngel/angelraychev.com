import json
from pathlib import Path
root=Path('research/paired-regional-2026-10-28/compression')
raw=json.loads(Path('research/uniform-even-rectangle-compression-map.json').read_text())
w,n=raw['shape'];vs=[list(map(tuple,x))for x in raw['coordinates']];ix=[{v:i for i,v in enumerate(vs[p])}for p in (0,1)];h=len(vs[0]);full=(1<<h)-1
N=[]
for p in (0,1):
 adj=[sum(1<<ix[1-p][v] for v in [(x-1,y),(x+1,y),(x,y-1),(x,y+1)]if v in ix[1-p])for x,y in vs[p]]
 a=[0]*(1<<h)
 for s in range(1,1<<h):
  bit=s&-s;a[s]=a[s^bit]|adj[bit.bit_length()-1]
 N.append(a)
def comparator(mode):
 C=[]
 for p in (0,1):
  edges=[]
  for i,(x,y)in enumerate(vs[p]):
   if y:
    for dx in (-1,1):
     if (x+dx,y-1) in ix[p]:edges.append((ix[p][x+dx,y-1],i,x,y,dx))
  def key(e):
   lo,hi,x,y,dx=e;return(y,-x if mode==1 else x,dx if mode==1 else -dx)
  edges.sort(key=key);a=[]
  for s in range(1<<h):
   z=s
   while True:
    old=z
    for lo,hi,*_ in edges:
     if(z>>hi&1)and not(z>>lo&1):z^=(1<<hi)|(1<<lo)
    if z==old:break
   a.append(z)
  C.append(a)
 return C

def faults(C):
 result=[]
 for p in (0,1):
  for s in range(1<<h):
   lhs=N[p][C[p][s]];rhs=C[1-p][N[p][s]]
   if lhs&~rhs:result.append(dict(p=p,s=s,size=s.bit_count(),missing=[v for i,v in enumerate(vs[p])if not(s>>i&1)],image=C[p][s],N=N[p][s],left=lhs,right=rhs,csp_image=raw['images'][p][s],csp_N_image=raw['images'][1-p][N[p][s]]))
 return result
out=[]
for mode in (1,4):
 C=comparator(mode);dist={str(p):{}for p in(0,1)};diff=[]
 for p in(0,1):
  for s in range(1<<h):
   if C[p][s]!=raw['images'][p][s]:
    q=s.bit_count();dist[str(p)][str(q)]=dist[str(p)].get(str(q),0)+1;diff.append((p,s,C[p][s],raw['images'][p][s]))
 f=faults(C)
 # Start by replacing source and target images involved in every fault by their known valid CSP images.
 repairs=set(); rounds=[]
 for round in range(30):
  nf=faults(C);mf=[]
  for p in(0,1):
   for s in range(1<<h):
    for v in range(h):
     if not(s>>v&1)and C[p][s]&~C[p][s|(1<<v)]:mf.append((p,s,s|(1<<v)))
  if not nf and not mf:break
  add=set()
  for z in nf:add|={(z['p'],z['s']),(1-z['p'],z['N'])}
  for p,s,t in mf:add|={(p,s),(p,t)}
  add={key for key in add if C[key[0]][key[1]]!=raw['images'][key[0]][key[1]]}
  if not add:raise RuntimeError('no repair progress')
  rounds.append({'round':round,'neighborhood_faults':len(nf),'monotonicity_faults':len(mf),'new_repairs':len(add)})
  for p,s in add:C[p][s]=raw['images'][p][s]
  repairs|=add
 out.append({'mode':mode,'initial_difference_by_cardinality':dist,'initial_faults':f,'repair_rounds':rounds,'repairs':[{ 'p':p,'s':s,'size':s.bit_count(),'support':[v for i,v in enumerate(vs[p])if s>>i&1],'missing':[v for i,v in enumerate(vs[p])if not(s>>i&1)]}for p,s in sorted(repairs)],'remaining_N_faults':len(faults(C))})
(root/'comparator-repair-4x6.json').write_text(json.dumps(out,indent=2)+'\n')
for r in out:
 print('mode',r['mode'],'diffs',r['initial_difference_by_cardinality'],'faults',r['initial_faults'],'rounds',r['repair_rounds'],'repaired',len(r['repairs']))

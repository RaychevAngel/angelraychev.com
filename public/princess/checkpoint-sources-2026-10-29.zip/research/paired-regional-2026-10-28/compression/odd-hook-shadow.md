# Complementary odd hooks on even rectangles

29 October 2026. Ordinary necessary shadow inequalities for arbitrary
physical sets. These are not an exact state description or a capture-time
classification. No formalization is claimed.

Let w,n be positive even integers, at least two, and
V={0,...,w-1} x {0,...,n-1}. Put

    D={0,...,w-2} x {0,...,n-2},
    K=V minus D,
    o=(w-1,n-1), c=(w-2,n-2),
    u=(w-2,n-1), v=(w-1,n-2).

D is an odd rectangle with majority physical color zero. The induced
graph on K is an odd path of length w+n-1, with majority physical color
one. In particular its majority color is opposite the majority of D.
Reflections give the other three adjacent-side hooks, with the appropriate
physical color offsets retained.

## 1. An additional shadow constraint using only outer-region counts

For a fixed-color source S write q_K=|S intersect K|. If A is an
opposite-color available set satisfying N_V(S) subset A, then

    |A intersect K| >= nu_K(q_K),

where, writing m=(w+n-2)/2,

    nu_K(q) = min(q,m)             for the K-majority source color,
    nu_K(0) = 0,
    nu_K(q) = q+1 for q>0          for the K-minority source color.

Proof: N_K(S intersect K) is a subset of A intersect K, and these are the
exact neighborhood profiles of an odd path. They follow directly by
counting the gaps between selected vertices along that path; a prefix at
an endpoint attains each minimum. This applies to arbitrary S, without
assuming that S itself is an interval or a pyramid.

The numbers q_K and |A intersect K| are sums of the counts of the two
outer sides minus the shared outer corner. Thus these four hook constraints
can be added to a three-by-three rectangular-region count relaxation without
adding a coordinate. In the central regimes, the shadow excess caps of D
and K sum to the even-board cap b=w/2: they are (b-1)+1 for D-majority
sources and b+0 for D-minority sources, assuming w<=n. This explains a
possible missing boundary charge; it does not prove that the two regional
minima are simultaneously attainable.

## 2. Exact cross-interface image counts

Let B be the inner boundary of D: its last row or last column, with c
counted once. Write X_D=N_V(S intersect D) intersect K and
X_K=N_V(S intersect K) intersect D. Then

    |X_D| = |S intersect B| + 1_(c in S),
    |X_K| = q_K - 1_(o in S) - 1_(u and v both in S).       (2)

For the first identity, every inner-boundary vertex other than c has one
cross-edge image and these images are all different. The vertex c has
two distinct cross-edge images, u and v. No other D vertex has a cross
edge. For the second, o has no cross-edge image, every other K vertex has
one, and the only collision is that u and v both map to c.

Consequently the available counts must satisfy

    |A intersect D| >= max(nu_D(|S intersect D|), |X_K|),
    |A intersect K| >= max(nu_K(q_K), |X_D|).              (3)

The maxima are essential: these two sources of neighbors may overlap
inside a target region. Their cardinalities must not be added.

Even without the individual u,v coordinates, (2) yields the safe bounds

    |A intersect D| >= q_K - 1_(o in S)  [D-majority source],
    |A intersect D| >= max(q_K-1,ceil(q_K/2))
                                                  [D-minority source].

In the first line u,v have the wrong color to lie in S; in the second o
has the wrong color and the only possible collision needs two vertices.
The stronger exact version in (2) is available when those two actual cell
indicators are retained.

## 3. History interface

For actual holes H and useful inspections I, write A=H union I. Any next
hole set H' obeys N(H') subset A. Apply all these inequalities with S the
appropriate physical-color part of H' and A the opposite-color part of
H union I. The same actual inspection set is used by every reflected
hook and every rectangular constraint. There is one shared budget |I|<=k;
neither the four projections nor the two physical colors receive separate
budgets. This proves necessity for every full physical history.

No claim of closure, sufficiency, direct optimal inspections, or a reduced
uniform capture-time gap follows from these inequalities alone.

"""Literal bounded audit of opposite compression and new mixed overlap bound."""
import sys,json
from pathlib import Path
from math import sqrt
ROOT=Path(__file__).resolve().parents[3];sys.path.insert(0,str(ROOT/'src'))
from resumed_even_construction_square_audit import prepare
count=0;boards=[]
for w,n in ((3,4),(5,6),(5,8),(7,8),(7,10),(9,10)):
 data=prepare(w,n);W=w-1;seen=0
 for p in (0,1):
  for mask,a in zip(data['ideals'][p],data['heights'][p]):
   F={v for i,v in enumerate(data['colors'][p]) if mask>>i&1};C=set()
   for y in range(n):
    available=[(x,y) for x in range(w) if (x+y)%2==p]
    num=sum(v in F for v in available)
    C.update(available[len(available)-num:])
   aa=tuple(max([y for xx,y in C if xx==x],default=(p-x)%2-2) for x in range(w))
   assert all(abs(aa[x+1]-aa[x])==1 for x in range(w-1))
   assert all(aa[x+2]>=aa[x] for x in range(w-2))
   assert len(C)==len(F)
   for R in range(p,W,2):
    T={(x,y) for x in range(w) for y in range(n) if (x+y)%2==p and x+y<=R}
    I=len(F&T);J=len(C&T);assert J<=I
    j=R+1;L=W-j;c=aa[j]+2
    if c<=j:
     inside={(x,y) for x,y in C if x<j}
     outer=inside-T
     images={(R-y,R-x) for x,y in outer}
     assert len(images)==len(outer) and images<=C&T
     assert len(F)<=2*J+(L+1)*c/2+L*(L+1)/4
    # It suffices to test D=actual overlap: RHS is increasing in D.
    D=I
    if D < (j*j//4)/2:
     threshold=2*D+(L+1)*(1+sqrt(8*D+4))/2+L*(L+1)/4
     assert len(F)<=threshold+1e-9,(w,n,p,a,R,I,threshold)
    count+=1;seen+=1
 boards.append(dict(w=w,n=n,front_triangle_pairs=seen))
out=dict(status='PASS',pairs=count,boards=boards,scope='Bounded literal audit; general proof is separate.')
Path(__file__).with_name('opposite-front-triangle-audit.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))

"""Literal one-cohort audit of all four odd-hook inequalities.

No search for strategies or claimed full-state closure. The paired transfer
then follows by adding disjoint physical-color target counts, as in the
ordinary proof.
"""
from array import array
from pathlib import Path
import json
import time


def audit(w, n):
    started = time.process_time()
    checked = 0
    for p in range(2):
        cells = [(x, y) for x in range(w) for y in range(n) if (x+y) % 2 == p]
        index = {v: i for i, v in enumerate(cells)}
        vertex_bit = lambda v: 1 << (v[0]*n+v[1])
        source_bit = lambda v: (1 << index[v]) if v in index else 0
        atom = []
        for x, y in cells:
            atom.append(sum(vertex_bit((a, b)) for a, b in
                            ((x-1, y), (x+1, y), (x, y-1), (x, y+1))
                            if 0 <= a < w and 0 <= b < n))
        shadows = array('Q', [0]) * (1 << len(cells))
        for mask in range(1, len(shadows)):
            low = mask & -mask
            shadows[mask] = shadows[mask ^ low] | atom[low.bit_length()-1]
        hooks = []
        for rx in (False, True):
            for ry in (False, True):
                transform = lambda v: ((w-1-v[0]) if rx else v[0],
                                       (n-1-v[1]) if ry else v[1])
                D = {transform((x, y)) for x in range(w-1) for y in range(n-1)}
                K = {(x, y) for x in range(w) for y in range(n)} - D
                boundary = {transform((x, y)) for x in range(w-1) for y in range(n-1)
                            if x == w-2 or y == n-2}
                corner, outer, u, v = map(transform,
                    ((w-2, n-2), (w-1, n-1), (w-2, n-1), (w-1, n-2)))
                hooks.append(dict(Ds=sum(source_bit(z) for z in D),
                    Ks=sum(source_bit(z) for z in K),
                    D=sum(vertex_bit(z) for z in D), K=sum(vertex_bit(z) for z in K),
                    B=sum(source_bit(z) for z in boundary), c=source_bit(corner),
                    o=source_bit(outer), u=source_bit(u), v=source_bit(v),
                    majority=(sum(outer)+1) % 2))
        m = (w+n-2)//2
        for mask in range(len(shadows)):
            for h in hooks:
                DK, DD = mask & h['Ks'], mask & h['Ds']
                q = DK.bit_count()
                exact_D_to_K = (mask & h['B']).bit_count() + bool(mask & h['c'])
                exact_K_to_D = q - bool(mask & h['o']) - bool(mask & h['u'] and mask & h['v'])
                assert (shadows[DD] & h['K']).bit_count() == exact_D_to_K
                assert (shadows[DK] & h['D']).bit_count() == exact_K_to_D
                profile = min(q, m) if p == h['majority'] else q + bool(q)
                assert (shadows[DK] & h['K']).bit_count() >= profile
                checked += 1
        for majority in (False, True):
            cap = m+1 if majority else m
            profile = lambda q: min(q, m) if majority else q+bool(q)
            for q in range(2*cap+1):
                literal = min(profile(a)+profile(q-a)
                              for a in range(max(0, q-cap), min(q, cap)+1))
                claimed = q-q//(m+1) if majority else q+(q+m-1)//m
                assert literal == claimed
    return dict(shape=[w,n], one_cohort_hook_cases=checked,
                CPU_seconds=time.process_time()-started, status='pass')


if __name__ == '__main__':
    results = [audit(*shape) for shape in ((2,2), (2,4), (4,4), (4,6), (6,6))]
    output = Path(__file__).with_name('odd-hook-audit.json')
    output.write_text(json.dumps(results, indent=2)+'\n')
    print(json.dumps(results))

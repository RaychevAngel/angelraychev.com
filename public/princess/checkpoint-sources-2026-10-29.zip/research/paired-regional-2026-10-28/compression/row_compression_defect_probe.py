"""Literal row-compression defect identities and bounded excess diagnostics."""
from pathlib import Path
from array import array
import json
import time


def run(w,n):
    assert n%2==0
    m=n//2; h=w*m; b=w//2; L=(b-1)**2; U=h-b*(b-1)
    allrows=(1<<m)-1
    checked=0; max_gap=-100; worst=None; zero_excess={}
    for p in (0,1):
        cells=[(x,y) for x in range(w) for y in range(n) if (x+y)%2==p]
        other=[(x,y) for x in range(w) for y in range(n) if (x+y)%2!=p]
        oi={v:i for i,v in enumerate(other)}
        adj=[sum(1<<oi[z] for z in ((x-1,y),(x+1,y),(x,y-1),(x,y+1)) if z in oi)
             for x,y in cells]
        N=array('Q',[0])*(1<<h)
        for S in range(1,len(N)):
            bit=S&-S; N[S]=N[S^bit]|adj[bit.bit_length()-1]
        for S in range(len(N)):
            rows=[(S>>(r*m))&allrows for r in range(w)]
            counts=[x.bit_count() for x in rows]
            actual=[((N[S]>>(r*m))&allrows).bit_count() for r in range(w)]
            bad=[0,0];saving=[0,0]
            for side in (0,1):
                for r,a in enumerate(counts):
                    q=(p-r)%2
                    expensive=q!=side
                    expected=max(a+int(expensive and 0<a<m),
                                 counts[r-1] if r else 0,
                                 counts[r+1] if r+1<w else 0)
                    defect=max(0,expected-actual[r])
                    proper=0<a<m
                    opposite=(allrows^((1<<(m-a))-1)) if side==0 else ((1<<a)-1)
                    condition=(expensive and proper and rows[r]==opposite
                               and (r==0 or not(rows[r-1]&~opposite))
                               and (r+1==w or not(rows[r+1]&~opposite)))
                    assert defect==int(condition)
                    bad[side]+=defect
                    saving[side]+=max(0,actual[r]-expected)
            q=S.bit_count();sigma=N[S].bit_count()-q
            if L<q<U:
                gap=min(bad)-(sigma-b)
                if gap>max_gap:
                    max_gap=gap
                    worst=dict(p=p,S=S,q=q,sigma=sigma,bad=bad,saving=saving,
                               cells=[v for i,v in enumerate(cells) if S>>i&1])
                if sigma==b:
                    zero_excess[q]=max(zero_excess.get(q,0),min(bad))
            checked+=1
    return dict(shape=[w,n],supports=checked,critical_range=[L+1,U-1],
                maximum_minimum_defect_minus_excess=max_gap,worst=worst,
                zero_excess_max_minimum_defect=zero_excess)


if __name__=='__main__':
    start=time.process_time()
    results=[run(*shape) for shape in ((2,4),(4,4),(4,6),(6,6))]
    result=dict(results=results,CPU_seconds=time.process_time()-start)
    Path(__file__).with_name('row-compression-defect-audit.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result))

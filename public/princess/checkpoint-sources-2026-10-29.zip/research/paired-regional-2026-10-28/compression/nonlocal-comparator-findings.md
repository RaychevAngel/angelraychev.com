# Nonlocal corner comparators: a failed uniform operator route

29 October 2026. Bounded falsification round; no random order search.

The proposed repair prepends compare-exchanges from each top corner to
its same-color opposite bottom corner before downward-pyramid sorting.
If both positions are occupied, neither moves; thus collisions naturally
leave a second particle to be placed by subsequent sorting. A second
variant uses every 180-degree-reflected pair comparable in the downward
pyramid order. Each comparator preserves inclusion and cardinality and
fixes every downward pyramid.

The diagnostic checks four previously specified local edge orders and the
two orders of full plus/minus diagonal sorting, with the prep applied
once or at each normalization cycle. This is 30 fixed variants per board,
including controls. Every parity subset of 4x6 and 6x6 was checked.

No unequal-rectangle variant passes N inclusion. On 4x6, the best corner
prep has 37 failures, and the best all-comparable-reflection prep has 47,
compared with two failures for the best original local sorter. Already
singletons fail. The square diagonal control passes all 524,288 parity
subsets of 6x6, including the corner-only prep variants.

A representative nearest-corner failure, 4x6 with reflection prep and the
first local order, is

    A={(0,4)},       C(A)={(2,0)},
    N(C(A))={(1,0),(2,1),(3,0)},
    C(N(A))={(0,1),(1,0),(3,0)}.

The old successful finite CSP map chooses the required target neighborhood
instead. Its singleton images of (0,3) and (1,4) collide at (1,0), while
(0,5) maps to (3,0); the third occupied target cell must be inserted at
(2,1), not (0,1). This is a neighborhood-compatible collision rule.
Adding remote comparators without such a rule merely moves the failure.

Source: `nonlocal_comparator_attack.cpp`; receipts:
`nonlocal-comparator-4x6.jsonl`, `nonlocal-comparator-6x6.jsonl`.
This route was stopped after these decisive failures.

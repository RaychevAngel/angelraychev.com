"""Bounded diagnostic of the uniform new interpolation edge on prefix clocks.

Failure says nothing about physical optimality. No files outside this lane.
"""
import sys,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[3]/'src'))
from resumed_even_construction_prefix_arithmetic import entrance,exit_thresholds
from bridge_upper_transport import prefix_height,height_neighborhood,support
from pyramid_interpolation_replay import pred

def run(w,n,k,target,p0=0):
    qs=entrance(w,n,k,p0);outs=exit_thresholds(w,n,k,target);H=(w+1)**2//8
    hits=[];newhits=[];best=None;checks=0
    for e,q0 in enumerate(qs):
        if e>=target:break
        p=(p0+e)%2;a=prefix_height(w,n,p,q0);u=a
        for end in range(e+1,target):
            u=height_neighborhood(w,n,(p0+end-1)%2,u)
            pp=(p0+end)%2;cap=outs[target-end][1-pp]
            raw=prefix_height(w,n,pp,cap,True)
            b=height_neighborhood(w,n,1-pp,pred(raw,pp));q1=len(support(w,n,pp,b))
            if not q0>=q1>H:continue
            T=end-e;mass=q1+(k-w//2)*T-q0
            geo=min(y-x for x,y in zip(b,u))
            checks+=1
            row=dict(entry=e,end=end,T=T,q0=q0,q1=q1,mass_slack=mass,geo_slack=geo)
            if best is None or (min(mass,geo),mass+geo)>(min(best['mass_slack'],best['geo_slack']),best['mass_slack']+best['geo_slack']):best=row
            if mass>=0 and geo>=0:
                hits.append(row)
                if q1<=(w//2-1)**2:newhits.append(row)
    return dict(w=w,n=n,k=k,target=target,p0=p0,checks=checks,hits=len(hits),newhits=len(newhits),best=best,first=hits[:1],newfirst=newhits[:1])

if __name__=='__main__':
    rows=[]
    for w,n,k in ((8,8,5),(10,10,6),(12,12,7),(12,14,7),(16,16,9),(20,20,11),(24,24,13),(32,32,17)):
        for p in (0,1):
            base=len(entrance(w,n,k,p))
            for t in range(base-3,base+1):rows.append(run(w,n,k,t,p))
    Path(__file__).with_suffix('.json').write_text(json.dumps(rows,indent=2)+'\n')
    print(json.dumps(rows))

"""Literal replay of pre-existing physical words; no search or optimality claim."""
import json,hashlib
from pathlib import Path

def hood(s,w,n):
 return {v for x,y in s for v in [(x-1,y),(x+1,y),(x,y-1),(x,y+1)] if 0<=v[0]<w and 0<=v[1]<n}
def profile(s,w,n,axis,kind):
 length,lines=(w,n) if axis else (n,w)
 for orientation in range(4 if kind==0 else 1):
  good=True
  for r in range(lines):
   for p in range(2):
    seq=[int(((j,r) if axis else (r,j)) in s) for j in range(length) if (j+r)%2==p]
    if kind==2: ok=sum(v and (i==0 or not seq[i-1]) for i,v in enumerate(seq))<=1
    elif kind==1:ok=sum(seq[i]!=seq[i-1] for i in range(1,len(seq)))<=1
    else:ok=all(seq[i]>=seq[i-1] if orientation>>p&1 else seq[i]<=seq[i-1] for i in range(1,len(seq)))
    good &=ok
  if good:return True
 return False
root=Path('research/paired-regional-2026-10-28/compression');reports=[]
for filename,key in [('research/bridge-upper-transport-25x26-prefix.json','solo_shots'),('research/bridge-upper-transport-25x26-prefix.json','full_shots')]:
 raw=json.loads(Path(filename).read_text());w,n=raw['shape'];k=raw['budget'];shots=raw[key]
 p=sum(shots[0][0])%2
 A={(x,y)for x in range(w)for y in range(n)if key=='full_shots' or (x+y)%2==p}
 failures=[[] for z in range(6)]
 for t,I in enumerate(shots):
  I=set(map(tuple,I));assert len(I)<=k
  S=A-I
  for z in range(6):
   for label,X in [('belief',A),('survivor',S)]:
    if not profile(X,w,n,z//3,z%3):failures[z].append([t+1,label])
  A=hood(S,w,n)
 assert not A
 reports.append({'source':filename,'source_sha256':hashlib.sha256(Path(filename).read_bytes()).hexdigest(),'key':key,'shape':[w,n],'k':k,'days':len(shots),'terminal_size':len(A),'profile_results':[{'axis':z//3,'kind':z%3,'failures':failures[z]}for z in range(6)]})
(root/'larger-witness-profile-replay.json').write_text(json.dumps(reports,indent=2)+'\n')
for d in reports:print(d['key'],d['days'],[(r['axis'],r['kind'],len(r['failures']))for r in d['profile_results']])

# Opposite short-axis compression sharpens mixed overlap

29 October 2026. New ordinary geometric lemma for independent review.
No capture-time family or Lean result follows without its separate physical
endpoint interface. This applies at every odd width, without a width cutoff.

Let the board have odd transverse width W+1=2b+1 and length n>W. Fix a
physical color p and the longitudinal end y=0. Let F be a downward pyramid:
its same-color row fibers are prefixes with canonical virtual cutoffs a_x
satisfying |a_(x+1)-a_x|=1. Empty and full fibers are allowed. Let q=|F|.
Let T be the same-color triangle at (0,0) of radius R, where

    0<=R<=W-1,   R congruent p (mod 2).

Put j=R+1, L=W-j. For any real D>=0, the following conditions imply
|F intersect T|>D:

    D < floor(j^2/4)/2,
    q > 2D + (L+1)(1+sqrt(8D+4))/2 + L(L+1)/4.       (1)

The old mixed-overlap lemma has the sufficient area condition
D+(W+1)(1+sqrt(8D+4))/2+L(L+1)/4. The new condition is stronger whenever
D<j(1+sqrt(8D+4))/2; either valid bound can be used. This is a mathematical
strengthening of one geometric tool, not a new full-history normal form.

## 1. Compress the front away from the triangle

Within every longitudinal column y and every x-parity, replace the occupied
x positions by the rightmost positions of that parity, preserving their
number. Call the resulting set F'. The odd-path prefix/suffix operator is
monotone, preserves cardinality, and satisfies N_x C_right(A) subset
C_right(N_x(A)); these are the accepted odd-coordinate compression facts.

F' is still a pyramid toward y=0. Indeed the pyramid property is exactly

    N_x(F_y) subset F_(y-1),  y>0,

where F_y denotes the transverse fiber and N_x is the open neighborhood
in the odd path of length W+1. Apply N-subcommutation and monotonicity to
preserve this inclusion. The resulting local predecessor conditions give
the canonical slope-one cutoff path, including empty/clipped fibers.

Every transverse fiber of T is a left prefix. Of all sets of a prescribed
size in a finite ordered fiber, the right suffix has minimum intersection
with that left prefix. Hence

    |F'|=q,   I'=|F' intersect T| <= |F intersect T|.

Furthermore right compression gives a'_(x+2)>=a'_x whenever both indices
exist. Together with the adjacent slope-one condition, this implies

    a'_x <= a'_j+1  for every 0<=x<=j.                (2)

All remaining steps concern the literal compressed pyramid F'. It need
not be substituted into a physical history to prove this static inequality.

## 2. The same one-point lens bound controls the boundary height

Write f_x=a'_x+2>=0 and c=f_j. The slope bound gives
f_x>=c-|x-j|. The triangle's virtual height plus two on x<=j is j+1-x.
Consequently the old literal-fiber argument gives

    I' >= (1/2) sum_(z=0)^j min(z,max(0,c-z-1)).       (3)

For completeness: at x=j-z the front has at least
max(0,(c-z-1)/2) cells, while the triangle has at least z/2 cells; both
fibers are same-color prefixes, so their intersection has the minimum of
their actual lengths. This proves (3) even when one lower bound is not
an integer.

If c>=j+1, (3) yields I'>=floor(j^2/4)/2. Under I'<=D and the first
condition in (1), that is impossible. Thus integer c<=j. Summing the
nonzero terms in (3), or using floor((c-1)^2/4), also gives

    c <= 1+sqrt(8D+4).                               (4)

The assertion is trivial for c=0; no positive-fiber assumption is used.

## 3. A literal reflection pays for all occupied cells in the first j rows

By (2), for x<=R=j-1 every occupied cell of F' has

    y<=a'_x<=a'_j+1=c-1<=j-1=R.

Thus this part of F' lies in the square 0<=x,y<=R. Take a cell (x,y)
there outside T, so x+y>R. The map

    (x,y) -> (R-y,R-x)

is an injective reflection into T, preserves checkerboard color, and
subtracts the same positive integer x+y-R from both coordinates.
Repeated downward-diagonal predecessor closure of F' therefore puts
its image in F'. All intermediate coordinates stay in the board.

The occupied cells outside T in these first j rows inject into F' intersect
T. Their occupied cells inside T are exactly the entire intersection,
since T has no rows beyond R. Hence the first j rows contain at most2I'
cells in total. This reflection does NOT assert closure under an upward
or horizontal move.

For the remaining rows x=j,...,W, the slope bound gives f_x<=c+x-j,
and their cardinalities are at most f_x/2. There are L+1 such rows, so

    q <= 2I' + (L+1)c/2 + L(L+1)/4.                 (5)

If the original intersection were at most D, then I'<=D. Equations
(4)-(5) contradict the second condition in (1), proving the lemma.

## Scope and reuse

Reflection of the board covers the other corner of the same longitudinal
end. The roles of a raw localized support and a front are unchanged: first
supply a literal retained canonical triangle, subtract its ORIGINAL missing
area and any independently proved allowed-set excess, then use their sum
as D. This lemma supplies no ancestor, phase, end, radius, or defect claim.

The exact opposite-compression overlap identity on arbitrary endpoints is
also useful separately: in each transverse column/color fiber of capacity
m, opposite prefix/suffix representatives intersect in max(0,u+v-m).
Such compression preserves every longitudinal-column count and therefore
the paired odd-subboard projection statistics.

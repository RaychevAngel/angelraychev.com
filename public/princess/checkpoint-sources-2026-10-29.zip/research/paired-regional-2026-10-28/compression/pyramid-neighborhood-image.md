# Every physical pyramid image has its canonical lower predecessor

29 October 2026. Explicit rederivation of the image-regularity lemma in
`../../phase-compatibility-2026-10-24/candidate-even-pyramid-interpolation-extension.md`,
Section1. The regularity conclusion and its interpolation application are
already established there. The displayed maximal-image identity is a compact
restatement; no new transport theorem is claimed. This concerns an actual
neighborhood image, not arbitrary endpoint availability.

Let w,n>=2. A physical-color-p pyramid Y toward y=0 has canonical cutoff
path a_x, adjacent differences1, with the usual parity-specific empty
values -2,-1. Let D(Y) lower each cutoff by1 and normalize empty/top values
in the opposite physical color. Define the isolated bottom roots

    Z(Y)={(x,0): a_x=0 and a_z=-1 for every valid |z-x|=1}.

Then, on the literal finite rectangle,

    N(D(Y)) = N(E(Y)) = Y minus Z(Y),                 (1)

where E(Y)={v:N({v}) subset Y}. Consequently:

- Y is some actual open-neighborhood image if and only if Z(Y) is empty.
- Every actual pyramid belief Y after a movement has N(D(Y))=Y.
- Y minus Z(Y) is the largest open-neighborhood image contained in Y.

## Proof

Every occupied v=(x,y) in D(Y) has y<=a_x-1. Its horizontal neighbors
are in Y, and each vertical neighbor is in Y because a_z>=a_x-1.
Thus D(Y) subset E(Y) and N(D(Y)) subset Y.

Every (x,y) in Y with y>=1 is supplied by (x,y-1) in D(Y). A bottom
cell (x,0) is supplied by (x,1) in D(Y) when a_x>=2, or by (z,0)
when a neighboring cutoff a_z>=1. With a_x=0 all adjacent cutoffs are
-1 or1. Thus exactly the displayed roots Z(Y) are omitted by N(D(Y)).

An isolated root has no neighbor in E(Y). A candidate (z,0), |z-x|=1,
has its own horizontal neighbor (z,1) outside Y, because a_z=-1. The
remaining candidate (x,1) has (x,2) outside Y when n>=3. When n=2,
use a vertical neighbor (z,1) outside Y instead; at least one exists
because w>=2. Therefore Z(Y) is disjoint from N(E(Y)). Since
D(Y) subset E(Y) and N(E(Y)) subset Y, equality(1) follows.

For any image B=N(S) contained in Y, S subset E(Y), hence
B subset N(E(Y)). This proves the maximal-image assertion, and gives
both directions of the image characterization.

## Scope and consequence for existing interpolation

For actual belief endpoints, regularity is automatic as already proved in
the cited extension. That extension also removes the original initial
full-fiber hypothesis by its relative occupancy closure; do not present
that premise as an unresolved interface. Its numerical, actual-inclusion
and size hypotheses still remain essential.

An arbitrary canonical envelope may contain isolated roots. Replacing it
by Y minus Z(Y) preserves the set of possible post-movement images that
it contains. This does not make the regular core attainable from a given
start; it only removes cells that no neighborhood image can use.

No statement is made for w=1 or n=1. In particular a loop-free two-vertex
path has a singleton image that would violate the unqualified one-row
version of this lemma.

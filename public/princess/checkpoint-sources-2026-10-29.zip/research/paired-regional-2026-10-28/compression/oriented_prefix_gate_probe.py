"""Physical oriented-prefix envelope strategy; no optimal normal-form claim."""
from pathlib import Path
import json

class PrefixGame:
    def __init__(self,w,n):
        self.w,self.n=w,n
        self.coords=[(x,y)for x in range(w)for y in range(n)]
        self.index={v:i for i,v in enumerate(self.coords)}
        self.adj=[]
        for x,y in self.coords:
            self.adj.append(sum(1<<self.index[v]for v in ((x+1,y),(x-1,y),(x,y+1),(x,y-1))if v in self.index))
        self.prefix=[];self.hood=[];self.labels=[]
        for sx in (0,1):
            for sy in (0,1):
                for axis in (0,1):
                    def key(i):
                        x,y=self.coords[i];u=w-1-x if sx else x;v=n-1-y if sy else y
                        return (u+v,u if axis==0 else v)
                    pp=[];hh=[]
                    for p in (0,1):
                        order=sorted((i for i,(x,y)in enumerate(self.coords)if (x+y)%2==p),key=key)
                        masks=[0];hoods=[0];hood=0
                        for i in order:
                            masks.append(masks[-1]|(1<<i));hood|=self.adj[i];hoods.append(hood)
                        pp.append(masks);hh.append(hoods)
                    for p in (0,1):
                        for S in hh[p]:assert S==pp[1-p][S.bit_count()]
                    self.prefix.append(pp);self.hood.append([[S.bit_count()for S in row]for row in hh]);self.labels.append((sx,sy,axis))

    def run(self,k,c,T):
        out=[]
        for p0 in (0,1):
            h=self.w*self.n//2;front=[h]*8;parents=[];layers=[front]
            for t in range(T):
                p=(p0+t)%2;nf=[h+1]*8;prev=[None]*8
                for i,q in enumerate(front):
                    if q>h:continue
                    A=self.prefix[i][p][q]
                    for j in range(8):
                        lo=0;hi=h
                        while lo<hi:
                            mid=(lo+hi)//2
                            if (A&~self.prefix[j][p][mid]).bit_count()<=k:hi=mid
                            else:lo=mid+1
                        s=lo
                        z=self.hood[j][p][s]
                        if z<nf[j]:nf[j]=z;prev[j]=(i,s)
                parents.append(prev);front=nf;layers.append(front)
            best=min(range(8),key=lambda i:front[i]);trace=[best];sur=[]
            for t in range(T-1,-1,-1):
                i,s=parents[t][trace[-1]];trace.append(i);sur.append(s)
            trace.reverse();sur.reverse();p=p0;actual=self.prefix[trace[0]][p][h];shots=[]
            for t,(i,j,s)in enumerate(zip(trace,trace[1:],sur)):
                A=self.prefix[i][p][layers[t][i]];S=self.prefix[j][p][s];D=A&~S
                assert not actual&~A and D.bit_count()<=k
                shots.append(D);actual&=~D;nb=0
                while actual:
                    bit=actual&-actual;actual-=bit;nb|=self.adj[bit.bit_length()-1]
                actual=nb;p^=1
                assert not actual&~self.prefix[j][p][layers[t+1][j]]
            out.append(dict(p0=p0,final_belief=front[best],terminal_quota=c,success=front[best]<=c,
                            literal_final_belief=actual.bit_count(),
                            orientations=[self.labels[i]for i in trace],layers=layers))
        return dict(shape=[self.w,self.n],budget=k,updates=T,results=out,
                    scope='Optimal bound among eight oriented-prefix envelope updates; actual replay supplied, no unrestricted optimality or failure lower bound.')

def main():
    out=[]
    for w,n,k,c,T in ((9,10,7,3,13),(33,34,25,25,44)):
        out.append(PrefixGame(w,n).run(k,c,T))
    Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps([{k:v for k,v in row.items()if k!='results'}|{'results':[{k:v for k,v in z.items()if k not in ('layers','orientations')}for z in row['results']]}for row in out]))

if __name__=='__main__':main()

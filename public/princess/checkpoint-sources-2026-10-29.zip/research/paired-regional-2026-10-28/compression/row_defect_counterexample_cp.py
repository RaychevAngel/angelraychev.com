"""Bounded falsification only of the static row-defect conjecture."""
import json
from pathlib import Path
import time
from ortools.sat.python import cp_model


def test(w,n,seconds=2):
    b=w//2;m=n//2;h=w*m
    model=cp_model.CpModel()
    source={(x,y):model.new_bool_var(f's{x}_{y}') for x in range(w) for y in range(n) if (x+y)%2==0}
    target={(x,y):model.new_bool_var(f't{x}_{y}') for x in range(w) for y in range(n) if (x+y)%2==1}
    for (x,y),v in target.items():
        inputs=[source[z] for z in ((x-1,y),(x+1,y),(x,y-1),(x,y+1)) if z in source]
        model.add_max_equality(v,inputs)
    q=sum(source.values());sigma=sum(target.values())-q
    model.add(q>(b-1)**2);model.add(q<h-b*(b-1))
    flags=[model.new_bool_var(f'bad{x}') for x in range(w)]
    for x,flag in enumerate(flags):
        a=sum(v for (xx,y),v in source.items() if xx==x)
        z=sum(v for (xx,y),v in target.items() if xx==x)
        model.add(z==a).only_enforce_if(flag)
        model.add(a>=1).only_enforce_if(flag)
        model.add(a<=m-1).only_enforce_if(flag)
    d=model.new_int_var(2,b,'minimum_defects')
    model.add(d<=sum(flags[::2]));model.add(d<=sum(flags[1::2]))
    model.add(sigma<=b+d-2)
    solver=cp_model.CpSolver();solver.parameters.max_time_in_seconds=seconds
    solver.parameters.num_search_workers=1
    started=time.monotonic();status=solver.solve(model)
    out=dict(shape=[w,n],status=solver.status_name(status),seconds=time.monotonic()-started,
             branches=solver.num_branches,conflicts=solver.num_conflicts)
    if status in (cp_model.FEASIBLE,cp_model.OPTIMAL):
        out.update(cells=[xy for xy,v in source.items() if solver.value(v)],
                   q=solver.value(q),sigma=solver.value(sigma),minimum_defects=solver.value(d))
    return out


if __name__=='__main__':
    output=[test(*shape) for shape in ((8,8),(8,16),(10,10),(10,20),(12,12),(12,24))]
    Path(__file__).with_name('row-defect-cp-falsification.json').write_text(json.dumps(output,indent=2)+'\n')
    print(json.dumps(output))

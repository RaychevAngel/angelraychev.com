#include <algorithm>
#include <bit>
#include <iostream>
#include <functional>
#include <map>
#include <set>
#include <tuple>
#include <vector>
using namespace std;
struct Board{int w,n,m,full; vector<pair<int,int>> cell[2];vector<unsigned>N[2];vector<unsigned>holes[2];Board(int w_,int n_):w(w_),n(n_),m(w*n/2),full((1u<<m)-1){int idx[2][20][30];for(int p=0;p<2;p++)for(int x=0;x<w;x++)for(int y=0;y<n;y++)if((x+y)%2==p){idx[p][x][y]=cell[p].size();cell[p].push_back({x,y});}for(int p=0;p<2;p++){vector<unsigned>a(m);for(int i=0;i<m;i++){auto[x,y]=cell[p][i];for(auto [dx,dy]:vector<pair<int,int>>{{-1,0},{1,0},{0,-1},{0,1}}){int X=x+dx,Y=y+dy;if(0<=X&&X<w&&0<=Y&&Y<n)a[i]|=1u<<idx[1-p][X][Y];}}N[p].resize(1u<<m);for(unsigned s=1;s<=unsigned(full);s++){unsigned b=s&-s;N[p][s]=N[p][s^b]|a[countr_zero(b)];}for(unsigned s=0;s<=unsigned(full);s++)holes[1-p].push_back(full^N[p][s]);sort(holes[1-p].begin(),holes[1-p].end());holes[1-p].erase(unique(holes[1-p].begin(),holes[1-p].end()),holes[1-p].end());}}
 bool raw(unsigned s,int p,int&root,int&corner){int q=popcount(s),sig=popcount(N[p][s])-q;root=sig;if(!q||sig<1||sig>w/2)return false;for(int c=0;c<4;c++){int X=c&1?w-1:0,Y=c&2?n-1:0;int rel=(p-X-Y)&1;int R=2*sig-2-rel;if(q<=(sig-1)*(sig-1-rel)||q>sig*(sig-rel))continue;if(R<0||R>=w||R>=n)continue;bool inside=true;for(int i=0;i<m;i++)if(s>>i&1){auto[x,y]=cell[p][i];if(abs(x-X)+abs(y-Y)>R)inside=false;}if(inside){corner=c;return true;}}return false;}
};
int main(int argc,char**argv){int w=atoi(argv[1]),n=atoi(argv[2]),k=atoi(argv[3]);Board b(w,n);int sz[2]={(int)b.holes[0].size(),(int)b.holes[1].size()};vector<int>d[2],parent[2];for(int p=0;p<2;p++){d[p].assign(sz[p],999);parent[p].assign(sz[p],-1);}vector<pair<int,int>>Q;d[0][0]=0;Q.push_back({0,0});for(int at=0;at<(int)Q.size();at++){auto[p,i]=Q[at];unsigned X=b.holes[p][i];for(int j=0;j<sz[1-p];j++){if(d[1-p][j]<999)continue;unsigned Y=b.holes[1-p][j],ny=b.N[1-p][Y];if(popcount(ny&~X)>k)continue;if((b.full^b.N[p][b.full^(X|ny)])!=Y)continue;d[1-p][j]=d[p][i]+1;parent[1-p][j]=i;Q.push_back({1-p,j});}}map<tuple<int,int,int,int>,int>best;for(int p=0;p<2;p++)for(int j=0;j<sz[p];j++){int r,c;unsigned s=b.holes[p][j];if(!b.raw(s,p,r,c))continue;auto key=make_tuple(p,popcount(s),r,(p-((c&1)?w-1:0)-((c&2)?n-1:0))&1);if(!best.count(key)||d[p][j]<best[key])best[key]=d[p][j];}// Independent literal inspection-subset BFS, without erosion or target scanning.
vector<int> literal[2];for(int p=0;p<2;p++)literal[p].assign(1u<<b.m,999);
vector<pair<int,unsigned>> LQ{{0,0}};literal[0][0]=0;
for(int at=0;at<(int)LQ.size();at++){auto[p,X]=LQ[at];unsigned belief=b.full^X;vector<int>bits;for(int j=0;j<b.m;j++)if(belief>>j&1)bits.push_back(j);
function<void(int,int,unsigned)>visit=[&](int pos,int left,unsigned survivor){unsigned Y=b.full^b.N[p][survivor];if(literal[1-p][Y]==999){literal[1-p][Y]=literal[p][X]+1;LQ.push_back({1-p,Y});}if(!left)return;for(int z=pos;z<(int)bits.size();z++)visit(z+1,left-1,survivor^(1u<<bits[z]));};visit(0,k,belief);}
for(int p=0;p<2;p++)for(int j=0;j<sz[p];j++)if(d[p][j]!=literal[p][b.holes[p][j]]){cerr<<"independent literal mismatch"<<endl;return 1;}
vector<int>contain[2]= {literal[0],literal[1]};for(int p=0;p<2;p++)for(int bit=0;bit<b.m;bit++)for(unsigned mask=0;mask<=unsigned(b.full);mask++)if(!(mask>>bit&1))contain[p][mask]=min(contain[p][mask],contain[p][mask|(1u<<bit)]);
int failures=0;cout<<"{\"w\":"<<w<<",\"n\":"<<n<<",\"k\":"<<k<<",\"independent_literal_replay\":true,\"states\":["<<sz[0]<<","<<sz[1]<<"],\"failures\":[";for(int p=0;p<2;p++)for(int j=0;j<sz[p];j++){int r,c;unsigned s=b.holes[p][j];if(!b.raw(s,p,r,c))continue;int minimum=best[{p,popcount(s),r,(p-((c&1)?w-1:0)-((c&2)?n-1:0))&1}];if(d[p][j]>minimum){if(failures++<12)cout<<(failures>1?",":"")<<"{\"color\":"<<p<<",\"mask\":"<<s<<",\"q\":"<<popcount(s)<<",\"root\":"<<r<<",\"corner\":"<<c<<",\"time\":"<<d[p][j]<<",\"containment_time\":"<<contain[p][s]<<",\"best_same_size\":"<<minimum;
int fi=-1;for(int z=0;z<sz[p];z++){int rr,cc;if(d[p][z]==minimum&&b.raw(b.holes[p][z],p,rr,cc)&&cc==c&&rr==r&&popcount(b.holes[p][z])==popcount(s)){fi=z;break;}}
cout<<",\"fast_same_corner_mask\":"<<(fi<0?0:b.holes[p][fi]);
int overlap=0,maxsize=0;unsigned shadow=b.N[p][s];for(int z=0;z<sz[1-p];z++)if(d[1-p][z]<=minimum-1){overlap=max(overlap,popcount(b.holes[1-p][z]&shadow));maxsize=max(maxsize,popcount(b.holes[1-p][z]));}cout<<",\"shadow_size\":"<<popcount(shadow)<<",\"prior_clock\":"<<minimum-1<<",\"prior_max_holes\":"<<maxsize<<",\"prior_max_shadow_overlap\":"<<overlap;

for(auto item:vector<pair<const char*,int>>{{"slow_path",j},{"fast_path",fi}}){cout<<",\""<<item.first<<"\":[";vector<unsigned> path;int pp=p,jj=item.second;while(jj>=0){path.push_back(b.holes[pp][jj]);jj=parent[pp][jj];pp=1-pp;}reverse(path.begin(),path.end());for(int z=0;z<(int)path.size();z++)cout<<(z?",":"")<<path[z];cout<<"]";}cout<<"}";}}cout<<"],\"failure_count\":"<<failures<<"}"<<endl;}

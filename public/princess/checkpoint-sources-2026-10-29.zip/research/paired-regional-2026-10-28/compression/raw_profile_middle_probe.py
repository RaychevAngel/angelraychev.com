from pathlib import Path
import sys,json
sys.path.insert(0,str(Path(__file__).resolve().parent))
from raw_profile_backward_arrival_probe import neigh,target
BASE=Path(__file__).resolve().parents[1]
w,n,k,c,T=102,124,72,36,206;h=w*n//2;b=w//2;d=k-b
V=[{(x,y)for x in range(w)for y in range(n)if(x+y)%2==p}for p in(0,1)]
def erode(S):
 p=1-((next(iter(S))[0]+next(iter(S))[1])%2)
 return {v for v in V[p]if neigh({v},w,n)<=S}
def tail(B,C,days,order):
 def key(v):
  x=abs(v[0]-C[0]);y=abs(v[1]-C[1]);return x+y,(x,-x,abs(x-y),-abs(x-y))[order],x
 hist=[len(B)];shots=[]
 for _ in range(days):
  S=set(sorted(B,key=key)[:max(0,len(B)-k)]);shots.append(B-S);B=neigh(S,w,n);hist.append(len(B))
 return dict(final=len(B),history=hist,shots=[sorted(I)for I in shots])
def main():
 data=json.loads((BASE/'root/joint_ancestor_layer_probe.json').read_text());out=[]
 for row in data:
  pp=row['result']['profiles'];fs=[p for p in pp if p['seed']['direction']=='forward'and p['seed']['index']==72];rs=[p for p in pp if p['seed']['direction']=='reverse'and p['seed']['index']==73]
  for f in fs:
   F=target(f['seed']['root'],f['positive_left_defects'],f['seed']['corner'],w,n);B=set(F)
   for _ in range(61):B=erode(B)if B else set()
   for r in rs:
    R=target(r['seed']['root'],r['positive_left_defects'],r['seed']['corner'],w,n)
    nr=neigh(R,w,n);tails=[tail(nr,r['seed']['corner'],72,o)for o in range(4)]
    mx=min(h-len(B),len(R-B)+k);need=h-len(F)-d*61
    out.append(dict(Q=row['Q'],Y=row['Y'],F=len(F),R=len(R),retainedF=len(B),overlap=len(B&R),max_target=mx,need=need,margin=mx-need,tail_finals=[a['final']for a in tails],tails=tails,Fcells=sorted(F),Rcells=sorted(R)))
 Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
 print(json.dumps([{k:v for k,v in r.items()if k not in('tails','Fcells','Rcells')}for r in out]))
if __name__=='__main__':main()

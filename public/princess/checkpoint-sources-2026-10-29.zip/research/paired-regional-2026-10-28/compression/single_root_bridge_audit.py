"""Literal audit of chain-ordered nonunit matching blocks at one wall root.
The proof concerns specified canonical endpoints, not their arrival clocks.
"""
from pathlib import Path
import json, random
from pyramid_interpolation_replay import paths,support
from front_bridge_scc_probe import matching_scc

def run():
    rng=random.Random(2026102917)
    tested=0; nontrivial=0; multiple=0; profile_checks=0; examples=[]
    for w,n in ((3,4),(4,4),(4,5),(4,6),(5,6),(6,6),(6,8),(8,8)):
        ps=[paths(w,n,p) for p in (0,1)]
        cols=[{(x,y) for x in range(w) for y in range(n) if (x+y)%2==p} for p in (0,1)]
        candidates=((a,r) for a in ps[0] for r in ps[1^((n-1)%2)]) if w<=4 else ((rng.choice(ps[0]),rng.choice(ps[1^((n-1)%2)])) for _ in range(12000))
        for a,r in candidates:
            H=support(a,n,0);R={(x,n-1-y) for x,y in support(r,n,1^((n-1)%2))}
            A=cols[0]-H;B=cols[1]-R
            adj={u:{v for v in B if abs(u[0]-v[0])+abs(u[1]-v[1])==1} for u in A}
            aa={u for u in A if adj[u]};bb=set().union(*adj.values()) if A else set()
            bottom={u for u in aa if u[1]==0};top={v for v in bb if v[1]==n-1}
            if len(bottom)>1 or len(top)>1:continue
            z=matching_scc(A,B);tested+=1
            m=len(z['weights']);reach=[{i} for i in range(m)]
            for i,j in z['reduction']:reach[i].add(j)
            for t in range(m):
                for i in range(m):
                    if t in reach[i]:reach[i]|=reach[t]
            big=[i for i,v in enumerate(z['weights']) if v>1]
            assert all(i in reach[j] or j in reach[i] for i in big for j in big),(w,n,a,r,z)
            if big:nontrivial+=1
            if len(big)>1:multiple+=1
            if big and len(examples)<3:examples.append(dict(w=w,n=n,a=a,r=r,weights=z['weights'],reduction=z['reduction']))
            # Independent enumeration of component ideals, then compare the
            # interval predicted after fixing each large-block prefix.
            if m<=14:
                actual=set()
                for mask in range(1<<m):
                    selected={i for i in range(m) if mask>>i&1}
                    if not set(z['forced_left'])<=selected or selected&set(z['forced_right']):continue
                    if any(j in selected and i not in selected for i,j in z['reduction']):continue
                    actual.add(sum(z['weights'][i] for i in selected))
                predicted=set()
                for mask in range(1<<len(big)):
                    inside={big[j] for j in range(len(big)) if mask>>j&1}
                    if any(j in inside and i not in inside for i in big for j in big if j in reach[i]):continue
                    lower=set(z['forced_left'])|{i for i in range(m) if reach[i]&inside}
                    outside=set(big)-inside
                    forbidden=set(z['forced_right'])|set().union(*(reach[i] for i in outside)) if outside else set(z['forced_right'])
                    if lower&forbidden:continue
                    lo=sum(z['weights'][i] for i in lower)
                    hi=sum(z['weights'][i] for i in range(m) if i not in forbidden)
                    predicted.update(range(lo,hi+1))
                assert actual==predicted,(w,n,a,r,actual,predicted,z)
                profile_checks+=1
    return dict(tested=tested,nontrivial=nontrivial,multiple_nonunit=multiple,exact_component_profile_checks=profile_checks,examples=examples,scope='Specified canonical endpoint bridge, at most one active root on each unmatched wall; no arrival/optimality claim.')

if __name__=='__main__':
    out=run();Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items() if k!='examples'}))

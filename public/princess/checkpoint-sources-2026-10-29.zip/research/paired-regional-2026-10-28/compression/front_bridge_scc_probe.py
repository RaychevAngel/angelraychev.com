"""Matching SCC geometry for literal bridges between opposite canonical fronts."""
from pathlib import Path
import json,random
from pyramid_interpolation_replay import paths,support

def matching_scc(A,B):
    A=sorted(A);B=sorted(B);bs=set(B)
    adj={u:[(u[0]+dx,u[1]+dy)for dx,dy in ((1,0),(-1,0),(0,1),(0,-1))
            if (u[0]+dx,u[1]+dy)in bs]for u in A}
    mt={}
    def aug(u,seen):
        for v in adj[u]:
            if v in seen:continue
            seen.add(v)
            if v not in mt or aug(mt[v],seen):mt[v]=u;return True
        return False
    for u in A:aug(u,set())
    pairs=sorted((u,v)for v,u in mt.items());idx={u:i for i,(u,v)in enumerate(pairs)}
    ridx={v:i for i,(u,v)in enumerate(pairs)}
    dag=[set()for _ in pairs]
    forceL=set();forceR=set()
    for u in A:
        for v in adj[u]:
            if u not in idx:forceR.add(ridx[v])
            elif v not in ridx:forceL.add(idx[u])
            elif idx[u]!=ridx[v]:dag[idx[u]].add(ridx[v])
    # A matched pair is encoded x=1 when left endpoint is in the cover.
    # Edge L_i--R_j requires x_j<=x_i, hence successor closure for x=0.
    m=len(pairs);reach=[]
    for i in range(m):
        seen={i};todo=[i]
        while todo:
            v=todo.pop()
            for z in dag[v]:
                if z not in seen:seen.add(z);todo.append(z)
        reach.append(seen)
    comps=[];assigned=set()
    for i in range(m):
        if i in assigned:continue
        c={j for j in reach[i]if i in reach[j]};comps.append(c);assigned|=c
    ci={v:i for i,c in enumerate(comps)for v in c};edges=set()
    for i in range(m):
        for j in dag[i]:
            if ci[i]!=ci[j]:edges.add((ci[i],ci[j]))
    # Compute the reduction at component level.
    cr=[{ci[j]for j in reach[next(iter(c))]}for c in comps]
    red={(i,j)for i,j in edges if not any(z!=i and z!=j and z in cr[i]and j in cr[z]for z in range(len(comps)))}
    fl={ci[i]for i in forceL};fr={ci[i]for i in forceR}
    # Closure: force left (x=1) propagates backwards; force right forwards.
    fl={i for i in range(len(comps))if cr[i]&fl}
    fr=set().union(*(cr[i]for i in fr))if fr else set()
    assert not fl&fr
    free=set(range(len(comps)))-fl-fr
    freeedges={(i,j)for i,j in red if i in free and j in free}
    und={i:set()for i in free}
    for i,j in freeedges:und[i].add(j);und[j].add(i)
    chain=all(j in cr[i]or i in cr[j]for i in free for j in free)
    pathforest=all(len(v)<=2 for v in und.values())
    visited=set();forest=True
    def visit(v,parent):
        nonlocal forest
        visited.add(v)
        for z in und[v]:
            if z==parent:continue
            if z in visited:forest=False
            else:visit(z,v)
    for i in free:
        if i not in visited:visit(i,None)
    return dict(matching=len(pairs),left=len(A),right=len(B),weights=[len(c)for c in comps],
                free=sorted(free),forced_left=sorted(fl),forced_right=sorted(fr),
                reduction=sorted(red),chain=chain,pathforest=pathforest,forest=forest,
                pair_coordinates=pairs)

def main():
    rng=random.Random(2026102913);tested=0;notchain=[];notpath=[];notforest=[];multiplebig=[]
    for w,n in ((4,4),(4,6),(6,6),(6,8),(8,8),(8,10)):
        ps=[paths(w,n,p)for p in (0,1)]
        colors=[{(x,y)for x in range(w)for y in range(n)if(x+y)%2==p}for p in (0,1)]
        for _ in range(2000):
            a=rng.choice(ps[0]);r=rng.choice(ps[1^((n-1)%2)])
            H=support(a,n,0);R={(x,n-1-y)for x,y in support(r,n,1^((n-1)%2))}
            A=colors[0]-H;B=colors[1]-R
            z=matching_scc(A,B);tested+=1
            row=dict(w=w,n=n,a=a,r=r,**z)
            if not z['chain'] and len(notchain)<4:notchain.append(row)
            if not z['pathforest'] and len(notpath)<4:notpath.append(row)
            if not z['forest'] and len(notforest)<4:notforest.append(row)
            if sum(z['weights'][i]>1 for i in z['free'])>1 and len(multiplebig)<4:multiplebig.append(row)
    out=dict(tested=tested,nonchain=notchain,non_path_forest=notpath,nonforest=notforest,multiple_big=multiplebig)
    Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out))

if __name__=='__main__':main()

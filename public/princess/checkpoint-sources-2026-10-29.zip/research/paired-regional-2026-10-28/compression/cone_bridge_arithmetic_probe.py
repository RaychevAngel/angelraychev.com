"""Row-arithmetic version of the reviewed cone-and-cover gate criterion."""
from pathlib import Path
import sys,json
ROOT=Path(__file__).resolve().parents[3];sys.path.insert(0,str(ROOT/'src'))
from resumed_even_construction_prefix_arithmetic import erosion_count,neighborhood_count
from bridge_upper_transport import prefix_height

def size(a,p):return sum(max(0,(x-(p-i)%2)//2+1)for i,x in enumerate(a))
def clipped(a,n,p,far=False):
 top=n-2 if far else n-1
 return tuple(max((p-i)%2-2,min(v,top-((top-p+i)%2)))for i,v in enumerate(a))
def union(a,b):return tuple(max(x,y)for x,y in zip(a,b))
def difference(a,b,p):return size(a,p)-size(tuple(min(x,y)for x,y in zip(a,b)),p)

def direct(w,n,k,c,e,Delta,ell):
 """Direct interpolation into Y intersect N^Delta(A), with literal guards."""
 b=w//2;h=w*n//2;H=b*(b-1);d=k-b;rows=[]
 cap=(c,c)
 for _ in range(ell):cap=tuple(min(h,k+erosion_count(w,n,1-p,cap[1-p]))for p in(0,1))
 for p0 in(0,1):
  belief=h;ph=p0
  for _ in range(e):belief=neighborhood_count(w,n,ph,max(0,belief-k));ph^=1
  px=ph^((n-1)%2);X=tuple(n-3-v for v in prefix_height(w,n,ph,belief));q=size(X,px)
  p=px^(Delta%2);B=clipped(tuple(v-Delta for v in X),n,p)
  assert all(abs(X[i]-X[i-1])==1 for i in range(1,w))
  if any(v>=n-1 for v in X):continue
  for side in(0,1):
   rel=p^((n-1)%2)^(side*((w-1)%2));Y=cap[rel]
   yh=prefix_height(w,n,rel,Y)
   if side:yh=tuple(reversed(yh))
   CY=clipped(tuple(n-3-v for v in yh),n,p)
   overlap=difference(B,CY,p);Z=Y-overlap;credit=q+Y+d*Delta-h
   success=Z>H+1 and h-q>=Z and overlap<=credit
   rows.append(dict(p0=p0,side=side,head_holes=q,tail_belief=Y,retained_holes=size(B,p),overlap=overlap,credit=credit,target_intersection_size=Z,success=success))
 return dict(shape=[w,n],budget=k,c=c,head=e,middle=Delta,tail=ell,updates=e+Delta+ell,
  success=any(z['success']for z in rows),rows=rows,
  scope='Reviewed direct canonical interpolation into Y intersect N^Delta(A); literal source containment, regular target and per-day quota. Fixed canonical endpoints, not an unrestricted normal form.')

def run(w,n,k,c,e,Delta,ell,keep_profiles=False):
 b=w//2;h=w*n//2;H=b*(b-1);d=k-b;t=Delta-2
 if t<0:return dict(rows=[],success=False,reason='Fewer than two middle updates.')
 cap=[(c,c)]
 for _ in range(ell):cap.append(tuple(min(h,k+erosion_count(w,n,1-p,cap[-1][1-p]))for p in(0,1)))
 rows=[]
 for p0 in(0,1):
  belief=h;ph=p0
  for _ in range(e):belief=neighborhood_count(w,n,ph,max(0,belief-k));ph^=1
  bh=prefix_height(w,n,ph,belief);px=ph^((n-1)%2)
  X=tuple(n-3-v for v in bh);q=size(X,px)
  pk=px^(t%2);base=clipped(tuple(v-t for v in X),n,pk)
  U=clipped((n,)*w,n,pk,far=True);Q=q+d*t
  guard=size(base,pk)<=Q<=size(U,pk) and Q>H and h-Q>H+1
  if not guard:
   rows.append(dict(p0=p0,source_holes=q,endpoint_holes=Q,success=False,reason='Constructive cone guard not met.'));continue
  assert all(abs(X[i]-X[i-1])==1 for i in range(1,w))
  assert all(v<n-1 for v in X)
  for side in(0,1):
   py=px^(Delta%2);rel=py^((n-1)%2)^(side*((w-1)%2));ys=cap[ell][rel]
   rs=erosion_count(w,n,rel,ys);rh=prefix_height(w,n,1-rel,rs)
   if side:rh=tuple(reversed(rh))
   pr=1-py;assert pr==1-pk
   C=clipped(tuple(n-2-v for v in rh),n,pk)
   roots=[i for i in range(w)if(i+n-1)%2==pr and rh[i]<0]
   if len(roots)>1:
    rows.append(dict(p0=p0,side=side,success=False,reason='More than one exposed root.'));continue
   J=clipped(tuple(min(n-abs(i-roots[0]),n-2 if i==roots[0]else n)for i in range(w)),n,pk)if roots else tuple((pk-i)%2-2 for i in range(w))
   m=max(difference(C,U,pk),size(union(base,C),pk)-Q)
   f=max(difference(J,U,pk),size(union(base,J),pk)-Q)if roots else 0
   row=dict(p0=p0,tail_corner_side=side,source_holes=q,endpoint_holes=Q,
    base_size=size(base,pk),tail_belief=ys,tail_survivor=rs,matching_min=m,forced_min=f,
    root_count=len(roots),success=m<2*k or(m==2*k and f<=k))
   if keep_profiles:row.update(base=base,C=C,J=J,U=U,X=X,phase=pk)
   rows.append(row)
 return dict(shape=[w,n],budget=k,terminal_quota=c,early=e,middle=Delta,late=ell,
  updates=e+Delta+ell,success=any(z['success']for z in rows),rows=rows,
  scope='Exact row counts for a sufficient actual prefix-cone-bridge-tail construction; failure is not a lower bound.')

if __name__=='__main__':
 out=[run(64,93,48,24,41,62,39),run(64,65,48,24,41,6,39),run(128,128,66,66,346,63,314)]
 Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
 print(json.dumps(out,indent=2))

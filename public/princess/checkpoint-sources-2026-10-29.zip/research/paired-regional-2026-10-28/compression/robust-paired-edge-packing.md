# A sharp edge-packing certificate from endpoint intervals and masses

29 October2026. Ordinary necessary bridge certificate. The numerical
relaxation below is exact for its interval-and-cardinality data; it is
not an attainability theorem for the physical histories supplying them.

## 1. Input data on one genuine two-inspection bridge

At the first inspection let H be the actual holes of one physical color,
and let R be the allowed survivors of the other physical color after the
second inspection. Let M be ANY specified matching of physical board
edges. Full-board perfection is not required. An edge of M not hit by
H or R survives in the bridge graph and must be hit by one of the two
inspections. Different edges require different inspections, since M is
a matching.

Suppose actual history arguments have supplied

    L_H subset H subset U_H,    |H|=q_H,
    L_R subset R subset U_R,    |R|=q_R.                 (1)

All sets have their true physical colors and occur at the indicated
clocks. Write

    a=q_H-|L_H|,    b=q_R-|L_R|.

Require `0<=a<=|U_H minus L_H|` and the analogous condition for b;
otherwise the endpoint data are already impossible.

First discard the p matching edges hit by L_H or L_R. On the remaining
edges classify optional availability:

* u edges have an H endpoint in U_H, but no R endpoint in U_R;
* v edges have an R endpoint in U_R, but no H endpoint in U_H;
* l edges have both endpoints available;
* z edges have neither endpoint available.

The maximum number of these edges that optional holes can hit is

    F=min(u+v+l, a+b, a+v+l, b+u+l).                    (2)

Therefore every actual two-inspection bridge satisfies

    k_0+k_1 >= |M|-p-F = u+v+l+z-F.                   (3)

This retains real endpoint masses and actual mandatory cells. It does
not independently choose convenient corner labels or charge one earlier
inspection quota twice.

## 2. Why the interval relaxation is exact

Each optional H hole can hit at most one matching edge, and likewise for
R. The four quantities in(2) are upper bounds: the number of available
edges, total available holes, all R-only/both edges plus H capacity, and
the symmetric bound.

To attain their minimum, first hit as many H-only edges as possible,
then as many R-only edges as possible. This covers
`min(a,u)+min(b,v)` edges. Use remaining holes from either side on distinct
both-available edges, giving

    min(a,u)+min(b,v)
      +min(l,max(0,a-u)+max(0,b-v)).                 (4)

Splitting into the four cases a<=u or a>u, b<=v or b>v verifies that(4)
equals(2). The chosen optional holes use at most a and b cells. Fill any
remaining required endpoint cardinality arbitrarily within its allowed
outer set. Such filling cannot uncover an edge; by the upper bound it
also cannot improve on F. Thus some sets satisfying(1) attain equality
in(3) for this specified matching. Raw geometry or actual reachability
may forbid those sets, which can only strengthen the true obstruction.

No optimization over endpoint sets is needed to evaluate(2): only the
four edge-class counts and two capacities. Counting them costs linear
time in the chosen packing and supplied set representations.

## 3. Multiple packings, cohorts, and evidence boundary

Apply(3) to several specified physical matchings and keep the largest
lower bound; different packings must not be added, as they can share
inspection vertices. For two actual simultaneous cohorts, however,
construct a packing in each color-directed bridge component. Their
vertices occur in disjoint physical colors on each of the two days,
so the two resulting lower bounds CAN be added against the common
`k_0+k_1` budget. This requires both sets of endpoint premises from the
same genuine history. Relaxing endpoint splits independently remains
necessary but may be weaker.

Typical valid premises include actual containing corner triangles,
literal retained cores, fixed wall exclusions, and proved endpoint mass
bounds. An enclosing triangle together with a defect bound is not by
itself a fixed mandatory core: its missing cells may be anywhere allowed
by the genuine raw-layer theorem. A particular core must first be proved,
or the interval relaxation must be minimized over all allowed choices.
Likewise a matching internal to a guessed overlap is not silently assumed
to extend to a perfect matching; only the explicitly chosen edges enter M.

This certificate can reject a proposed gate bridge while allowing all
endpoint sets in its outer intervals. Its failure to reject says nothing
about their historical attainability or balanced per-day cover existence.
It does not establish a new global capture-time gap on its own.

## 4. The same certificate for an actual multi-update transport

Replace the matching M by any specified family of time-vertex-disjoint
walks of a common length t. Interpret H as holes at the initial layer,
and R as allowed survivor locations at the final layer. The initial and
final endpoints are distinct within their layers, so exactly the same
four optional endpoint classes and formula(2) apply. Every walk whose
initial endpoint is not in H and whose final endpoint is not in R must
be intercepted by an inspection at one of the first t layers. Time-vertex
disjointness ensures one inspection intercepts at most one such walk.
Thus the right side of(3) is a lower bound on the sum of the t actual
inspection quotas.

In particular the explicit parallel-column packing in
`../root/column-trajectory-transport.md` can be used as M. This refines
its coarse endpoint-defect subtraction when stronger endpoint intervals
and masses are known: endpoint holes on the same walk do not eliminate
two paths, mandatory holes are counted once, and holes outside all packed
path endpoints provide no interception. The actual individual daily
quotas remain necessary additional constraints; this total-quota
certificate never treats them as freely transferable between days.

The timing differs from the original two-inspection bridge: t physical
inspection-and-movement updates inspect layers0 through t-1 and constrain
the pre-inspection belief at layer t. If the final target R is instead a
post-inspection survivor set at layer t, also include that final layer's
quota. The original bridge is t=1 movement with inspections at BOTH layers.
The endpoint counting formula is unchanged, but the quota sum must match
which physical layers are actually inspected.

"""Independent endpoint-subset audit of exact interval/cardinality packing."""
from pathlib import Path
from itertools import combinations
import random,json

def subsets(s,k):
 return [set(v) for v in combinations(s,k)] if 0<=k<=len(s) else []
def run():
 rng=random.Random(2026102953);checks=0;endpointpairs=0
 for _ in range(2500):
  m=rng.randrange(0,7);N=m+rng.randrange(0,3)
  status=[[rng.randrange(3) for _ in range(N)] for _ in range(2)]
  L=[{i for i,s in enumerate(row) if s==2} for row in status]
  U=[{i for i,s in enumerate(row) if s>=1} for row in status]
  q=[rng.randrange(len(L[p]),len(U[p])+1) for p in (0,1)]
  a,b=[q[p]-len(L[p]) for p in (0,1)]
  remains=[i for i in range(m) if i not in L[0] and i not in L[1]]
  u=sum(i in U[0] and i not in U[1] for i in remains)
  v=sum(i in U[1] and i not in U[0] for i in remains)
  l=sum(i in U[0] and i in U[1] for i in remains)
  F=min(u+v+l,a+b,a+v+l,b+u+l);predicted=len(remains)-F
  actual=m
  for x in subsets(U[0]-L[0],a):
   H=L[0]|x
   for y in subsets(U[1]-L[1],b):
    R=L[1]|y;actual=min(actual,sum(i not in H and i not in R for i in range(m)));endpointpairs+=1
  assert actual==predicted,(m,L,U,q,predicted,actual)
  checks+=1
 return dict(instances=checks,literal_endpoint_pairs=endpointpairs,maximum_packing=6,scope='Exact endpoint interval-and-cardinality relaxation for a specified disjoint edge packing; no physical-history attainability claim.')
if __name__=='__main__':
 out=run();Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))

# All-cut ancestor certificates: successes and a precise stopping point

29 October 2026. Ordinary necessary-history computation, not Lean verification
or a uniform capture-time theorem.

The implementation is `ancestral_gate_certificate_probe.py`. It uses the
accepted common-deficit reduction at the actual first/last pronic cuts, the
new shifted ordinary cap `H+k`, sensitive-ancestor demand, and the unique-mass
credit-creator theorem. Each actual physical phase and every scalar-feasible
cut is retained. Reverse endpoint and creator bounds cover all genuine
activation indices; no reverse history is restarted from a chosen prefix.

## 1. Exact finite scalar-cut enumeration

For `w=2b`, `k=b+d`, `1<=d<=b-1`, write `H=b(b-1)`, `h=bn`.
An alleged faster gate has actual

    H-d+1<=Q<=H, H+1<=Y<=H+d+1,
    e+Delta+ell=T,
    R=Q+Y+d Delta-h>=0,
    delta_E=max E_e-Q, delta_L=max V_ell-Y,
    delta_E+delta_L+R<g=min(span E_e,span V_ell)<=d.

These finite inequalities are enumerated literally. In particular possible
clock ranges are not replaced by independently optimal head and tail clocks.
If no cut remains, the scalar theorem already rejects the whole deadline.

Before the first cut the forward cap is
`min(max E_s,H-d)`. Backward mass requirements therefore force actual
sensitive seeds when their availability is tight enough. At the late real
day `v=T-ell`, the reverse allowed set has size at least `Y-k`, at most
`max V_ell-k`, and incoming availability at most `max V_(ell-1)` for EVERY
activation branch. The actual holes at this day have exactly `h-Y` cells,
so the allowed-set intersection excess is at most `max V_ell-Y`.

## 2. A successful even-square certificate

For `128 by 128, k=66, c=66`, the physical prefix gate is724 and the tested
deadline723 has exactly one scalar cut:

    Q=4032, Y=4034, e=346, ell=314, Delta=63,
    g=1, delta_E=delta_L=R=0.

Backward forward-demand forces an own root63 triangle with at most one
missing cell at clock314. The actual reverse endpoint at day409 is another
own root63 triangle with at most one missing cell. Its availability4031
and required size3968 work uniformly over all activation indices.

The early triangle has aged95 moves, leaving radius29. The two actual
seed colors are opposite; on the even square their possible corner pairs
are adjacent. Every such literal intersection has105 cells. The total raw
defect and allowed-set excess is2. Thus this complete candidate gate is
excluded. This is stronger than failure of a particular prefix construction.

The same implementation independently reproduces the complete64 by65,
`k=48,c=24,T=86` rejection. Exact counts are in
`ancestral_gate_certificate_probe.json`.

## 3. Creator alternatives require the existing matching-phase theorem

The first bounded diagnostic failure was64 by64, `k=40,c=40,T=133`.
Its actual cut has `Q=992,Y=1000,e=65,ell=61,Delta=7`, and no deterministic
sensitive-seed demand fires. The demanded positive tokens still have true
sensitive creators. Tracking a token through minority-map first preimages
gives one possible creator mass per clock.

Using only maximum reference caps leaves creator61/root31/defect1 and
creator60/root31/defect9. Opposite parities spuriously allow antipodal
corner choices. The accepted ordinary matching theorem rules this out:
an OWN sensitive creator obeys coordinate0, not the maximum coordinate.
Moreover its tracked minority suffix is bounded by the alternating matching
reference branch, so the age parity must equal the unique endpoint leader.
These are necessary actual-history filters, not an assumed normalization.

Both creator domains reduce to clock60/root31/defect9. Every actual corner
pair then violates the same-day lens, with minimum margin258. The original
unfiltered diagnostics are retained as evidence of what the weaker model
forgot; the corrected files have `phase` in their names.

## 4. The first stopping point was resolved by a better construction

The prescribed bounded diagnostic stopped at the first surviving case after
26 tested parameter combinations:

    64 by93, k=48, c=24, prefix gate143, tested gate142;
    Q=989, Y=995, e=41, ell=39, Delta=62;
    g=1, delta_E=delta_L=R=0.

The domains are already singletons: forward creator39/root31/defect4;
reverse creator at absolute index39/root31/defect14. Thus this failure is
not a missing creator choice, activation choice, or ordinary phase label.

At the late cut the early raw marker has radius minus4 and is extinct.
At any intermediate common cut the two retained radii sum to60, below the
distance92 between the two admissible opposite-longitudinal-end corners.
Their intersection test gives zero. The numerical phase token survives the
long critical middle even though the original localized marker has expired.

This initially suggested refreshing the phase label through the critical
middle. The subsequent physical construction showed that this would have
been the wrong exclusion target: the142-update gate EXISTS. The actual
prefix head, canonical arrival cone, and a balanced two-inspection bridge
produce it. `long_middle_gate_literal_replay.py/.json` independently replay
every update from full uncertainty. Its solo residue24 gives a
reflection palindrome of length285, and the separate all-cut lower
bound proves `T_48(64,93)=285`. Thus the universal fixed-prefix-gate
optimality conjecture is false, even though the prefix remains an upper
bound. The dead ancestor is a signal to test a better construction.

`ancestral_creator_structural_diagnostic.json` records that historical
stopping point. The later prescribed170-case diagnostic resolved165 by
necessary certificates and5 by physical construction; it is finite evidence,
not a uniform theorem.

## 5. Positive credit requires reshaping the actual raw boundary

The seeded adversarial diagnostic stopped at its264th tested case:
`102 by124,k72,c36`, prefix gate207, tested gate206. There were three
scalar cuts, all at e75,ell73,Delta58, with g2 and one unit divided between
early deficit, late deficit, and middle credit. All excess-token birth
orders, same-history retained triangles, phase labels and pairwise lenses
survived. The standard-prefix cone and even direct whole-middle transfer
failed over1,085 head/tail clock pairs. Flexible first-tail inspection alone
still missed by one. These were failures of restricted constructions.

Root's shared raw-layer relaxation supplied genuinely different small
notches. The forward own root50 triangle has left deficits
`alpha_45=1,alpha_46=3,alpha_47=4,alpha_48=5,alpha_49=6`, total19;
the reverse own root50 triangle has `alpha_48=2,alpha_49=7`, total9.
All unspecified defects are zero. The exact backward-neighborhood greedy
builder reaches the forward target by72 updates. The actual reverse-side
tail from the neighborhood of its target takes72 updates to36 cells.
After61 moves the two retained supports are disjoint. Direct regular-
pyramid interpolation and a71-shot first-tail inspection therefore join
these actual boundary words into206 updates. The complete literal replay
is `raw_notch_gate_102_replay.py/.json`, including a413-day full-capture
word. The all-cut lower bound excludes205 updates for both c72 and c71;
with matching noncontraction and the retained all-split theorem this gives
`T_72(102,124)=413`. The phase lane independently replayed all413 updates
and checked the separate lower-bound arithmetic.

This again turns a surviving necessary certificate into a constructive
improvement, but it does NOT prove a general lower-or-construction
dichotomy. The missing uniform statement concerns simultaneous selection
of raw boundary profiles, their actual arrival/tail clocks, and the
middle overlap. The shared raw-layer model is a necessary relaxation;
the greedy builders are sufficient physical constructions. Their uniform
equivalence remains unproved.

"""Literal complete gate from newly reachable raw notches; no inferred lower bound."""
from pathlib import Path
import sys,json,hashlib
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
from raw_profile_backward_arrival_probe import neigh
from pyramid_interpolation_replay import height,support,pred
w,n,k,c=102,124,72,36;b=w//2;d=k-b;h=w*n//2
V=[{(x,y)for x in range(w)for y in range(n)if(x+y)%2==p}for p in(0,1)]
flip=lambda S:{(x,n-1-y)for x,y in S}
def rank(lower,upper,p,Q):
 z=list(lower);area=sum(max(0,(v-(p-i)%2)//2+1)for i,v in enumerate(z))
 while area<Q:
  for i,a in enumerate(z):
   if a+2<=upper[i] and all(z[j]==a+1 for j in(i-1,i+1)if 0<=j<w):z[i]+=2;area+=1;break
  else:raise AssertionError(('rank stuck',area,Q))
 return tuple(z)
def construct(A,Z,T):
 A=flip(A);Z=flip(Z);p=sum(next(iter(A)))%2;a=height(A,w,p);z=height(Z,w,(p+T)%2)
 assert support(a,n,p)==A and support(z,n,(p+T)%2)==Z
 ups=[a];U=A
 for t in range(T):U=neigh(U,w,n);ups.append(height(U,w,(p+t+1)%2))
 qs=[max(len(Z),len(A)-d*t)for t in range(T+1)];zz=[None]*(T+1);zz[T]=z
 for t in range(T-1,-1,-1):
  ph=(p+t)%2;lower=pred(zz[t+1],1-ph)
  repaired=tuple(max(v,min(u,(ph-i)%2))for i,(v,u)in enumerate(zip(lower,ups[t])))
  zz[t]=rank(repaired,ups[t],ph,qs[t])
 assert zz[0]==a
 shots=[]
 for t in range(T):
  ph=(p+t)%2;B=support(zz[t],n,ph);S=support(pred(zz[t+1],1-ph),n,ph)
  assert S<=B and len(B-S)<=k and neigh(S,w,n)==support(zz[t+1],n,1-ph)
  shots.append(flip(B-S))
 return shots

def main():
 source=HERE/'raw_profile_middle_probe.json';row=json.loads(source.read_text())[-1]
 F={tuple(v)for v in row['Fcells']};R={tuple(v)for v in row['Rcells']}
 assert len(F)==2481 and len(R)==2491
 # Construct actual head by reverse neighborhood deletion toward corner(0,0).
 H=set(F);back=[]
 while H:
  N=neigh(H,w,n);old=set(sorted(N,key=lambda v:(sum(v),v[0]))[:max(0,len(N)-k)])
  back.append(N-old);H=old
 head=list(reversed(back));assert len(head)==72
 A=V[0]-F;U=set(A)
 for _ in range(61):U=neigh(U,w,n)
 assert R<=U
 p=sum(next(iter(flip(R))))%2
 Zlocal=rank(height(flip(R),w,p),height(flip(U),w,p),p,len(A)-61*d)
 Z=flip(support(Zlocal,n,p));assert R<=Z<=U and len(Z)==2562
 middle=construct(A,Z,61)
 first_tail=Z-R;assert len(first_tail)==71
 tail=[{tuple(v)for v in S}for S in row['tails'][0]['shots']]
 shots=head+middle+[first_tail]+tail;assert len(shots)==206
 solo=set(V[0]);belief=V[0]|V[1];counts=[];fullcounts=[]
 for t,I in enumerate(shots,1):
  assert len(I)<=k and all(sum(v)%2==(t-1)%2 for v in I)
  solo=neigh(solo-I,w,n);belief=neigh(belief-I,w,n);counts.append(len(solo));fullcounts.append(len(belief))
  assert len(belief)==h+len(solo)
  if t==72:assert solo<=A
  if t==133:assert solo<=Z
  if t==134:assert solo<=neigh(R,w,n)
 assert len(solo)<=c
 rx=lambda S:{(w-1-x,y)for x,y in S}
 center=belief&rx(belief);assert len(center)<=k
 word=shots+[center]+[rx(I)for I in reversed(shots)];B=V[0]|V[1];capcounts=[];first=None
 for day,I in enumerate(word,1):
  assert len(I)<=k;B-=I
  if not B and first is None:first=day
  B=neigh(B,w,n);capcounts.append(len(B))
 assert not B
 out=dict(shape=[w,n],budget=k,terminal_quota=c,gate_updates=len(shots),final_solo=len(solo),final_signed=len(belief)-h,
  head_updates=72,middle_updates=61,first_tail_shots=len(first_tail),tail_updates=72,
  head_target_size=len(F),reverse_target_size=len(R),middle_target_size=len(Z),center_size=len(center),
  full_capture_day=first,source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
  shot_max=max(map(len,word)),solo_counts=counts,full_counts=fullcounts,gate_shots=[sorted(I)for I in shots],
  capture_counts=capcounts,capture_shots=[sorted(I)for I in word],
  scope='Literal full-uncertainty solo206 gate and413capture word. Source and tail are actual words, middle uses proved regular-pyramid interpolation. Lower optimality is a separate claim.')
 Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
 print(json.dumps({a:v for a,v in out.items()if a not in('solo_counts','full_counts','gate_shots','capture_counts','capture_shots')}))
if __name__=='__main__':main()

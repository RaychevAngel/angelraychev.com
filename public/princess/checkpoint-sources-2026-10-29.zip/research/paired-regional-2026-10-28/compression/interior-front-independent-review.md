# Independent review of the interior full-front core

29 October 2026. Reviewed `../phase/interior-front-core.md` after deriving
the geometry independently from root's suggestion. Ordinary proof review;
no Lean coverage or capture-time conclusion follows.

Accepted statement: if M is the largest majority-fiber length and it is
attained at x0=2i0, then the actual full front contains the parity ball
centered at (x0,0) of radius 2M-2, truncated by the actual board. The literal
fiber heights differ by exactly one, so at each x their height is at least
2M-2-|x-x0|. This proves the full ball inclusion, not just a deep column.
Since every fiber has at most M cells, q<=(2b+1)M. If q>(b-1)^2, integrality
gives radius R>=b-4.

The identity-change barrier remains valid with this interior center. After
Delta<R updates the residual ball contains two current-color near-end
cells. With odd residual radius use a horizontal neighbor of the center
and its vertical neighbor; with positive even radius use the center and a
short-side vertex two units away. All these vertices exist in scope.
Opposite-end localized supports cannot reach them because their radius is
at most 2b-2 while the relevant longitudinal distances are at least 2b.
One singleton outlier cannot absorb both. An opposite-end full front
omits its far paired row in every majority fiber and has no longer minority
fiber, so it omits the relevant near-end color layer across the WHOLE
short side. A changed cohort likewise cannot absorb two old-cohort cells.

The radius-zero accounting charge also survives. The center has even short
coordinate, as do both near-end corners, so it cannot be adjacent to a
corner singleton. Far-end corners are distant. The opposite-end localized
neighborhood and proper full front neighborhood both omit this center.
Thus an incompatible next good event loses one usable old hole.

Reported one cosmetic inequality issue: the first strict sign in display
(I2) should be nonstrict before its subsequent strict lower bound. The
substantive conclusion R>b-5 and hence R>=b-4 is valid. The existing
sufficient condition 2E<=b-6 is conservative; R-1>=b-5 directly follows.

Critical limitation preserved: the center need not be a BOARD CORNER.
Use this core for phase persistence and the unusable-origin charge only;
it cannot be substituted into corner-lens geometry without a new proof.

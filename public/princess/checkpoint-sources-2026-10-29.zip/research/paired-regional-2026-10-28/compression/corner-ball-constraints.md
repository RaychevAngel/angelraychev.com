# Corner-ball constraints recover the small operator but not a uniform selector

29 October 2026. Finite structural evidence and a general necessary lemma.
No new rectangle normal form is claimed.

## Necessary overlap constraints

Let C be monotone and cardinality preserving. If C(J)=J', then for every A,

    |C(A) intersect J'| >= |A intersect J|.

Indeed C(A intersect J) is contained in both C(A) and C(J), and has the
cardinality of A intersect J.

Suppose additionally N C(A) is contained in C(N A), where N is the literal
open graph neighborhood. If C maps a singleton corner {c} to {f(c)}, then
it maps every exact-walk ball N^t({c}) to N^t({f(c)}), provided those two
balls have equal cardinality at every preceding radius. Inclusion follows
by iteration, and equal cardinality makes it equality. On a rectangle
all corner balls at the same walk radius are related by reflection and
therefore have the same cardinality.

For an even transverse width w and even length n, coordinates are
0<=x<w, 0<=y<n. Fix the corner image assignment

    f(c)=(0,0) if x_c+y_c is even,
    f(c)=(w-1,0) if x_c+y_c is odd.

Thus each physical color's two corners map to its own bottom corner.
For every source subset A of one checkerboard color and every physical
corner c and integer t>=0 for which N^t({c}) has A's color, any such
compression must satisfy

    |C(A) intersect N^t({f(c)})| >= |A intersect N^t({c})|.

These are exact-walk parity balls, not ordinary closed balls containing
both colors. After saturation, repeated constraints add nothing.

## Tested selector

Generate all downward pyramids I of the source color having |I|=|A|.
Keep those satisfying the corner inequalities. Select the least numeric
bit mask, using row-major (x then y) ordering within each color.
A stronger variant additionally imposes

    |I intersect J| >= |A intersect J|

for every downward pyramid J, as required of a retraction fixing J.

This is a precisely defined finite selector, not a proved general
compression. No state is inferred reachable from these constraints.

## Exhaustive results

- 4x6: every 8,192 parity subset passes monotonicity on all one-cell
  inclusions, N inclusion, idempotence and fixing every pyramid. The
  corner-only selector equals **every image** of the earlier successful
  finite CSP operator in `uniform-even-rectangle-compression-map.json`.
- 4x8: every 131,072 parity subset passes the same checks. There are
  32 pyramids per color.
- 6x6: all 524,288 parity subsets have nonempty feasible domains, and
  every pyramid is fixed. Nevertheless corner-only selection has
  1,772 monotonicity violations and 6 N-inclusion violations.
- 6x6 with every fixed-pyramid constraint: still no empty domain and
  every pyramid fixed, but 1,698 monotonicity and 5 N violations.

The first inclusion failure is elementary:

    A={(0,2)} subset B={(0,2),(4,0)},
    C(A)={(2,0)},
    C(B)={(0,0),(4,0)}.

This fails even with every fixed-pyramid overlap constraint. The known
square diagonal operator instead maps B to {(2,0),(4,0)}. Thus the
failure identifies a **compatible selection** problem, rather than
showing that pyramids are too small or that no suitable operator exists.
Indeed the square theorem independently supplies an operator on 6x6.

## Reproducibility and remaining target

Implementation: `corner_ball_compression.cpp`, compile as C++20.
Arguments are w n, followed optionally by `fixed` to include every
fixed-pyramid overlap constraint. Receipts are
`corner-ball-general-{4x6,4x8,6x6}.json` and
`corner-ball-fixed-6x6.json`. The initial exact comparison with the old
CSP map is in `corner_ball_map_audit.py` / `corner-ball-map-audit.json`.

A uniform proof would need compatible choices across nested inputs and
neighborhood images, not merely feasible endpoint profiles. A possible
route is a stable ancestry-preserving transport or an actual sequence
of neighborhood-compatible operators. The present corner-distance
constraints are necessary tests for such a construction, not its proof.

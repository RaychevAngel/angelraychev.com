#include <algorithm>
#include <bit>
#include <cstdint>
#include <iostream>
#include <tuple>
#include <vector>
using namespace std;
struct Edge{int lo,hi,x,y,dx;};
int main(int argc,char**argv){int w=argc>1?atoi(argv[1]):4,n=argc>2?atoi(argv[2]):6,h=w*n/2;if(w%2||n%2||h>20)return 2;
 vector<pair<int,int>>vs[2];int ix[24][32];for(int x=0;x<w;++x)for(int y=0;y<n;++y){int p=(x+y)%2;ix[x][y]=vs[p].size();vs[p].push_back({x,y});}
 vector<unsigned>N[2];vector<Edge>E[2],pre[3][2];vector<vector<int>>diag[2][2];
 for(int p=0;p<2;++p){N[p].resize(1u<<h);vector<unsigned>adj(h);for(int i=0;i<h;++i){auto[x,y]=vs[p][i];for(auto[xx,yy]:vector<pair<int,int>>{{x-1,y},{x+1,y},{x,y-1},{x,y+1}})if(xx>=0&&xx<w&&yy>=0&&yy<n)adj[i]|=1u<<ix[xx][yy];if(y)for(int dx:{-1,1})if(x+dx>=0&&x+dx<w)E[p].push_back({ix[x+dx][y-1],i,x,y,dx});int xx=w-1-x,yy=n-1-y;if(yy<y&&y-yy>=abs(x-xx))pre[2][p].push_back({ix[xx][yy],i,x,y,0});}
 for(unsigned s=1;s<N[p].size();++s){unsigned b=s&-s;N[p][s]=N[p][s^b]|adj[countr_zero(b)];}
 for(int x:{0,w-1}){int y=n-1;if((x+y)%2==p)pre[1][p].push_back({ix[w-1-x][0],ix[x][y],x,y,0});}
 sort(pre[2][p].begin(),pre[2][p].end(),[](Edge a,Edge b){return tuple{-a.y,a.x}<tuple{-b.y,b.x};});
 for(int d=0;d<2;++d)for(int k=-(n-1);k<=w+n-2;++k){vector<int>v;for(int i=0;i<h;++i){auto[x,y]=vs[p][i];if((d?x-y:x+y)==k)v.push_back(i);}sort(v.begin(),v.end(),[&](int i,int j){return vs[p][i].second<vs[p][j].second;});if(!v.empty())diag[d][p].push_back(v);}
 }
 for(int prep=0;prep<3;++prep)for(int norm=0;norm<6;++norm)for(int repeat=0;repeat<2;++repeat){if(prep==0&&repeat)continue;vector<unsigned>C[2];for(int p=0;p<2;++p){auto es=E[p];int mode=norm<4?vector<int>{0,1,4,5}[norm]:0;sort(es.begin(),es.end(),[&](Edge a,Edge b){auto key=[&](Edge e){return tuple{e.y,(mode&1)?-e.x:e.x,(mode&4)?-e.dx:e.dx};};return key(a)<key(b);});C[p].resize(N[p].size());for(unsigned s=0;s<C[p].size();++s){unsigned z=s;bool changed=true,first=true;while(changed){changed=false;auto compare=[&](Edge e){if((z>>e.hi&1)&&!(z>>e.lo&1)){z^=(1u<<e.hi)|(1u<<e.lo);changed=true;}};if(first||repeat)for(auto e:pre[prep][p])compare(e);first=false;
 if(norm<4){for(auto e:es)compare(e);}else for(int dd=0;dd<2;++dd){int d=norm==4?dd:1-dd;for(auto&v:diag[d][p]){int cnt=0;for(int i:v)cnt+=z>>i&1;for(int j=0;j<int(v.size());++j){int i=v[j];bool a=z>>i&1,b=j<cnt;if(a!=b){z^=1u<<i;changed=true;}}}}
 }C[p][s]=z;}}
 uint64_t nf=0;int fp=-1;unsigned fs=0,fl=0,fr=0;int minsize=h+1;unsigned mins=0;int minp=-1;for(int p=0;p<2;++p)for(unsigned s=0;s<C[p].size();++s){unsigned l=N[p][C[p][s]],r=C[1-p][N[p][s]];if(l&~r){++nf;if(fp<0){fp=p;fs=s;fl=l;fr=r;}if(popcount(s)<minsize){minsize=popcount(s);mins=s;minp=p;}}}
 cout<<"{\"w\":"<<w<<",\"n\":"<<n<<",\"prep\":"<<prep<<",\"normalizer\":"<<norm<<",\"repeat\":"<<repeat<<",\"N_failures\":"<<nf<<",\"first\":["<<fp<<","<<fs<<","<<fl<<","<<fr<<"],\"smallest\":["<<minp<<","<<mins<<","<<minsize<<"]}"<<endl;
 }
}

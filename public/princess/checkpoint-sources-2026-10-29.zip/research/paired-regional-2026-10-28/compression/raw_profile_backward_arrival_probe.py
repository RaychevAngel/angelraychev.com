"""Constructive backward raw-corner target diagnostic; no optimality claim."""
from pathlib import Path
import json
BASE=Path(__file__).resolve().parents[1]
def neigh(S,w,n):
 return {(u,v) for x,y in S for u,v in ((x-1,y),(x+1,y),(x,y-1),(x,y+1)) if 0<=u<w and 0<=v<n}
def target(m,alpha,C,w,n):
 A=dict(alpha);out=set()
 for i in range(m):
  for x in range(A.get(i,0),2*i+1):
   y=2*i-x;out.add((x if C[0]==0 else w-1-x,y if C[1]==0 else n-1-y))
 return out
def backward(Y,w,n,k,C,order):
 def key(v):
  x=abs(v[0]-C[0]);y=abs(v[1]-C[1]);s=x+y
  tie=(x,-x,abs(x-y),-abs(x-y))[order]
  return s,tie,x
 H=set(Y);hist=[len(H)];states=[H];shots=[]
 while H:
  N=neigh(H,w,n);q=max(0,len(N)-k);old=set(sorted(N,key=key)[:q]);shots.append(N-old);H=old;states.append(H);hist.append(len(H))
  if len(hist)>150:return dict(updates=None,history=hist)
 # Literal forward replay starts with no holes (the entire tracked cohort).
 holes=set();phase=(next(iter(Y))[0]+next(iter(Y))[1]+len(shots))%2
 V=[{(x,y)for x in range(w)for y in range(n)if(x+y)%2==p}for p in(0,1)]
 for I in reversed(shots):
  phase^=1;available=holes|I;holes={v for v in V[phase]if neigh({v},w,n)<=available}
 assert Y<=holes
 return dict(updates=len(shots),history=hist,final_holes=len(holes),target_size=len(Y),max_shots=max(map(len,shots),default=0))
def main():
 d=json.loads((BASE/'root/joint_ancestor_layer_probe.json').read_text());out=[]
 for row in d:
  for prof in row['result']['profiles']:
   s=prof['seed']
   if s['direction']!='forward':continue
   Y=target(s['root'],prof['positive_left_defects'],s['corner'],102,124)
   out.append(dict(Q=row['Q'],Y=row['Y'],seed=s,results=[backward(Y,102,124,72,s['corner'],o)for o in range(4)]))
 Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
 print(json.dumps([dict(Q=r['Q'],Y=r['Y'],required=r['seed']['index'],size=r['results'][0]['target_size'],updates=[z['updates']for z in r['results']])for r in out]))
if __name__=='__main__':main()

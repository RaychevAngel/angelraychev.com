# One-sided raw compression: the valid local theorem and the missing history interface

29 October2026,15:37UTC. Ordinary operator observation. It does not assert
an all-rectangle normal form or new capture-time classification.

## 1. A genuine quadrant operator

In the nonnegative square-grid quadrant, diagonal l consists of
(x,l-x),0<=x<=l. For a finite set S, let q_l be its cardinality on that
diagonal and replace it by the q_l cells with smallest x. Call this C(S).
Then C is monotone, cardinality preserving, and

    N(C(S)) subset C(N(S)).                           (D1)

The same holds for largest x by exchanging the two axes.

Proof. The upper shadow of a nonempty q-cell subset of diagonal l has
at least q+1 cells, with equality for an interval. The lower shadow has
at least q cells when q<=l, and has l=q-1 cells for the full diagonal.
For the prefix {0,...,q-1}, both shadows are prefixes and attain those
bounds (with the origin and empty set treated directly). On any target
diagonal, N(S) is the union of the upper shadow of one adjacent diagonal
and the lower shadow of the other. Its cardinality is at least the larger
of their two separate lower bounds. The compressed shadows are nested
prefixes, so their union has exactly that larger cardinality. This proves
(D1) diagonal by diagonal. Monotonicity and cardinality preservation are
immediate from the definition.

For a raw localized support with diagonal interval
[alpha_l,l-gamma_l], the largest-x version produces
[alpha_l+gamma_l,l]. Thus two-ended deficits become one-sided without
changing any diagonal mass. The raw strict-suffix condition is preserved:
if alpha+gamma is positive at one layer, at least one component is positive
and increases by at least one at every following occupied layer.

The operator also transports an ENTIRE finite hole history on the quadrant
without increasing any daily budget. Indeed N(X_t) subset X_(t-1) union I_t
implies

    N(C(X_t)) subset C(X_(t-1) union I_t).

By monotonicity C(X_(t-1)) lies in that last set, and the difference has
cardinality |I_t minus X_(t-1)|<=|I_t|. Inspecting this difference gives the
compressed transition. This is a true history statement on the quadrant;
it is not merely an assertion about independent endpoint masses.

## 2. Why the finite-rectangle extension is false

Take an unequal rectangle w by n with2<=w<n and the singleton
S={(w-1,0)}. It is a board corner and has two neighbors. The smallest-x
diagonal compression sends it to(0,w-1), which is an interior point of a
long side and has THREE board neighbors. Consequently

    |N_board(C(S))|=3 >2=|C(N_board(S))|.

Thus(D1) fails even for a singleton. Choosing the opposite fixed diagonal
order merely moves the obstruction to the other short-axis corner. This
is not an artifact of exponentially many states: it is the physical degree
change caused by folding one free boundary into an interior side point.

On diagonals beyond the shorter side, quadrant compression can also place
cells outside the board. Restricting the prefix to the actual truncated
board diagonal does not repair the neighborhood inequality above.
The existing successful square/odd-axis operators do not authorize this
unequal-even rectangle extension.

## 3. Why a last-sensitive ancestor does not yet permit the history proof

A precise limited positive statement is available. If a desired target Y
lies in a corner triangle of radius R and is reachable in T updates with
`R+T<min(w,n)`, its entire relevant causal history can be compressed.
Indeed replace each actual earlier hole set H_t by

    X_t=H_t intersect N^(T-t)(Y).

For t>=1, N(X_t) lies both in H_(t-1) union I_t and in
N^(T-t+1)(Y). Hence it lies in X_(t-1) union I_t. The truncated sets
therefore remain a valid hole certificate, start empty, and end at Y.
Their sets and every required shadow have radius at most R+T, so the
quadrant operator and all its images remain inside the rectangle. This
proves actual arrival of C(Y) at no later clock under the explicit guard.
It is a conditional boundary-arrival theorem, not a claim that the guard
holds in the remaining critical families.

A genuine localized sensitive event supplies an upper enclosing triangle
for THAT event and lower retained-triangle bounds for its future. It does
not confine every earlier possible/hole set to the same corner quadrant
below the opposite walls. A backward causal truncation has support inside
N^a(S), and its outer radius grows with a. At a near-critical own root
m=b-1 on width2b, the seed radius is2b-4: after only three backward moves,
the causal cone already reaches the opposite short wall at distance2b-1.
Thus even a short recent history can encounter the boundary where(D1) is
invalid. The entire earlier history is much longer.

At a saturated step, equality in the quota and neighborhood ledger can
force the preceding holes to lie inside N(S). This is useful but does not
stop the iterated backward cone from reaching the wall. At a nonsaturated
step there may also be old holes outside that neighborhood. Neither case
currently supplies a whole-prefix localization theorem.

Our new actual raw-notch constructions bypass this obstacle constructively:
they generate real finite-board words, rather than compressing a presumed
optimal word. The backward builder's success proves arrival for its target;
its failure does not prove that arrival is impossible.

## 4. The weakest useful next replacement target

A plausible useful theorem would concern only a winning PAIR of full-origin
entry/exit boundary histories: if an alleged faster gate exists, there is
a pair of one-sided raw profiles with no later arrival/exit clocks, correct
physical labels, and no larger inherited middle overlap. Their profiles
may be selected together; their entire histories need not be normalized
by one static operator, and intermediate critical fronts may tilt.

This is strictly weaker than preserving arbitrary partial states or every
raw target. It is also still unproved. A proof must charge or replace the
far-wall fold above, using the real shared quota/clock ledger. The accepted
quadrant operator alone cannot establish it. The joint raw-layer constraints
and the actual greedy boundary certificates give useful necessary and
sufficient sides, but their equality has not been shown.

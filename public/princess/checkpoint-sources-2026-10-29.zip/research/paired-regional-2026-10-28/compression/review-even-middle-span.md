# Independent review: genuine even middle span and its longitudinal corollary

29 October2026. Compression-lane review of root
`even-genuine-middle-span.md` and `even-longitudinal-front-switch.md`.

The genuine-span bound `g<3b/5+7` is accepted for b>=64 and b<k<2b
in the stated failed-prefix actual-middle setup. The shared ledger gives
`max E_e<=H+d-1<b²`, so every complete reference-minimum interval up to
the ACTUAL index e stays in the integral domain. No substitution of a
first hitting time occurs. The uncapped square/pronic inverse maps have
the required monotonicity and oriented-gap property; capping is not used
in either estimate. The finite correction A4 applies on k/b in(8/5,2).
Finally `log(8/3)<1` follows from the positive exponential series, proving
the strict numerical constant without a floating approximation.

The longitudinal front/front erosion argument is also mathematically
sound: the first dual front has at least L+1 holes, each erosion loses
at most b cells, the retained set has more than two cells, and a unit-
slope pyramid on at most two occupied rows has at most two cells. The
later front above L has at most two empty rows. Their common occupied
row therefore forces a forbidden same-end, same-color wall-cell overlap.

However, parent recovered earlier complete longitudinal barriers in
`../../boundary-reachability-2026-10-25/candidate-opposite-longitudinal-front-exclusion.md`
and `candidate-reversed-middle-front-corner.md`, reviewed there in
`root-review-front-transitions.md`. Thus the longitudinal corollary is a
rederivation and supplies NO new case coverage. The stronger genuine
middle-span inequality is the potentially reusable new numerical input.
Transverse fronts, last-boundary targets and raw arrival compatibility
remain separate issues. No new capture equality or Lean coverage follows.

"""One deliberately ambiguous medium-budget gate, exact literal two-inspection bridges."""
from pathlib import Path
import sys,json
ROOT=Path(__file__).resolve().parents[3];sys.path.insert(0,str(ROOT/'src'))
from bridge_upper_transport import prefix_height,support
from resumed_even_construction_prefix_arithmetic import erosion_count
from front_bridge_scc_probe import matching_scc

def hood(S,w,n):
 return {(x+dx,y+dy) for x,y in S for dx,dy in [(1,0),(-1,0),(0,1),(0,-1)] if 0<=x+dx<w and 0<=y+dy<n}
def erode(S,w,n,p):
 return {(x,y) for x in range(w) for y in range(n) if (x+y)%2==p and hood({(x,y)},w,n)<=S}
def profile(z):
 m=len(z['weights']);reach=[{i} for i in range(m)]
 for i,j in z['reduction']:reach[i].add(j)
 for t in range(m):
  for i in range(m):
   if t in reach[i]:reach[i]|=reach[t]
 big=[i for i,v in enumerate(z['weights']) if v>1]
 if any(i not in reach[j] and j not in reach[i] for i in big for j in big):return None
 big.sort(key=lambda i:-len(reach[i]))
 out=set()
 for q in range(len(big)+1):
  inside=set(big[:q]);outside=set(big[q:]);lo=set(z['forced_left'])|{i for i in range(m) if reach[i]&inside}
  no=set(z['forced_right'])|set().union(*(reach[i] for i in outside)) if outside else set(z['forced_right'])
  if lo&no:continue
  a=sum(z['weights'][i] for i in lo);b=sum(z['weights'][i] for i in range(m) if i not in no)
  out.update(range(a,b+1))
 return sorted(out)
def run():
 w=n=64;k=72;c=36;T=41;h=w*n//2;C=[(0,0)];V=[(c,c)]
 for t in range(T):
  a=C[-1];C.append(tuple(erosion_count(w,n,1-p,min(h,a[1-p]+k)) for p in [0,1]))
  a=V[-1];V.append(tuple(min(h,k+erosion_count(w,n,1-p,a[1-p])) for p in [0,1]))
 rows=[]
 for e in range(18,23):
  ell=T-e-2
  for p in [0,1]:
   H=support(w,n,p,prefix_height(w,n,p,C[e][p]))
   for right in [False,True]:
    loc=p^((n-1)%2)^int(right)
    Y0=support(w,n,loc,prefix_height(w,n,loc,V[ell][loc]))
    Y={(w-1-x if right else x,n-1-y) for x,y in Y0}
    assert all((x+y)%2==p for x,y in Y)
    R=erode(Y,w,n,1-p)
    A={(x,y) for x in range(w) for y in range(n) if (x+y)%2==p}-H
    B={(x,y) for x in range(w) for y in range(n) if (x+y)%2!=p}-R
    z=matching_scc(A,B);ps=profile(z)
    rootsA=sum(y==0 for x,y in A);rootsB=sum(y==n-1 for x,y in B)
    minimum=ps is not None and any(z['matching']-k<=a<=k for a in ps)
    spare=rootsA<=1 and rootsB<=1 and z['matching']<2*k
    rows.append(dict(e=e,ell=ell,p=p,right=right,Q=len(H),Y=len(Y),R=len(R),roots=[rootsA,rootsB],matching=z['matching'],minimum_cover_balanced=minimum,one_spare_applies=spare,nonunit=[a for a in z['weights'] if a>1],profile_min=min(ps) if ps else None,profile_max=max(ps) if ps else None))
 return dict(shape=[w,n],k=k,c=c,candidate_gate=T,known_prefix_gate=42,rows=rows,scope='Specified real corner-prefix head and reverse-prefix tail; literal two-inspection graph. No exhaustive upper family or unrestricted lower claim.')
if __name__=='__main__':
 z=run();Path(__file__).with_suffix('.json').write_text(json.dumps(z,indent=2)+'\n');print(json.dumps(z))

# Four odd windows do not determine even-board continuation

29 October 2026. Independently computed finite counterexample, not a new
all-parameter capture theorem. The conjecture rejected here is stronger
than a full-origin paired projection inequality.

On an even-by-even rectangle, delete either boundary row and either
boundary column to obtain four odd-by-odd subboards. For a set S, their
four counts satisfy exactly

    q_ij = |S| - |S on omitted row i| - |S on omitted column j|
                 + 1_(their corner belongs to S).

Consequently these windows retain boundary imbalances but no finer
information about the placement of an interior front.

The following literal 8-by-8 example shows that even adding the full
mass, all four boundary-fiber counts, all corner bits, and the arrival
clock does not produce a complete continuation state. Take budget 6,
physical color 0, and downward-pyramidal supports with row counts

    A = (4,4,4,3,4,3,4,3),
    B = (4,3,4,4,4,3,4,3).

The row fibers consist of the first stated number of cells of their
physical color, measured from y=0. Both are actual beliefs reachable
from the full color-0 cohort after two inspection/movement updates.
Their common data are

    mass:                         29,
    odd-window counts:            (22,24,22,25),
    corner bits:                  (1,0,0,0),
    boundary-row/column counts:   (4,3,4,1).

Yet the exact remaining constant-budget capture times are 10 from A
and 11 from B. The state graph used here consists of all 424 downward
pyramids in each physical color. The existing square compression theorem
proves unrestricted optimality from every such initial support; this is
not an assumption that the same normal form holds on unequal rectangles.
The graph includes every pyramid survivor at inspection cost at most 6,
and the times come from exhaustive reverse shortest paths.

`odd_window_signature_attack.py` constructs the masks from height walks,
forms exact physical transitions and computes both arrival and remaining
clocks. `odd-window-signature-larger.json` includes the above case and
further examples. On 6-by-6 the same signature passed all comparisons for
budgets 4 through 9; the failure at 8-by-8 demonstrates why that finite
negative evidence could not be extrapolated.

This rejects arbitrary-partial-state numerical closure by four windows,
not the usefulness of their inequalities. In particular it does not reject
an optimum-pair replacement theorem, a full-origin separating potential,
or a larger projection family retaining interior front position. There
is no conclusion that A or B lies on a globally optimal full-board word.

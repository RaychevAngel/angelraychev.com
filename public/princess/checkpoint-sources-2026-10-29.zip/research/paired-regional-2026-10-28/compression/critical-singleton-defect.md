# At zero central excess, the opposite row defect is a single corner

29 October 2026. Ordinary deduction from the accepted critical-duality
classification. Submitted for independent review. This is a static result;
no budget-preserving temporal cancellation is asserted.

Let the board be 2b by 2m, with m>=b>=4. Put h=2bm and L=(b-1)^2.
Let S be one physical color, with |N(S)|-|S|=b, and put
T=V_opposite minus N(S). Assume BOTH |S|>L and |T|>L.
Use the exact proper-zero-row defect counts d_L,d_R from
`exact-row-compression-defect.md`.

Then

    min(d_L(S),d_R(S))<=1.                              (1)

More precisely, unless S or its exact dual T is the accepted rigid
full own (b-1)-triangle plus the diagonally opposite own-corner singleton,
one of the two defect counts is zero. In the exceptional case every
proper zero row of the less frequent orientation is at the singleton's
transverse coordinate on the classified side. Duality preserves that
row coordinate and exchanges the left/right labels.

## 1. A pyramid in any of the four axes has only one defect orientation

A pyramid facing a horizontal end is rowwise a common-end prefix, so a
proper zero row cannot face the other end.

Now suppose it faces the top edge: every occupied cell (x,y), x>0,
forces both valid diagonal predecessors (x-1,y-1),(x-1,y+1). Assume two
proper zero rows i<j have opposite end orientations. A proper zero row
is its own cheap-end interval, and its cheap physical endpoint is in S.
Their row parities differ, so j-i is odd.

If row j is right-facing, it contains physical column 2m-1. An alternating
left/right sequence of j-i diagonal predecessor moves stays in columns
2m-2 and 2m-1 and reaches column 2m-2 in row i. Row i has the other
physical parity and is a left prefix. Column 2m-2 is the last possible
index of that row, making this prefix full, a contradiction.

If row j is left-facing, use columns0 and1 instead. The predecessor
chain forces column1 in row i, whose right suffix then contains its first
possible index and is full. This is again a contradiction. A bottom-facing
pyramid follows by reversing the transverse row order.

Thus every literal pyramid in either axis has min(d_L,d_R)=0. Empty and
full fibers cause no exception because a counted defect row is proper.

## 2. Localized and rigid forms

A genuine corner-quadrant component of surplus b in the accepted critical
classification lies in an own triangle of radius2b-2 or an opposite
triangle of radius2b-3. Both radii are less than 2m-1. It therefore misses
the entire opposite horizontal endpoint column. Every proper zero row
facing that endpoint would contain a cell in that column, so there are
none.

For the rigid form, the full own (b-1)-triangle likewise misses that
opposite endpoint column. Only the additional opposite corner singleton
can supply a zero row of the other orientation. There is exactly one
possible transverse row for it, proving the bound1.

## 3. Transfer through the actual dual

The theorem in
`../../phase-compatibility-2026-10-24/even-central-critical-duality.md`
classifies S or the actual T in exactly these forms, and under the two
strict cardinality assumptions establishes

    N(T)=V_current minus S.

Thus S,T are a closed complementary pair. Section2a of
`exact-row-compression-defect.md` gives exact exchanged defect counts,
not merely a cardinality comparison. Applying Sections1-2 on the classified
side proves(1) on S as well.

## Boundaries and temporal target

This deduction inherits b>=4 and the TWO strict size conditions. It does
not silently include the terminal equality |S|=L or |T|=L, positive surplus
excess, or a two-cohort total-good event without identifying the actual
one-color support to which the classification applies.

The reason this may help the dynamic problem is specific: a zero-excess
state with two defect orientations does not carry an arbitrary row error.
It carries the accepted two-corner rigid exception, or its literal closed
dual. Its residual error is localized at one corner row. What is still
needed is a chronological argument showing that this singleton can be
transported, charged to earlier usable inspection credit, or absorbed into
the actual paired endpoint intersection without increasing any daily quota.

There is a further exact cardinality localization. A rigid S has |S|=L+1,
so |N(S)|=L+b+1=b(b-1)+2. A rigid dual T has |T|=L+1. Hence these
opposite-orientation zero-excess defects can occur only at the two named
collar-adjacent cardinalities. Along any stretch where the accepted middle
credit ledger proves strict monotone progress, each such cardinality occurs
at most once. This does not yet determine its position relative to the
paired cut or supply its usable inspection credit.

# Independent review: physical entrance and column packing

29 October 2026. Ordinary independent review, not Lean.

## Corner entrance

Reviewed `../phase/corner-hole-pyramid-entrance.md`. Accepted after checking:
canonical row parity zero gains at most zero neighbors and parity one at
most one, including empty rows; the two critical triangle predecessors
have areas H and L and really have neighborhood equal to the containing
triangle for b>=2; rank interpolation respects the finite board; the
literal inspection N(K)\X costs at most k and creates holes containing
K by erosion adjunction. Its certified area is at least H, and at genuine
early crossing Q>=H-d+1 it is strictly greater than H. No endpoint access,
free tilt, or later clock conclusion is inferred. Suggested fixing the
chosen facing-edge wording to the orientation having transverse width2b.

## Column trajectory packing

Reviewed `../root/column-trajectory-transport.md`. Accepted the exact 1D
packing formula for every t>=1. Same-cohort noncrossing gives the smallest
walker's speed bound; a block of m walks has lower-coordinate path with
at least two vertices, nonempty endpoint intervals, and the required
parity, so shortest motion plus two-step padding attains m. Distinct
physical columns provide disjoint trajectories; every trajectory ending
outside the target must be hit at a pre-final inspection. The actual
total quota bound and the one-path loss per endpoint defect follow.
No transition sufficiency or full-origin optimality is inferred.

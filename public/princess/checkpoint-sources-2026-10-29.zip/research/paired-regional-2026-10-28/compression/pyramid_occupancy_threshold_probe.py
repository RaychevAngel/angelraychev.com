"""Max area where enforcing all predecessor rows increases target area."""
from pathlib import Path
import json

def run(w,p):
 # Every bad path has an empty row, hence all heights <=w-2.
 dp={}
 for h in range(-2,w):
  if h%2==p:
   l=max(0,(h-(p%2))//2+1)
   dp[h,int(l==0),int(p==0 and l>=2)]=(l,(h,))
 for x in range(1,w):
  nd={};par=(p-x)%2
  for (h,E,D),(q,a) in dp.items():
   for H in(h-1,h+1):
    if H< -2 or H>=w:continue
    l=max(0,(H-par)//2+1);key=(H,E+(l==0),D+(par==0 and l>=2));v=(q+l,a+(H,))
    if key not in nd or v[0]>nd[key][0]:nd[key]=v
  dp=nd
 q,a=max((v for(h,E,D),v in dp.items()if E>D),default=(-1,()))
 return {'w':w,'p':p,'max_bad_area':q,'height_path':a}
if __name__=='__main__':
 out=[run(w,p)for w in range(2,41)for p in(0,1)]
 Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
 print(json.dumps(out))

"""Independent literal replay of the smaller-threshold interpolation proof."""
from pathlib import Path
import random
import json

def paths(w,n,p):
    out=[]
    def rec(a):
        i=len(a)
        if i==w:
            out.append(tuple(a));return
        z=(p-i)%2;top=n-1-((n-1-z)%2)
        for h in range(z-2,top+1,2):
            if not a or abs(h-a[-1])==1:rec(a+[h])
    rec([]);return out

def support(a,n,p):
    return {(i,y)for i,h in enumerate(a)for y in range((p-i)%2,h+1,2)}

def neigh(S,w,n):
    return {(x+dx,y+dy)for x,y in S for dx,dy in ((1,0),(-1,0),(0,1),(0,-1))
            if 0<=x+dx<w and 0<=y+dy<n}

def height(S,w,p):
    return tuple(max([y for x,y in S if x==i],default=(p-i)%2-2)for i in range(w))

def pred(a,p):
    return tuple(max(h-1,(1-p-i)%2-2)for i,h in enumerate(a))

def area(a,n,p):return len(support(a,n,p))

def construct(w,n,p,a,b,T,k):
    d=k-(w+1)//2;q0=area(a,n,p);qT=area(b,n,(p+T)%2)
    q=[max(qT,q0-t*d)for t in range(T+1)]
    up=[a]
    for t in range(T):
        up.append(height(neigh(support(up[-1],n,(p+t)%2),w,n),w,(p+t+1)%2))
    zs=[None]*(T+1);zs[T]=b
    for t in range(T-1,-1,-1):
        ph=(p+t)%2;lower=pred(zs[t+1],1-ph)
        z=[max(h,min(u,(ph-i)%2))for i,(h,u)in enumerate(zip(lower,up[t]))]
        while area(z,n,ph)<q[t]:
            for i,h in enumerate(z):
                if h+2<=up[t][i] and all(z[j]==h+1 for j in (i-1,i+1)if 0<=j<w):
                    z[i]+=2;break
            else:raise AssertionError(('rank stuck',w,n,p,a,b,T,k,t,z,up[t],q[t]))
        zs[t]=tuple(z)
    assert zs[0]==a
    for t in range(T):
        A=support(zs[t],n,(p+t)%2)
        R=support(pred(zs[t+1],(p+t+1)%2),n,(p+t)%2)
        assert R<=A and len(A-R)<=k
        assert neigh(R,w,n)==support(zs[t+1],n,(p+t+1)%2)
    return zs

def main():
    rng=random.Random(2026102912);passed=0;newthreshold=0;transposed=0;fixtures=[]
    for w,n in ((2,5),(3,4),(4,3),(4,6),(6,4),(6,6),(6,7),(8,5),(8,8),(10,7)):
        pp=[paths(w,n,p)for p in (0,1)];H=(w+1)**2//8
        for _ in range(2500):
            p=rng.randrange(2);T=rng.randrange(1,7);k=(w+1)//2+rng.randrange(4)
            a=rng.choice(pp[p]);b=rng.choice(pp[(p+T)%2])
            X=support(a,n,p);Y=support(b,n,(p+T)%2)
            if not len(X)>=len(Y)>H or len(X)-len(Y)>(k-(w+1)//2)*T:continue
            if neigh(support(pred(b,(p+T)%2),n,(p+T-1)%2),w,n)!=Y:continue
            U=X
            for _ in range(T):U=neigh(U,w,n)
            if not Y<=U:continue
            zz=construct(w,n,p,a,b,T,k);passed+=1
            transposed+=w>n
            if w%2==0 and len(Y)<=(w//2-1)**2:
                newthreshold+=1
                if len(fixtures)<5:fixtures.append(dict(w=w,n=n,p=p,T=T,k=k,a=a,b=b,word=zz))
    ans=dict(passed=passed,transposed=transposed,below_old_threshold=newthreshold,fixtures=fixtures)
    Path(__file__).with_suffix('.json').write_text(json.dumps(ans,indent=2)+'\n')
    print(json.dumps(ans))

if __name__=='__main__':main()

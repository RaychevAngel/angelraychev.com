# Independent review of the quadratic-budget tail branches

29 October 2026. Compression-lane independent attack of the root
`quadratic-tail-localized-join.md` and phase
`quadratic-tail-front-attachment.md`.

Verdict: accepted as ordinary proofs with an exact rational finite
certificate, conditional on their cited actual protected-cut, common-end,
last-cheap ancestry, and shared-deficit interfaces. This review adds no
Lean coverage and does not independently replace those upstream proofs.

The localized branch keeps the genuine reverse convention
`W_r=V_(r+1)-k`; hence the scalar full-board fit uses `s+r+1` updates.
The half-quota rounding in Q1 is paid by strict dangerousness: the actual
integer seed exceeds its reference minimum, compensating for the safe
estimate `floor(k/2)>=k/2-1`. Genuine seed indices are at most21 because
the root mass is at most b squared. Enlarging both ages weakens both the
joint scalar fit and the retained-radius estimate, so taking the lower
allowed mu at each signature is valid.

At reverse index zero, a nonzero initial gap has oriented pair `(m+1,m)`.
The bad map sends its maximum to at most G(m), and `G(m)<=F(m+1)` for
the actual square/pronic inverse maps. Thus the first bad step destroys
dangerousness and the special age bound zero is justified. It is not an
assumption about an arbitrary interlaced initialization.

I replayed the rational certificate after disabling only its output-file
write and printed output. All924 computed records agree exactly with
the saved JSON. The source SHA256 is

    b6b6a525ea72857f819222161f77e07a6235e755b5987fda046ca1c062bb26a0

The root-sum test is algebraically exact for nonnegative radicands. The
normalized radius sum at least11/10 gives positive individual lower
radii, since the other localized radius is at most2b-2. The raw defects
and the single allowed overlap eta are subtracted once.

In the front attachment, `J<=21`, integral span at most12, and age at
most23 follow from the genuine crossing estimate. The weakest localized
seed has mass at least `b²/40-b-1>=b²/49`; hence its retained radius is
at least `2b/7-27>=b/4`. Eroding a full front23 times loses at most
`23b+12`, so its retained area is at least `b²-25b-10`. The small-overlap
premise and the displayed upper-area estimate are valid throughout
b>=4096. After division by b, the difference is already greater than458
at sqrt(b)=64 and increases. The two-front case lies strictly inside the
reviewed aged-front row-support hypotheses.

The scope remains the two terminal quotas k and floor(k/2), all lengths,
and the displayed quadratic budget tail. No arbitrary-partial-state
normal form or uniformly bounded-operation evaluator is inferred.

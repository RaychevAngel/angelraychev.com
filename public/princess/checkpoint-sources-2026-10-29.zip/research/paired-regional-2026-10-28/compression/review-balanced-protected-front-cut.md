# Independent review of the adaptive and balanced front cut

29 October 2026. Compression lane, ordinary mathematical review. No Lean
verification and no independent claim about unreviewed upstream theorems.

Reviewed current versions of:

- `../regional/adaptive-cut-near-late-front.md`;
- `../regional/balanced-protected-front-cut.md`;
- `../root/aged-front-row-support.md`;
- the actual normalization and finite-horizon reverse interfaces, the
  genuine signed span/age ledger, and the arrival-integral span bound.

## Assessment

Accepted under their stated dependencies, for b>=4096 and
5b/4<=k<=2b. In particular this review finds no remaining temporal
attachment gap in the two-full-front branch. It does not establish the
other budget bands or independently re-prove all upstream shape results.

## Physical indexing and moving the cut

The reverse recurrence has J_l=E(C_l) at physical time
T-(r0+l+1), with authoritative reference W_(r0+l). Thus the explicit
reindexing W_hat_i=V_i-k=W_(i-1) correctly places a seed of suffix
index i at physical time T-i. Age differences are unchanged. The large
front seed cannot be the terminal tied set: its mass exceeds the permitted
terminal quota. The two birth times used in the balanced proof are genuine.

The history is normalized once. At a new cut between the original forward
and reverse births, both actual marker inclusions remain valid: forward
holes contain the erosion of their earlier seed, and the allowed-set reverse
recursion contains the erosion of its later seed. Each reverse seed is itself
within the real solo segment, so no marker is extrapolated through an
unavailable reverse prehistory. Current physical colors agree at the old
cut; changing the cut by d changes the two ages by d and -d, equal modulo
two. The geometric longitudinal end is fixed. Neither last-cheap status
at the new cut nor a new normalization is needed.

The adaptive cut lies within the old reverse bad suffix. If moved by v0,
its reverse minimum reaches b^2. Failed actual prefix adjunction then gives
both stronger final-index guards. If it does not move far enough, it is
exactly the original protected cut. This also supplies the needed mass
premises to exchange the names of the young-front and localized markers.

## Balancing and constants

The safe interval contains the old cut. Its endpoints are at distance at
most v=ceil((3b-4)/(k-b-1))<=13 from any offending seed birth. Clamping the
midpoint either preserves its balanced age, or makes BOTH ages at most13;
there is no additive13 error. The actual full-front mass gives the stated
seed-minimum bound b^2-3b+3, and every coordinate grows by at least k-b-1.

The two old bad-run ledgers have +1 each. The old shared deficit bound has
-1 inside a factor two, so these constants cancel exactly:

    j-u <= 2(s1+s2-max(e1,e2)-eta_old).

The critical one-wall bounds s_i-e_i<=3 therefore give
j-u<=2(min(s1,s2)+3-eta_old). The global front span bound
s_i<=3b/5+8 follows by splitting lambda=k/b at8/5, using either
lambda-1 or the decreasing integral expression. The crossing/affine
extension, rather than a localized-only arrival bound, is required here
and is explicitly available. Hence both new ages are at most3b/5+12.

The new common-cut allowance is established afresh; eta_new is not equated
with eta_old. The global span gives eta_new<=b-1.

## Row-support finish

For a one-Lipschitz virtual-height front, a missing row after t erosions
bounds heights elsewhere by t+1 plus distance to the missing-row set.
Summing each occupied component yields
4A<=2w(t+1)+p(p+1). A further2z erosions preserve color and turn each
common occupied row into z+1 common cells before those erosions. These are
contained markers; equality with actual finite-board erosion is unnecessary.

With z=floor(b/20), A>=b^2-2b+2 and ages<=3b/5+15, the displayed
quadratic estimates imply p_i>21b/20 and intersection>b-1 for b>=4096.
I checked both coefficient expansions and the saturated p_i=w case.
This exceeds the independently obtained eta_new and contradicts the
actual common-cut allowance.

"""Independent literal edge check for every split of full-front bridge covers."""
from pathlib import Path
import json
from pyramid_interpolation_replay import paths,support
from front_bridge_scc_probe import matching_scc

def main():
    count=splits=0;boards=[]
    for W,N in ((2,3),(3,4),(4,3),(4,4),(4,6),(6,4),(6,6),(8,4)):
        P=paths(W,N,0);Q=paths(W,N,1^((N-1)%2))
        C=[{(x,y)for x in range(W)for y in range(N)if(x+y)%2==p}for p in (0,1)]
        local=0
        for a in P:
            A=C[0]-support(a,N,0)
            if any(y==0 for x,y in A):continue
            for r in Q:
                R={(x,N-1-y)for x,y in support(r,N,1^((N-1)%2))};B=C[1]-R
                if any(y==N-1 for x,y in B):continue
                c=[N-3-z for z in r]
                m=sum(max(0,(z+1-u)//2)for u,z in zip(a,c))
                pairs=sorted((((x,y),(x,y-1))for x,y in A if(x,y-1)in B),key=lambda uv:(uv[0][1],uv[0][0]))
                assert len(pairs)==m
                z=matching_scc(A,B)
                assert z['matching']==m and all(z['weights'][i]==1 for i in z['free'])
                for ell in range(m+1):
                    DA={u for u,v in pairs[:ell]};DB={v for u,v in pairs[ell:]}
                    for x,y in A-DA:
                        assert all(v not in B-DB for v in ((x+1,y),(x-1,y),(x,y+1),(x,y-1)))
                    splits+=1
                count+=1;local+=1
        boards.append(dict(W=W,N=N,pairs=local))
    ans=dict(endpoint_pairs=count,cover_splits=splits,boards=boards)
    Path(__file__).with_suffix('.json').write_text(json.dumps(ans,indent=2)+'\n')
    print(json.dumps(ans))

if __name__=='__main__':main()

# Exact balanced two-inspection bridge between opposite full fronts

29 October 2026. Ordinary proof, independently reviewed through the full-front,
boundary-root SCC, one-spare-shot, central-area and one-root cone/selection
statements. Review receipts are in the sibling reviews directory. This concerns
specified actual endpoints, not their attainability from full uncertainty.

## Endpoint convention and exact bridge criterion

Let the board be `W by N`, `W,N>=2`, and let its physical color classes
be V0,V1. An incoming hole set H is in V0. A desired outgoing allowed
set R is in V1. A two-inspection bridge means: inspect at most k cells
of `A=V0 minus H`; let the survivors move once; then inspect at most k
cells, leaving only cells in R. Equivalently the induced bipartite graph

    G = board[A, B],    B=V1 minus R,                (1)

has a vertex cover containing at most k vertices on each side. Indeed
each surviving edge from A into B must be removed by inspecting one of
its two endpoints. This equivalence preserves both daily budgets.

Assume H is a canonical pyramid toward y=0, with cutoffs a_i, and R is
a canonical pyramid toward y=N-1. Thus B is a prefix in each row with
canonical cutoffs c_i. Adjacent a cutoffs and adjacent c cutoffs differ
by one; their row parities are opposite.

The exact wall hypotheses needed are

    A contains no vertex with y=0,
    B contains no vertex with y=N-1.                (2)

They hold in particular when H and R occupy every row (opposite full
fronts). They are weaker than that: only the corresponding physical
boundary-color cells need to belong to H and R.

Define

    m_i=max(0,(c_i+1-a_i)/2),     m=sum_i m_i.       (3)

The quotient is integral because a_i and c_i have opposite parity.
Then an exact two-inspection bridge exists **if and only if m<=2k**.
More generally its exact minimum-cover side profiles include every pair

    (ell, m-ell),       0<=ell<=m.                 (4)

Consequently unequal quotas k0,k1 are possible iff `m<=k0+k1`.

## Proof and direct construction

Every nonisolated A vertex `(i,y)` has its same-row left neighbor
`(i,y-1)` in B. Condition (2) ensures y>=1. A rightward B neighbor
implies the leftward one because B is a row prefix. A vertical neighbor
in row j gives `y<=c_j<=c_i+1`, so again `y-1<=c_i`.

Conversely every nonisolated B vertex `(i,z)` has its same-row right
neighbor `(i,z+1)` in A. Condition (2) ensures z<=N-2. A leftward A
neighbor implies the rightward one because A is a row suffix. A vertical
neighbor in row j gives `z>a_j>=a_i-1`; opposite parity then gives
`z>=a_i+1`, hence `z+1>a_i`.

These two partner maps are inverse. They form a perfect matching of
all nonisolated vertices of G. In row i its source coordinates run from
`a_i+2` through `c_i+1` in steps of two, giving (3). Every cover therefore
has at least m vertices.

Order the matched pairs by increasing y-coordinate of their A endpoint;
break ties arbitrarily. For any ell, select the A endpoints of the first
ell pairs and the B endpoints of all remaining pairs. This is a cover.
To check an unmatched edge `A(i,y)--B(j,z)`, the matched A partner of
its B endpoint has coordinate z+1. If the edge is vertical, z+1=y+1;
if it is horizontal and unmatched, z+1=y+2. In either case the B
endpoint's matched pair comes strictly later. If that later pair's A
endpoint was selected, the earlier A endpoint was also selected;
otherwise that later pair's B endpoint was selected. Thus every edge
is covered.

The cover has exactly ell A vertices and m-ell B vertices, proving (4).
Choose `ell=min(k0,m)` when `m<=k0+k1`; the two cover parts are the
actual two inspection sets. No weighted-min-cut relaxation, assumption
about arbitrary matching extension, or optimization over strategies is
used.

### Exact shifted-overlap charge

On an even-area rectangle put `h=|V0|=|V1|` and let beta be the number
of V0 cells on the bottom wall. Define

    R^+={(i,y+1):(i,y) in R, y<N-1}.

Under (2), shifting B upward by one is injective and stays inside V0.
The source color class is partitioned into its bottom-wall cells,
the shifted B, and R^+. Since H contains those bottom-wall cells,

    m=h-|H|-|R|+beta+|H intersect R^+|.             (6)

Thus the exact bridge test is equivalently

    |H intersect R^+| <= k0+k1-h+|H|+|R|-beta.      (7)

This is an actual geometric overlap, not a freely chosen phase label.
It specifies precisely the remaining quantity for a joint history
ledger to control if the two endpoints are supplied by real histories.

## Scope and obstruction outside it

### One full wall: the exact minimum-cover obstruction

If only the first wall condition in (2) holds, the same horizontal
matching still saturates every nonisolated A vertex. Every unmatched
nonisolated B vertex lies on the top wall: the partner proof fails only
at `z=N-1`. Denote their set by U. The matching digraph still has only
unit-weight components, since every unmatched edge between matched pairs
strictly increases the A endpoint's y-coordinate.

In a minimum cover, each matched pair contributes exactly one endpoint
and unmatched B vertices contribute none. Hence all A neighbors of U
must be selected. Let F be their predecessor closure in the matching
digraph: include every pair from which a directed path reaches such a
forced pair. These, and only these, are the mandatory A endpoints in a
minimum cover. Ordering the remaining poset topologically shows that
every split

    (ell,m-ell),       |F|<=ell<=m                 (5)

occurs among minimum covers. Thus a minimum cover respecting quotas
`k0,k1` exists iff `max(|F|,m-k1)<=min(m,k0)`. In the matching-tight
case `m=k0+k1`, this is also necessary for *any* quota-respecting cover,
since there is no allowance for more than m total vertices.

For `m<k0+k1`, a larger cover may buy unmatched B vertices to avoid some
forced A endpoints. Formula (5) is then sufficient, not an exact test
for all covers. It isolates the remaining obstruction at exposed wall
roots and does not silently discard the allowed extra cover vertices.

The result removes any additional balanced-cover phase obstruction for
specified opposite full canonical fronts. Actual entry clocks, shared
earlier inspection budget, and the availability of these fronts still
need proof in a full-board optimality argument.

### Boundary-root extension: nonunit matching blocks have bounded width

The following extension keeps specified canonical endpoints but removes
the two full-wall assumptions. Discard isolated vertices. Let a be the
number of remaining A vertices at y=0 and b the number of remaining B
vertices at y=N-1. Let M0 be the same horizontal matching as above: it
pairs `(i,y)` in A with `(i,y-1)` in B whenever both exist. Its unmatched
vertices are exactly those a bottom roots and b top roots. This follows
from the two partner arguments above, which fail only at those walls.

Choose a maximum matching M minimizing its symmetric difference with M0,
and put r=|M|-|M0|. Then r<=min(a,b). In the standard matching digraph
(one vertex per M-pair; an edge A_i--B_j gives i->j), every strongly
connected component containing more than one matched pair belongs to a
poset of width at most r. In particular, if a,b<=1, all nonunit components
form a chain. The statement concerns the nonunit components; unit-weight
components can still form diamonds and need not be linearly ordered.

To prove this, orient the physical edges unmatched by M0 from A to B,
and its matched edges from B to A. This orientation is acyclic: every
matched edge raises y by one, every other horizontal edge raises y by
one, and vertical edges preserve y and run only A to B. A directed cycle
cannot consist solely of the latter. The symmetric difference M△M0 is
a union of vertex-disjoint M0-augmenting paths. A component with more M0
edges would contradict maximality of M; a cycle or equal-size alternating
path could be replaced by its M0 edges without changing |M| and would
contradict the minimum-difference choice. There are exactly r paths.

Passing to the M orientation reverses precisely these disjoint paths.
Every directed cycle now meets one of them, since the orientation outside
them is unchanged and acyclic. Each reversed path remains directed, so
the strongly connected components it meets are linearly ordered. Every
nonunit matching component contains an alternating directed cycle and
therefore meets at least one of the r paths. Assigning each such component
to one path which it meets covers the nonunit component poset by r chains.
Unmatched vertices cannot lie on a directed cycle. This also handles r=0:
all matching components then have unit weight.

This supplies an exact polynomial minimum-cover side profile when r<=1.
An M-pair contributes one vertex to every minimum cover. Write x_i=1
if its A endpoint is selected. An unmatched edge i->j imposes x_j<=x_i;
thus the selected matching components form a predecessor-closed set.
An unmatched B vertex forces its neighboring matched A endpoints selected;
an unmatched A vertex forces the neighboring matched B endpoints selected.
Close the first constraints backward and the second forward.

List the nonunit components in chain order. For each prefix of this list,
force those components selected and the remainder unselected, propagating
the same closures. Reject inconsistent choices. Let L be the forced
selected components and U all components not forced unselected. Every
component in U\L has weight one. Every integer between the total weights
of L and U occurs as the A-side size of a minimum cover: add the remaining
unit components in predecessor order. The union of these at most one plus
the number of nonunit components integer intervals is therefore the EXACT
minimum-cover side profile. It is evaluated by ordinary matching, graph
reachability and topological ordering, and supplies actual covers.

For a bridge with quotas k0,k1, intersect this profile with
`[|M|-k1,k0]`. Nonempty intersection proves a bridge. It is also necessary
when |M|=k0+k1, because every permitted cover is then minimum. For general
root counts a larger cover may split a nonunit block, and this profile
alone is not a necessary test when the total quota exceeds |M|.

### With one root per wall, one spare inspection settles every balance

Still assume a,b<=1, and put m=|M|. If both quotas are positive, then

    k0+k1>=m+1  implies a quota-respecting physical bridge.       (8)

Together with the chain-profile test this is an EXACT bridge decision:
total quota below m fails; total quota equal to m uses the exact minimum-
cover profile; total quota above m succeeds. Zero quota cases are handled
directly by inspecting all active vertices on the opposite side.

If there is an augmenting path, both wall roots exist, m=|M0|+1, and
M matches all active vertices. Select BOTH unmatched M0 roots. The graph
on the old M0 pairs is height-acyclic and has a cover using exactly one
endpoint from every pair with any prescribed left-side count. These
covers plus the roots have total size m+1 and realize every side split
`(ell,m+1-ell)`,1<=ell<=m. Positive quotas with total at least m+1 can
accommodate one of them.

If both roots exist but no augmenting path exists, M0 is maximum and
all matching components have unit weight. Let F_L be the predecessor
closure forced left by the unmatched B root, and F_R the successor closure
forced right by the unmatched A root. They are disjoint; an intersection
would produce an augmenting path. Selecting the A root removes F_R and
gives size-m+1 covers with every left count in `[1+|F_L|,m+1]`.
Selecting the B root removes F_L and gives every left count in
`[0,m-|F_R|]`. Their union contains EVERY integer from0 through m+1,
since `|F_L|+|F_R|<=m`. This proves(8) in this case.

With only one root, select it and use any side split in the remaining
height-acyclic pair graph; the positive quota on its side pays that root.
With no roots the already proved full-front minimum-cover rule suffices.
All constructions give the actual two inspection sets and preserve their
individual quotas. No weighted fractional cover or free endpoint change
is used.

### Every central canonical endpoint has at most one exposed root

For an even width W=2b, put L=(b-1)^2. A canonical pyramid X with
`|X|>L` misses at most ONE of its own-color vertices on its facing wall.
Consequently the exact bridge rule above applies to any specified pair
of opposite-facing canonical pyramids H,R with `|H|,|R|>L`.

Here is a proof that includes empty fibers. A missing own-color wall
vertex in an interior row forces that row and both adjacent rows empty:
its cutoff is -2 and the two neighboring cutoffs must be -1. If a
canonical pyramid has at least three empty rows, break its occupied rows
into consecutive runs of lengths m_j. Each run has an adjacent empty
row. Moving away from that empty row, canonical cutoff increments bound
its row sizes by `1,1,2,2,...` (or a still smaller alternating sequence).
Thus its area is at most

    f(m_j)=floor((m_j+1)^2/4).

The elementary identity `f(m)=floor((m+1)/2)*ceil((m+1)/2)` shows
`f(u)+f(v)<=f(u+v)` for nonnegative integers u,v (with f(0)=0).
As the total occupied-row count is at most 2b-3, the total area is at most
`f(2b-3)=(b-1)^2=L`. Hence a pyramid larger than L cannot miss an interior
own-color wall vertex. The two extreme rows have opposite parity because
W is even; only one can contain an own-color wall vertex. At most that
single extreme vertex is missing. Reflection proves the same statement
at the opposite wall. For b=1 there are no interior rows, and the last
parity argument directly proves the claim.

This strengthens the applicability condition; it does not assert that
an arbitrary physical endpoint is canonical.

### Slightly stronger root threshold and full-wall threshold

The same row-run argument yields two useful refinements. Two missing
own-color facing-wall vertices force at least four empty rows: they cannot
both be extreme rows on an even width; an interior missing vertex forces
its row and both neighbors, and a second missing root adds at least one
new empty row. Therefore every canonical pyramid of area

    |X|>(b-2)(b-1)

has at most one exposed root (b>=2). This includes area L itself.
A single missing root forces at least two empty rows, hence area at most
`f(2b-2)=H_pr`. Consequently every canonical pyramid larger than H_pr
contains ALL its own-color facing-wall vertices.

### Selecting the entrance pyramid for a fixed outgoing survivor

Suppose a genuine one-update entrance allows any canonical K of color V0
containing a fixed canonical base A, of prescribed area q>H_pr. Let R be
a specified opposite-facing canonical survivor in V1, of area greater
than (b-2)(b-1). Define R^+ as above and set C=V0 minus R^+.
The set C is a canonical lower ideal and contains every V0 facing-wall
vertex. All admissible K also contain that wall by the preceding lemma.
The horizontal matching therefore saturates every active A-side vertex,
and its exact matching number is

    m(K)=|C minus K|.

Among all such K, its minimum is

    m_min=max(0, |A union C|-q).                    (9)

Indeed |C\K|=|C union K|-q>=|C union A|-q, and it is nonnegative.
If q<=|A union C|, choose K by rank interpolation between A and A union C.
If q>=|A union C|, interpolate from A union C to the whole color class.
These choices attain(9). This is a specified canonical cell-addition rule;
it does not search over inspection strategies.

### The one-root forced-cover cone is an explicit canonical ideal

If the opposite wall has no missing root, every minimum-cover split is
available. If its unique missing root is z=(r,N-1), define a source-color
canonical ideal J_z by

    J_z={ (i,y) in V0 : y<=N-|i-r|,
                         and if i=r then y<=N-2 }.               (10)

Board clipping and physical parity are understood. Then J_z is a subset
of C, and the forced A-side cardinality of every minimum cover is exactly

    F(K)=|J_z minus K|.                                         (11)

To check J_z subset C, the missing root forces the opposite-facing R
cutoff in row r above the board. The slope-one constraints imply that
its lower cutoff in row i is at least N+1-|i-r|. Shifting R upward makes
C contain exactly the cone in(10), with clipping at row r.

For(11), every matching-pair edge raises the source y-coordinate by one
while moving to an adjacent row, or by two while staying in the row.
The pairs forced by z end at source neighbors (r,N-2) or
(r plus/minus1,N-1). A path into these pairs therefore requires(10).
Conversely, from a source vertex in J_z outside K, move toward row r until
reaching its adjacent row, raising y by one each time, and then move
upward in increments of two to that row's top source vertex. At row r
itself just move upward to N-2. Source suffixes and their slope-one
bounds ensure every intermediate source remains outside K; J_z subset C
ensures each corresponding target vertex is in B. The final edge reaches
z. Thus exactly J_z minus K is the predecessor closure forced onto the
A side. This argument also handles an interior unique root, although the
central-area guard normally restricts the root to an extreme row.

This makes the entrance optimization exact, including matching equality.
The canonical ideals are nested:

    A subset A union J_z subset A union C.

By filling these ideals in that order until area q is reached, one
simultaneously attains

    m_min=max(0,|A union C|-q),
    F_min=max(0,|A union J_z|-q).                                (12)

The elementary union lower bounds prove both are minimal over all allowed
K. If q lies beyond A union C, finish with arbitrary eligible canonical
cells. For no root set F_min=0 and omit the middle ideal.

Consequently the three-inspection splice consisting of the genuine
one-update entrance and two bridge inspections with POSITIVE quotas
k0,k1 has the following EXACT decision within this entrance family:

* if m_min>k0+k1, no endpoint K in the family works;
* if m_min<k0+k1, the selected endpoint works by the one-spare theorem;
* if m_min=k0+k1, it works exactly when F_min<=k0.

In the equality case the remaining minimum-cover requirement
`m_min-k1<=k0` already holds with equality. The nested-ideal rule produces
the actual K, and the minimum-cover or root-purchase constructions above
produce the two inspection sets. This is an exact family-level physical
splice, not an assertion that every optimal full-origin history has such
an entrance. In particular the one entrance update must be counted in
its actual capture horizon.

The independent literal cone audit `one_root_forced_cone_audit.py/.json`
checks 11,810 specified endpoint pairs on eight board shapes. Direct
matching-predecessor closures agree with(10)--(11) in every case, including
interior roots. Larger boards were randomly sampled, not exhaustively
classified. The ordinary proof is separate from that finite evidence.

### The same exact selection with a prescribed upper envelope

The preceding optimization also allows a canonical upper ideal U, with
`A subset U` and `|A|<=q<=|U|`. Among K with `A subset K subset U`,
fill the nested ideals

    A subset A union(J_z intersect U)
      subset A union(C intersect U) subset U.

This simultaneously attains the two exact minima

    m_min=max(|C minus U|, |A union C|-q),
    F_min=max(|J_z minus U|, |A union J_z|-q).                    (13)

If the opposite root is absent use F_min=0. The unavoidable cells outside
U give the first lower bounds. The union/area inequalities give the
second. Nested rank interpolation attains each bound in the corresponding
area interval, so no additional optimization is hidden in(13).
The same three-case bridge criterion applies, provided q>H_pr and the
opposite-root assumption holds. In particular U may be the full source
color class with its far-wall cells deleted, as in a physically proved
multi-step entrance cone. Such an arrival theorem is an additional input;
this static selection lemma never supplies missing arrival clocks.

### Genuine clock and suffix interface

The two supplied endpoints have different temporal meanings. H is the
actual hole set immediately BEFORE the first bridge inspection. R is an
allowed survivor set immediately AFTER the second bridge inspection and
BEFORE its mandatory movement. A cover C_A union C_B gives the literal
inspections C_A on the first day and C_B on the second. Their quotas are
separate. The second-day surviving belief is a subset of R, so its next
mandatory movement is a subset of N(R). Any genuine suffix whose starting
belief contains N(R) therefore attaches at that exact next clock.
Similarly a genuine prefix producing holes containing H suffices: fewer
current possible locations can only help the same inspection sequence.
No equality of an envelope with an actual image is required.

For the retained even critical collar, write H_pr=b(b-1). If a genuine
next belief has at least H_pr+2 cells and the actual preceding survivor
R has original surplus b, then

    |R|=|N(R)|-b >= H_pr+2-b = L+1.

Thus, whenever this actual survivor R is canonical, its exposed-root
count is automatically at most one. The same area guard for an incoming
canonical hole set H supplies the other root condition. The preceding
bridge theorem is then an exact finite algorithm producing the two real
inspection sets, with the one-spare-shot simplification whenever its
matching number is strictly smaller than the total quota.

This is a physical splice theorem for supplied endpoints. It does not
establish their full-origin arrival times, replace a raw localized set
by an inaccessible canonical set, or prove that the bridge's intermediate
belief is itself canonical. For two simultaneous physical-color cohorts,
their bridge graphs share the daily budgets; one spare shot per component
is not automatically one spare shot in total.

Without the two wall conditions, large strongly connected matching
blocks can occur. The literal 8 by 4 example in
`front_bridge_balanced_obstruction.json` has canonical

    H={(2,0),(6,0)},      R={(2,3),(4,3)}.

Its bridge graph has matching size14, but no cover with7 vertices on
each side: the minimum right cover with at most7 left vertices has8.
This is not a counterexample to the theorem, since (2) fails. It shows
why total matching size alone is insufficient for arbitrary canonical
or sparse endpoints. No claim about its role at optimal full-origin
clocks is made.

Independent literal audit: `full_front_bridge_audit.py/.json` enumerates
18,237 endpoint pairs on eight board shapes and checks 58,891 cover splits
against every physical graph edge. It also independently computes a
maximum matching and its residual strongly connected components.


Independent audit of the one-spare-shot statement:
`single_root_bridge_slack_audit.py/.json` checks 1,200 endpoint pairs,
200 on each of six boards from 3 by 4 through 6 by 6. It enumerates
144,410 left-side subsets and independently checks 2,922 positive
quota splits. All cases agree; the largest matching has 13 edges.
This finite check supports the stated ordinary proof and is not Lean.

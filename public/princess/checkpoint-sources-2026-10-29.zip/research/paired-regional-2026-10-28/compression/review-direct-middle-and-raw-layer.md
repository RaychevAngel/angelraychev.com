# Independent review: direct middle transfer and raw-layer diagnostic

29 October2026,15:35UTC. Compression lane ordinary review; no Lean claim.

## Direct middle transfer

Accepted `../phase/direct-pyramid-middle-transfer.md`, Sections1–6.
The physical identity Y intersect N^Delta(A)=Y minus E^Delta(X) has the
correct complementary colors. Far-wall-free canonical X permits the
literal D^Delta erosion. Canonical intersection is canonical. Regularity
and the occupancy threshold are explicitly retained. The accepted
interpolator requires only |A|>=|Z|, and the note now uses that weaker
condition. Its per-day decrement bound supplies both construction and
the stated conditional necessity. Necessity is not claimed for an
unrestricted middle that may enter a lower-surplus regime.

The flexible first-tail step is physical: inspect Z minus E(C), then
N(Z intersect E(C)) subset C. Alternatively supply any actual R with
N(R) subset C; the same statement holds with R in place of E(C). The
selected102x124 construction uses this latter sufficient version. Rank
interpolation between U intersect R and U gives all intermediate areas,
while the regularity guard must still be checked. No reverse initial
quota is invented.

Independent diagnostics of fixed ordinary head/tail endpoints failed
on102x124 over1,085 clock pairs. This was superseded by actual raw-notch
head/tail words, not by weakening the direct-middle hypotheses. Those
new words satisfy every hypothesis and yield the literal206 gate.

## Root raw-layer necessary model

Read `../root/joint_ancestor_layer_probe.py/.json`.
The positive suffix staircase implies

    alpha_i <= floor((delta-r(r-1)/2)/r), r=m-i.

The integer positivity variables implement the original endpoint condition.
The profile sum<=delta is safe when right-end defects are omitted. Literal
same-history erosion gives alpha_later(j)<=alpha_earlier(j+age) whenever
the eroded earlier interval is nonempty. The code's diagonal>delta guard
ensures this and discards other constraints safely. For a lens cell whose
local y>=delta, a right-end deficit cannot delete it, so its absence must
be paid by the retained left defect. The binary alternative correctly
requires absence in at least one endpoint.

The original Y2562 diagnostic supplied eta0 although its actual allowed
excess may be1. This is a stronger selected subcase, not a necessary model
for every history in that row; root was informed. Since it was FEASIBLE,
no false exclusion followed. A future infeasibility claim must retain a
single shared exception-cell ledger or the true eta bound. The model
omits many arrival constraints and never establishes physical sufficiency.

The integer witnesses nevertheless suggested new useful raw profiles.
Those profiles were separately realized by actual backward-neighborhood
head construction and literal forward tails, then joined using the
accepted direct interpolation theorem. Feasibility of the integer model
was not itself treated as the strategy certificate.

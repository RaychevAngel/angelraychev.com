"""Independent exhaustive side-cover audit of the one-root spare-unit lemma."""
from pathlib import Path
import json,random
from pyramid_interpolation_replay import paths,support
from front_bridge_scc_probe import matching_scc

def run():
    rng=random.Random(2026102919);cases=0;subsets=0;quotas=0;maxM=0
    for w,n in ((3,4),(4,4),(4,5),(4,6),(5,6),(6,6)):
        board_cases=0
        ps=[paths(w,n,p) for p in (0,1)]
        cols=[{(x,y) for x in range(w) for y in range(n) if (x+y)%2==p} for p in (0,1)]
        for _ in range(4000):
            aa=rng.choice(ps[0]);rr=rng.choice(ps[1^((n-1)%2)])
            H=support(aa,n,0);R={(x,n-1-y) for x,y in support(rr,n,1^((n-1)%2))}
            A=cols[0]-H;B=cols[1]-R
            adj={u:{v for v in B if abs(u[0]-v[0])+abs(u[1]-v[1])==1} for u in A}
            A=sorted(u for u in A if adj[u]);B=sorted(set().union(*(adj[u] for u in A)) if A else set())
            if len(A)>13 or sum(y==0 for x,y in A)>1 or sum(y==n-1 for x,y in B)>1:continue
            z=matching_scc(A,B);m=z['matching']
            bm={v:i for i,v in enumerate(B)}
            neigh=[sum(1<<bm[v] for v in adj[u]) for u in A]
            ns=[0]*(1<<len(A));best=[len(B)+1]*(len(A)+1)
            for mask in range(1<<len(A)):
                if mask:
                    bit=mask&-mask;ns[mask]=ns[mask^bit]|neigh[bit.bit_length()-1]
                left=len(A)-mask.bit_count();best[left]=min(best[left],ns[mask].bit_count())
            for j in range(1,len(best)):best[j]=min(best[j],best[j-1])
            for k0 in range(1,m+1):
                k1=m+1-k0
                assert best[min(k0,len(A))]<=k1,(w,n,aa,rr,k0,k1,best,z)
                quotas+=1
            cases+=1;board_cases+=1;subsets+=len(ns);maxM=max(maxM,m)
            if board_cases>=200:break
    return dict(cases=cases,all_left_subsets=subsets,positive_quota_splits=quotas,maximum_matching_seen=maxM,claim='At most one active wall root each: total matching+1 always admits positive side quotas.',method='Enumerate all subsets of actual left vertices; require exact neighborhood of unselected left vertices on right.')

if __name__=='__main__':
    out=run();Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))

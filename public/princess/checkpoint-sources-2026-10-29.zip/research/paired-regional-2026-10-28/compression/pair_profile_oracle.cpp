#include <algorithm>
#include <bit>
#include <chrono>
#include <cstdint>
#include <iostream>
#include <numeric>
#include <vector>
using namespace std;
struct Board {
 int w,n,N,full; vector<unsigned> adj,nb,states,er; vector<int> sizes;
 Board(int W,int L):w(W),n(L),N(W*L),full((1u<<N)-1),adj(N),nb(1u<<N){
  for(int x=0;x<w;++x)for(int y=0;y<n;++y){int i=x*n+y;
   if(x)adj[i]|=1u<<(i-n);if(x+1<w)adj[i]|=1u<<(i+n);
   if(y)adj[i]|=1u<<(i-1);if(y+1<n)adj[i]|=1u<<(i+1);
  }
  for(unsigned s=1;s<=unsigned(full);++s){unsigned bit=s&-s;nb[s]=nb[s^bit]|adj[countr_zero(bit)];}
  states=nb;sort(states.begin(),states.end());states.erase(unique(states.begin(),states.end()),states.end());
  for(unsigned s:states){er.push_back(full^nb[full^s]);sizes.push_back(popcount(s));}
 }
 bool profile(unsigned s,int axis,int kind) const {
  // kind0: same end within every parity on every line; opposite ends allowed between parities.
  // kind1: each parity line independently occupies a prefix or suffix.
  // kind2: each parity line independently occupies one interval.
  int len=axis?w:n,lines=axis?n:w;
  for(int orientation=0;orientation<(kind==0?4:1);++orientation){bool good=true;
   for(int r=0;r<lines&&good;++r)for(int parity=0;parity<2&&good;++parity){
    vector<int> seq;for(int j=0;j<len;++j){int x=axis?j:r,y=axis?r:j;
     if((x+y)%2==parity)seq.push_back((s>>(x*n+y))&1);}
    int changes=0;for(int j=1;j<int(seq.size());++j)changes+=seq[j]!=seq[j-1];
    if(kind==2){int blocks=0;for(int j=0;j<int(seq.size());++j)if(seq[j]&&(j==0||!seq[j-1]))++blocks;good=blocks<=1;}
    else if(kind==1)good=changes<=1;
    else {int end=(orientation>>parity)&1;for(int j=1;j<int(seq.size());++j)if(end?seq[j]<seq[j-1]:seq[j]>seq[j-1])good=false;}
   }
   if(good)return true;
  }
  return false;
 }
};
int main(int argc,char**argv){
 vector<pair<int,int>> boards={{2,4},{2,5},{2,6},{3,4},{3,5},{4,4}};
 if(argc==3)boards={{atoi(argv[1]),atoi(argv[2])}};
 for(auto[w,n]:boards){Board b(w,n);int M=b.states.size(),h=b.N/2;
  vector<unsigned char> costs(size_t(M)*M,255);uint64_t legal=0;
  for(int i=0;i<M;++i)for(int j=0;j<M;++j){unsigned s=b.states[i]&b.er[j];if(b.nb[s]==b.states[j]){costs[size_t(i)*M+j]=b.sizes[i]-popcount(s);++legal;}}
  vector<vector<char>> profiles(6,vector<char>(M));
  for(int z=0;z<6;++z)for(int i=0;i<M;++i)profiles[z][i]=b.profile(b.states[i],z/3,z%3);
  for(int k=w/2+1;k<h;++k){vector<int>d(M,999),parent(M,-1),queue{M-1};d[M-1]=0;
   for(size_t at=0;at<queue.size();++at){int i=queue[at];for(int j=0;j<M;++j)if(d[j]==999&&costs[size_t(i)*M+j]<=k){d[j]=d[i]+1;parent[j]=i;queue.push_back(j);}}
   vector<int> restricted_time(6,999), restricted_reached(6,0);
   for(int z=0;z<6;++z){vector<int> rd(M,999),rq{M-1};rd[M-1]=0;
    for(size_t at=0;at<rq.size();++at){int i=rq[at];for(int j=0;j<M;++j)if(profiles[z][j]&&rd[j]==999&&costs[size_t(i)*M+j]<=k){rd[j]=rd[i]+1;rq.push_back(j);}}
    restricted_time[z]=rd[0];restricted_reached[z]=rq.size();}
   int T=d[0],maxclock=T-1;
   vector<vector<int>> env(7,vector<int>((maxclock+1)*(maxclock+1),b.N+1));
   vector<pair<int,int>> best(7,{-1,-1});vector<int> besttime(7,999);
   for(int i=0;i<M;++i)if(d[i]<=maxclock)for(int j=0;j<M;++j)if(d[j]<=maxclock){int ov=popcount(b.states[i]&b.states[j]),t=d[i]+d[j]+1;
    for(int z=0;z<7;++z)if(z==6||(profiles[z][i]&&profiles[z][j])){
     int slot=d[i]*(maxclock+1)+d[j];env[z][slot]=min(env[z][slot],ov);
     if(ov<=k&&t<besttime[z]){besttime[z]=t;best[z]={i,j};}
    }
   }
   for(auto&e:env)for(int a=0;a<=maxclock;++a)for(int c=0;c<=maxclock;++c){int idx=a*(maxclock+1)+c;if(a)e[idx]=min(e[idx],e[idx-maxclock-1]);if(c)e[idx]=min(e[idx],e[idx-1]);}
   cout<<"{\"w\":"<<w<<",\"n\":"<<n<<",\"k\":"<<k<<",\"states\":"<<M<<",\"reachable\":"<<queue.size()<<",\"T\":"<<T<<",\"profile_results\":[";
   for(int z=0;z<6;++z){int failures=0,firsta=-1,firstc=-1;for(int a=0;a<=maxclock;++a)for(int c=0;c<=maxclock;++c)if(env[z][a*(maxclock+1)+c]>env[6][a*(maxclock+1)+c]){++failures;if(firsta<0){firsta=a;firstc=c;}}
    auto[i,j]=best[z];cout<<(z?",":"")<<"{\"axis\":"<<z/3<<",\"kind\":"<<z%3<<",\"pair_time\":"<<besttime[z]<<",\"path_time\":"<<restricted_time[z]<<",\"path_reachable\":"<<restricted_reached[z]<<",\"endpoint_masks\":["<<(i<0?0:b.states[i])<<","<<(j<0?0:b.states[j])<<"],\"envelope_failures\":"<<failures;
    if(failures)cout<<",\"first_failure\":{\"a\":"<<firsta<<",\"b\":"<<firstc<<",\"full\":"<<env[6][firsta*(maxclock+1)+firstc]<<",\"restricted\":"<<env[z][firsta*(maxclock+1)+firstc]<<"}";
    cout<<"}";
   }cout<<"]}"<<endl;
  }
 }
}

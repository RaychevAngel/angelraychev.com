# Independent review of the exact mixed overlap evaluator

29 October 2026. Ordinary independent review, not Lean.

Reviewed `../root/exact-front-triangle-profile.md`. The numerical theorem
passes this review. Right compression on the odd transverse path preserves
the original front and area and weakly decreases overlap. Its canonical
height paths have alternating parity, adjacent increments plus or minus1,
and no consecutive minus steps. The row area and triangle-count formulas
include both empty virtual heights correctly.

Missing one triangle cell bounds every row height by R+W-2, independently
of the longitudinal length. The dynamic program therefore enumerates all
right-compressed candidates with intersection below the full triangle;
intersection is nonnegative and additive, so discarding saturated partial
states loses no unsaturated candidate. The full-triangle case has the
separate capacity h.

For the down-set argument, rank (W+2)y-x strictly decreases along either
lower diagonal prerequisite and along a same-parity transverse step to
the right. The prerequisite relation is acyclic. Deleting a maximal
occupied cell preserves the ideal and cannot increase triangle overlap.
Thus an attained maximum area M(D) really implies attainable exact size q
for every q<=M(D), which is the critical sufficiency direction in F5.

O(w^4) arithmetic operations and O(w^3) working memory hold for evaluation
with adjacent row layers. Storing all row-layer predecessor pointers for
optional witness reconstruction would use O(w^4) memory; recomputation or
a separate reconstruction bound avoids suggesting that both memory bounds
hold simultaneously without explanation. This is an exposition issue,
not a flaw in the exact numerical evaluator.

The result is a static overlap calculation. It does not establish a true
ancestor, phase-compatible age, availability, or a daily-budget-preserving
path to its minimizing shape. Those physical interfaces remain necessary.

## Uniform strengthening, independent of parity compression

The same proof works for EVERY2<=w<=n, either parity of either side, and
0<=R<=w-1 with R congruent to the source physical color p. Enumerate all
ordinary cutoff paths, dropping the optional no-consecutive-down-steps
condition and the last-step coordinate. The height bound becomes
H=min(n-1,R+w-3), unchanged in substance. The complete color capacity is
|V_p|=floor((wn+1-p)/2), rather than necessarily wn/2.

Only diagonal prerequisites are now needed; rank y strictly decreases
along them. All other maximum-area/down-set-deletion arguments remain
valid. Odd-axis compression was useful pruning but was never required
for the polynomial bound. This generalizes the same static theorem,
including unequal even-even rectangles, rather than adding another family.

An independent implementation `uniform_front_triangle_profile.py` compares
this maximum-area recurrence against literal minima AT EVERY exact size q,
not just against maximum envelopes. It checks162 cases and155,761 ordinary
pyramid paths on widths2..10, lengths w,w+1,2w+1, both colors, and every
admissible radius R<w. All passed. Receipt is the adjacent JSON file.
This supports the ordinary proof; the finite audit is not its justification.

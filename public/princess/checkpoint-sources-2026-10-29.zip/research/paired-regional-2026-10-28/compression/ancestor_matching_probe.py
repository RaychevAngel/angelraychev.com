"""One structural ancestor-matching compression, not a random search.

Select the lexicographically least target basis admitting a perfect match
from the source into its downward-diagonal predecessor cones.
"""
from pathlib import Path
import json
import sys
import time


def prepare(w,n,p):
    cells=[(x,y) for x in range(w) for y in range(n) if (x+y)%2==p]
    ranks={v:i for i,v in enumerate(cells)}
    ancestors=[]
    for u,z in cells:
        ancestors.append([j for j,(x,y) in enumerate(cells)
                          if z<=y and abs(u-x)<=y-z])
    order=sorted(range(len(cells)),key=lambda j:(cells[j][1],
                  (-cells[j][0] if p==1 and cells[j][1]==0 else cells[j][0])))
    other=[(x,y) for x in range(w) for y in range(n) if (x+y)%2!=p]
    oi={v:i for i,v in enumerate(other)}
    adj=[sum(1<<oi[v] for v in ((x-1,y),(x+1,y),(x,y-1),(x,y+1)) if v in oi)
         for x,y in cells]
    return cells,ancestors,order,adj


def compress(A, ancestors, order):
    matching={}
    targets=0
    def augment(target,seen):
        for source in ancestors[target]:
            if not (A>>source&1) or source in seen: continue
            seen.add(source)
            if source not in matching or augment(matching[source],seen):
                matching[source]=target
                return True
        return False
    for target in order:
        if augment(target,set()): targets|=1<<target
    assert targets.bit_count()==A.bit_count()
    return targets


def probe(w,n):
    start=time.process_time()
    data=[prepare(w,n,p) for p in range(2)]
    maps=[]; shadows=[]
    for cells,ancestors,order,adj in data:
        maps.append([compress(A,ancestors,order) for A in range(1<<len(cells))])
        ns=[0]*(1<<len(cells))
        for A in range(1,len(ns)):
            bit=A&-A
            ns[A]=ns[A^bit]|adj[bit.bit_length()-1]
        shadows.append(ns)
    fail={'monotonicity':0,'N_compatibility':0}
    fixtures={}
    for p in range(2):
        cells=data[p][0]
        for A,CA in enumerate(maps[p]):
            for bitno in range(len(cells)):
                if A>>bitno&1:continue
                if CA&~maps[p][A|1<<bitno]:
                    fail['monotonicity']+=1
                    fixtures.setdefault('monotonicity',dict(p=p,A=A,B=A|1<<bitno,
                                       CA=CA,CB=maps[p][A|1<<bitno]))
            lhs=shadows[p][CA];rhs=maps[1-p][shadows[p][A]]
            if lhs&~rhs:
                fail['N_compatibility']+=1
                item=dict(p=p,A=A,CA=CA,NCA=lhs,CNA=rhs,source_size=A.bit_count())
                previous=fixtures.get('N_compatibility')
                if previous is None or item['source_size']<previous['source_size']:
                    item.update(source_cells=[v for j,v in enumerate(cells) if A>>j&1],
                                compressed_cells=[v for j,v in enumerate(cells) if CA>>j&1])
                    fixtures['N_compatibility']=item
    return dict(shape=[w,n],failures=fail,fixtures=fixtures,
                supports=sum(map(len,maps)),CPU_seconds=time.process_time()-start)


if __name__=='__main__':
    shape=tuple(map(int,sys.argv[1].split(','))) if len(sys.argv)>1 else (4,6)
    result=probe(*shape)
    Path(__file__).with_name('ancestor-matching-%dx%d.json'%shape).write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result))

"""Independent literal full-uncertainty replay of a shorter nonprefix gate.

Consumes the regional head/cone certificate, constructs an explicit balanced
two-inspection cover and ordinary tail, then replays every actual grid update.
"""
from pathlib import Path
import sys,json,hashlib
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2]
sys.path.insert(0,str(ROOT/'src'))
from bridge_upper_transport import prefix_height

def cells(w,n,p):return{(x,y)for x in range(w)for y in range(n)if(x+y)%2==p}
def hood(S,w,n):
 return{(xx,yy)for x,y in S for xx,yy in((x-1,y),(x+1,y),(x,y-1),(x,y+1))if 0<=xx<w and 0<=yy<n}
def support(a,n,p):return{(x,y)for x in range(len(a))for y in range(n)if(x+y)%2==p and y<=a[x]}
def both(S,w,n):return{(w-1-x,n-1-y)for x,y in S}

def run(source_name='long_middle_cone_replay.json',tail_updates=39,output_name='long_middle_gate_literal_replay.json'):
 source=HERE.parent/'regional'/source_name;z=json.loads(source.read_text())
 w,n,k,c=(z[x]for x in('w','n','k','c'));h=w*n//2;p=z['bridge_phase']
 K,Y,R=({tuple(v)for v in z[x]}for x in('K','Y','R'))
 A=cells(w,n,p)-K;B=cells(w,n,1-p)-R
 pairs={u:(u[0],u[1]-1)for u in A if u[1]>0 and(u[0],u[1]-1)in B}
 roots={v for v in B if v[1]==n-1}
 assert len(roots)==1 and len(pairs)==2*k-1
 # Buying the sole far root leaves the acyclic horizontal matching graph.
 # Selecting the first48 source pairs by height is predecessor-closed.
 first=set(sorted(pairs,key=lambda u:(u[1],u[0]))[:k])
 second=roots|{v for u,v in pairs.items()if u not in first}
 assert len(first)==k and len(second)==k
 for u in A:
  assert all(u in first or v in second for v in hood({u},w,n)&B)
 shots=[{tuple(v)for v in ss}for ss in z['head_and_cone_shots']]+[first,second]
 # Literal solo replay of the imported head/cone and new bridge.
 solo=cells(w,n,0);counts=[len(solo)]
 for day,S in enumerate(shots):
  assert len(S)<=k and all((x+y)%2==day%2 for x,y in S)
  solo=hood(solo-S,w,n);counts.append(len(solo))
  if day==z['physical_head_and_cone_updates']-1:assert solo==A
 assert solo<=Y and hood(R,w,n)<=Y
 bridge_after=len(solo)
 # Genuine upper-right ordinary tail: initial local phase0 and exactly39 updates.
 local=both(Y,w,n);phase=sum(next(iter(local)))%2
 assert local==support(prefix_height(w,n,phase,len(local)),n,phase)
 for _ in range(tail_updates):
  survivor=support(prefix_height(w,n,phase,max(0,len(local)-k)),n,phase)
  assert survivor<=local
  shot=both(local-survivor,w,n);assert len(shot)<=k
  shots.append(shot);solo=hood(solo-shot,w,n);counts.append(len(solo))
  local=hood(survivor,w,n);phase^=1
  assert solo<=both(local,w,n)
 assert len(shots)==z['physical_head_and_cone_updates']+2+tail_updates and len(solo)<=c
 # Independent full-uncertainty semantics, without assuming the other cohort.
 all_cells=cells(w,n,0)|cells(w,n,1);belief=set(all_cells);full_counts=[len(belief)]
 for day,S in enumerate(shots):
  assert S<=all_cells and len(S)<=k
  belief=hood(belief-S,w,n);full_counts.append(len(belief))
  assert len(belief)==h+counts[day+1]
 signed=len(belief)-h;assert signed<=c
 # The reached gate is solo: reflecting the even transverse axis swaps
 # physical colors. Its actual overlap supplies the central inspection.
 reflect_x=lambda S:{(w-1-x,y)for x,y in S}
 center=belief&reflect_x(belief)
 full_word=[];capture_counts=[];first_capture=None
 if len(center)<=k:
  full_word=shots+[center]+[reflect_x(S)for S in reversed(shots)]
  captured=set(all_cells);capture_counts=[len(captured)]
  for day,S in enumerate(full_word,1):
   assert len(S)<=k
   captured-=S
   if not captured and first_capture is None:first_capture=day
   captured=hood(captured,w,n);capture_counts.append(len(captured))
  assert not captured
 from ancestral_gate_certificate_probe import prefix_gate
 oldP=prefix_gate(w,n,k,c)
 out=dict(shape=[w,n],budget=k,terminal_signed_quota=c,updates=len(shots),
  final_solo_size=len(solo),final_full_belief_size=len(belief),final_signed_mass=signed,
  bridge_matching=len(pairs),bridge_shot_sizes=[len(first),len(second)],
  bridge_postmovement_size=bridge_after,daily_probe_max=max(map(len,shots)),
  retained_prefix_gate=oldP,strict_improvement=oldP-len(shots),
  full_capture_days=first_capture,central_probe_size=len(center),
  full_capture_counts=capture_counts,full_capture_shots=[sorted(S)for S in full_word],
  imported_source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
  solo_counts=counts,full_counts=full_counts,shots=[sorted(S)for S in shots],
  scope='Explicit full-uncertainty solo gate; when its actual color-swapped overlap fits the quota, the full palindrome is also replayed. Every simultaneous inspection and obligatory movement uses literal cells. Lower bounds are separate ordinary arguments, not inferred from this replay.')
 (HERE/output_name).write_text(json.dumps(out,indent=2)+'\n')
 return {key:value for key,value in out.items()if key not in('shots','solo_counts','full_counts','full_capture_counts','full_capture_shots')}

if __name__=='__main__':print(json.dumps(run(),indent=2))

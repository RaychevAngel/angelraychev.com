"""Bounded induced-region diagnostic for the raw-boundary ancestry obstruction."""
from itertools import combinations
import json
from pathlib import Path
W=N=6
V={(x,y) for x in range(W) for y in range(N)}
cells=[sorted(z for z in V if sum(z)%2==p) for p in (0,1)]
Y={z for i,z in enumerate(cells[1]) if 2486>>i&1}
def neigh(S):return {z for x,y in S for z in [(x-1,y),(x+1,y),(x,y-1),(x,y+1)] if z in V}
B=neigh(Y)
def run(R):
 c=[sorted(z for z in R if sum(z)%2==p) for p in (0,1)];idx=[{z:i for i,z in enumerate(C)} for C in c]
 nb=[]
 for p in (0,1):
  adj=[sum(1<<idx[1-p][z] for z in neigh({v}) if z in idx[1-p]) for v in c[p]]
  M=[0]*(1<<len(c[p]))
  for s in range(1,len(M)):
   bit=s&-s;M[s]=M[s^bit]|adj[bit.bit_length()-1]
  nb.append(M)
 Rstates={(1<<len(c[0]))-1};trace=[]
 for t in range(5):
  p=t%2;target=sum(1<<i for i,z in enumerate(c[p]) if z in B)
  trace.append({'t':t,'states':len(Rstates),'max_target_holes':max((target&~s).bit_count() for s in Rstates)})
  if t==4:break
  out=set()
  for s in Rstates:
   bits=[i for i in range(len(c[p])) if s>>i&1]
   for j in range(min(4,len(bits))+1):
    for D in combinations(bits,j):out.add(nb[p][s^sum(1<<i for i in D)])
  Rstates=out
 return {'size':len(R),'colors':list(map(len,c)),'trace':trace}
regions={
 'Y_plus_shadow':Y|B,
 'full_corner_radius5':{(x,y) for x,y in V if x+5-y<=5},
 'upper4rows':{(x,y) for x,y in V if x<4},
 'upper5rows':{(x,y) for x,y in V if x<5},
 'right5cols':{(x,y) for x,y in V if y>0},
}
out={name:run(R) for name,R in regions.items()}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out))

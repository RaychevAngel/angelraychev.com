"""Falsify a numerical-only route to simultaneous terminal-gate exactness."""
from pathlib import Path
import sys,json
from math import isqrt
ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT/'src'))
from bridge_upper_transport_odd_coupling import physical_step

def rho(x):
 r=(isqrt(4*x+1)-1)//2
 return r+(r*(r+1)<x)
def R(x):return isqrt(x-1)+1 if x else 0

def case(b,n,k,c):
 h=(2*b+1)*n//2;Z=h-b*b;P=(c,c);clock=0
 while max(P)<h:P=physical_step(b,h,k,P);clock+=1
 T=clock-1
 C=[(0,0)];V=[(c,c)]
 for _ in range(max(0,T)):
  x,y=C[-1];C.append((y+k-min(rho(y+k),b),x+k-min(R(x+k),b+1)))
  x,y=V[-1];V.append((k+y-min(rho(y),b),k+x-min(R(x),b+1)))
 checks=[]
 for s in range(1,T+1):
  r=T-s
  if max(C[s-1])+k>=Z or (r and max(V[r-1])>=Z):continue
  checks.append((s,r,max(C[s])+max(V[r])-h,C[s],V[r]))
 return {'c':c,'P':clock,'candidate':T,'protected_cuts':checks,'scalar_rejects':any(x[2]<0 for x in checks)}

def main():
 fixtures=[];count=0
 for b in range(2,40):
  for n in (2*b+2,2*b+4,4*b+2):
   for k in range(b+1,3*b):
    if k>=(2*b+1)*n//2-b*b:continue
    a=case(b,n,k,k);d=case(b,n,k,k//2);count+=1
    if not a['scalar_rejects'] and not d['scalar_rejects']:
     fixtures.append({'b':b,'n':n,'k':k,'gates':[a,d]})
     if len(fixtures)>=8:break
   if len(fixtures)>=8:break
  if len(fixtures)>=8:break
 out={'scope':'Numerical protected-cut necessary maxima only; no physical attainability or counterexample to prefix optimality.','cases':count,'both_gates_scalar_unresolved':fixtures}
 Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
 print(json.dumps(out,indent=2))
if __name__=='__main__':main()

"""Test an explicit finite boundary-profile rule against the known4x6 map."""
import json,hashlib
from pathlib import Path
exec(Path('research/paired-regional-2026-10-28/compression/comparator_repair_audit.py').read_text().split('out=[]')[0])
constraints=[[],[]]
for p in(0,1):
 for J in raw['ideals'][p]:constraints[p].append((J,J,'fixed_pyramid'))
for c in[(0,0),(0,n-1),(w-1,0),(w-1,n-1)]:
 p=sum(c)%2;s=1<<ix[p][c];target=raw['images'][p][s]
 for t in range(w+n):
  constraints[p].append((s,target,'corner_ball'))
  s=N[p][s];target=N[p][target];p^=1
reports=[]
for variant in('corners','pyramids','both'):
 C=[[],[]];empty=0
 for p in(0,1):
  con=[(S,T)for S,T,name in constraints[p]if variant=='both' or (name=='corner_ball')==(variant=='corners')]
  for s in range(1<<h):
   k=s.bit_count();allowed=[I for I in raw['ideals'][p]if I.bit_count()==k and all((I&T).bit_count()>=(s&S).bit_count()for S,T in con)]
   if not allowed:empty+=1;C[p].append(raw['images'][p][s])
   else:C[p].append(min(allowed))
 nf=faults(C);mf=[]
 for p in(0,1):
  for s in range(1<<h):
   for v in range(h):
    if not(s>>v&1)and C[p][s]&~C[p][s|(1<<v)]:mf.append((p,s,s|(1<<v)))
 diffs=sum(C[p][s]!=raw['images'][p][s]for p in(0,1)for s in range(1<<h))
 reports.append({'variant':variant,'empty_domains':empty,'N_faults':len(nf),'first_N_fault':nf[:1],'mono_faults':len(mf),'first_mono_fault':mf[:1],'differences_from_CSP':diffs})
(root/'corner-ball-map-audit.json').write_text(json.dumps(reports,indent=2)+'\n')
print(json.dumps(reports,indent=2))

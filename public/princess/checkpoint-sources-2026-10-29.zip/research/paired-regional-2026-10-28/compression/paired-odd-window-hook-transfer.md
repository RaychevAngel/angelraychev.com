# Paired odd-window and hook transfers on even-by-even rectangles

29 October 2026. Necessary all-history inequalities, for independent
review. These retain exact clipped regional profiles and the shared daily
budget. They do not assert closure or a new capture-time equality.

Let w=2b<=n be even side lengths, b>=1. Put h=wn/2 and
m=(w+n-2)/2. Keep the rows x=0,...,w-2, and define

    J_0={0,...,w-2} x {0,...,n-2},
    J_1={0,...,w-2} x {1,...,n-1},
    K_i=V minus J_i.

Both J_i are odd rectangles; their majority physical colors are i.
Each J_i has majority capacity M=h-m and minority capacity M-1.
K_i is an odd path with majority physical color 1-i, majority capacity
m+1 and minority capacity m. Reflection supplies the analogous pair
which deletes the first row; exchanging coordinates supplies the two
other orientations when desired.

For a physical set S define Q(S)=|S| and

    Z_p(S)=|S_0 intersect J_p|+|S_1 intersect J_(1-p)|,
    H_p(S)=Q(S)-Z_p(S),                         p=0,1.

Thus Z_0 counts majority-class sources in their selected odd windows,
Z_1 counts minority-class sources, and H_p is the complementary hook
count, separately for each physical color. These are literal counts.

## 1. Regional shadow functions, including their endpoints

Let nu_0(s),nu_1(s) be the accepted exact majority and minority open-shadow
profiles for the (w-1) by (n-1) odd rectangle. They are defined only on
0<=s<=M and 0<=s<=M-1 respectively, with nu_p(0)=0. For positive s,

    nu_0(s)=s+min(ceil(sqrt(s)), b-1, ceil(sqrt(M-s))-1),
    nu_1(s)=s+min(1+rho(s), b, 1+rho(M-1-s)),

where rho(s)=min{r>=0:s<=r(r+1)}. These also include width-one odd
rectangles (b=1): majority shadow min(s,M-1), minority shadow s+1.

Define the two-copy minimum convolutions

    B_p(z)=min{nu_p(x)+nu_p(z-x): both arguments are in domain}.

This is a stated finite optimization, not claimed to be an O(1) expression.
Keeping the two component counts instead gives the stronger directly
evaluated sum nu_p(x)+nu_p(y), with no optimization at all.

For the two hook copies their minimum convolutions are explicit:

    G_0(q)=q-floor(q/(m+1)),   0<=q<=2(m+1),
    G_1(q)=q+ceil(q/m),       0<=q<=2m.

G_0 uses hook-majority sources, whose only saving is one for each full
copy. G_1 uses hook-minority sources, whose cost is one for each nonempty
copy. Concentrating as much mass as possible into one copy proves these
formulas, including q=0 and the full endpoints. Here m>=1.

## 2. Static paired transfer and a combined shadow charge

For every physical set S, with no shape or size restriction,

    B_p(Z_p(S)) <= Z_(1-p)(N_V(S)),
    G_(1-p)(H_p(S)) <= H_(1-p)(N_V(S)),          p=0,1.       (1)

Proof: restrict each physical-color component to its selected J_i or K_i,
apply the exact induced-subgraph profile, and add. The two source
components have different physical colors, and their target components
therefore also have different physical colors. There is no overlap or
double-counting between those two summands. Flipping source color in the
same selected region changes the label p to 1-p. Minimum convolution
can only weaken the sum of the two actual profile values.

Adding the two inequalities gives the useful combined charge

    |N_V(S)| >= B_p(Z_p(S))+G_(1-p)(Q(S)-Z_p(S)).             (2)

The rectangle and hook shadows are added here only because they lie in
disjoint target regions within EACH physical color. This differs from
adding the overlapping internal and cross-interface shadows, which is
invalid. The additional cross-interface constraints in odd-hook-shadow.md
remain separately available.

## 3. Actual histories and the common inspection allocation

Let D'=E_V(D union I) be one actual hole update. Inspections may be taken
useful, I disjoint D, with |I|<=k. Then (1) gives

    B_p(Z_p(D')) <= Z_(1-p)(D)+Z_(1-p)(I),
    G_(1-p)(H_p(D')) <= H_(1-p)(D)+H_(1-p)(I).               (3)

In particular, writing v_p=Z_(1-p)(I), the SAME physical inspections give
the complementary allocation H_(1-p)(I)=|I|-v_p. Thus

    B_p(Z_p(D'))+G_(1-p)(|D'|-Z_p(D')) <= |D|+k.           (4)

One must not allocate k independently to the rectangle and hook terms.
Nor are the two phase allocations independent: if X is the deleted row
and C the union of the two end columns within the retained rows, then

    Z_0(I)+Z_1(I)=2|I|-2|I intersect X|-|I intersect C|.     (5)

The same identity holds for any physical set in place of I. Simultaneous
top/bottom or transverse versions use the SAME actual region counts and
the SAME total inspection quota. The construction therefore gives a
uniform necessary regional-history framework, not free per-projection
budgets or per-step phase resets.

## 4. What does and does not copy from the odd-width theorem

There is a simple unclipped sufficient range for the odd-window costs:
if each projected component has size strictly below

    U_D=M-(b-1)^2,

then nu_0(s)=s+min(ceil(sqrt(s)),b-1) and
nu_1(s)=s+min(1+rho(s),b). The proof is the same complement-distance
calculation as for odd rectangles, with radius parameter b-1: the
majority complement has size at least (b-1)^2+1 and the minority
complement at least (b-1)^2.
For actual component counts x,y<U_D, subadditivity bounds their actual
profile sum below by z plus the corresponding capped cost at z=x+y.
Thus (1) and (3) can use that stronger capped expression directly under
the componentwise guard. This is NOT an unconditional lower bound on the
global minimum convolution B_p(z), whose other decompositions may contain
a clipped component.

Unlike the odd-width paired-window theorem, U_D need not cover the whole
original even-board collar. For long boards, deleting a transverse row
removes a parameter-dependent number of vertices. Consequently all claims
outside that sufficient range must use the exact clipped profiles in
Sections1-3; silently copying the old unclipped phase recurrence would be
incorrect.

When both actual projected components are below U_D, Z_0 reaches its
capped cost b-1, and H_0>0, adding the actual profile sums gives a charge
of at least (b-1)+1=b. Under the same componentwise guard for p1, its
capped charge is b minus the number of full-majority-hook savings
allowed by G_0. The locations and ages of those hook occupations,
and the cross-interface injections, are the remaining compatibility
information. No theorem that these inequalities attain the optimal
full-origin time has been proved here.

"""Audit exact forced-cover cone for canonical bridge with one full wall."""
from pathlib import Path
import json, random
from pyramid_interpolation_replay import paths,support

def check(w,n,H,R):
    V=[{(x,y) for x in range(w) for y in range(n) if (x+y)%2==p} for p in (0,1)]
    A=V[0]-H; B=V[1]-R
    if any(y==0 for x,y in A):return None
    roots={v for v in B if v[1]==n-1}
    if len(roots)!=1:return None
    pairs={u:(u[0],u[1]-1) for u in A if u[1]>0 and (u[0],u[1]-1) in B}
    inv={v:u for u,v in pairs.items()}
    rev={u:set() for u in pairs}
    forced=set()
    for u in pairs:
        for v in B:
            if abs(u[0]-v[0])+abs(u[1]-v[1])!=1:continue
            if v in roots:forced.add(u)
            elif v in inv and inv[v]!=u:rev[inv[v]].add(u)
    todo=list(forced)
    while todo:
        v=todo.pop()
        for u in rev[v]-forced:forced.add(u);todo.append(u)
    z=next(iter(roots));r=z[0]
    J={u for u in V[0] if u[1]<=n-abs(u[0]-r) and (u[0]!=r or u[1]<=n-2)}
    assert J<=({u for u in V[0] if u[1]==0}|{(x,y+1) for x,y in B if y<n-1})
    assert forced==A&J,(w,n,sorted(H),sorted(R),sorted(forced),sorted(A&J))
    return len(forced)

def run():
    rng=random.Random(2026102941);out=[]
    for w,n in [(3,4),(4,4),(4,5),(4,6),(5,6),(6,6),(6,8),(8,8)]:
        ps=[paths(w,n,p) for p in (0,1)];cs=[]
        cand=((a,r) for a in ps[0] for r in ps[1^((n-1)%2)]) if w<=4 else ((rng.choice(ps[0]),rng.choice(ps[1^((n-1)%2)])) for _ in range(30000))
        for a,r in cand:
            H=support(a,n,0);R={(x,n-1-y) for x,y in support(r,n,1^((n-1)%2))}
            q=check(w,n,H,R)
            if q is not None:cs.append(q)
        out.append(dict(w=w,n=n,checks=len(cs),maximum_forced=max(cs,default=0)))
    return dict(cases=out,total=sum(x['checks'] for x in out),scope='Full incoming wall; exactly one missing outgoing wall root; literal matching-predecessor closure agrees with fixed cone. Specified endpoints only.')
if __name__=='__main__':
    out=run();Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))

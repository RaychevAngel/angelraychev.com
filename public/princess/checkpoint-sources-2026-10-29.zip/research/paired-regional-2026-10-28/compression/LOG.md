# Compression lane log

29 October 2026 UTC. Read-only historical sources; new files confined here.

## Initial target and discovery

Aim: an optimum-PAIR replacement theorem preserving clocks, physical reachability, and central overlap, without requiring a normal form for every partial-state optimum.

The root proposed opposite row-end compression along an odd coordinate. Source audit found the single-history operator already proved in `research/odd-cylinder-exact-recurrence.md`, based on `research/corner-ideal-exchange.md`. The useful new application is opposite compression of the two histories, yielding exact fiberwise overlap. This is an exact reduction, not a new all-parameter numerical solution.

The source also contains a rigorous obstruction on even paths: every static parity-preserving, monotone, cardinality-preserving, neighborhood-subcommuting map is the identity. Thus blindly extending odd path compression is impossible. We must exploit whole-board structure, time alternation, or optimum-pair replacement without such an operator.

## First research round and cross-review

- Replayed literal full-origin endpoint and history restriction oracles on
  30 small board/budget triples. All six row-profile families matched full
  capture and 1,855 clock-pair overlap minima per family. This is finite
  evidence, not a uniform normal form.
- Proved the exact erosion/intersection transition lemma for interval
  states; no hull approximation is needed inside the restricted graph.
- Audited the old 25x26,k13 transport witness: all actual beliefs and
  survivors are common-end-per-color row-prefix profiles in both axes,
  despite its many pyramid-axis switches.
- Found the odd-coordinate paired compression consequence, while locating
  and preserving attribution to the already existing odd-cylinder
  single-history compression theorem.
- Comparator-network sorting does not supply a uniform pyramid operator.
  Two 4x6 failures already encode sparse-corner/co-sparse-corner tension;
  repair propagation changes 249 images. Random-order search was stopped.
- Reconstructed the entire old successful 4x6 CSP operator from corner
  exact-walk-ball overlap constraints and minimum numeric-mask selection.
  This also passes every 4x8 subset. The same selection fails on 6x6;
  adding every fixed-pyramid overlap constraint does not repair it.
  Thus the constraints are structural necessary conditions, but the
  uniform compatible selection theorem remains open.
- Independently reviewed the phase lane's new high-budget continuation
  and conditional common-cut overlap arguments. See
  `phase-independent-review.md`. No flaw found in those stated candidates;
  a separate uncapped diagnostic initialization mismatch was reported.
- Root's high-budget signed reverse interface independently passed review;
  see `signed-reverse-independent-review.md`. The explicit first-crossing
  dichotomy removes the old A>L premise without extending geometry beyond
  its stated domain.
- A proposed fixed per-particle metric-fold matching has an immediate Hall
  obstruction: the two same-color physical corners both have the same
  unique allowed target. This was independently noticed by root and this
  lane before any implementation. A useful replacement would need actual
  collision/overflow behavior, not a fixed bipartite assignment.
- Nonlocal corner/reflection comparator variants all fail on 4x6, already
  on nearest-corner singleton neighborhoods. The route is stopped; see
  `nonlocal-comparator-findings.md`.
- Independently accepted the new interior full-front core: an actual
  radius at least b-4 ball at a possibly interior near-end vertex. It
  preserves the physical phase-change barrier and the radius-zero charge.
  See `interior-front-independent-review.md`; no corner-lens substitution
  or new capture bound is implied.
- Proved an all-seed elementary capped phase-span estimate for
  b>=512,k>=ceil(7b/4): 2E<39b/40+7<b-5. A monotone drift integral
  replaces discrepancy machinery; root independently accepted it.
  Source `seven-quarter-span.md`; the phase lane owns physical assembly.
- Independently accepted the exact odd-width gate assembly for
  b>=512,3b<=k<=floor(15b/4), conditional on its reviewed dependencies.
  The co-small support supplies its own literal dual marker. See
  `high-budget-assembly-independent-review.md`.

## 29 October: four odd-window signature attacked

After independently reviewing the phase lane and proving the seven-quarter
span estimate, revisited even-width closure. The October25 sources already
resolve longitudinal front-to-corner and opposite-front switches; do not
redo those older obligations. Strict same-end interpolation already resolves
the interior schedule for specified regular pyramid endpoints.

Root/regional proposed odd-subboard projections as a new boundary invariant.
Their odd-width paired projection theorem is structurally promising. For
even-even boards, the four natural odd subboards encode only boundary
counts. A bounded square test disproves complete continuation by those
counts even with all side counts, corner bits, mass and genuine arrival
clock. The explicit 8x8,k6 example has remaining times10 and11 at identical
features/clock2; see `odd-window-signature-failure.md`. This does not reject
full-origin inequalities or optimum-pair compression. All checks finished;
no process left running.

## 29 October: paired overlap, hook projections, and exact row defects

- Proved a stronger mixed full-front/triangle overlap bound after opposite
  short-axis compression; root independently accepted it. The coefficient
  uses only the uncovered transverse tail, with an additional interior
  lens charge. Source `opposite-compressed-front-triangle.md`; 12,042 literal
  front/triangle checks passed through width9. This does not supply missing
  physical ancestry or candidate gate equality.
- Proved exact odd-hook profiles and cross-interface injections on every
  even-even rectangle, plus paired odd-window/hook transfer with actual
  shared shot quotas. Regional independently accepted them, after a guard
  clarification: component sizes must remain in the unclipped range; the
  global profile convolution may choose clipped components. An exhaustive
  2,132,128 source/hook audit passed. Sources `odd-hook-shadow.md` and
  `paired-odd-window-hook-transfer.md`.
- Ancestor-matching insertion remained monotone on4x6 but failed
  neighborhood compatibility, already on a top-corner singleton's
  neighborhood. The dictated order correction leaves8 failures; stopped.
  Fixed source-target ancestry assignments lose joint corner-ball congestion.
- Proved the exact row-compression defect identity. The only added cells
  are one fringe cell at each proper zero-surplus row facing the wrong end.
  Oppositely oriented such rows require an actual symmetric-difference
  surplus charge between them. Source `exact-row-compression-defect.md`.
- Proved closure-dual preservation and exchange of these zero rows; root
  and regional independently accepted Section2a. The dual size can fall
  to L-e, so no strict central hypothesis is transferred silently.
- The conjecture min(d_L,d_R)<=sigma-b+1 passed533,024 literal supports
  on2x4,4x4,4x6,6x6. Static CP found no counterexample on8x8 or8x16
  (INFEASIBLE); its bounded10x10,10x20,12x12,12x24 tests were UNKNOWN.
  This is not a general proof and gives no temporal inspection transfer.
- A proposed opposite-corner-triangle counterexample was false: vertical
  union removes the expected proper-zero rows. Large overlapping triangles
  have min defect b-max(root), not min(root). The saved examples are
  structural diagnostics, not counterexamples to the conjecture.
- Deduced the zero-excess case with BOTH source and actual dual sizes>L
  from the accepted critical-duality classification: min defect<=1, with
  a nonzero minimum possible only for the rigid triangle-plus-singleton
  form or its exact dual. Every pyramid in either axis has one defect
  orientation absent. Source `critical-singleton-defect.md`; independent
  review requested. The earlier October25 label analysis already isolates
  the rigid event in time; only its row-defect interpretation is new here.
- Independently accepted root's exact static paired-triangle packing
  lemma. Total defect >= triangular lens is SHARP for raw minimal-shadow
  supports. See `paired-triangle-independent-review.md`. Thus stronger
  total-defect-only geometric obstructions cannot close the remaining
  chronological gap.

No global capture-time ceiling is changed by this lane's current results.
The temporal theorem remains open: defects must be assigned to usable
spatial/chronological credit with every daily quota and true paired
intersection retained. No expression simplification or public edits.
- Regional independently accepted `critical-singleton-defect.md` with its
  two strict cardinality guards and b>=4. The at-most-once time statement
  remains conditional on the actual strict-progress middle ledger.
- Independently accepted root's O(w^4)-arithmetic exact static front/triangle
  overlap evaluator, including the acyclic ideal deletion proof that maximum
  area suffices for every smaller requested size. See
  `exact-front-triangle-independent-review.md`. Optional all-layer witness
  pointers need a separate memory qualification. No temporal realization
  follows from this static recurrence.
- Strengthened root's exact mixed front/triangle evaluator to ALL widths
  and both length parities: remove the optional odd-axis compression and
  enumerate all slope-one paths, with state only(height,intersection).
  The same O(w^4) time/O(w^3) value memory bound holds because missing one
  triangle cell still bounds every height by R+w-3. Root is rewriting the
  original theorem around this stronger scope. Independent exact-size
  audit:162 cases,155,761 literal pyramid paths, PASS. See
  `uniform_front_triangle_profile.py/.json` and the appended independent
  review. This is a true mathematical scope extension of a static tool,
  not full dynamic capture classification.
- Attribution correction after reading the full interpolation extension:
  automatic physical-image regularity and removal of the initial-full-fiber
  hypothesis were ALREADY proved in October24
  `candidate-even-pyramid-interpolation-extension.md`. The new explicit
  identity N(DY)=N(EY)=Y minus isolated bottom roots is retained only as a
  concise rederivation/maximal-image restatement, not promoted as new
  transport progress. `pyramid-neighborhood-image.md` now states this.
- Likewise the old `bridge-upper-transport-triangle-contraction.md` already
  gives a uniform feasible-budget failure of arbitrary-order necessity for
  the prescribed descending word. Our quick exact small-state attack in
  `fixedword_transport_attack.py/.json` corroborates that failure, including
  a six-cell6x6,k4 state clearing in2 days though its fixed-word test fails.
  This is a failure shield, not a new classification result. No further
  fixed-word necessity campaign is justified.

## 29 October, breadth pivot and ancestry obstruction

- Reviewed the October25 exact low-even evaluator and October24 actual
  same-end interpolation extension. The latter already normalizes an
  arbitrary middle subword between available same-end actual pyramids;
  boundary access and paired endpoint compatibility remain the target.
- Rejected using the spatial row-defect conjecture as the main closure
  route absent a causal, per-day physical replacement theorem.
- New literal full-origin boundary test: 6×6,k4, seven-hole own-corner
  triangle minus both tips takes seven updates, while a same-corner
  seven-hole transverse pyramid takes five. Exact arrival and earliest
  containment both separate. Two independent transition implementations
  agree on every image state's distance.
- Root correctly requested containment verification. Superset-min audit
  confirmed it. Exact clock-four overlap capacity in the slow target's
  shadow is five although the mass maximum is six. All 24 max-mass
  states hit the preferred board-corner pair omitted by that shadow.
- Induced Young-subboard relaxation fails badly (10 versus5 target
  holes at clock4), so exterior shadow demand cannot be discarded.
- Derived and saved the uniform static component stability lemma:
  σ=b+e<2b in the central collar gives at most one component above L,
  satellites <=e² if it exists; otherwise an exact square-root bound
  on satellite mass. At e0 this gives <=1 satellite cell. No temporal
  persistence, connected-neck exclusion, or new capture bound claimed.
- Extended the same component lemma to both even-area parity families;
  phase lane independently confirmed the identical two-profile proof.
  Added the elementary capped-square corollary: all components <=L and
  e<=b-2 imply q<=L+(e+1)^2. This is consolidation within the same lemma.
- Constructive tilt pivot produced a genuine interpolation strengthening:
  full occupancy repair adds E-D cells, where E counts empty target rows
  and D counts deep target-even rows. If positive, max row length m gives
  E>=m and area<=m(W+1-2m)<=floor((W+1)^2/8). This replaces the old
  approximately W^2/4 sufficient area threshold by approximately W^2/8.
- The prior backward physical interpolation proof now works on arbitrary
  even-area aspect ratios, including W>N, at that smaller threshold.
  Phase lane independently accepted all details. A separate literal replay
  constructed3,289 admissible words, including863 transposed boards and18
  targets below the old sufficient threshold. Source and evidence are in
  `pyramid-occupancy-interpolation.md` and `pyramid_interpolation_replay.*`.
- Exact path DP for W2..40 suggests a sharper threshold near W^2/9, but no
  effort is spent simplifying or proving that expression: the sufficient
  bound already permits near-square transverse central transport.
- Limitation: occupancy matching may pay ceil(W/2) per update, so this does
  not preserve a smaller localized root's isoperimetric surplus. Nor does
  it prove reachable entry/exit endpoints or the final shared-clock join.

## 29 October, protected-cut review and uniform odd-width bracket

Independently accepted adaptive and balanced front-cut arguments, including
the corrected reverse suffix indexing and the fixed-original-seed physical
containment under moving a cut. Review saved in
`review-balanced-protected-front-cut.md`.

Derived a simpler consequence of today's uniform protected-cut theorem:
every actual gate faster than physical P(c) has duration at least P(c)-1.
At the protected cut the two scalar maxima must sum to h; one extra
forward update dominates the old maximum in BOTH labels, so physical
adjunction constructs a gate one day later. This needs no ancestor shape
classification or width threshold. Together with existing large-budget
exactness and tiny-width results it supplies a two-day bracket at EVERY
odd width, all lengths and feasible budgets. Draft submitted for independent
review in `odd-width-uniform-two-day-gap.md`. Small even widths still need
separate work before claiming a global two-day ceiling.

The full-front balanced two-inspection bridge and smaller occupancy-threshold
pyramid interpolation are preserved in their own notes. Targeted prefix/
interpolation attempts did not beat P(c) on the already-geometrically-rejected
9x10 and33x34 candidate gates; these are restricted construction diagnostics,
not lower bounds or an optimal normal form.

The initially conservative small-even statement above was superseded by
recovering the authoritative October23 final panel. It already proves a
two-day ceiling at every small even width; its only two gap-three residue
families are odd widths47 and61. The new all-odd proof therefore gives
the GLOBAL ceiling TWO. The read-only source/hash and aggregation receipt
is `retained-small-even-gap-two-audit.json`; the global corollary is in
`odd-width-uniform-two-day-gap.md`. Parent and regional reviewers accepted
the argument. No new Lean claim is attached.

A bounded coupled-terminal scalar probe found that cardinality clocks
alone do not force one of the k and half-k gates to be exact: at29x58,k17
both one-day-faster candidate gates satisfy every protected scalar cross-
sum. This is not a physical construction or counterexample to prefix
optimality. `coupled_terminal_scalar_probe.py/.json` preserves the traces.

Independently replayed the regional target-layer demand recurrence. All
saved count-vector maxima and static edges agree exactly; the apparent
first comparison mismatch was only tuples versus JSON lists. The physical
necessity and separable directed-distance transform check. This diagnostic
detects the old6x6 tip-deleted target creation obstruction, but its static
tables are still exhaustive and no efficient uniform closure is claimed.

Independently accepted both quadratic-budget tail branches and replayed
all924 exact rational signatures. The detailed review is
`review-quadratic-tail-assembly.md`. The genuine reverse index, strict
half-quota rounding, index-zero age exception, and all front/lens constants
were checked; acceptance retains the cited actual-history interfaces.

## 29 October, later bridge/interface round

- Independent review accepted root quadratic-tail assembly and exact certificate;
  accepted the even genuine-middle span bound. The associated longitudinal
  switch barriers were recovered from October25, so are NOT counted as new
  coverage. Review files preserve this distinction.
- Extended `full-front-balanced-bridge.md`: selected maximum-matching symmetric
  difference gives nonunit SCC width bounded by augmenting wall paths. With at
  most one root per wall, a chain profile exactly determines matching-tight
  balanced covers. Root independently accepted this extension.
- Proved one-spare-shot theorem for positive side quotas and at most one root
  per wall. Literal independent subset audit: 1,200 endpoint pairs,144,410
  left subsets,2,922 positive-quota splits, no disagreement.
- Central canonical pyramids on2b rows larger than(b-2)(b-1) have at most one
  exposed own-color facing-wall root; larger thanH=b(b-1) have none. This
  includes genuine critical survivor targets of areaL=(b-1)^2.
- Proved exact one-root forced-cover cone J_z. Literal predecessor-closure
  audit:11,810 pairs on eight shapes agree. Root independently accepted the
  cone and nested-ideal endpoint-selection formulas. With baseA, upperU,
  endpoint areaq>H, minimize matching and forced-left counts simultaneously:
  m=min=max(|C\\U|,|A unionC|-q), F=min=max(|J\\U|,|A unionJ|-q).
  This supplies exact two-inspection selection inside a certified arrival
  cone, not a full-origin normal form.
- Independently accepted phase's actual raw-corner→pyramid entrance and
  regional's whole arrival-cone proof. The direct ordinary-prefix variant
  avoids the entrance update because genuine anchored prefixes are already
  slope-one pyramids. Regional is attaching it to the Q,Y,tau family.
- Independently accepted root's boundary-aware column trajectory packing;
  no sufficiency claim. Independently accepted regional sensitive-ancestor
  demand closure conditional on its cited raw localization theorem.
- Bounded medium-band diagnostic:64×64,k72,c36 has prefixgate42, scalar gate41.
  Twenty genuine head/tail two-inspection splices at candidate41 all fail
  total matching capacity (minimum148>144). This does not refute endpoint
  flexibility or classify unrestricted strategies; it rules out an automatic
  two-update replacement of those actual prefix endpoints.
- No public files, manuscript, Lean source, or git commits changed. Ordinary
  proof reviews and finite literal checks remain separate evidence tiers.

## 29 October, 14:38 UTC: necessary certificate round

- Added `robust-paired-edge-packing.md`: an explicit matching or time-disjoint
  path family, endpoint interval constraints, and exact endpoint masses give
  a sharp endpoint-deletion lower bound within that relaxation. The audit
  checks 2,500 interval instances and 4,811 endpoint choices. No sufficiency
  or uniform deadline rejection follows from this alone.
- Independently accepted the regional ancestral-corner Boolean certificate,
  its same-end path packing, and the genuine backward sensitive-seed interface.
  `review-ancestral-corner-certificate.md` records physical day, quota, excess,
  variable-sharing, and activation-branch checks.
- Independently accepted the phase raw-corner transport obstruction and its
  one-longer-board antipodal-label consequence in the stated guarded range.
  This restricts genuine endpoint labels; it does not supply ordinary prefix
  arrival optimality or a complete capture-time classification.

## 29 October,15:28UTC: actual boundary shapes change the upper bound

- The genuine own-coordinate and endpoint-leader parity filters remove false
  antipodal creator alternatives. Every surviving excess token has a unique
  creator mass per clock; token order implies strictly increasing birth clocks.
  The necessary all-token graph retains shared seed variables, all physical
  corner choices, and every reverse activation branch.
- `ancestral_gate_certificate_probe.py` rejects the entire723-update gate for
  128x128,k66,c66 (one cut, lens105 versus defect2), and86 for64x65,k48,c24.
  These are complete necessary certificates for those deadlines, not failures
  of a chosen strategy.
- The first surviving64x93,k48,c24 case was SOLVED BY A BETTER UPPER WORD.
  Head41 + cone60 + bridge2 + tail39 gives142 updates versus prefix143.
  Every full-uncertainty update is independently replayed in
  `long_middle_gate_literal_replay.py/.json`; solo24 permits a285-day full
  reflection palindrome. The separate all-cut lower bound matches285.
  Thus T_48(64,93)=285, and universal ordinary-prefix optimality is false.
- Earlier entrance matters:96x97,k50,c50 has a516-update actual gate versus
  prefix517. Use head211 rather than pronic head234; its full root47 triangle
  erodes to one cell during92 cone updates. Bridge2 + tail211 ends at42.
  `earlier_head_96x97_gate_literal_replay.json` replays every shot. No full
  capture equality is inferred, since the reflection center would need84>50.
- Prescribed170 structural tests:165 rejected by lower certificates,5 supplied
  a shorter actual upper construction,0 unresolved. The subsequent seeded
  adversarial diagnostic stopped at264 cases:258 rejected,5 constructed,
  one unresolved. It included g up to7 and positive shared deficits/credit.
  These bounded counts are evidence only, not an all-parameter theorem.
- The latter survivor102x124,k72,c36 has three scalar cuts with g2. Standard
  head/tail prefixes, cone+bridge, direct whole-middle interpolation and a
  flexible first-tail inspection all fail over the tested1,085 clock pairs.
  The obstruction is actual raw-notch placement, not merely scalar clocks.
- Root's raw-layer CSP nevertheless supplied different Ferrers notches.
  Our backward neighborhood builder PHYSICALLY reached each proposed root50
  forward target by72 updates. A literal72-update tail from N(reverse target)
  reaches36. Their retained supports after61 middle moves are disjoint.
  Direct interpolation reaches a2562-cell target containing the2491-cell
  reverse seed;71 first-tail shots join the words. The COMPLETE206-update
  solo gate and413-day full capture are in `raw_notch_gate_102_replay.py/.json`.
  Independent phase replay and all-cut lower arithmetic accept
  T_72(102,124)=413, improving the old prefix-derived414 upper bound.
- The general direct interpolation and flexible-tail criterion is owned by
  `../phase/direct-pyramid-middle-transfer.md`. It exactly decides transfer
  between the specified canonical endpoints under actual central drift and
  regularity hypotheses. It does not normalize arbitrary optimal histories.
- Raw-layer CSP audit accepted the staircase and same-history constraints;
  flagged that the Y2562 row's eta1 had been strengthened to eta0. It was
  feasible even under the stronger constraint, so no false exclusion resulted.
  No infeasibility or sufficiency is claimed for that relaxation.
- The next uniform target is paired RAW-profile selection with true boundary
  arrival/tail clocks. Neither free raw packing nor fixed prefix endpoints
  suffice. Existing achievements are ordinary proofs, reviewed interfaces,
  and literal finite words; NO new Lean/public/manuscript claim is made.

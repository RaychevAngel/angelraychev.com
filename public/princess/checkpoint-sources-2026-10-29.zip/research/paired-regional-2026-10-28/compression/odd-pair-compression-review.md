# Independent review: opposite odd-fiber compression

29 October 2026 UTC. Ordinary mathematical review, no Lean claim.

Let G=H square P_(2q+1). Partition each H-fiber into its two path-parity classes, each indexed in increasing path coordinate. Let C_L and C_R sort each class to its left and right endpoints, respectively. The prior odd-cylinder proof establishes that each is monotone, cardinality preserving, idempotent, and satisfies N(C(S)) subset C(N(S)). The right version follows by reflection, which preserves path parity because length is odd.

For any physical prefix of length a, starting at the full board, the standard simulation gives a same-length, no-larger-daily-budget prefix with actual endpoint F' subset C_L(F), and F' fixed by C_L. Independently transform a second prefix of length b using C_R, obtaining R' subset C_R(R). Each fiber class U has

    |C_L(F) intersect C_R(R) intersect U|
      = max(0, |F intersect U|+|R intersect U|-|U|)
      <= |F intersect R intersect U|.

Therefore |F' intersect R'|<=|F intersect R|. Every feasible physical splice is replaced by a feasible splice at exactly the same clocks, with the two endpoints oppositely ordered in every fiber class. No equal-cardinality assumption on F' relative to F is needed; shrinkage strengthens the conclusion.

For actual ordered endpoints F',R', their intersection is EXACTLY the sum of the displayed max expression using their own row/path-parity counts. The odd-cylinder vector neighborhood and inspection-cost recurrence is physical, so together with opposite ordering this is an exact pair recurrence, rather than a regional lower relaxation.

Boundary audit: source-even capacity q+1 maps a-prefix to min(a,q); source-odd capacity q maps nonempty a-prefix to a+1, with zero mapping to zero. Full source-even class correctly maps q+1 to q. Empty classes are preserved. The two path-parity directions exchange after movement, and transverse neighbors contribute to the same output fiber parity, yielding maxima. Reflection preserves these rules.

Scope: arbitrary H (not necessarily bipartite), arbitrary fixed prefix lengths, arbitrary prescribed daily budgets separately for each prefix, and all widths when the chosen path length is odd. This does not establish a smaller scalar gap or a polynomial evaluator with both side lengths variable. The existing vector family has (n+1)^(2|V(H)|) scale.

Even lengths: this proof fails, not merely at an omitted boundary detail. On P4, the right endpoint singleton {3} has one neighbor. Left-compressing its odd-parity class produces {1}, with two neighbors. The prior even-path rigidity result rules out every nontrivial static parity-preserving operator with these strong hypotheses.

Verdict: accepted as a valid paired consequence of the prior odd-cylinder operator theorem. It must be credited as such, not presented as a newly discovered single-history compression theorem.

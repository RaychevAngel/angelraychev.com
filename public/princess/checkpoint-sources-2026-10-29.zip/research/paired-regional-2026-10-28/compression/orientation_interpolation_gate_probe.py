"""One physical interpolation macroedge between oriented-prefix envelopes.

The diagnostic retains actual geometry and both prefix boundary clocks.
Failure supplies no lower bound. No exhaustive shape search is performed.
"""
from pathlib import Path
from functools import lru_cache
import json
from oriented_prefix_gate_probe import PrefixGame
from pyramid_interpolation_replay import pred,area

def hoodheight(a,W,N,p):
    out=[]
    for i,h in enumerate(a):
        empty=(1-p-i)%2-2;top=N-1-((N-1-(1-p-i)%2)%2)
        vals=[empty]
        if h>=0:vals.append(min(top,h+1))
        vals.extend(a[j]for j in (i-1,i+1)if 0<=j<W and a[j]>=0)
        out.append(max(vals))
    return tuple(out)

def run(w,n,k,c,T):
    G=PrefixGame(w,n);h=w*n//2
    # cap[r][p][i]: largest oriented prefix admitted by r more envelope updates.
    cap=[[[c]*8 for p in (0,1)]]
    for r in range(1,T+1):
        layer=[]
        for p in (0,1):
            survivors=[]
            for j in range(8):
                lo=0;hi=h
                while lo<hi:
                    mid=(lo+hi+1)//2
                    if G.hood[j][p][mid]<=cap[-1][1-p][j]:lo=mid
                    else:hi=mid-1
                survivors.append(G.prefix[j][p][lo])
            row=[]
            for i in range(8):
                best=0
                for S in survivors:
                    lo=0;hi=h
                    while lo<hi:
                        mid=(lo+hi+1)//2
                        if (G.prefix[i][p][mid]&~S).bit_count()<=k:lo=mid
                        else:hi=mid-1
                    best=max(best,lo)
                row.append(best)
            layer.append(row)
        cap.append(layer)

    @lru_cache(None)
    def canonical(o,p,q,axis,end):
        W,N=(w,n)if axis==0 else(n,w);phase=p^(end*((N-1)%2))
        a=[(phase-i)%2-2 for i in range(W)];S=G.prefix[o][p][q];code=S
        while code:
            bit=code&-code;code-=bit;x,y=G.coords[bit.bit_length()-1]
            u,v=(x,y)if axis==0 else(y,x)
            if end:v=N-1-v
            a[u]=max(a[u],v)
        if any(abs(x-y)!=1 for x,y in zip(a,a[1:])):return None
        if area(a,N,phase)!=q:return None
        return tuple(a)

    forwards=G.run(k,c,T)['results'];hits=[];checked=0;newarea=0;best=None
    for fwd in forwards:
        p0=fwd['p0'];layers=fwd['layers']
        for e in range(T):
            p=(p0+e)%2
            for i,q0 in enumerate(layers[e]):
                if q0>h:continue
                for axis in (0,1):
                    W,N=(w,n)if axis==0 else(n,w);d=k-(W+1)//2;threshold=(W+1)**2//8
                    if d<0:continue
                    for side in (0,1):
                        a=canonical(i,p,q0,axis,side)
                        if a is None:continue
                        U=a;phase=p^(side*((N-1)%2))
                        for end in range(e+1,T+1):
                            U=hoodheight(U,W,N,phase);phase^=1
                            pe=(p0+end)%2;rem=T-end
                            for j,qcap in enumerate(cap[rem][pe]):
                                b=canonical(j,pe,qcap,axis,side)
                                if b is None:continue
                                b=hoodheight(pred(b,phase),W,N,1-phase)
                                q1=area(b,N,phase)
                                if not q0>=q1>threshold:continue
                                checked+=1;ms=q1+d*(end-e)-q0;gs=min(y-x for x,y in zip(b,U))
                                row=dict(p0=p0,entry=e,end=end,axis=axis,side=side,source_orientation=i,target_orientation=j,
                                         q0=q0,q1=q1,target_capacity=qcap,mass_slack=ms,geometry_slack=gs)
                                if best is None or(min(ms,gs),ms+gs)>(min(best['mass_slack'],best['geometry_slack']),best['mass_slack']+best['geometry_slack']):best=row
                                if ms>=0 and gs>=0:
                                    if len(hits)<10:hits.append(row)
                                    newarea+=W%2==0 and q1<=(W//2-1)**2
    return dict(shape=[w,n],budget=k,terminal=c,updates=T,checked=checked,hits=hits,newarea_hits=newarea,best=best,
                scope='One proved same-axis interpolation macroedge, either board axis, with literal oriented-prefix envelope access and exit. Failure gives no lower bound.')

if __name__=='__main__':
    out=[run(*args)for args in ((9,10,7,3,13),(33,34,25,25,44))]
    Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out))

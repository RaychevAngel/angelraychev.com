"""Bounded exact pyramid transport test of prescribed descending flip order."""
from pathlib import Path
import json
import time


def run(w,n,horizon=5):
    cells=[[(x,y) for x in range(w) for y in range(n) if (x+y)%2==p] for p in (0,1)]
    indexes=[{v:i for i,v in enumerate(c)} for c in cells]
    adj=[]
    for p in (0,1):
        adj.append([sum(1<<indexes[1-p][z] for z in ((x-1,y),(x+1,y),(x,y-1),(x,y+1)) if z in indexes[1-p]) for x,y in cells[p]])
    def N(mask,p):
        out=0
        while mask:
            bit=mask&-mask;mask^=bit;out|=adj[p][bit.bit_length()-1]
        return out
    profiles=[{},{}]
    for p in (0,1):
        def visit(a):
            if len(a)==w:
                mask=sum(1<<i for i,(x,y) in enumerate(cells[p]) if y<=a[x]);profiles[p][mask]=a;return
            if not a:
                for h in range(-2,n):
                    if (h-p)%2==0:visit([h])
            else:
                for h in (a[-1]-1,a[-1]+1):
                    if -2<=h<n:visit(a+[h])
        visit([])
    transitions={}
    for k in range(w//2+1,w+1):
      for p in (0,1):
       for mask in profiles[p]:
        transitions[k,p,mask]={N(s,p) for s in profiles[p] if not(s&~mask) and (mask^s).bit_count()<=k}
    checked=0;counter=[];classes={};class_examples={}
    for k in range(w//2+1,w+1):
      for p in (0,1):
       for A,a in profiles[p].items():
        reach={A}
        for t in range(1,horizon+1):
            phase=(p+t-1)%2
            reach={z for r in reach for z in transitions[k,phase,r]}
            for B,b in profiles[1-phase].items():
                checked+=1
                actual=any(not(z&~B) for z in reach)
                flips=sum(max(0,(x-y+t)//2) for x,y in zip(a,b))
                credit=sum(y<0 and (p+t-x)%2==0 for x,y in enumerate(b))
                proposed=flips<=k*t+credit
                if proposed:assert actual,(w,n,p,k,A,B,t,a,b)
                if actual and not proposed:
                    key=str((all(x>=0 for x in a), B.bit_count()>(w//2-1)**2, A.bit_count()>=B.bit_count()))
                    classes[key]=classes.get(key,0)+1
                    example=dict(w=w,n=n,p=p,k=k,t=t,source=A,target=B,
                         source_heights=a,target_heights=b,source_size=A.bit_count(),target_size=B.bit_count(),
                         virtual_flips=flips,root_credit=credit,source_full_fibers=all(x>=0 for x in a))
                    class_examples.setdefault(key,example)
                    if len(counter)<3:counter.append(example)
    return dict(shape=[w,n],profiles=list(map(len,profiles)),comparisons=checked,counterexamples=counter,classes=classes,class_examples=class_examples)


if __name__=='__main__':
    start=time.process_time();results=[run(4,6),run(6,6,4)]
    out=dict(results=results,CPU_seconds=time.process_time()-start,
             scope='Exact restricted physical pyramid history; existence of a fixed-word counter disproves fixed-word necessity, never unrestricted optimality.')
    Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out))

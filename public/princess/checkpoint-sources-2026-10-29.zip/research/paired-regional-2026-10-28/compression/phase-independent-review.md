# Independent review of the high-budget phase and common-cut candidates

29 October 2026. Reviewer: compression lane. Ordinary mathematical review;
not Lean verification, and not a new capture-time classification.

Reviewed sources:
- `../phase/high-budget-phase-continuation.md`;
- `../phase/high-budget-common-cut-overlap.md`;
- the October 24 critical classification, capped continuation, first-quota
  interface, localized-erosion-defect, whole-front and mixed-overlap lemmas.

## Matched-phase continuation

I find the stated argument sound conditional on the cited physical
classification and erosion lemmas. Its scope is odd width `2b+1`, even
length, `b>=512`, **all** `k>=3b`, every first quota `0<=c<=k`, and only
histories whose hole counts remain strictly below `U`. This is not a late
terminal theorem.

The arbitrary first quota is correctly capped in this theorem. If the
initial count exceeds the smaller coordinate, the coordinate gap is one.
The exact incoming-cost equality forces an actual own-phase support,
including an own critical front when the seed is large. Thus the initial
occupied origin is justified; no radius-positive core is needed there.

The immediate changed-identity charge is valid. For a changed cohort the
old origin has the wrong color for the new dominant neighborhood. For an
opposite longitudinal end, a localized neighborhood has radius at most
`2b-1`, whereas the old corner is at distance at least `n-1>=2b+1`.
A full front misses the far opposite-colored corner. A possible singleton
outlier is at a board corner, and no board corner is adjacent to another
board corner (or itself). This handles simultaneous cohort/end changes
as well; retaining extra same-phase transitions only weakens necessity.

The core-persistence barrier uses two retained old-cohort cells, not one.
Consequently the rigid triangle-plus-singleton alternative cannot evade
it. Short-axis corner changes at the same longitudinal end preserve the
numerical phase and are correctly permitted.

The global span calculation has enough slack. The first stage uses
`floor(H/A)+1` steps, so its minimum is **strictly** greater than `H`.
This justifies a strict crossing above `b^2` after the subsequent ceiling
count, even at a divisibility endpoint. The affine phase alternation is
safe once both inputs exceed `b^2`. The resulting
`2E<=19b/40+65/12<b/2-5` holds at `b=512` and thereafter.

The critical-front core bound follows from
`(b^2-3b+4)/(4b+2)>b/4-1`. For subcritical roots the endpoint inequality
`2r-5-4sqrt(r)>=r/2+2` is already positive at `r=15` and increases.
Roots at most 14 are excluded by the positive genuine index and the
minimum increment `2b-1`. The root-by-root singleton exception has a
larger core, so it does not invalidate this comparison.

## Conditional common-cut overlap

I find the algebra and its use of retained supports sound, under the
explicit common-cut and actual-last-good-history premises. This does
**not** construct the needed cut or a reverse history. Scope is
`b>=512`, `3b<=k<=4b`, with both actual endpoint sizes at least
`b^2-5b` and allowed-set excess at most `E`.

Details independently checked:

1. A dangerous bad suffix of age `a` obeys `a<=2e_u-1<=u+1`.
   The scalar bound `Q<=r^2+a(k-r-1)` remains valid even if the actual
   count retreats: dominate it by the monotone bad-map orbit from the
   seed. That dominating orbit is nondecreasing, so its root never falls
   below `r`. The manuscript should make this one-line justification
   explicit when polishing.
2. The exclusion of `r<=b/2` uses only `b>36`. After obtaining `r>b/2`,
   the estimate `3r^2/(k-r-4)+(k-r-1)<=5b+4` is safe: bound the first
   term by `3b^2/(2b-4)<=3b/2+4` and the second by `<7b/2-1`.
3. The endpoint-size estimate gives `r^2>b^2/2-5b-2>49b^2/100` for
   `b>=512`. For `r>=7b/10`, the retained-radius expression is
   increasing. Substitution at `7b/10` exceeds `7b/6-6`: clearing the
   positive denominator leaves `14b^2+410b-1200>0`.
4. The retained-front estimate expands to at least
   `21b^2/40-10b-2`, with conservative rounding.
5. The two-triangle overlap inequality reduces to
   `b^2/72-5b+10>0`. The two-front inequality reduces to
   `b^2/40-43b/4-2>0`. Both hold at 512 and increase thereafter.
6. The mixed-front calculation has the stated coefficients. Its final
   sufficient margin is `109b^2/720-1877b/120-10`, positive at 512
   and increasing thereafter. Also `sqrt(18b+4)<=b/5` holds there and
   thereafter. The first mixed-overlap condition has much larger slack.
7. The raw localized defect is legitimately preserved by the cited
   literal diagonal-interval erosion lemma. It must remain attached to
   the original ancestor; replacing it by a current cardinality deficit
   would not be justified.

## Separate draft issue found

`../phase/phase-core-automaton.md` and the diagnostic's initial seed still
used the **uncapped** first-quota values `c-rho(c)` and `c-ceil_sqrt(c)` at
review time. This does not cover arbitrary large first quotas. For example
once `c>b(b+1)`, an own critical front can attain `c-b`, beyond that seed.
The high-budget theorem reviewed above already fixes this correctly.
The phase author was notified to update the diagnostic/draft or narrow
its seed scope; the sampled small-quota receipts are not evidence for
large first quotas.

No flaw was found in the two reviewed theorem candidates beyond that
separate diagnostic initialization mismatch. Their stated physical and
common-cut premises remain essential and unresolved in the complete game.

## Addendum: two-b continuation

Also reviewed `../phase/two-b-phase-continuation.md`. Its two-slab travel
estimate, interior critical core, arbitrary first-quota charge and actual
induction are sound. In its subcritical display, the comparison
`r+2>r^2/(b-1)+2` should be nonstrict when r=b-1; the preceding strict
inequality `2e<r^2/(b-1)+2` makes the desired conclusion unchanged.
All other endpoint and small-root constants check directly.

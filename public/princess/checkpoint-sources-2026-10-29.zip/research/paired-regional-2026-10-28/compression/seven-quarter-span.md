# A bounded-integral phase-span estimate from k >= 7b/4

29 October 2026. New ordinary numerical lemma for independent review.
It contains no physical assertion by itself. The integral is a proof
instrument; its conclusion is an elementary numerical inequality.

Let b>=512 and k>=ceil(7b/4). For every first quota 0<=c<=k define

    F(x)=x+k-min(ceil_sqrt(x+k),b+1),
    G(x)=x+k-min(rho(x+k),b),
    W_0=(c-min(rho(c),b), c-min(ceil_sqrt(c),b+1)),
    W_(j+1)=(G(W_j[1]),F(W_j[0])).

Here rho(z) is the least nonnegative integer r with z<=r(r+1). Then

    2 sup_j |W_j[0]-W_j[1]| <= 39b/40+7 < b-5.       (S1)

This is uniform over all first quotas and arbitrarily large k. It uses
no discrepancy estimate or width-by-width certificate.

## 1. Reduce span to the minimum's travel time

The maps are increasing and 1-Lipschitz, F<=G<=F+1, and every increment
is positive in this budget range. The seed gap is zero or one. The usual
oriented-gap induction gives

    |W_j[0]-W_j[1]| <= ceil((j+1)/2).

Let x_j=min W_j, and let tau be its first index above b^2. Once x_tau>b^2,
both capped maps are affine: their increments are k-b and k-b-1.
The signed gap thereafter alternates D,1-D. Hence its global absolute
maximum E occurs by index tau+1, and

    2E <= tau+3.                                      (S2)

If x_0>b^2, the affine orbit has E<=1 directly.

For x_j<=b^2, monotonicity gives x_(j+1)>=F(x_j), and therefore

    x_(j+1)-x_j >= k-sqrt(x_j+k)-1.

The right side increases with k. Put k0=7b/4, K=k0-1 and

    a(x)=k0-sqrt(x+k0)-1=K-sqrt(x+k0).

It is positive and decreasing on [0,b^2], so 1/a is increasing. On each
complete step whose endpoint remains at most b^2,

    integral_[x_j,x_(j+1)] dx/a(x)
        >= (x_(j+1)-x_j)/a(x_j) >=1.

Summing the tau-1 complete steps before the crossing yields

    tau <= 1 + I,
    I = integral_0^(b^2) dx/[K-sqrt(x+k0)].            (S3)

This argument retains the genuine first quota: x_0>=0 merely reduces the
remaining integration interval. There is no artificial restart or phase
reset. The strict crossing causes no rounding problem: the final crossing
step is precisely the single extra step in (S3).

## 2. An explicit rational upper bound for the integral

Put R=b+1. Since b^2+k0<=R^2 and K>R,

    I <= integral_0^(R^2) dv/[K-sqrt(v)]
          - integral_0^(k0) dv/[K-sqrt(v)]
      <= 2K log(K/(K-R))-2R-k0/K.                     (S4)

The antiderivative follows by v=r^2. Also

    K/(K-R) = (7/3)*(1-4/(7b))/(1-8/(3b)).

The elementary bounds log(1-u)<=-u and -log(1-u)<=u/(1-u), together with
b>=512, give

    log(K/(K-R))
      < 17/20 + (512/191-4/7)/b
       =17/20 + 2820/(1337b).                        (S5)

Here log(7/3)<17/20 follows already from the first five nonnegative terms
of exp(17/20): their sum exceeds 7/3 by 7761/3840000.
Retain the exact factor 2K=7b/2-2 when expanding the 17/20 term.
For the additional 2820/(1337b) term, drop only the negative correction
-5640/(1337b). Also k0/K>1. Thus (S4)-(S5) imply

    I < 39b/40 + 9870/1337 - 47/10
      = 39b/40 + 35861/13370
      < 39b/40 + 3.                                  (S6)

Combining (S2),(S3),(S6) proves 2E<39b/40+7. For b>=512,

    b-5-(39b/40+7)=b/40-12 >=4/5>0,

which proves (S1).

## What this supplies

The reviewed interior-front lemma gives every critical full front an
ACTUAL retained core of integer radius at least b-4. Thus its available
R-1 is at least b-5, larger than 2E in (S1). The same comparison handles
the larger localized critical cores. This closes the critical phase-mixing
input uniformly from k>=7b/4.

A full matched-phase continuation theorem must still verify its
subcritical good events, actual sensitive seed and any shifted-start
interfaces. The all-budget rectangle capture question and common-cut
geometry are not settled by this numerical lemma. Budgets below 7b/4
retain their separate numerical/physical obligations.

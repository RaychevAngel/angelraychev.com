"""Uniform exact static overlap; independently enumerate literal down-ideals."""
from pathlib import Path
import json
import time


def profile(w,n,p,R):
    assert 2<=w<=n and 0<=R<w and R%2==p
    C=sum((R-x+2)//2 for x in range(R+1))
    H=min(n-1,R+w-3)
    def area(a):return (a+2)//2
    def overlap(x,a):return min(area(a),(R-x+2)//2) if x<=R else 0
    states={}
    for a in range(-2,H+1):
        if (a-p)%2:continue
        i=overlap(0,a)
        if i<C:states[a,i]=area(a)
    for x in range(1,w):
        nxt={}
        for (a,i),q in states.items():
            for v in (a-1,a+1):
                if not -2<=v<=H:continue
                j=i+overlap(x,v)
                if j<C:
                    nxt[v,j]=max(nxt.get((v,j),-1),q+area(v))
        states=nxt
    M=[-1]*(C+1)
    for (a,i),q in states.items():M[i]=max(M[i],q)
    for i in range(1,C):M[i]=max(M[i],M[i-1])
    M[C]=(w*n+1-p)//2
    return M


def literal(w,n,p,R):
    cells={(x,y) for x in range(w) for y in range(n) if (x+y)%2==p}
    triangle={v for v in cells if sum(v)<=R}
    J=[len(triangle)+1]*(len(cells)+1)
    count=0
    def visit(path):
        nonlocal count
        if len(path)==w:
            F={(x,y) for x,y in cells if y<=path[x]}
            assert all(z in F for x,y in F if y>0 for z in ((x-1,y-1),(x+1,y-1)) if z in cells)
            J[len(F)]=min(J[len(F)],len(F&triangle));count+=1
            return
        if not path:
            for a in range(-2,n):
                if (a-p)%2==0:visit([a])
        else:
            for a in (path[-1]-1,path[-1]+1):
                if -2<=a<n:visit(path+[a])
    visit([])
    return J,count


if __name__=='__main__':
    start=time.process_time();cases=paths=0
    for w in range(2,11):
      for n in (w,w+1,2*w+1):
       for p in (0,1):
        for R in range(p,w,2):
            M=profile(w,n,p,R)
            J,count=literal(w,n,p,R)
            expected=[next(d for d,qmax in enumerate(M) if qmax>=q) for q in range(len(J))]
            assert J==expected,(w,n,p,R,J,expected)
            cases+=1;paths+=count
    out=dict(status='PASS',cases=cases,literal_pyramid_paths=paths,
             CPU_seconds=time.process_time()-start,
             scope='Every exact cardinality, both colors, all radii R<w, even and odd widths and lengths in the stated sample. Static overlap only.')
    Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out))

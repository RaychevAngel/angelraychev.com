# Exact component stability in either even-area central collar

29 October 2026. Ordinary lemma; independent review requested. This is a
static component statement, not a phase-persistence or temporal-credit theorem.

Let S lie in one physical checkerboard color of either of these boards:

- even width `2b × n`, `n>=2b`, with `h=bn` and `U=h-b(b-1)`;
- odd width `2b+1 × n`, even `n>=2b+1`, with `h=(2b+1)n/2` and
  `U=h-b(b+1)`.

Put

```
L=(b-1)^2, q=|S|,
L<q<U, |N(S)|-|S|=b+e=:s, 0<=e<b.
```

The accepted rectangle isoperimetric bound supplies:

- for `0<|A|<=L`, `|N(A)|-|A| >= ceil(sqrt(|A|))`;
- for `L<|A|<U`, `|N(A)|-|A| >= b`.

Only these two bounds are used below. The even-width case allows either
parity of n. The argument is an abstract consequence of these bounds and
therefore applies unchanged to the stated odd-width collar.

Join two cells of S when they share a physical neighbor. Let `S_i` be
the connected components of this two-step graph, with `q_i=|S_i|` and
`s_i=|N(S_i)|-|S_i|`. Neighborhoods of distinct components are disjoint,
so

```
s=sum_i s_i,   q=sum_i q_i.
```

1. At most one component has more than L cells. If it exists, all other
   components together have at most `e^2` cells.
2. Suppose no component has more than L cells, and `2q>s^2`.
   There is a unique component of size greater than q/2. If z denotes
   the total size of all other components, then

```
0<=z<= [q-s*sqrt(2q-s^2)]/2.                         (1)
```

In particular, if e=0 and b>=3, at most one cell lies outside the largest
component. If a component has more than L cells, there are no satellites;
otherwise the right side of (1) is at most one.

There is also a useful threshold version. If `e<=b-2` and all components
have size at most L, then

```
q <= L+(e+1)^2.                                    (2)
```

Consequently, if `q>=b^2-b` and `(e+1)^2<b-1`, a component with more than
L cells must exist and its satellites have total size at most `e^2`.

## Proof

Every component with size greater than L has surplus at least b,
because its size is at most q<U. Two such components would contradict
`s<2b`. If one exists, the others have total surplus at most e, and each
small component satisfies `q_i<=s_i^2`. Consequently

```
sum_(small i) q_i <= sum_(small i) s_i^2
                  <= (sum_(small i) s_i)^2 <= e^2.
```

If all components are small, `sum_i sqrt(q_i)<=s`. Writing Q for the
largest q_i gives

```
q=sum_i sqrt(q_i)*sqrt(q_i) <= sqrt(Q)*s.
```

Thus `Q>=q^2/s^2>q/2`. Put z=q-Q. Since the square roots of the satellite
sizes sum to at least sqrt(z),

```
s>=sqrt(q-z)+sqrt(z),
2sqrt(z(q-z))<=s^2-q.
```

The right side is nonnegative since `q<=sum_i s_i^2<=s^2`.
Squaring and selecting the branch `0<=z<q/2` yields (1).

For e=0, q is at least `(b-1)^2+1`, and the expression in (1) is
nonincreasing for q in this range up to b². At its left endpoint it is

```
[((b-1)^2+1)-b*(b-2)]/2 = 1.
```

For (2), set `a_i=min(s_i,b-1)`. Then `q_i<=a_i^2`,
`0<=a_i<=b-1`, and `sum_i a_i<=b+e<=2(b-1)`. Under this sum and cap,
convexity maximizes `sum_i a_i^2` by filling one entry to `b-1` before
filling a second. Its value is at most `(b-1)^2+(e+1)^2`. The final
consequence follows because `b^2-b-L=b-1`.

## Exact limitation

This identifies a dominant **connected component**. It does not identify
its corner or longitudinal end, and it does not rule out a narrow neck
inside that component. An actual full front may change axis at zero
surplus excess; any stronger label-stability statement must preserve
those valid tilt transitions. Nor does the bound turn disconnected
satellite mass into usable earlier inspection credit.

The potentially useful next statement is a relative-perimeter stability
result inside the dominant component: after permitting actual front
axis changes, a neck or detour connecting incompatible boundary bodies
should carry a quantitatively charged excess. That statement is open.

Independent ordinary review: root and the phase lane accepted the
algebra and strict guards. The phase lane identified the odd-width
instance as the same lemma, now included above. This is not Lean coverage.

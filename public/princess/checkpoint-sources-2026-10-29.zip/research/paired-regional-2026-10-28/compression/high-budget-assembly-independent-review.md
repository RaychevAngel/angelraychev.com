# Independent review of the high-budget exact-gate assembly

29 October 2026. Ordinary review of
`../phase/high-budget-exact-gate-assembly.md`, including its first-co-small
source and the older same-cut actual-set ledger. No Lean verification.

I find the theorem candidate sound in its stated range:
odd width 2b+1, even n>=w, b>=512, and
3b<=k<=floor(15b/4), every terminal gate 0<=c<=k.

The new direct co-small marker is valid. The original solo survivor S0
has surplus exactly b and size between b(b-1)+2 and b^2, excluding both
opposite localization and the rigid singleton alternative. If localized,
N(S0) lies within radius 2b-1 of its own corner. The diagonally opposite
corner has the new holes' color and is at distance at least4b+1; hence
its entire radius2b own triangle is actually in H. For a literal full
front, N(S0) has majority lengths a_i and minority lengths a_j+1.
The opposite-end complement therefore has majority ell-a_i and minority
ell-a_j-1. These obey the correct adjacent inequalities, and majority
lengths remain proper and positive. Thus H is a real full front; no
classification outside the collar was used.

The previous bad-crossing case remains covered: its original surplus is
at least b+1, so the final update obeys the same bad map and actual erosion
persistence. No new good event outside the collar is silently inserted.
All earlier updates are inside the collar because the numerical cut is
the first minimum above b^2.

The same-cut indexing and physical color alignment match the prior ledger.
Dangerous late signed mass excludes an already permanently mixed suffix,
since that suffix has the stronger MIN V comparison. Thus the actual cut
is solo, its holes and the reversed allowed erosion belong to the same
physical cohort, and their matching phases determine the same end. The
reverse maximum below Z makes its shifted erosion bound unclipped. The
single deficit allowance includes eta; no independent slack is spent twice.

The lower size bound for J is safely above b^2-5b throughout the claimed
budget range. The direct co-small support is stronger than each support
used in the common-cut overlap calculation. When invoking the mixed
front/triangle lemma, whose radius is required to be at most2b-1, use the
radius2b-2 subtriangle of the larger radius2b marker. Its zero defect still
gives strictly more than the required overlap. This and the explicit solo
sentence were sent to the author as clarifications and incorporated.

Conclusion: the assembly passes independent ordinary review under its
listed reviewed dependencies. It gives a new exact parameter family,
not a universal capture-time closure or a fixed-size numerical expression.

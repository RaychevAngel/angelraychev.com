"""Bounded attack on four odd-subboard counts as a complete continuation state.

Square pyramid transitions are unrestricted-exact by the old square compression
 theorem; this does not assert an unequal-rectangle normal form.
"""
import sys,json
from pathlib import Path
from collections import deque,defaultdict
ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT/'src'))
from resumed_even_construction_square_audit import prepare

def run(w,n,k):
 d=prepare(w,n);masks=d['ideals'];sizes=d['sizes'];hood=d['hood'];points=d['colors']
 edges=[[],[]];reverse=[[[] for _ in row] for row in masks]
 for p in (0,1):
  for i,B in enumerate(masks[p]):
   targets={hood[p][j] for j,S in enumerate(masks[p]) if S&~B==0 and sizes[p][i]-sizes[p][j]<=k}
   edges[p].append(targets)
   for j in targets:reverse[1-p][j].append((p,i))
 rank=[[-1]*len(r) for r in masks];q=deque([(0,0),(1,0)]);rank[0][0]=rank[1][0]=0
 while q:
  p,j=q.popleft()
  for pp,i in reverse[p][j]:
   if rank[pp][i]<0:rank[pp][i]=rank[p][j]+1;q.append((pp,i))
 dist=[[-1]*len(r) for r in masks];dist[0][-1]=0;q=deque([(0,len(masks[0])-1)])
 while q:
  p,i=q.popleft()
  for j in edges[p][i]:
   if dist[1-p][j]<0:dist[1-p][j]=dist[p][i]+1;q.append((1-p,j))
 def feature(p,i):
  S={v for j,v in enumerate(points[p]) if masks[p][i]>>j&1}
  windows=tuple(sum(x!=rx and y!=ry for x,y in S) for rx in (0,w-1) for ry in (0,n-1))
  corners=tuple(int((x,y) in S) for x in (0,w-1) for y in (0,n-1))
  # Stronger signature than merely four projected masses: retain every boundary
  # fiber count and the four corner bits as well as full mass.
  sides=tuple(sum(x==v for x,y in S) for v in (0,w-1))+tuple(sum(y==v for x,y in S) for v in (0,n-1))
  return (sizes[p][i],windows,corners,sides)
 groups=defaultdict(list)
 for p in (0,1):
  for i in range(len(masks[p])):
   if dist[p][i]>=0:groups[(p,feature(p,i))].append(i)
 failures=[]
 for (p,f),inds in groups.items():
  for ia,i in enumerate(inds):
   for j in inds[ia+1:]:
    if rank[p][i]==rank[p][j]:continue
    # Padding a full initial state uses no quota, hence both are reachable at
    # the same physical-color clock, the maximum of the two shortest clocks.
    t=max(dist[p][i],dist[p][j]);assert (t-dist[p][i])%2==0 and (t-dist[p][j])%2==0
    failures.append(dict(p=p,clock=t,signature=f,A=dict(id=i,counts=[sum((masks[p][i]>>z)&1 for z,(xx,y) in enumerate(points[p]) if xx==x) for x in range(w)],heights=d['heights'][p][i],remaining=rank[p][i],arrival=dist[p][i]),B=dict(id=j,counts=[sum((masks[p][j]>>z)&1 for z,(xx,y) in enumerate(points[p]) if xx==x) for x in range(w)],heights=d['heights'][p][j],remaining=rank[p][j],arrival=dist[p][j])))
    if len(failures)>=3:break
   if len(failures)>=3:break
  if len(failures)>=3:break
 return dict(w=w,n=n,k=k,states=list(map(len,masks)),equal_feature_groups=sum(len(v)>1 for v in groups.values()),failures=failures)
if __name__=='__main__':
 out=[run(6,6,k) for k in range(4,10)]
 p=Path(__file__).with_name('odd-window-signature-6x6.json');p.write_text(json.dumps(out,indent=2)+'\n')
 for row in out:print(json.dumps(row))

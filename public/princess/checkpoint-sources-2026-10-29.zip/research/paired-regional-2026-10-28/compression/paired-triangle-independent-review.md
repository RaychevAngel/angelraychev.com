# Independent review of the paired-triangle packing lemma

29 October 2026. Ordinary independent review, not Lean verification.

Reviewed `../root/paired-triangle-packing.md`. The statement and proof pass
this review, including the asymmetric relative parities and smallest roots.

The coordinate change at the second corner is exactly
(u',v')=(B0-v,B0-u), so it reverses the product order. The lens is an upper
set in either triangle, misses both complete outer spines because both
radii are strictly below the corner distance, and has the stated triangular
cardinality. Consequently a lower ideal J in the first-coordinate lens
removes an upper ideal from each of the two triangles, with complementary
lens deficits. Every requested split exists by a linear extension.

Each spine cell (u,-u-p) is minimal in its whole triangle: any predecessor
(u',v') has v'>=-u'-p>=-u-p, forcing equality in both coordinates. Hence
maximal nonspine deletion reaches every size down to the complete spine
without changing its occupied layer count. Product-order closure gives
nonempty layer intervals; after a layer first becomes nonfull, its right
endpoint cannot increase. Their upper shadows contain all next-layer
lower shadows. The initial lower shadow has p cells and each of the r-p
occupied layers contributes one surplus cell, so the quadrant surplus
is exactly r. The second corner gives s identically.

The finite-board qualification is essential and correctly retained:
clipping a quadrant shadow may lower its surplus. The necessary lens
condition is purely set-theoretic and does not use a shadow hypothesis.
The sufficiency construction says nothing about chronological reachability,
shared daily quota, or compatibility with another prescribed endpoint.
No uniform capture-time equality follows yet.

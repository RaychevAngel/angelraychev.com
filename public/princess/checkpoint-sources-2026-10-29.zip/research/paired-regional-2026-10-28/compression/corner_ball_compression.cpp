#include <algorithm>
#include <bit>
#include <cstdint>
#include <iostream>
#include <set>
#include <utility>
#include <vector>
using namespace std;
int main(int argc,char**argv){int w=argc>1?atoi(argv[1]):4,n=argc>2?atoi(argv[2]):6;int h=w*n/2;if(w%2||h>22||w>20||n>30)return 2;
 vector<pair<int,int>>vs[2];int ix[20][30];for(int x=0;x<w;++x)for(int y=0;y<n;++y){int p=(x+y)%2;ix[x][y]=vs[p].size();vs[p].push_back({x,y});}
 vector<unsigned>N[2],I[2];for(int p=0;p<2;++p){N[p].resize(1u<<h);vector<unsigned>adj(h);for(int i=0;i<h;++i){auto[x,y]=vs[p][i];for(auto[xx,yy]:vector<pair<int,int>>{{x-1,y},{x+1,y},{x,y-1},{x,y+1}})if(xx>=0&&xx<w&&yy>=0&&yy<n)adj[i]|=1u<<ix[xx][yy];}
  for(unsigned s=1;s<N[p].size();++s){unsigned b=s&-s;N[p][s]=N[p][s^b]|adj[countr_zero(b)];}
  auto recurse=[&](auto&&self,int x,int last,unsigned mask)->void{if(x==w){I[p].push_back(mask);return;}for(int a=-2;a<n;++a)if(((a+x-p)%2+2)%2==0&&(x==0||abs(a-last)==1)){unsigned s=mask;for(int y=(p-x+100)%2;y<=a;y+=2)s|=1u<<ix[x][y];self(self,x+1,a,s);}};recurse(recurse,0,0,0);sort(I[p].begin(),I[p].end());I[p].erase(unique(I[p].begin(),I[p].end()),I[p].end());
 }
 set<pair<unsigned,unsigned>> consset[2];for(auto[x,y]:vector<pair<int,int>>{{0,0},{0,n-1},{w-1,0},{w-1,n-1}}){int p=(x+y)%2;unsigned source=1u<<ix[x][y],target=1u<<ix[p?w-1:0][0];for(int t=0;t<2*(w+n);++t){consset[p].insert({source,target});source=N[p][source];target=N[p][target];p^=1;}}
 if(argc>3)for(int p=0;p<2;++p)for(unsigned i:I[p])consset[p].insert({i,i});
 vector<pair<unsigned,unsigned>>cons[2];for(int p=0;p<2;++p)cons[p]=vector<pair<unsigned,unsigned>>(consset[p].begin(),consset[p].end());
 vector<unsigned>C[2];uint64_t empties=0;unsigned firstempty=0;int firstp=-1;uint64_t nonfixed=0;
 for(int p=0;p<2;++p){vector<vector<unsigned>>bySize(h+1);for(unsigned i:I[p])bySize[popcount(i)].push_back(i);C[p].resize(1u<<h);vector<vector<unsigned char>>vals(h+1);vector<vector<vector<unsigned char>>>limits(h+1);for(int k=0;k<=h;++k)for(unsigned i:bySize[k]){vector<unsigned char>v;for(auto[s,t]:cons[p])v.push_back(popcount(i&t));limits[k].push_back(v);}
  for(unsigned s=0;s<(1u<<h);++s){int k=popcount(s);vector<unsigned char>counts;for(auto[a,b]:cons[p])counts.push_back(popcount(s&a));bool found=false;for(int j=0;j<int(bySize[k].size());++j){bool ok=true;for(int t=0;t<int(counts.size());++t)if(limits[k][j][t]<counts[t]){ok=false;break;}if(ok){C[p][s]=bySize[k][j];found=true;break;}}if(!found){++empties;if(firstp<0){firstp=p;firstempty=s;}C[p][s]=s;}}
  for(unsigned i:I[p])nonfixed+=C[p][i]!=i;
 }
 uint64_t nf=0,mf=0,idem=0;int np=-1,mp=-1;unsigned ns=0,ms=0,mt=0,nleft=0,nright=0;
 for(int p=0;p<2;++p)for(unsigned s=0;s<(1u<<h);++s){unsigned l=N[p][C[p][s]],r=C[1-p][N[p][s]];if(l&~r){++nf;if(np<0){np=p;ns=s;nleft=l;nright=r;}}idem+=C[p][C[p][s]]!=C[p][s];for(int v=0;v<h;++v)if(!(s>>v&1)&&(C[p][s]&~C[p][s|(1u<<v)])){++mf;if(mp<0){mp=p;ms=s;mt=s|(1u<<v);}}}
 if(mp>=0)cerr<<"firstmono images "<<mp<<" "<<ms<<" -> "<<C[mp][ms]<<"; "<<mt<<" -> "<<C[mp][mt]<<endl;
 cout<<"{\"w\":"<<w<<",\"n\":"<<n<<",\"parity_subsets\":"<<(2u<<h)<<",\"pyramids\":["<<I[0].size()<<","<<I[1].size()<<"],\"constraints\":["<<cons[0].size()<<","<<cons[1].size()<<"],\"empty_domains\":"<<empties<<",\"first_empty\":["<<firstp<<","<<firstempty<<"],\"nonfixed_pyramids\":"<<nonfixed<<",\"idempotence_failures\":"<<idem<<",\"N_failures\":"<<nf<<",\"first_N_failure\":["<<np<<","<<ns<<","<<nleft<<","<<nright<<"],\"monotonicity_failures\":"<<mf<<",\"first_mono_failure\":["<<mp<<","<<ms<<","<<mt<<"]}"<<endl;
}

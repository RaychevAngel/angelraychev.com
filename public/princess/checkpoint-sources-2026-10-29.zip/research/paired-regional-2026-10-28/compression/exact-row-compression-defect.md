# Exact shadow defect of row-prefix compression

29 October 2026. Ordinary local identities, with a separately stated
unproved structural inequality. No same-budget normalization follows
without a causal transfer of the saved and added cells.

Use the notation of `../regional/exact-row-expansion-ledger.md`: the board
has w rows and 2m columns, the source has one physical color p, row r is
represented by A_r subset {0,...,m-1}, q_r=(p-r) mod2, and

    H_r=A_r union (A_r-1) if q_r=0,
    H_r=A_r union (A_r+1) if q_r=1,
    B_r=H_r union A_(r-1) union A_(r+1).

Out-of-range indices and rows are absent. Write a_r=|A_r|, b_r=|B_r|,
gamma_r=b_r-a_r>=0. Thus sigma=sum gamma_r is the actual surplus.

## 1. Exact left-compression defect, after the vertical union

Let C_L replace every source and target row by its left prefix of the
same cardinality. The row count of N(C_L(S)) is exactly

    g_r=max(a_r+1_[q_r=1 and 0<a_r<m], a_(r-1), a_(r+1)).  (1)

All the sets being united are prefixes, so the largest size is the union
size. Since b_r>=max(a_r,a_(r-1),a_(r+1)), one always has g_r-b_r<=1.

More precisely, g_r=b_r+1 if and only if ALL of the following hold:

1. q_r=1 and 0<a_r<m;
2. A_r is the right suffix {m-a_r,...,m-1};
3. A_(r-1) and A_(r+1) are subsets of that same suffix.    (2)

Proof: positive difference forces the extra unit in (1), and then b_r=a_r.
The exact horizontal ledger says |H_r|=a_r precisely when A_r is a single
component containing its cheap right endpoint. This is the suffix in(2).
Equality b_r=a_r then says that the two vertical neighbor sets add nothing.
Conversely those three conditions give b_r=a_r and g_r=a_r+1.

Thus the defect after vertical union is a literal SINGLE next fringe cell
in each row satisfying(2). It is not merely bounded by the number of
right-touching rows. Empty rows, full rows, and suffix rows receiving an
additional vertical neighbor do not count.

Define d_L(S) to be the number of these rows and

    c_L(S)=sum_r max(0,b_r-g_r).

Then the exact cardinality ledger is

    |N(C_L(S))|-|N(S)| = d_L(S)-c_L(S).              (3)

The right-prefix/suffix reflection gives d_R,c_R: its defect rows have
q_r=0 and are proper LEFT prefixes containing both neighboring source
rows. In particular d_L and d_R partition the nonempty proper rows whose
actual local surplus gamma_r is zero, according to q_r. Their defect
cells and saving cells lie in different target rows or fringe locations;
equation(3) alone does not permit their physical cancellation.

## 2. Oppositely oriented zero-surplus rows require an interface charge

Suppose i<j are proper zero-surplus rows of opposite orientation: A_i is
a right suffix and A_j a left prefix, or conversely. Then

    sum_(r=i+1)^(j-1) gamma_r >= |A_i symmetric_difference A_j|. (4)

For each column index present at exactly one endpoint, the binary
occupancy string across rows i,...,j changes between one and zero.
It has a zero entry adjacent to a one. This zero cannot be at either
endpoint: gamma_i=gamma_j=0 says that a neighboring occupied entry must
also be occupied at that endpoint. Hence an INTERIOR row contributes
this column to B_r minus A_r. Distinct columns give distinct charged
row/column positions, proving(4). No horizontal growth is needed for
this lower bound.

If the endpoint suffix/prefix sizes are s,t, their symmetric difference
has size

    min(s+t,2m-s-t).                                (5)

Thus low available surplus between opposite defect rows forces their
combined depths to be close either to zero or to the full two-row
capacity. This is a spatial orientation-interface charge, not a temporal
potential or a proved inspection-reallocation theorem.

Opposite defect rows cannot be adjacent. Their zero-surplus conditions
would force the two proper sets to be equal, while a nonempty proper
prefix cannot equal a suffix. A separator containing real surplus is
therefore unavoidable whenever both d_L and d_R are positive.

## 2a. Complementary closed sets preserve and exchange defect rows

For a one-color source S put

    T=V_(1-p) minus N(S),
    Sbar=V_p minus N(T)=E(N(S)).

Then S subset Sbar and N(Sbar)=N(S). Consequently

    sigma(T)=sigma(Sbar)=sigma(S)-|Sbar minus S|.

Every proper zero-surplus row of S remains such a row of Sbar. The
proper zero-surplus rows of Sbar are EXACTLY those of T, with their
left/right defect labels exchanged. In particular

    d_L(S)<=d_L(Sbar)=d_R(T),
    d_R(S)<=d_R(Sbar)=d_L(T).                         (7)

For the direct inclusion, a zero-surplus row has B_r=A_r equal to a
cheap-end proper interval. The T row is its complement, a cheap-end
proper interval of the opposite physical parity. Every adjacent target
row B_(r+-1) contains A_r, so the corresponding T neighbor is contained
in that complement. The horizontal and vertical neighbors of T therefore
give exactly that T row, proving zero surplus. Conversely, if a T row
has zero surplus, the Sbar row is its complement; the same argument,
or N(Sbar)=N(S), proves the reverse assertion for this closed pair.

The equal-neighborhood identity follows from the neighborhood/erosion
adjunction: Sbar contains S, while no vertex of Sbar is adjacent to T.
No geometric regularity or connectedness is assumed.

This gives a useful saturated separator representation for the conjecture
below. It does NOT automatically preserve its central cardinality range:
Sbar can be larger than S. If sigma(S)=b+e and L<|S|<U, the dual only
satisfies |T|>=L-e, not necessarily |T|>L. The missing e units must remain
in any argument using closure; they cannot be discarded by relabelling.

## 3. A falsifiable structural target

For even w=2b<=n=2m put L=(b-1)^2 and U=b*n-b(b-1).
The following is a CONJECTURE, not a consequence of Sections1-2:

    L<|S|<U  ==>  min(d_L(S),d_R(S)) <= sigma(S)-b+1.       (6)

All one-color supports on 2x4,4x4,4x6,6x6 satisfy(6), as recorded in
`row-compression-defect-audit.json`. The same audit independently checks
the exact row identity for every support, both physical colors, both ends.
There are 533,024 checked supports in total. This is finite evidence only.

The +1 cannot simply be removed. On 6x6, source color0 and

    S={(0,0),(0,2),(1,1),(2,0),(5,5)}

have |S|=5, sigma=3=b, but (d_L,d_R)=(1,2). It is a size-four near-corner
triangle plus the diagonally opposite corner singleton. Thus even zero
isoperimetric excess does not guarantee a defect-free choice of end.

## 4. The remaining temporal theorem

Starting from a full state, compression leaves the state unchanged. In a
compressed history each new defect is an extra next-day fringe cell;
each saving is an actual missing fringe cell. To turn(3), or even(6), into
same-budget normalization, one must match added cells to geometrically
usable earlier vacancies or unused inspections. Every time prefix must
respect its original daily quota, not only the total inspection count.
The final unmatched error must also disappear or be included in the
actual central endpoint intersection test for the paired histories.

A bounded unmatched token that can be transported is a possible theorem
target. It has not been established. Ordinary surplus telescoping and the
existence of the spatial interface charge(4) do not prove it.

# A two-day bracket at every odd width, without a width cutoff

29 October 2026. New ordinary consequence of the reviewed regional
projection and protected-cut interfaces. Submitted for independent review.
No Lean coverage, numerical simplification, or equality claim is made.

Let w=2b+1, n>=w be even, b>=2, k>=b+1, h=wn/2 and Z=h-b^2.
Let P(c) be the ACTUAL finite-board compatible-prefix signed-gate clock
for terminal quota 0<=c<=k. Let g(c) be the unrestricted full-origin
signed-gate optimum, with the same number-of-updates convention.

If k<Z, then

    max(0,P(c)-1) <= g(c) <= P(c).                 (G1)

This holds at every length and budget in the displayed domain. There is
no fixed-width finite base and no history-shape assumption.

## Proof of the gate bracket

The upper bound is the existing physical prefix construction. Suppose an
actual gate has length T<P(c). The theorem
`../regional/uniform-protected-cut-existence.md` supplies a cut s+r=T,
s>=1, with both previous-index collar guards. Normalize the full-origin
history once using the accepted quota-preserving finite-prefix
normalization. At this cut its total holes Q and signed mass m=h-Q obey

    Q<=max C_s,       m<=max V_r.

Here C is the genuine capped forward pair from zero and V is the genuine
capped allowed-source pair from (c,c). Thus

    max C_s+max V_r>=h.                           (G2)

The genuine forward pair is interlaced:

    min C_(s+1)>=max C_s.                         (G3)

For completeness, its two maps are monotone and inflationary because their
costs are capped by b and b+1 and k>=b+1. Starting at the tied zero seed,
coordinatewise time monotonicity follows by induction. A new coordinate
therefore dominates its old same-label coordinate by time monotonicity,
and its old opposite-label coordinate by inflationarity. This proves(G3),
including minimum budget k=b+1.

The physical finite-board forward and reverse prefix pairs dominate the
capped pairs, clipped at h, as in the protected-cut proof. Choose the label
of a maximum coordinate of V_r; the required opposite coordinate of C_(s+1)
is at least max C_s by(G3). Hence(G2) gives a compatible physical meeting
at s+1+r=T+1. Exact prefix adjunction yields P(c)<=T+1. This proves(G1).
Clipping is harmless: for nonnegative x,y with x+y>=h,
min(x,h)+min(y,h)>=h. The r=0 case already contradicts T<P(c) in the
protected-cut proof, but the same meeting implication would suffice.

No leader identification or ancestor geometry is needed for this one-day
comparison. Those stronger tools remain necessary to decide whether the
one day can be removed.

## Full capture and explicit bound evaluator

Put p=P(k), q=P(floor(k/2)). The existing terminal-shift and quota
monotonicity identities give q in {p,p+1}. The exact final-inspection
intersection lower bound and the sequential/reflected prefix constructions
give

    L=max(2p-1,2q-2),
    U=min(2p+2,2q+1),
    L<=T_k(w,n)<=U,       U-L=2.                  (G4)

Indeed if q=p, these displayed values are 2p-1 and2p+1; if q=p+1,
they are2p and2p+2. Retaining stronger already proved bounds can only
reduce the gap. Formula(G4) evaluates two physical prefix recurrences;
it does not claim fixed-operation numerical evaluation.

## Coverage outside the strict-collar budget range

The already proved large-budget theorem in
`paper/sections/odd-short-even-high-budget.tex`, theorem
`thm:odd-short-even-high-budget`, gives equality for
k>=b(b+1)+1, with one-/two-day endpoints at k>=h. Since n>=2b+2,

    Z=h-b^2 >= b^2+3b+1 > b(b+1)+1,

all k>=Z lie inside that retained exact range. In fact one can use the
large-budget theorem earlier; the overlap causes no issue.

Widths one and three retain their complete previous classifications;
odd-by-odd rectangles retain the exact joint evaluator. Combining these
with(G4) gives a computable, constructive bracket of width at most TWO
for EVERY odd width, every length n>=w, and every feasible budget.

This is a uniform improvement over the earlier width-below64 three-day
fallback on odd widths. It does not by itself improve that fallback on
small EVEN widths. It does not prove gap zero on odd widths. In particular
the P(c)-1 candidate remains exactly the phase/shape compatibility problem
addressed by the stronger current research.

## Whole-domain consequence after recovering the sharper retained base

The conservative later checkpoint summaries say only that widths below64
retain a three-day ceiling. The authoritative older final assembly is
sharper: `research/uniform-gap-2026-10-23/comparison-final-panel.json` proves
gap at most TWO on every even width at most64, every length and budget.
Its ONLY gap-three exceptions are the odd-width residue families
(w,k)=(47,25) and(61,32). Their full length coverage follows the reviewed
finite-residue and common-envelope theorems; it is not a length sample.

The read-only receipt `retained-small-even-gap-two-audit.json` reproduces
its aggregation, verifies all seven pinned source/receipt hashes, and checks
all1650 even-width parameter/parity lines have gap at most two. It does not
rerun the old graph searches or claim new formal certification.

Combining that retained small-even base with the accepted even-width
w>=64 two-day theorem and the NEW all-odd-width theorem above proves:

    for EVERY w<=n and feasible k>=floor(w/2)+1,
    there are computable constructive bounds L<=T_k(w,n)<=U with U-L<=2.

For the one-cell board use the retained immediate-capture convention. Every
previous exact family and one-day improvement is retained. This improves
the whole-domain ceiling from THREE to TWO; it is mathematical progress,
not merely reorganization. The only new argument is the uniform odd-width
projection/protected-cut consequence. The existing even-width finite base
is reused rather than newly asserted or recomputed by enumeration.

Independent regional review accepted(G1)--(G4), including the clipped
cross-sum and the final inspection shift. Parent review and the full
upstream dependency audit remain recorded separately.

"""Bounded all-cut necessary ancestor certificate, not a full classifier.

All scalar-cut candidates and actual physical phases are retained. Reverse
endpoint sensitivity is uniform over every true activation branch. A surviving
candidate is not a physical strategy. Ordinary source interfaces are cited in
the accompanying note; this is not Lean verification.
"""
from pathlib import Path
from math import isqrt
from functools import lru_cache
import json,sys
ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT/'src'))
from resumed_even_construction_prefix_arithmetic import erosion_count

def cs(q): return isqrt(q)+(isqrt(q)**2<q)
def rho(q):
 r=(isqrt(4*q+1)-1)//2
 return r+(r*(r+1)<q)

def orbits(k,c,T):
 E=[(0,0)];V=[(c,c)]
 for _ in range(T):
  x,y=E[-1];E.append((y+k-rho(y+k),x+k-cs(x+k)))
  x,y=V[-1];V.append((k+y-rho(y),k+x-cs(x)))
 return E,V

def prefix_gate(w,n,k,c):
 h=w*n//2;v=(c,c);t=0
 while max(v)<h:
  v=tuple(min(h,k+erosion_count(w,n,1-p,v[1-p]))for p in(0,1));t+=1
 return t

def sensitive(q,U,b,h):
 m=cs(q)
 if 1<=m<b and q>m*(m-1) and U-q<=m and U<h-m*m:
  return dict(root=m,defect=m*m-q,required=q,available=U)
 return None

def corners(w,n,p):
 return [(x,y)for x in(0,w-1)for y in(0,n-1)if(x+y)%2==p]

@lru_cache(None)
def lens(w,n,C,R,D,S,p):
 if min(R,S)<0:return 0
 total=0
 for x in range(w):
  ra=R-abs(x-C[0]);rb=S-abs(x-D[0])
  if min(ra,rb)<0:continue
  lo=max(0,C[1]-ra,D[1]-rb);hi=min(n-1,C[1]+ra,D[1]+rb)
  lo+=(p-x-lo)%2
  total+=max(0,(hi-lo)//2+1)
 return total

def candidate_cuts(w,n,k,c,T,E,V):
 b=w//2;d=k-b;H=b*(b-1);h=w*n//2
 cuts=[]
 early={Q:[e for e in range(1,T+1)if Q<=max(E[e])<=Q+d-1]for Q in range(H-d+1,H+1)}
 late={Y:[l for l in range(1,T+1)if Y<=max(V[l])<=Y+d-1]for Y in range(H+1,H+d+2)}
 for Q in range(H-d+1,H+1):
  es=early[Q]
  for Y in range(H+1,H+d+2):
   ls=late[Y]
   for e in es:
    for ell in ls:
     Delta=T-e-ell
     if Delta<0:continue
     R=Q+Y+d*Delta-h;g=min(abs(E[e][0]-E[e][1]),abs(V[ell][0]-V[ell][1]))
     de=max(E[e])-Q;dl=max(V[ell])-Y
     if min(R,de,dl)<0 or de+dl+R>=g or g>d:continue
     assert Delta==max(0,(h-Q-Y+d-1)//d)
     cuts.append(dict(Q=Q,Y=Y,early=e,late=ell,middle=Delta,R=R,g=g,
                      delta_early=de,delta_late=dl,E=E[e],V=V[ell]))
 return cuts

def forward_seeds(Q,e,E,k,b,h):
 H=b*(b-1);d=k-b;req=Q;out=[]
 for s in range(e,0,-1):
  B=max(E[s]) if s==e else min(max(E[s]),H-d)
  if req>B:return [],dict(index=s,required=req,cap=B)
  U=min(max(E[s-1]),H-d)+k
  z=sensitive(req,U,b,h)
  if z:out.append(z|dict(index=s))
  req=max(0,req+cs(req)-k)
 if req:return [],dict(index=0,required=req,cap=0)
 return out,None

def evaluate(w,n,k,c,T=None):
 assert w%2==0 and n>=w
 b=w//2;d=k-b;h=w*n//2;H=b*(b-1)
 assert b>=32 and 1<=d<=b-1
 P=prefix_gate(w,n,k,c);T=P-1 if T is None else T
 E,V=orbits(k,c,T)
 cuts=candidate_cuts(w,n,k,c,T,E,V);rows=[]
 for cut in cuts:
  Q,Y,e,ell,Delta=(cut[z]for z in('Q','Y','early','late','middle'))
  if max(V[ell])>=H+k:
   rows.append(cut|dict(rejected=False,reason='Reverse ordinary cap is outside the retained unclipped regime.'));continue
  seeds,contradiction=forward_seeds(Q,e,E,k,b,h)
  if contradiction:
   rows.append(cut|dict(rejected=True,reason='Backward mass demand exceeds an actual early cap.',contradiction=contradiction));continue
  J=sensitive(Y-k,max(V[ell-1]),b,h)
  if J is None:
   rows.append(cut|dict(rejected=False,reason='Endpoint reverse sensitive test does not fire.',forward_seeds=seeds));continue
  v=e+Delta;eta=max(V[ell])-Y
  # H_v has exactly h-Y cells, since the late cut is actually solo.
  checks=[];best=None
  for F in seeds:
   age=v-F['index'];rF=2*F['root']-2-age
   vals=[]
   for p0 in(0,1):
    p=(p0+v)%2
    for C in corners(w,n,(p0+F['index'])%2):
     for D in corners(w,n,p):
      val=lens(w,n,C,rF,D,2*J['root']-2,p)
      vals.append(dict(p0=p0,C=C,D=D,lens=val))
   z=dict(seed=F,age=age,minimum_lens=min(vv['lens']for vv in vals),
          allowance=F['defect']+J['defect']+eta,corner_cases=vals)
   z['margin']=z['minimum_lens']-z['allowance'];checks.append(z)
   if best is None or z['margin']>best['margin']:best=z
  ok=best is not None and best['margin']>0
  rows.append(cut|dict(rejected=ok,reason='Every physical corner pair violates the same-day lens.'if ok else 'A raw corner pair survives the one-seed lens.',
                      endpoint_reverse_seed=J,eta=eta,forward_seed_count=len(seeds),best=best))
 return dict(shape=[w,n],budget=k,terminal_quota=c,canonical_updates=P,tested_updates=T,
  scalar_candidates=len(cuts),rejected_candidates=sum(z['rejected']for z in rows),
  rejects_whole_gate=all(z['rejected']for z in rows),scalar_excluded=not cuts,rows=rows,
  scope='All scalar first/last pronic-cut candidates; genuine activation-uniform endpoint seed. A surviving row is not a physical strategy. Ordinary conditional source interfaces, no Lean coverage.')

def creator_domains(cut,E,V,k,b,h,forward_level=None,reverse_level=None):
 """Exhaustive alternatives for one chosen forward and reverse excess token.

 Reverse index s means W_(s-1)=V_s-k, real day T-s. The union of initial
 and noninitial birth conditions safely retains every activation branch.
 """
 e,ell,Q,Y=(cut[z]for z in('early','late','Q','Y'));H=b*(b-1);d=k-b
 outF=[];outJ=[];q=Q if forward_level is None else forward_level
 assert Q>min(E[e]) and Y-k>min(V[ell])-k
 for s in range(e,0,-1):
  m=cs(q);old=q+m-k
  if (min(E[s])<q<=min(E[s][0],Q if s==e else H-d)
      and (e-s)%2==(0 if E[e][0]>E[e][1]else 1)
      and m<b and q>m*(m-1) and 0<=old<=min(max(E[s-1]),H-d)):
   assert q+m<h-m*m
   outF.append(dict(index=s,root=m,defect=m*m-q,mass=q,old_mass=old))
  q=max(0,q+(1+rho(q)if q else 0)-k)
 q=Y-k if reverse_level is None else reverse_level
 for s in range(ell,0,-1):
  m=cs(q)
  if (min(V[s])-k<q<=V[s][0]-k
      and (ell-s)%2==(0 if V[ell][0]>V[ell][1]else 1)
      and m<b and q>m*(m-1)):
   initial=q+m==min(V[s-1])
   ordinary=s>=2 and 0<=q+m-k<=max(V[s-1])-k
   if initial or ordinary:
    assert q+m<h-m*m
    outJ.append(dict(index=s,root=m,defect=m*m-q,mass=q,
                     initial_branch=initial,ordinary_branch=ordinary))
  q=max(0,q+(1+rho(q)if q else 0)-k)
 return outF,outJ

def creator_test(w,n,k,c,T=None):
 b=w//2;h=w*n//2;P=prefix_gate(w,n,k,c);T=P-1 if T is None else T
 E,V=orbits(k,c,T);cuts=candidate_cuts(w,n,k,c,T,E,V);rows=[]
 for cut in cuts:
  if max(V[cut['late']])>=b*(b-1)+k:
   rows.append(cut|dict(rejected=False,reason='Reverse cap clipped.'));continue
  Fs,Js=creator_domains(cut,E,V,k,b,h)
  v=T-cut['late'];eta=max(V[cut['late']])-cut['Y'];survivors=[];bestmargin=None
  for F in Fs:
   for J in Js:
    R=2*F['root']-2-(v-F['index']);S=2*J['root']-2-(cut['late']-J['index'])
    allowance=F['defect']+J['defect']+eta
    for p0 in(0,1):
     p=(p0+v)%2
     for C in corners(w,n,(p0+F['index'])%2):
      for D in corners(w,n,(p0+T-J['index'])%2):
       val=lens(w,n,C,R,D,S,p);margin=val-allowance
       bestmargin=margin if bestmargin is None else min(bestmargin,margin)
       if margin<=0:survivors.append(dict(F=F,J=J,p0=p0,C=C,D=D,forward_radius=R,reverse_radius=S,lens=val,allowance=allowance))
  rows.append(cut|dict(rejected=not survivors,forward_creators=len(Fs),reverse_creators=len(Js),
     creator_pairs=len(Fs)*len(Js),surviving_corner_pairs=len(survivors),minimum_margin=bestmargin,
     survivors=survivors,forward_domain=Fs,reverse_domain=Js))
 return dict(shape=[w,n],budget=k,terminal_quota=c,canonical_updates=P,tested_updates=T,
  scalar_candidates=len(cuts),rejected_candidates=sum(z['rejected']for z in rows),
  rejects_whole_gate=all(z['rejected']for z in rows),rows=rows,
  scope='All scalar cuts plus the exhaustive creator disjunction for one demanded token at each endpoint. Reverse initial/ordinary creators union all true activation branches. Surviving alternatives need not be physical.')

def all_token_graph(w,n,k,c,T=None):
 """Finite-domain creators; pairwise physical clauses, not strategy search."""
 b=w//2;h=w*n//2;P=prefix_gate(w,n,k,c);T=P-1 if T is None else T
 E,V=orbits(k,c,T);cuts=candidate_cuts(w,n,k,c,T,E,V);rows=[]
 for cut in cuts:
  e,ell,Q,Y=(cut[z]for z in('early','late','Q','Y'));v=T-ell;eta=max(V[ell])-Y
  tokens=[]
  for q in range(min(E[e])+1,Q+1):
   F,_=creator_domains(cut,E,V,k,b,h,forward_level=q)
   tokens.append(dict(direction='forward',level=q,domain=F))
  for q in range(min(V[ell])-k+1,Y-k+1):
   _,J=creator_domains(cut,E,V,k,b,h,reverse_level=q)
   tokens.append(dict(direction='reverse',level=q,domain=J))
  phases=[]
  for p0 in(0,1):
   domains=[]
   for token in tokens:
    dd=[]
    for z in token['domain']:
     day=z['index']if token['direction']=='forward'else T-z['index']
     dd.extend(z|dict(corner=C,day=day,direction=token['direction'],endpoint_level=token['level'])for C in corners(w,n,(p0+day)%2))
    domains.append(dd)
   rejects={'same_birth':0,'same_history':0,'cross_lens':0};nodes=0
   def compatible(A,B):
    if A['direction']==B['direction']:
     if A['index']==B['index']:
      rejects['same_birth']+=1;return False
     if (A['index']-B['index'])*(A['endpoint_level']-B['endpoint_level'])<=0:
      rejects['same_birth']+=1;return False
     A,B=sorted((A,B),key=lambda z:z['index']);age=B['index']-A['index'];R=2*A['root']-2-age
     p=(p0+B['day'])%2
     missing=lens(w,n,A['corner'],R,A['corner'],R,p)-lens(w,n,A['corner'],R,B['corner'],2*B['root']-2,p)
     if missing>A['defect']:rejects['same_history']+=1;return False
    else:
     F=A if A['direction']=='forward'else B;J=B if B['direction']=='reverse'else A
     RF=2*F['root']-2-(v-F['index']);RJ=2*J['root']-2-(ell-J['index'])
     z=lens(w,n,F['corner'],RF,J['corner'],RJ,(p0+v)%2)
     if z>F['defect']+J['defect']+eta:rejects['cross_lens']+=1;return False
    return True
   order=sorted(range(len(tokens)),key=lambda j:len(domains[j]))
   def search(at,chosen):
    nonlocal nodes
    nodes+=1
    if at==len(order):return chosen
    j=order[at]
    for z in domains[j]:
     if all(compatible(z,a)for _,a in chosen):
      hit=search(at+1,chosen+[(j,z)])
      if hit is not None:return hit
    return None
   hit=search(0,[])
   phases.append(dict(p0=p0,rejected=hit is None,witness=hit,visited_nodes=nodes,rejected_pair_counts=rejects))
  rows.append(cut|dict(tokens=tokens,phases=phases,rejected=all(z['rejected']for z in phases)))
 return dict(shape=[w,n],budget=k,terminal_quota=c,canonical_updates=P,tested_updates=T,
  scalar_candidates=len(cuts),rejects_whole_gate=all(z['rejected']for z in rows),rows=rows,
  scope='Every demanded excess token retains an exclusive true creator clock and physical corner; same-history erosion and same-cut lenses. All genuine activation branches are relaxed into reverse creator domains. Finite-domain necessary certificate, not physical-state enumeration or general optimality.')

if __name__=='__main__':
 out=[evaluate(128,128,66,66),evaluate(64,65,48,24)]
 Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
 for z in out:
  print(json.dumps({k:v for k,v in z.items()if k!='rows'}))
  for row in z['rows']:
   if not row['rejected']:print(json.dumps(row))

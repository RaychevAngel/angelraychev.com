# Independent review: raw corner tilt and one-longer label

29 October2026. Ordinary proof review, not Lean.

Reviewed `../phase/raw-corner-tilt-transport.md`, including its actual-history
one-longer corollary. Accepted conditional on the stated previously proved
same-end core barrier and common-deficit ledger.

The reflected square source cutoffs i+p-1, target cutoffs2b-2-q-i,
q=p+t+1 modulo2, and the resulting exact column packing count are correct.
For odd t the p=1 sum is the p=0 sum plus b by shifting the column index;
for even t the two phases give the preceding p=0 odd expression at t+1.
The t=0 boundary is the direct count of initially forbidden vertices and
agrees with the same staircase formula. The larger-board far-square
restriction weakens the initial hole envelope and retains the entire
final corner triangle, so it is a valid physical path packing.

The raw endpoint directions are correct: fewer initial holes enlarge the
available starting belief, and a final survivor subset only removes allowed
endpoints. No raw-defect subtraction is needed for those outer envelopes.
The holes at j+1 to survivors at l convention has r-1 moves and r inspected
layers, including the final inspection.

For the one-longer application the middle ledger gives
Delta<=floor((3b-3)/d)+2 and r<=Delta-1. Substituting r<=3b/d+1 into the
decreasing packing-minus-budget expression gives exactly
b²(1/2-3/(2d)-9/(8d²))-4b-d. Its derivative is at least1/2 on4<=d<=b,
and at d4 the margin is7b²/128-4b-4>2 for b>=128. The explicit outlier
allowances are therefore paid. No ordinary arrival phase, transverse
front classification, or capture equality is inferred from the label.

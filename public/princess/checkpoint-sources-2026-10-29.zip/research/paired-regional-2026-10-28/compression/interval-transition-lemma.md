# Exact transitions between row/color interval profiles

29 October 2026 UTC. Ordinary lemma; the optimum normal form is NOT proved.

Fix a rectangle and one choice of row axis. In every row, order the cells of each checkerboard color from left to right. Call a physical set interval-shaped if its intersection with each such row/color fiber is empty or one contiguous interval in that order. Different fibers may have different endpoints.

Let E(T)={v : every graph neighbor of v belongs to T}. If T is interval-shaped, then E(T) is interval-shaped. Indeed, each vertical-neighbor requirement is membership in an interval of the same physical column positions on a neighboring row. A horizontal-neighbor requirement says that both adjacent opposite-parity positions lie in the target interval, except for the single available neighbor at a board endpoint. In the spacing-two source order, the satisfying positions form one interval: the ordinary interval is shortened by one at the appropriate end; a degree-one endpoint can add only the adjacent end position. Their intersection is an interval. The n=1 horizontal condition is vacuous and preserves the claim. Intersecting E(T) with another interval-shaped B also preserves the claim.

For arbitrary physical sets B,T on any graph, put S*=B intersect E(T). There is a survivor S subset B with N(S)=T if and only if N(S*)=T. In that event S* is the unique maximal survivor producing T, and the minimum useful inspection cost is

    c(B,T)=|B|-|S*|.

Necessity: N(S)=T implies S subset E(T), hence S subset S*. Therefore T=N(S) subset N(S*) subset T. Sufficiency is direct. Maximality yields the minimum cost.

Consequently the exact physical transition graph restricted to interval-shaped BELIEFS automatically has interval-shaped minimum-cost SURVIVORS. There is no convex-hull transition or relaxed neighborhood in this graph. N(S*) must be checked literally, or by exact interval-union equality on every target row/color fiber.

A profile has at most two endpoints for each of the 2w row/color fibers. There are at most (n+1)^(4w) such profiles, independent of k. Naive dense exact-graph search therefore has cost (n+1)^(O(w)), up to polynomial arithmetic factors. This would remove the budget-dependent area degeneration IF a full-origin optimum interval-profile normal form were proved. The lemma alone does not prove that normal form and does not tighten the unrestricted capture-time lower bound.

Bounded diagnostic: the accompanying literal N-image oracle compares unrestricted capture with this restricted physical graph, rather than assuming completeness. All results are recorded separately.

# Complement-dual compression of a pair of physical histories

29 October 2026. New abstract deduction from the existing compression
comparison theorem. For independent review. This is a proof tool, not a new
capture-time formula or a claim that the missing rectangle operator exists.

Let V be the vertices of a finite undirected graph, N the open neighborhood,
and E(B)=V\\N(V\\B). Then N(A) subset B iff A subset E(B).

Suppose C is monotone, cardinality preserving, and

    N(C(A)) subset C(N(A)) for every A.

Define its complement dual by

    Cdagger(A)=V\\C(V\\A).

## 1. The dual is also a legitimate strategy compression

Monotonicity and preservation of cardinality are immediate. Since
N(E(B)) subset B, the assumed inclusion and monotonicity imply

    N(C(E(B))) subset C(N(E(B))) subset C(B).

Adjunction gives C(E(B)) subset E(C(B)). Taking complements with B=V\\A
gives exactly

    N(Cdagger(A)) subset Cdagger(N(A)).

If C is idempotent, so is Cdagger. If C preserves the two checkerboard
color classes, so does Cdagger. No graph reflection is needed.

## 2. Opposite compression cannot increase the joining inspection

For arbitrary endpoints F,R, monotonicity gives

    C(F intersect (V\\R)) subset C(F) intersect C(V\\R).

Consequently

    |C(F) intersect Cdagger(R)|
      = |C(F)\\C(V\\R)|
      <= |F|-|F\\R|
      = |F intersect R|.

Apply the existing physical strategy comparison to the forward prefix
using C and independently to the reverse prefix using Cdagger. Their
actual transformed endpoints are subsets of these two envelopes; every
day retains its original inspection cap and each prefix retains its clock.
Therefore any feasible splice remains feasible after the paired replacement.

For odd-coordinate fiber compression the dual is the opposite prefix
operator, recovering the first-round result. For square downward-pyramid
compression the dual has upward-pyramid fixed sets. Thus the square also
admits an exact paired recurrence with literal intersection calculated from
oppositely ordered row/color counts. This is a consequence of the existing
square theorem, not a new proof of its single-history normal form.

## 3. Time-dependent compression has the correct reversed compatibility

More generally let C_t and C_(t+1) be monotone and cardinality preserving,
and suppose

    N C_t subset C_(t+1) N

as operators on all sets under consideration. Repeating the adjunction
argument, now keeping the indices, gives

    C_t E subset E C_(t+1),
    N Cdagger_(t+1) subset Cdagger_t N.

Thus a forward sequence of compatible compressions automatically gives a
compatible reverse sequence of complement-dual compressions. At a common
cut the overlap contraction in Section2 applies. The two histories must
use the same C at that cut; choosing unrelated independently good endpoint
operators would not justify the intersection inequality.

This identifies a useful weaker target than a single stationary operator:
construct compatible time-dependent rectangle compressions through the
actual history. It does not supply those operators. If compatibility has
only been shown for selected sets rather than all sets, the argument must
also check the E(B) inputs used above; those cannot be silently inherited.

## Limits

The lemma does not remove any daily cap, make arbitrary independently
minimizing shapes compatible, or turn a necessary regional profile into
a reachable state. The original even-path rigidity obstruction remains.
An unequal even-rectangle normal form still needs its own operator or
whole-history construction.

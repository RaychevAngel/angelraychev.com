# Projected initialization and signed reverse necessity at every feasible budget

29 October2026. New ordinary theorem for independent attack. This replaces
the core-dependent initialization in `high-budget-signed-reverse-interface.md`.
The same actual reversal and shared-deficit bookkeeping are retained.

Let w=2b+1, n>=w even, b>=2, h=wn/2, and

    b+1<=k<Z=h-b²,  U=h-b(b+1),  A=Z-k>0,
    L=(b-1)², 0<=c<=k.

Define the inverse shadow maps on nonnegative integers

    I_0(x)=x-min(rho(x),b),
    I_1(x)=x-min(ceil_sqrt(x),b+1),

and the genuine backward pair

    V_0=(c,c),
    V_(j+1)=(k+I_0(V_j[1]), k+I_1(V_j[0])),
    W_j=V_(j+1)-(k,k).

Thus W_(j+1)=(I_0(W_j[1]+k),I_1(W_j[0]+k)). The pairs V,W are
coordinatewise nondecreasing: k>=b+1 makes both increments nonnegative,
and V_1>=V_0 supplies the monotone induction. No span bound is used.

## 1. The three initial inequalities

Use the actual aligned projections Z^0,Z^1 from
`regional/paired-odd-subboard-projection.md`. The strict-collar continuation
needs precisely

    |J_0|<=max W_r,  Z^0(J_0)<=W_r[0],  Z^1(J_0)<=W_r[1].       (R0)

Indeed projection propagates the last two inequalities. A minimal-original-
surplus target is wholly retained by one matching projection, by the
independently reviewed phase-coherence lemma. Any other nonempty target
has original surplus at least its majority capped cost plus one, hence is
bounded by I_1(Qprev+k). Since I_1<=I_0 and both maps are monotone,

    I_1(max W+k)<=max(I_0(W[1]+k),I_1(W[0]+k)).

The empty target is automatic. This propagates the scalar inequality too,
for arbitrary shapes and arbitrary retreats as long as actual Q<U.

Let D be ANY actual one-color set with |D|<=min V_r, and J_0=E_V(D).
Assume max W_r<A; otherwise every later clipped claim is automatic.
Then max V_(r+1)<Z and monotonicity gives M=|D|<Z.

Write q=|E_V(D)|. If q<=L, then q<U. If q>L and M-q<b, the ordinary
small/co-small separator forces q>=U+2b, impossible since q<=M<Z=U+b.
Here q<=M follows from the board's perfect matching. Otherwise M-q>=b,
and q<=M-b<U. Thus the initial actual erosion is inside the collar.

Its original one-shot surplus is M-q, so the scalar small-side bound gives
q+min(ceil_sqrt(q),b)<=M, and therefore

    q<=I_0(M)<=I_0(V_r[1])=W_r[0]<=max W_r.

Apply the projection theorem directly to J_0=E_V(D), with empty old holes
and inspection set D. It gives

    Z^p(J_0)<=I_p(Z^(1-p)(D))<=I_p(M)
            <=I_p(V_r[1-p])=W_r[p].

These are all three inequalities(R0). No artificial physical prehistory,
good-label choice, positive core, tiny-root certificate, or first-quota
exception is needed. This also includes r=0.

## 2. The same safe clipping works without A>L

Starting below A, consider the first actual crossing of A. Its preceding
count is at most A-1, so original accounting gives

    Qnew+sigma<=A-1+k=U+b-1.

If Qnew<=L it is already below U. Otherwise sigma<b would require the
co-small Qnew>=U+2b, impossible from this raw bound; hence sigma>=b and
Qnew<=U-1. The strict-collar comparison therefore holds through this
crossing, making the reference maximum at least A. Later clipped claims
are automatic by monotonicity. Consequently, for every subsequent actual
erosion history J_(i+1)=E_V(J_i union I_i), |I_i|<=k,

    min(|J_i|,A)<=min(max W_(r+i),A).                         (R1)

## 3. The permanently mixed suffix controls both phases

This is the accepted signed comparison with its parameter guard audited.
For x<=k set phi_p(x)=0; for x>k put u=x-k and

    phi_0(x)=u+min(ceil_sqrt(u),b),
    phi_1(x)=u+min(1+rho(u),b+1).

Their inverse thresholds are exactly V. Start either phase at
0<=x<=min(max(m,0),Z), where m is actual signed belief mass. Both
post-inspection survivors are proper on a normalized permanently mixed
suffix. If x>k, their signed survivor mass q satisfies q>=m-k>=u.
When q>=phi_p(x), nonnegative surplus suffices. In the remaining case,

    0<q<phi_p(x)<=Z-k+b+1=U+b-(k-b)+1<=U+b.

Thus q<=U+b-1<U+2b-2 for b>=2. For q>=L the accepted strict mixed
central barrier supplies original surplus at least b+1. For q<L the
accepted mixed small-boundary profile supplies both ordinary costs, hence
both capped costs. This proves propagation for either phase. An r-update
mixed suffix reaching signed gate c therefore has

    min(max(m,0),Z)<=min V_r.                                (R2)

The strict integer inequality above includes b=2; merely dropping the
strict q<phi_p(x) would unnecessarily require b>=3.

## 4. Reverse the actual solo part

For any last-full-normalized source with t updates remaining to signed
gate c,

    min(max(m_source,0),Z)<=max V_t.                          (R3)

If already mixed, (R2) is stronger. Otherwise let activation follow a
solo updates, and let r=t-a>=1 count the updates from its pre-state to
the gate. Its actual smaller cohort D satisfies min(|D|,Z)<=min V_r by
(R2). If min V_r>=Z, (R3) is automatic; otherwise |D|<=min V_r<Z.

Reverse the actual solo inspections, C_0=D,
C_(i+1)=I_(a-1-i) union E_V(C_i), J_i=E_V(C_i). The actual source S
is contained in C_a, so for a>=1, |S|<=k+|J_(a-1)|. By(R1),

    min(|S|,Z)<=k+min(|J_(a-1)|,A)
                 <=k+max W_(r+a-1)=max V_t.

For a=0 use(R2); with no activation use the actual terminal set of size
at most c and r=0 in(R1). Zero-update suffixes are immediate. This proves
(R3), retaining the real allowed set and any excess for a later join.

## Evidence and limits

Dependencies: the accepted last-full normalization, scalar small/co-small
separator, mixed central and boundary profiles; the newly independently
reviewed paired projection and minimal-surplus phase-coherence lemmas.
The root independently checked each changed interface above. A separate
agent review is requested before promotion of the assembled theorem.

The theorem supplies all-budget shifted and signed reverse necessity at
every b>=2 in its stated k<Z range. It does not prove a compatible common
cut, physical/capped prefix agreement outside its old corridor, or endpoint
overlap. It is not a new exact capture formula, uniform gap-zero claim,
or Lean theorem.

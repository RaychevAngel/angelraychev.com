# Paired geometry: structural gates and independent attacks

18 September 2026. Ordinary derivations and diagnostic counterexamples, not a new capture-time classification. Sources: the current checkpoint, September 13 exploration, accepted even-area profile, corner localization, and joint 24-row day-28 barrier. No manuscript, website, or Lean changes.

## 1. A static asynchronous paired potential includes the unilateral problem

Suppose a function Phi(A,B) is required to decrease by at most one when **either** history is advanced, and Phi(A,B)<=0 whenever |A intersect B|<=k. Then h(A)=Phi(A,V) is an ordinary unilateral capture potential: its legal-step inequality is inherited and h(A)<=0 for |A|<=k. Moreover h(V)=Phi(V,V).

Thus the proposed globally valid asynchronous paired potential cannot automatically escape the unilateral initial-value problem. In particular, adding a relative-anchor correction that vanishes when B=V does not improve the initial calibration. This does not prove paired analysis useless. It identifies an unnecessarily strong domain that should be avoided if the intended advantage is balanced full-board histories.

## 2. Exact balanced terminal formulations

For an odd deadline 2L+1, take two independent full-start histories of L inspection-and-movement steps, one using the prefix and one the reversed suffix. Their preinspection states A,B can be joined if and only if |A intersect B|<=k.

For an even deadline 2L, take two independent full-start histories of L **postinspection** states, using the last L shots in reverse for the second. If U,W are the terminal states, they can be joined if and only if no edge joins U to W. Each replica uses the update U -> N(U) minus S; starting with V is valid because N(V)=V. A surviving complete walk is exactly a surviving forward half, a central edge, and a reversed surviving half. This proves both directions.

Writing U=U0 union U1 and W=W0 union W1, even success is equivalent to BOTH

- I0=U0 union W1 being independent;
- I1=U1 union W0 being independent.

A synchronized calibration can therefore target two cross-history independent sets; unlike the unrestricted asynchronous proposal it need not retain arbitrary pairs (A,V) at positive layers.

## 3. A universal static stability consequence for even-area rectangles

Let the two color classes have size h, let r=floor(w/2), and let I be an independent set of size h-delta, with 0<=delta<r. Then

    min(|I intersect V0|,|I intersect V1|) <= delta^2.

Proof. Put A=I intersect V0, a=|A|, B=I intersect V1, b=|B|. Anticompleteness gives |N(A)|<=h-b=a+delta. Its surplus s is nonnegative and at most delta<r. The accepted even-area dichotomy says a<=s^2 or h-a<=s(s+1). In the first case a<=delta^2. In the second, b=h-a-delta<=s(s+1)-delta<=s^2<=delta^2. This also proves that a maximum independent set is monochromatic (delta=0), without a separate matching-covered argument.

If the smaller color part has q>delta(delta-1), it has exact surplus delta (a smaller surplus has square capacity at most (delta-1)^2), and the larger part fills the entire complement of its neighborhood. The high alternative cannot occur because the small part has q<=delta^2 and delta<r. The accepted strict-square corner localization then puts that minority part inside its corner triangle. The precise corner hypotheses and critical delta=r case must be preserved; this paragraph is an application of existing localization, not a new universal critical classification.

### The 24 by 24, k=13 gate

The existing joint bound gives at least 295 rooms before inspection103. Therefore each candidate 103-day postinspection half has at least282 rooms. If a206-day solution existed, its two cross-history independent sets would have defects delta0,delta1>=0 satisfying

    delta0+delta1 <= 576-(282+282)=12.

Except when one defect equals12 (forcing the other zero), both are subcritical and have minority islands bounded by delta_i^2. This is a concrete middle-geometry restriction, stronger than treating the two history sizes independently. In the strict-square portions it reduces to two localized corner islands and the complementary dominant regions.

However the degenerate terminal U=W=one complete physical color is not excluded. A103-day solo strategy would produce exactly this configuration by spending all shots on the other cohort, and concatenating its reflected/reversed copy yields206 full days. Therefore excluding206 necessarily excludes103-day solo capture. The paired formulation changes how that obstruction can be proved; it cannot eliminate the logical obligation.

## 4. Fixed temporal pricing cannot supply the desired lower bound

For any finite graph with N rooms and any horizon T, the set of unrestricted winning inspection-cost vectors includes N e_j for each day j: inspect all rooms on that day. For nonnegative temporal prices lambda_j, the minimum weighted cost of a winning strategy is consequently at most N min_j lambda_j. A budget-k strategy would cost at most k sum_j lambda_j. Whenever kT>=N,

    N min lambda <= (N/T) sum lambda <= k sum lambda.

Hence no certificate consisting solely of a lower bound on weighted total inspections can exclude the horizon after the counting bound. This holds even if the weighted strategy optimization is integral, not just after an LP relaxation. A useful least-action/calibration argument must keep nonlinear, quota-sensitive history compatibility.

## 5. Independent rejection tests for the new odd paired-cap proposal

The proposed synthetic domain at a genuine solo layer (a,c) uses coordinate caps, each source total <=max(a,c), and a cap on the pair's covered union. Transitions have independent budget splits. The boundary-focused checker deliberately samples cap facets and near-axis endpoints; uniform random states mostly leave irrelevant slack.

### Unoriented floor E fails

w=n=33,k32,t14:

- genuine solo (268,270) -> (286,283);
- synthetic sources (0,270),(268,2), with splits0,32;
- outputs (286,0),(1,283);
- old cap max(E,a+c)=545; old union540;
- new cap569; new union570.

### Orientation plus floor E still fails

w=n=129,k130,t49:

- genuine solo (4098,4091) -> (4157,4163);
- oriented synthetic sources (4096,2),(4098,0), splits130,128;
- outputs (1,4161),(1,4161);
- old cap8321; old union8196;
- new cap8321; new union8322.

This occurs at a solo phase switch. It rejects the synthetic induction, not the physical classification.

### Unoriented floor E+k fails

w=n=33,k32,t15:

- genuine solo (286,283) -> (300,301);
- synthetic sources (286,0),(3,283), splits32,0;
- outputs (0,301),(300,1);
- old cap577; new cap601; new union602.

### Even the unoriented decision floor fails

w=n=9,k7,t10:

- genuine solo (33,29) -> (34,38);
- synthetic sources (33,0),(4,29), splits7,0;
- outputs (0,38),(34,2);
- constant decision floor N-k-1=73;
- new union74=N-k while pure new sum72.

The wrong-axis mixed source is not asserted reachable. This is a precise demonstration that relaxing numerical equality to the terminal decision still requires some history-sensitive restriction.

### Surviving conditional candidate

Adding numerical orientation to the E+k-floor domain passed191,379,288 admitted boundary-focused transitions in a25-second bounded run (through width193 in the chosen ordering). This is evidence only. For the remaining k<=r^2 odd rectangle ranges, 2k<M, hence E+k<N-k; this harmless floor would be sufficient for the intended central decision if orientation and the conditional induction were proved. No proof of either is supplied here.

Checker: src/closure_20260918_geometry_pair_gate.cpp; mode0 is original floor,1 oriented original,2 budget floor,3 oriented budget floor,4 decision floor. Receipts are geometry-pair-*.txt. All states are synthetic unless explicitly called genuine solo capacities.

## 6. Rejected shortcut inside the old sharp-event CHARGE route

The claim that the lens forces two even strict-square visits is false. At b5, initial old radius4 and size18, a switch at t5 to r2,q3 is lens-admissible with zero such visits. Its all-pronic source trace is18,16,14,12,9. CHARGE itself holds with equality.

A bounded screen through b60 found6,121,147 admissible scalar/lens tuples;25 had fewer than two strict visits, all at b<=16, and all passed CHARGE. This does not prove that larger widths have no exceptions. The screen was stopped rather than promoted into a width catalogue, because the balanced central geometry is the parent priority.

Files: src/closure_20260918_geometry_charge.py and geometry-charge-screen.json.

## 7. Further exact obstructions to a purely local oriented proof

The E+k-floor candidate survives the tested genuine solo orbits but not arbitrary monotone solo-capacity pairs.

- On7x7,k8, the synthetic solo step(14,9)->(14,19) is coordinatewise nondecreasing. Oriented sources(14,0),(7,7), with splits8,2, yield(0,19),(10,6). The covered union34 exceeds cap33. The second output crosses numerical orientation.
- Requiring correct numerical orientation on BOTH layers still does not repair generic synthetic solo pairs: on7x15,k9, the synthetic step(24,28)->(34,29) admits sources(12,16),(0,28), splits6,0, and outputs(16,14),(34,0). Every source and output points toward its corresponding faster capacity; the union64 exceeds cap63.

Consequently the hypothetical paired induction would need more actual-orbit information than numerical orientation, concentration and coordinatewise monotonicity. Neither displayed solo source lies on the genuine full-start orbit. The checks are exact integer evaluations; no physical counterexample follows.

An attempted shortcut asserting ancestry-secondary<=k was independently rejected on an actual retained frontier:33x33,k17, day231, solo capacities(506,517), attained exceptional state(18,489). This is in the previously solved low-budget range k<=2b, so it does not by itself refute the same bound in the remaining high-budget range. The parent subsequently reported a distinct actual high-budget rejection at1537x1537,k1538. The geometry lane did not rerun that parent computation and does not use it as its independent receipt.

## 8. Explicit scalar guard and attempted zero-start invariants

The numeric lane's fixed-size exact guard is in numerical-crossing-guard.md. It reduces the test for a crossed exceptional successor to a fixed number of root evaluations. This lane tested two concrete ways to make it an invariant, rather than guessing further width-specific bounds.

First, the guard-safe domain is not forward invariant. On the synthetic11x11,k11 trace

    (11,8) -> (15,17) -> (23,20),

the first exact guard equals15, the next smaller solo capacity, but the next guard is21>20. Every coordinate increases at both steps. The older synthetic11x11,k7 trace(9,7)->(10,12)->(15,12) gives the same failure. These are off-orbit capacities, not physical failures. The exact receipt is geometry-guard-invariance.json.

Second, there is a genuine shared-age structure beyond scalar gap bounds. Put f(z)=I0(z+k), g(z)=I1(z+k), F=f composed g, G=g composed f. Then

    D0(2t)=F^t(0), D0(2t+1)=F^t(f(0)),
    D1(2t)=G^t(0), D1(2t+1)=G^t(g(0)).

Thus each color's even/odd subsequences are two interlaced orbits of a single map. In a lower/plateau region where the relevant maps are nonexpanding, distances between these trajectories cannot increase. At even layers the two color0 spacings

    f(c)-a, F(a)-f(c)

are bounded by f(0), F(0)-f(0); at odd layers the bounds swap. There are the corresponding two color1 bounds. This excludes some earlier fake traces but does not suffice to imply the guard.

An explicit rejection in the remaining high-budget range is17x17,b8,k17, synthetic even-layer capacities(24,27)->(37,34). Its exact crossing guard is35>34. Color0 spacings(13,7) fit initial bounds(13,11); color1 spacings(7,12) fit bounds(12,12). The source dominates the genuine layer2 seed(24,24), and all relevant inverse inputs are at most M-b^2=80, a safe nonexpanding cutoff. Both scalar capacities grow. Nevertheless the source is off the genuine orbit. The four spacing inequalities therefore leave out essential shared-age information. Receipt: geometry-interlaced-gap-check.json; checker: src/closure_20260918_geometry_interlaced_gap.py.

No further ad hoc phase flags were added after this failure. A proof must use more of the intertwined dynamics, or a different invariant; the experiment does not refute the guard on genuine zero-start orbits.

## 9. Accepted positive output

The precise uniform balanced-half theorem is in geometry-balanced-stability.md. The boundary-accounting lane independently checked its assumptions, inequalities, critical-defect alternative, strict-square localization and static sharpness constructions. Its review is boundary-balanced-stability-review.md. This is an ordinary new lemma; the existing profile and localization remain its dependencies. It is not yet a capture-time formula or a new formal classification.

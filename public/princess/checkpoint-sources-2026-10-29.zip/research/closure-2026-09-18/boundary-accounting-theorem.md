# Exact boundary and roughness accounting for physical column fronts

18 September 2026. Ordinary proof; independently replayed finite witnesses.
This is an exact accounting theorem, **not** an optimal-time theorem and not
an assertion that unrestricted optimal strategies are column fronts.

## Scope and conventions

The board is `P_w × P_n`, with `w,n ≥ 2`, coordinates `0 ≤ v < w`,
`0 ≤ y < n`, and physical color `v+y mod 2`. Write `u~v` for adjacent
transverse coordinates. At color `p`, a column front has cutoff vector `b`
with

    l_p(v) = (p-v mod 2)-2 ≤ b_v ≤ u_p(v)
    u_p(v) = n-1-((n-1-p+v) mod 2),
    b_v ≡ p-v (mod 2).

Its rooms are `(v,y)` of color `p` with `0 ≤ y ≤ b_v`. The values `-2,-1`
are canonical empty-column sentinels. No Lipschitz or monotonicity condition
is imposed on adjacent cutoffs. In particular jumps of three are allowed.

Define the healing vector and two boundary indicators by

    h_v(b) = max( {0} ∪ {(b_u-b_v-1)/2 : u~v} ),
    r_top,v(b) = 1[b_v=n-1],
    r_bot,v(b) = 1[b_v=-1 and b_u=-2 for every u~v].

All are nonnegative integers. Write `H=Σh`, `R_top=Σr_top`, `R_bot=Σr_bot`,
and `R=R_top+R_bot`.

## Theorem: exact physical movement

The actual graph neighborhood of the front is a column front of the
opposite color, with canonical cutoffs

    M(b)_v = b_v + 1 + 2 h_v(b)
                       - 2 r_top,v(b) - 2 r_bot,v(b).          (1)

Thus healing is the exact upward correction needed when a taller adjacent
column defeats the putative uniform vertical shift. Boundary regulators
are the exact downward corrections from the missing neighbor above the
board and from a bottom room having no possible predecessor.

### Proof

A room in column `v` can have a predecessor in that same column or in an
adjacent column. The largest transverse candidate is `max_{u~v} b_u`,
ignoring negative entries because they represent empty columns. If the
source column is nonempty, its longitudinal candidates have top
`b_v+1`, except that `b_v=n-1` is clipped to `n-2`.

Away from that top exception, and when `b_v≥0`, the largest candidate is
`max(b_v+1,max b_u)`. All candidates have the required opposite parity,
and subtracting `b_v+1` gives exactly `2h_v`. The neighbors of a cutoff
`n-1` have the opposite parity and cutoff at most `n-2`, so `h_v=0` in
the top exception and the correction is exactly minus two.

If `b_v=-2`, the opposite empty sentinel is `-1`; the same maximum
`max(b_v+1,max b_u)` is correct, including when all transverse columns
are empty. If `b_v=-1`, the virtual value `b_v+1=0` is correct precisely
when some transverse column contains its bottom room. Otherwise every
transverse cutoff is `-2`, the true opposite empty sentinel is `-2`,
and this is exactly the bottom correction. These alternatives are
exhaustive. Taking predecessors also shows that every room below the
reported cutoff with the required parity is present, proving the front
claim and (1).

## Corollary: exact daily and cumulative action

Let `a_0,...,a_T` be the actual beliefs of one initial-color cohort. For `t=0,...,T-1`, on day
`t+1` remove useful inspections from `a_t` to obtain a column front `b_t`,
then set `a_{t+1}=M(b_t)`. Put

    i_t = |A_t \ B_t| = (Σa_t - Σb_t)/2.

There is no assumption that the successive supports are nested, even after
identifying equal physical colors. Then

    i_t = (Σa_t - Σa_{t+1} + w)/2 + H(b_t)-R(b_t),             (2)

and hence

    Σ i_t = (Σa_0 - Σa_T + wT)/2
                     + Σ H(b_t) - Σ R(b_t).                 (3)

Both follow by summing (1), and (3) telescopes (2). Every actual daily quota
remains the separate constraint `i_t≤k`; summing it is not an equivalent
feasibility criterion. For two cohorts, sum the two identities and retain
`i_t^(0)+i_t^(1)≤k` on each actual day.

Capture on day `T` means the post-inspection support is empty. To use (3)
we append the harmless convention `N(∅)=∅` after that final inspection.
No physical princess is claimed to move after capture. The final cutoff
vector is therefore the canonical empty vector in phase `p+T`. The same
convention covers an already captured cohort during subsequent days when
the other cohort remains possible.

## Exact local exchange in the smooth subclass

Suppose adjacent cutoffs differ by one and `v` is a legal local maximum
at nonnegative height `J`. Let `F_v` lower that cutoff by two. Then:

* If `J=n-1`, `M(F_v a)=M(a)`. This one inspection is swallowed by the
  top clipping; it has no immediate effect on the next belief.
* If `1≤J≤n-2`, `M(F_v a)=F_v M(a)`.
* If `J=0`, first perform `F_v` on `M(a)`, then perform `F_u` for every
  neighbor `u~v` whose transverse neighbors all have cutoff `-2` in
  `F_v a`. The result is exactly `M(F_v a)`.

For the last case those additional vertices have old cutoff `-1`; removing
`v` makes their bottom room have no predecessor. They are mutually
nonadjacent on a path and the indicated flips are legal in any order.
These formulas follow directly from (1). They quantify failure of
commutation; they do not assert cost-preserving commutation across days.

## Why the roughness term is essential

The accepted 25×26, k=13, 188-day solo witness is a column-front history,
but 76 of its beliefs and 78 of its survivors fail the adjacent-difference-
one condition (their largest jump is three). Its first survivor already
has a jump from 19 to 16. It cannot be justified solely by the smooth legal-
maximum descent theorem.

The independently replayed totals are:

    actual useful inspections     2433
    virtual endpoint work         2675
    healing                         78
    top regulator                  135
    bottom regulator               185

Indeed `2433 = 2675 + 78 - 135 - 185`. Ignoring roughness would undercount
its useful inspections by 78. Its known same-color reentries cause no
problem for (1)--(3).

The accepted 16-row shape-changing solo witnesses also obey the identity:

* length 22, four days: `196 = 208 + 0 - 1 - 11`;
* length 34, six days: `308 = 320 + 0 - 1 - 11`.

These use the complete solo sequences from
`research/bridge-quadratic-edge-exception-splice.json`, not just their
transport subblocks.

## Validation and boundaries of the claim

`src/closure_20260918_boundary.py` computes physical neighborhoods by
literal room adjacency, independently of formula (1). The smooth-front
local-exchange audit covers 2,284 fronts and 4,251 legal cell removals on
widths 2 through 7 and lengths between the width and 8. It includes 500
top-swallowed removals, 3,251 interior removals, and 500 bottom removals.
`boundary-witnesses.json` records the full day-by-day physical replay of
the three cited existing strategy witnesses.

No new capture-time value, full-game lower bound, or Lean theorem is claimed.
The next necessary mathematical step is an inequality bounding the
**cumulative healing-minus-regulator term under every individual daily
quota**, preferably jointly for a forward and backward history. Replacing
those separate constraints by total ammunition is known to lose the game.

## Extension to arbitrary physical supports: the signed hole correction

For an arbitrary single-color support `A`, let `E(A)` fill each column
below its highest occupied room, and put `q(A)=|E(A)\A|`. Empty columns
retain their canonical sentinel. Then the following exact identity holds:

    E(N(A)) = N(E(A)).                                         (4)

Indeed, the highest occupied room in each target column depends only on
the highest occupied room of the source column and its transverse
neighbors. Longitudinal reflection at the top sends `n-1` to `n-2`;
all other highest candidates are as in the proof of (1). Hence the two
sides have the same highest room in every column. `N(E(A))` is itself a
column front by (1), which proves (4).

For a completely unrestricted physical history, let `A_t` be the actual
belief, `B_t=A_t\S_t` its actual survivor, `A_{t+1}=N(B_t)`, and let
`a_t,b_t` be the cutoffs of their respective envelopes. Only useful
inspections are counted. Then

    i_t = (Σa_t - Σa_{t+1} + w)/2 + H(b_t)-R(b_t)
                                              + q(B_t)-q(A_t). (5)

Summing and adding/subtracting `q(A_{t+1})` yields

    Σ i_t = (Σa_0 - Σa_T + wT)/2 + q(A_T)-q(A_0)
          + Σ [ H(b_t)-R(b_t) + q(B_t)-q(N(B_t)) ].             (6)

This follows because
`|A_t|-|B_t| = |E(A_t)|-|E(B_t)| + q(B_t)-q(A_t)`, followed by (1)
and (4). There is **no normal-form assumption** in (5)--(6).
For a full initial color class and terminal capture, both endpoint hole
counts vanish. The two-cohort full game is again obtained by addition,
retaining the shared inspection constraint each day.

The hole drift is genuinely signed and cannot be discarded:

* On a 2×4 board, `B={(1,3)}` has envelope `{(1,1),(1,3)}` and one hole.
  Its actual neighborhood `{(0,3),(1,2)}` has two holes below its column
  tops. Thus `q(B)-q(N(B))=-1`.
* On a 2×3 board, `B={(0,2),(1,1)}` has one hole, while its neighborhood
  `{(0,1),(1,0),(1,2)}` has none. The hole drift is `+1`.

The independent exhaustive audit checks (4), the cutoff formula, and
one-step hole-corrected cardinality on 3,416 subsets across boards of
widths 2--4 and lengths 2--5. See `boundary-holes-audit.json`.

Equation (6) removes the logical gap from projecting arbitrary supports,
but it does not remove the mathematical difficulty. In fact, its
one-step correction is exactly the neighborhood surplus minus the
uniform interior growth. A sharp lower bound still needs to control
which corrections can occur successively under the daily budget.
Calling the identity a new lower bound would be incorrect. Its useful
content is identifying the three separate mechanisms any proposed
boundary calibration must account for: transverse healing, physical
boundary relief, and creation or healing of holes below occupied tops.

## A nonnegative combination: holes cannot outperform envelope healing

There is a useful inequality stronger than treating the last correction as
an arbitrary signed quantity. For every single-color support `S`, with
cutoff vector `b` of its envelope,

    H(b) + q(S) - q(N(S)) ≥ 0.                                (7)

Equivalently, with `gamma_p = #{v : (p-v mod 2)=1}`,

    |N(S)| ≥ |S| + gamma_p - R(b).                            (8)

This is a geometric lower bound for unrestricted supports, using only
which columns touch the top and which bottom-empty columns have no
nonempty adjacent column. It does not assert reachability of equality
or an optimal capture time.

### Proof without a normal-form assumption

Write `S_v` for the occupied source heights in column `v` and
`s_v=(p-v mod 2)`. If `S_v` is nonempty, split its heights into `c_v≥1`
maximal runs with spacing two. Its longitudinal neighborhood has exactly

    |S_v| + c_v - 1[0∈S_v] - 1[n-1∈S_v]

rooms: each run of `j` rooms gives `j+1` adjacent opposite-parity heights,
with one lost at each physical end it touches, and distinct runs have
disjoint longitudinal neighborhoods. Therefore this count is at least

    |S_v| + 1[s_v=1] - 1[b_v=n-1].

Indeed `s_v=1` prevents `0∈S_v`, while if `s_v=0`,
`c_v-1[0∈S_v]≥0` suffices.

If `S_v` is empty with `s_v=1`, then either an adjacent source column
is nonempty, in which case it supplies at least one transverse neighbor
in column `v`, or all adjacent source columns are empty, which is exactly
`r_bot,v(b)=1`. An empty column with `s_v=0` requires no contribution.
Summing these separate target-column lower bounds gives (8). Formula (1)
gives `|N(E(S))|-|E(S)|=gamma_p+H(b)-R(b)`. Subtracting the holes from
both sides turns (8) into (7).

For an arbitrary full-initial-cohort history, (8) implies the genuine lower
inequality

    Σ i_t ≥ |A_0|-|A_T| + Σ gamma_(p+t) - Σ R(b_t).            (9)

The individual day version remains valid and should be used when daily
budgets matter. This still requires a bound on attainable boundary contact
histories to yield a new deadline bound. Merely maximizing `ΣR` without
its physical evolution would discard the information we are trying to
recover.

The inequality explains the negative hole-drift examples above: holes may
multiply, but only by consuming at least as much of the envelope's
transverse-healing contribution. For a smooth envelope (`H=0`), holes
cannot multiply under movement.


## Reproduction

From the project root, `python3 src/closure_20260918_boundary.py` reproduces
all boundary, hole, and existing-witness receipts. Input/source hashes are
recorded in `boundary-audit-sources.json`. The independent numeric review
is reproduced separately by
`python3 src/closure_20260918_boundary_numeric_review.py`.

# Independent review of the whole minimum-budget clock decomposition

18 September 2026. Reviewed `numerical-clock-action.md` without importing
its implementation. Accepted the exact split, the two-day tail comparison,
and the root-free ceiling-iteration identity. No gap found.

## Upper-band proof reconstructed

For band `D`, `2≤D≤N=b-1+[b odd]`, its upper endpoint is explicitly

    U_D=b(b-D+1)+j(j+1), j=floor((D-1)/2).

The width is `W_D=b-D` for even D and `W_D=b` for odd D. The band is
`U_D-W_D+1 ≤ y ≤ U_D`. This gives a direct verification of the stated
translation bands, rather than inferring them from sampled trajectories.

For `D=2j`, put `r=b+1-j`. Then `U_D=r(r-1)`. Throughout this band,
`Q(y)=r` and `R(y+Q(y)-(b+1))=r`, so a paired step loses exactly `2j`.
For `D=2j+1`, use the same r: the upper endpoint is `(r-1)^2+j`.
Throughout this band, the two roots are respectively `r,r-1`, so the
loss is `2j+1`. The inequalities follow directly from the strict lower
and weak upper definitions of the square and pronic roots. The lower
survivor after these upper bands is the displayed `U-e_N`.

The entry overshoot `e_(D-1)≤D-2` can skip a short even band, but its
count `ceil((W_D-e_(D-1))/D)` never becomes negative. Since subtracting
`W_D` is the same modulo D as subtracting b, the stated Josephus update
is exact even for a skipped band.

## Tail comparison

For every `0<y≤U`, both phase maps are nondecreasing. A full pair from
U loses at least `b+1` for even b and `b+2` for odd b, unless it captures
earlier. Since `e_N≤N-1<b`, that pair reaches a value below `U-e_N`.
The phase after two steps is the original Q phase, so comparing future
iterations yields

    K_b(U)-2 ≤ K_b(U-e_N) ≤ K_b(U).

The phase alignment is essential and is preserved in the proof. The
edge case b=2 has N=1, no upper bands, e=0, U=2, and L=K=2. The b=3
case also agrees directly.

## Ceiling hitting-time identity

In `x'=x+ceil(x/b)`, band D is `((D-1)b,Db]` and the increment is D.
Its entry is `(D-1)b+1+e_(D-1)`, so its duration is
`ceil((b-e_(D-1))/D)`. Relative to the original paired-band count this
adds one precisely in even bands. Band 1 lasts b steps. Hence

    s=b+P_b+floor(N/2), x_s=bN+1+e_N.

The target convention `x_s>bN` is correct; replacing it by `≥` would
change some cases.

## Asymptotic and limitations

The displayed summation-by-parts identity and the `b=j!-1` lower bound
for the weighted remainder sum are algebraically correct. The proposed
smooth tail comparison also has valid constants: its three aggregate
error terms are at most `16/7`, `162/49`, and `18/7`, whose sum is less
than 9. This supports the stated O(1) tail error, but not an exact
rounding formula. No impossibility result for a different bounded
expression follows from the Josephus correspondence.

## Independent finite validation

`src/closure_20260918_boundary_numeric_review.py` independently evaluates:

* the original two-coordinate deficit recurrence;
* the alternating actual survivor recurrence;
* the Josephus action split;
* the root-free ceiling hitting time.

All 1,023 widths indexed by `b=2,...,1024` agree. The tail sandwich holds
throughout. In addition, every one of 218,832 integer points in the
upper bands for `b≤96` has the claimed exact paired decrement. Receipt:
`boundary-numerical-review.json`. These are supporting audits; the
reconstructed proofs above establish the uniform statements.

# Exact slack, equality rigidity, and a bounded-column stability lemma

18 September 2026. Follow-up to `boundary-accounting-theorem.md`.
These are necessary geometric conditions for unrestricted physical supports.
They do not establish a new capture-time value.

## Exact local nonnegative decomposition

Keep its notation. For source fiber `S_v`, let `m_v=|S_v|`, let `c_v` be
its number of maximal runs with spacing two (zero if empty), and put
`alpha_v=1[0∈S_v]`, `s_v=(p-v mod2)`. Define the two target-fiber sets

    V_v = {y in the board : |y-z|=1 for some z∈S_v},
    W_v = union of S_u over transverse neighbors u~v,
    z_v = |W_v \ V_v|.

The local slack `sigma_v` is exactly:

* nonempty fiber, `s_v=0`: `c_v-alpha_v+z_v`;
* nonempty fiber, `s_v=1`: `c_v-1+z_v`;
* empty fiber, `s_v=0`: `|W_v|`;
* empty fiber, `s_v=1`: `max(0,|W_v|-1)`.

Then

    sigma(S):=|N(S)|-|S|-gamma_p+R(E(S)) = Σ_v sigma_v.        (10)

Each summand is manifestly nonnegative. This is not an unnamed residual:
it specifies separate integer defects for extra runs, failure of an
even-height fiber to touch the bottom, and transverse cells lying outside
the longitudinal neighborhood. For an empty odd-height fiber, one incoming
cell is already credited by the base inequality, so only additional cells
count as slack.

Proof: for a nonempty fiber,
`|V_v|=m_v+c_v-alpha_v-1[n-1∈S_v]`, and its entire target fiber is
`V_v∪W_v`. Subtracting the exact local term used in inequality (8) gives
the first two cases. The empty cases follow directly. Sum over columns.

## Equality characterization

For `w,n≥2`, `sigma(S)=0` **if and only if** `S` is a downward pyramid:
every occupied fiber is a bottom initial segment, and its canonical
cutoffs satisfy `|b_(v+1)-b_v|=1` on every adjacent pair.

Proof of necessity. All local summands vanish. A nonempty even-height
fiber has one run containing zero. A nonempty odd-height fiber has one
run. If that odd run began at height at least three, take any adjacent
even-height fiber (one exists because `w≥2`). If the neighboring fiber
is nonempty, it contains zero, which lies outside the odd fiber's
longitudinal neighborhood, giving positive transverse slack in the odd
column. If the neighboring fiber is empty, it receives all cells of the
odd fiber transversely, giving positive slack in that empty even column.
Either alternative contradicts equality. Hence every odd run starts at
one and all fibers are bottom initial segments. Thus S is a column front,
with no holes before or after movement. Equation (7) now gives `sigma=H`.
Vanishing H in both directions on each transverse edge is exactly adjacent
cutoff differences one. Sufficiency follows from the movement formula.

Thus the inequality has a rigid equality class even though it is valid
for completely arbitrary sets. This makes equality usable without first
assuming a strategy normal form.

## Quantified near-equality without a false edit-distance claim

Let `D={v:sigma_v>0}` and suppose `sigma(S)≤d`. Then `|D|≤d`.
Remove `D` and its transverse neighbors, at most `3d` columns. On each
remaining interval of columns:

1. Every nonempty fiber is a bottom initial segment.
2. Adjacent canonical cutoffs differ by one.

To prove (1), a zero-slack even column is anchored as above. A zero-slack
odd column has one run; if it floats above height one, *every* neighboring
even column must have positive slack, by the two-case equality argument.
Therefore such a floating column is adjacent to D and has been removed.
For (2), take two retained adjacent columns. They are bottom initial
segments. A cutoff difference greater than one would produce transverse
spill at the lower column. If it is a nonempty column or an empty even
column this is directly positive slack. If it is an empty odd column,
a neighboring even cutoff at least two supplies at least two incoming
cells, again giving positive slack. Thus the difference is one.

This is a bound on the number of exceptional **columns**, not on the
number of exceptional cells or their height. For example, on width two,
a vertically shifted solid pair of long fibers can have slack one while
leaving arbitrarily many holes below their tops. A claimed O(d) cell edit
distance from a bottom pyramid would therefore be false.

## What this says about 24×24 at budget13

For a full solo cohort on even width `w=2r`, the exact daily identity is

    |A_(t+1)| = |A_t|-i_t+r-R(E(B_t))+sigma(B_t).

With empty terminal support and unused budget `u_t=k-i_t≥0`, summation
is exactly

    |A_0| = (k-r)T + Σ_t [ R(E(B_t))-sigma(B_t)-u_t ].          (11)

The unused-budget term is essential: adding idle days cannot manufacture
useful boundary credit.

On 24×24 with k13, a 103-day solo strategy would therefore require net
boundary credit `288-103=185`. The known 104-day solo witness has zero
slack on every day, top regulator86, bottom regulator109, and unused
quota11, giving net credit `195-0-11=184` as (11) requires.

This isolates the desired missing statement: every 103-day physical
history would need to have net credit at most184. The new equality lemma
does not itself establish that statement. In particular, it would be
invalid to infer that a proposed 103-day history has zero slack: additional
boundary contact might compensate for positive slack. Likewise, the
existing day28 numerical possibilities `(177,1),(177,2),(178,2)` do not
specify these columnwise defects, so they cannot yet force equality here.

A valid use of rigidity would first prove a global upper bound on available
boundary credit (including unused quota), then show that attaining its
limiting value requires equality in selected local inequalities. At those
days, (10) identifies the exact allowable fronts; with one unit of slack,
it restricts exceptions to at most three columns. This supplies an explicit
geometric equality test, not a proof that an equality schedule is impossible.


## Independent literal-set corroboration

The local decomposition, equality characterization, and exceptional-column
bound were checked on all 3,416 single-color subsets of boards with widths
2--4 and lengths 2--5. Exactly 212 cases have zero slack, and all and only
those are smooth downward pyramids. The 24-square benchmark was replayed
from its existing 104-day source schedule. Receipt: `boundary-rigidity-audit.json`.
All are reproduced by `python3 src/closure_20260918_boundary.py`.

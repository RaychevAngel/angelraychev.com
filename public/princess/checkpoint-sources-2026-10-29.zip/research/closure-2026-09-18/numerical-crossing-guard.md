# A fixed-size exact scalar test for a crossed exceptional successor

18 September 2026. Arithmetic lane. Ordinary algebra; independently compared
with the full feasible input polygon. This removes the optimization inside
one proposed orientation guard. It **does not prove that every genuine
solo layer satisfies the guard**.

## Domain

Fix an odd rectangle `(2b+1) by n`, n odd and at least 2b+1, with b>=1,
color capacities E=(wn+1)/2 and M=E-1, and feasible budget m>=b+1.
Write I_p for the exact maximal neighborhood inverse. At a proper true solo
layer `(a,c)->(I_0(c+m),I_1(a+m))`, assume the numerically larger initial
cohort remains larger after movement, so `(a-c)(a'-c')<0`. Put
A=max(a,c), B=min(a,c), and p equal to the new physical color of that
cohort. No new solo is at its full color capacity. Set S=A+m.

We test whether ANY synthetic oriented source

```
primary>=secondary>=0,
primary<=A, secondary<=B, primary+secondary<=A
```
can produce a target `0<u<=v` with `u+v>min(a',c')` by splitting a full
quota m. We allow source totals below B as well; this only makes the test
stronger than exceptional-source propagation.

## First reduction: the entire feasible polygon

Let X=primary+m-q and Y=secondary+q be the inverse inputs. Feasibility is
exactly

```
X,Y>=0,  m<=X+Y<=A+m,  Y<=B+m,  Y-X<=m.
```
For sufficiency choose secondary=max(0,Y-m), primary=X+Y-m-secondary,
and q=Y-secondary. These choices satisfy all displayed source and quota
constraints. Necessity follows by addition and primary>=secondary.

For any fixed X the largest feasible Y is

```
Ymax=min(A+m-X,B+m,X+m),
```
provided Ymax>=max(0,m-X). If a crossed exceptional target exists for this
X, it also exists at Ymax: I_(1-p)(Y) and the target total are nondecreasing
in Y. This is an exact reduction, not a heuristic boundary search.

## A<=2B on proper genuine solo layers when m>=3

The accepted proper-solo gap bound is A-B<=m-1
(`bounded-odd-frontier.tex`, the proper-input argument near line148).
Initially both inverses are at most m-1 and at least m-R(m), where
R(z)=ceil(sqrt(z)). For m>=3, `2R(m)<=m+1`, so A<=2B at layer1.
By layer2, monotonicity gives

```
B >= 2m-R(m)-R(2m-R(m)) >= m-1.
```
For the second inequality put r=R(m), h=m-r+1. From 2r<=m+1,
h>=(m+1)/2 and h(h-1)>=(m²-1)/4>=m-1, so h²>=2m-r.
Physical-coordinate solo capacities are nondecreasing, so B>=m-1 persists;
together with the gap bound it gives A<=2B at all subsequent layers.
All bounds are used before saturation. The m=2 case belongs to width3 and
may instead be checked directly; it is not needed for the unresolved widths.

Consequently Ymax=min(X+m,S-X). Its increasing part is jointly monotone
in X and Y until X=ceil(A/2). At that first maximum-total point,
Y=floor(A/2)+m, so Y-X>=m-1>=b. Proper positive inverse inputs satisfy
`I_p(X)<=X-1` and `I_(1-p)(Y)>=Y-(b+1)`, hence u<=v there.
Thus a crossed positive target on the increasing roof is dominated by a
crossed target at the first diagonal point. If the target there has u=0,
all earlier targets also have u=0. It is therefore enough to test

```
X+Y=S,   X>=ceil(A/2).
```

## A constant-width midpoint strip handles orientation exactly

On proper common inputs,

```
I_1(z)<=I_0(z)<=I_1(z+2).
```
The first inequality follows componentwise from the inverse penalties

```
delta_0(z)=min(rho(z),b,rho(M-z)),
delta_1(z)=min(R(z),b+1,1+R(E-z)),
I_p(z)=z-delta_p(z),
rho(z)=least r>=0 with z<=r(r+1).
```
For the second, each possible minimal delta_0 branch bounds the matching
delta_1(z+2) branch by delta_0(z)+2. The elementary root comparisons are
`R(z+2)<=rho(z)+2` and `1+R(M-z-1)<=rho(M-z)+2`.
Saturation at z+2>=E is harmless for proper I_0(z).

Also `I_p(z+2)>=I_p(z)+1` whenever z>=1 and the right side is not past
the full capacity. This follows since consecutive *positive-size* profile
values rise by at most2. The exception I_1(0)=I_1(2)=0 is real; it is not
used below because the crossed targets under consideration are positive.

Therefore:

- If Y>=X+2, then `I_p(X)<=I_(1-p)(Y)` for either p.
- If X>=Y+4, then `I_p(X)>I_(1-p)(Y)` for positive targets. For p=0
  even X>=Y+2 suffices. For p=1 combine interlacing with the strict
  two-input increase from Y+2 to X.

Set

```
L=max(ceil(A/2),2+p),
H=floor((S-2)/2).
```
The term 2+p is the first input with I_p(input)>0. On the entire interval
L<=X<=H the crossed orientation is automatic. Outside this interval it
is enough to evaluate the at most THREE integers

```
max(L,H+1)<=X<=floor((S+3)/2)
```
and retain those satisfying `0<I_p(X)<=I_(1-p)(S-X)`.
Every larger X is impossible. This is an absolute finite case distinction.

## Exact two-candidate minimum for opposite square/pronic roots

Let F(r)=r(r+alpha), G(s)=s(s+beta), alpha,beta in {0,1}; let root_F and
root_G be their least nonnegative integer inverses. For 0<=L<=H<=V put
r0=root_F(L), s0=root_G(V-H). Then

```
min_(L<=x<=H) [root_F(x)+root_G(V-x)]
 = min(
     r0+max(s0,root_G((V-F(r0))_+)),
     s0+max(r0,root_F((V-G(s0))_+))
   ).
```
Proof: a pair r,s with r+s=t supports some x in the interval exactly when
r>=r0, s>=s0, and F(r)+G(s)>=V. For fixed t, the function
F(r)+G(t-r) is convex on the integer interval r0<=r<=t-s0. If it meets
V anywhere, it meets V at one of the two endpoints. Minimizing t for
those endpoint alternatives gives the displayed formula. This proves
both necessity and attainment.

This is different from evaluating the ORIGINAL interval endpoints L,H;
that shortcut fails on actual solo layers. The candidate fixes one root
at its minimum possible value and then uses its entire capacity plateau.

## Exact fixed-size guard

On L<=X<=H,

```
u+v=S-delta_p(X)-delta_(1-p)(S-X).
```
Each delta is the minimum of three branches, so minimizing their sum is
exactly the minimum of nine branch-pair minima. Each pair is:

- two constants;
- a constant plus one monotone root (choose the appropriate endpoint);
- two roots with the same direction (choose the appropriate endpoint);
- opposite roots with constant total argument (use the two-candidate lemma).

There is therefore a fixed number of arithmetic/root/floor operations to
compute the maximum crossed-target total on the whole polygon: combine
this nine-branch calculation with the at most three midpoint checks. The
candidate guard is that this maximum is <=min(a',c').

`guard_value` in `src/closure_20260918_numeric_root_guard.py` implements
this fixed expression with direct inverse formulas. It does NOT allocate
profiles, do binary search, or iterate a parameter-sized interval. Arrays
and variable loops occur only in the separate independent reference tests.

## Checks, failures, and remaining obligation

The two-root minimum passed49,364 interval/type cases with V<=40.
The fixed guard matched a full-polygon enumeration on259 retained-fastest
layers of selected odd squares, including129 by129 with budget130.
The earlier broad targeted polygon audit covered50 parameter triples,
2,195 true solo layers and6,028,225 roof points; it found no crossed
exceptional successor. None of these checks proves the true-orbit guard.

An original-endpoints-only maximum fails49 times among252 diagnostic
layers, usually by one. One actual example is11 by11, m=7, old solo
(14,12), next(15,16): the diagonal endpoints have total14 but the interior
input (9,12) has target(6,9), total15. The root-plateau formula captures it.

The previously documented synthetic trace
(4,5)->(9,7)->(10,12)->(15,12) still defeats a generic-capacity propagation
claim. The theorem above is an EXACT TEST, not a proof that zero-start
orbits satisfy that test. The next mathematical obligation is to exploit
the finite root-branch description to derive a genuine scalar-orbit
invariant, or establish the inequality directly from the full-start orbit.

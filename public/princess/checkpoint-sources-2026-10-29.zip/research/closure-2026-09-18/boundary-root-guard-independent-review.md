# Independent review of the fixed-size crossed-polygon root guard

18 September 2026. Reviewed `numerical-crossing-guard.md` and the current
`src/closure_20260918_numeric_root_guard.py`. The exact local evaluator is
accepted. It does not prove the proposed guard on every genuine solo orbit.

## Convex root-capacity lemma

For root capacities `F(r)=r(r+alpha)` and `G(s)=s(s+beta)`, a pair `(r,s)`
can cover some split `L≤x≤H`, `x+(V-x)=V`, if and only if

    F(r)≥L, G(s)≥V-H, F(r)+G(s)≥V.

Indeed these conditions say that the intervals `[L,H]` and
`[V-G(s),F(r)]` intersect. They give exactly the claimed lower bounds
`r≥r0`, `s≥s0`. At fixed sum `r+s=t`, capacity `F(r)+G(t-r)` is convex
on the integer segment `r0≤r≤t-s0`, so its maximum is at an endpoint.
Thus if any root pair of total t works, one with `r=r0` or `s=s0` works.
The two displayed formulas are precisely the least t for those two
choices. Both zero-root cases and degenerate intervals are included.

## Source polygon and diagonal reduction

The stated witness for feasibility of `(X,Y)` is valid:
`secondary=max(0,Y-m)`, `primary=X+Y-m-secondary`, `q=Y-secondary`.
The four polygon inequalities guarantee `0≤q≤m`, nonnegative ordered
source coordinates, their sum at most A, and secondary at most B.
The assumption `A≤2B` makes the `B+m` roof redundant globally.

An earlier increasing-roof point is dominated coordinatewise by the
first diagonal point. If it has positive crossed output, that diagonal
point does too: its input separation is at least `m-1≥b`, while
`I_p(X)≤X-1` and `I_(1-p)(Y)≥Y-(b+1)` force the correct orientation.
This argument preserves orientation; coordinatewise domination alone
would not have sufficed.

The proof of `A≤2B` on proper true layers when `m≥3` is sound. In
particular `2ceil(sqrt(m))≤m+1`, and the displayed lower estimate at
layer two is strong enough to give `B≥m-1`. The m=2 special case is
explicitly excluded from that derivation, as it should be. The evaluator
itself remains conditional on `A≤2B` and passed the small m=2 cases
independently checked below.

## Orientation strip

The componentwise penalty comparisons establish
`I_1(z)≤I_0(z)≤I_1(z+2)` on proper common inputs, including harmless
saturation in the latter argument. The strict two-input increase is
valid when starting above the exceptional zero input. Positive crossed
targets ensure this condition when it is needed.

Consequently `Y≥X+2` guarantees crossed orientation, while
`X≥Y+4` excludes it. The automatic interval ends at
`floor((S-2)/2)`. The remaining candidates through `floor((S+3)/2)`
number two for even S and three for odd S. The code filters these by the
actual inverse values, so the conservative strip introduces no error.

The nine branch-pair minima are an exact interchange of finite minima.
Their monotone and opposite-direction cases are exhaustive. The current
`guard_value` uses direct inverse expressions; no profile array or
parameter-sized preprocessing occurs inside it. Its only integer loop
has at most three iterations.

## Independent physical-profile audit

`src/closure_20260918_boundary_guard_review.py` uses a separate integer-
root implementation and independently constructs odd-rectangle prefix
neighborhood profiles from literal room adjacency. Its reference
polygon check enumerates *all* integer feasible `(X,Y)` pairs, not just
the roof or the proposed midpoint strip.

* 26,180 interval/root-type cases through V=32 agree with the two-candidate
  convex formula.
* 23,947 entire source polygons on boards 3×3, 3×5, 3×9, 5×5, 5×9,
  7×7, 9×9, and 11×11 agree with the fixed expression. These include
  synthetic A,B satisfying the explicit conditions, not only true orbits.

The literal prefix ordering must prioritize the shorter transverse
coordinate on equal diagonals; an initial audit with the opposite tie
order correctly exposed that reference-model error on 3×5. The corrected
reference uses `(x+y,-x)` and agrees on all cases. No failure of the
proposed guard evaluator was found.

Receipt: `boundary-root-guard-review.json`. Reproduce with
`python3 src/closure_20260918_boundary_guard_review.py`.

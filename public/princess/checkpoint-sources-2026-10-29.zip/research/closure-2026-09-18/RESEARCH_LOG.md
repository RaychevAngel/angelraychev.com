# Rectangle closure research, 18 September 2026

Authorized by the user's “I agree. Go execute.” following selection of the
paired-geometry, whole-clock arithmetic, and boundary-accounting routes.
The fixed-operation numerical completion criterion is unchanged. This is
private research; no new global classification or Lean verification is implied.

## Starting point

All four original residual families still have an unfilled part. In particular
24 by 24 at budget 13 has full-game bounds 206 and 207, and solo bounds 103
and 104. The minimum-budget odd width clock has an exact recurrence, but no
accepted fixed-operation expression. The public checkpoint is the September
13 release, not the results of this new pass.

The work was divided into independent geometric, arithmetic, and boundary
lanes. Root attacked the odd two-history decision and reviewed the new tools.
Cross-review deliberately used independently implemented physical neighborhoods,
profile inverses, and clock recurrences.

## Boundary accounting: new ordinary proofs

`boundary-accounting-theorem.md` gives an exact physical movement formula for
arbitrary column fronts, then extends it to arbitrary supports using the
column-fill envelope and a signed hole correction. It does not assume an
optimal strategy is monotone or a column front.

The combined roughness-plus-hole correction is nonnegative. The follow-up
`boundary-slack-rigidity.md` decomposes it into explicit nonnegative local
defects. Zero defect forces an actual smooth, bottom-anchored pyramid. Defect
at most d confines failures of this structure to at most 3d columns; this is
not a bound on the number of cells that need changing.

The accepted 25 by 26 solo witness leaves the smooth-front class on many
days. Its exact work accounting is 2433 = 2675 + 78 - 135 - 185. Omitting
the refilling term would lose 78 inspections. The unrestricted extension
and the zero-defect characterization address this logical issue rather
than imposing a false normal form.

For the 24-square solo diagnostic the exact net-credit identity is
288 = T + sum(boundary relief - geometric defect - unused daily quota).
The known 104-day witness has net credit 184. A 103-day witness would need
185. No upper bound of 184 for every admissible history has been proved.
Ignoring daily quotas or assuming all candidate histories have zero defect
would be invalid.

Independent checks and reviews are in `numerical-boundary-independent-review.md`,
`boundary-*-audit.json`, and the physical witness receipts. The proofs, not
the finite checks, establish the displayed general identities.

## Paired geometry: target refined and false inductions rejected

The proposed asynchronous two-history potential, if valid under advancing
either side independently, restricts at the full second history to an ordinary
one-sided potential. It does not bypass the unilateral sharp-initial-value
problem. The useful formulation advances two equally long histories toward
the middle, preserving both daily budgets. Odd horizons end at a vertex
intersection of size at most k; even horizons end at two post-inspection
supports with no edge between them.

`geometry-progress.md` develops the cross-independent-set consequences of
the even terminal condition, including the 24-square diagnostic. These are
necessary middle-shape restrictions, not proofs of attainability or exclusion.

The independently reviewed uniform lemma `geometry-balanced-stability.md`
shows that two anticomplete middle supports of size at least h-s, with
2s<=floor(w/2), are either solo-degenerate or share a dominant physical color
and have minorities at most s^2. If either minority exceeds s(s-1), both
minorities have equal size, the half sizes equal h-s, and the minority islands
lie in their s-square corner triangles with complementary dominant parts.
For the 24-square this means minority size at most 36; a size in 31..36
forces synchronized equal-size islands in the two six-radius corner triangles.
Static examples attain the bound, so temporal reachability is still needed.

Root proposed preserving the capped union of two deficit states by a scalar
bound depending only on the solo clocks. Exact small checks and over 43 million
random admitted transitions found no failure, but independent tests focused
on the constraint facets quickly rejected the proposal:

* On 33 by 33, budget 32, at genuine solo layer (268,270), synthetic sources
  (0,270) and (268,2) satisfy the proposed source conditions. Quotas 0 and 32
  yield (286,0) and (1,283), whose capped union is 570, exceeding the proposed
  bound 569.
* Adding numerical orientation still fails for the stronger capped-sum bound:
  on 129 by 129, budget 130, genuine layer (4098,4091), sources (4096,2) and
  (4098,0), with quotas 130 and 128, both yield (1,4161). Their capped union
  8322 exceeds the proposed cap 8321.
* Even weakening the floor to one below the winning threshold fails without
  ancestry: on 9 by 9, budget 7, layer (33,29), sources (33,0),(4,29) and
  quotas 7,0 yield (0,38),(34,2). The union reaches 74 although the next pure
  clocks sum to 72.

Root independently replayed all three. These are counterexamples to the
listed induction hypotheses. The synthetic mixed sources are not asserted
reachable; none refutes the physical scalar-midpoint conjecture.

The oriented bound with floor E+k survived a boundary-focused true-clock
screen, but fails for some synthetic monotone solo clocks, even with source
and successor orientation. Actual zero-start clock structure remains necessary
for this particular proposed induction. It is not an accepted theorem.

## Arithmetic: exact reduction, and a cancellation route ruled out

`numerical-clock-action.md` decomposes the actual whole minimum-budget clock
into its upper Josephus action and its lower tail. Changing the terminal upper
residue over its full legal interval changes the entire lower tail by at most
two days. The weighted upper action is unbounded: for b=j!-1 the first j
residues are maximal and give a harmonic lower bound. Thus the terminal residue
cannot produce a large automatic cancellation of that action.

The upper action has a precise alternative description by the first time
the root-free iteration x -> ceil((b+1)x/b), starting at 1, exceeds bN.
This is an exact reduction, not an O(1) numerical formula. An unknown
parameter-dependent limiting constant would merely hide the unresolved
iteration. No impossibility theorem for bounded numerical expressions is
claimed.

Independent review `boundary-numerical-independent-review.md` reconstructs
the proof and checks the original, survivor, Josephus, and ceiling clocks
through b=1024, including the small endpoints.

## Exact local orientation guard

The complete synthetic crossing question at a genuine persistent-winner
layer reduces to a feasible input polygon. Its increasing part can be removed;
only a fixed-total diagonal interval and a constant-width midpoint strip remain.
An exact two-candidate minimum for opposite square/pronic ceiling roots then
removes the interval optimization. See `numerical-crossing-guard.md`.

The evaluator uses a fixed nine branch pairs and at most three midpoint
inputs, with direct closed inverses and no profile preprocessing. Arrays are
confined to independent reference tests. This solves the local evaluation
problem. The still-unproved assertion is that every actual zero-start solo
orbit satisfies the resulting explicit inequality.

`boundary-root-guard-independent-review.md` accepts this evaluator after an
independent derivation and literal-grid/full-polygon comparisons. The guard
itself is not a forward-invariant region for arbitrary scalar capacities:
on the 11-square at budget 11 the synthetic pair (11,8) passes, maps to
(15,17), and then fails. The actual zero-start orbit never follows that
displayed synthetic trace. See `geometry-guard-invariance.json`.

The distinction is essential: a fixed-operation guard evaluated at a single
layer is not a fixed-operation solution of the full game, and testing every
layer would still be an input-dependent procedure.

## Additional root diagnostics and failures

* A prospective solo-gap bound 2 ceil(sqrt(k)) is false in low budgets:
  width 385, budget 193 has gap 192. A restricted high-budget scan did not
  falsify it, which is not a proof of that restriction.
* The secondary-deficit bound k/2 fails even above width. On width 129,
  budget 130, an actual retained frontier has minimum coordinate 122.
* Even the weaker bound k fails above width: on the 1537-square, budget
  1538, the actual retained frontier reaches minimum coordinate 1561 at
  day 1159. A complete earlier counterexample has been extracted: at day1141
  the state is (1116773,1539), with solo capacities (1118362,1118311).
  Its 1141 quotas are saved in `root-wide-collar-witness.json` and pass an
  independent binary-search-on-profiles replay. This eliminates the proposed
  simple k-sized collar shortcut.
* Low-budget examples exceeding k also exist, but those alone would not
  reject a conjecture restricted to k>2b. The wide witness does.

Receipts are `root-gap-diagnostics.json`, `root-collar-diagnostics.json`,
`root-high-budget-collar.json`, and `root-wide-budget-collar.json`. The
compiled retained solver enumerates every quota at each retained state;
its authority is the previously proved exact-retention theorem. These
finite results do not prove a uniform collar or orientation bound.

The exact two-interlaced-orbit representation of each physical-color solo
clock is valid. However both colors' elementary initial-spacing bounds do
not force the crossing guard, even entirely within nonexpanding lower bands:
on the 17-square at budget17, the synthetic even-layer pair (24,27) satisfies
those four bounds but maps to (37,34) and has guard value35>34. The genuine
second layer is (24,24); this is again a failed sufficient invariant, not an
actual failure of orientation. See `geometry-interlaced-gap-check.json`.

## Obligations still open

1. Bound the accumulated net boundary credit under each daily quota, allowing
   arbitrary supports and geometric defects. This would close even-area
   lower-bound gaps when matched to constructions.
2. Prove a true-orbit scalar invariant implying the new local crossing guard
   and a sufficient two-history central inequality, or replace both by a
   direct full-board argument. The false synthetic inductions must not return.
3. Evaluate the actual whole width-dependent clock in an absolute fixed number
   of standard numerical operations. A recurrence or limiting constant is
   not a replacement for this obligation.
4. Independently check any resulting global theorem before changing the
   manuscript, public coverage, or complete Lean claims.

No residual family has been declared closed during this pass. New tools and
more precise obstructions are research progress, separate from coverage gains.

# Independent review: balanced anticomplete-half stability

18 September 2026. Read-only mathematical review of
`geometry-balanced-stability.md`, together with the accepted even-area
profile dichotomy and strict subcritical near-square localization.
The stated uniform static lemma is accepted; no mathematical gap found.

## Checks of the proof

1. For an independent set of defect delta<r, the neighborhood surplus
   of either color part is at most delta. In the high profile branch,
   the other color part has size at most `t(t+1)-delta≤t²`. Thus the
   minority bound `delta²` is valid in both profile branches, including
   delta=0. The strict-majority comparison also holds at delta=r-1:
   `2(r-1)²<2r²-(r-1)≤h-delta`.

2. The two cross-history independent sets have total defect at most
   `2s≤r`. A critical defect equal to r forces the other defect zero,
   and a zero defect forces one history to have an empty color part.
   Hence in the genuinely two-colored alternative both defects are
   strictly below r. This correctly avoids an unjustified application
   of the strict subcritical profile at its boundary.

3. If both cross-set majority parts belonged to one history, the other
   would have size at most `delta0²+delta1²≤4s²`, contradicting
   `h-s≥8s²-s>4s²` for s≥1. The s=0 case has already been handled by
   zero defect. Majorities in different histories necessarily share
   the same physical color.

4. The two half-size inequalities have the correct signs. If one
   defect exceeds s, the associated minority is at least one smaller
   than the other, whose defect is at most s-1. This proves the s²
   minority bound and forces both defects to equal s when either
   minority exceeds `s(s-1)`. The same inequalities then force equal
   minorities and exact half sizes h-s.

5. In that strict-square range, a neighborhood surplus below s violates
   both branches of the accepted profile. The high branch is very far
   from possible: `h-q≥7s²`, whereas a surplus below s allows at most
   `s(s-1)` holes. Thus each surplus equals s, and cardinality turns
   neighborhood avoidance into the exact complementary-neighborhood
   identities. The existing finite corner capacities exclude zero or
   two incoming corners and positive outgoing corners for s≥2; the
   s=1 case is the direct degree-two corner test. Strict interval
   localization therefore applies without a critical-radius claim.

6. The static sharpness construction is valid even when the two chosen
   triangles use the same corner. Anticompleteness holds separately
   across the two color pairs, and each half has exactly h-s rooms.
   It correctly demonstrates that temporal reachability, not another
   static exclusion, remains necessary.

## Application boundary

For 24×24 and budget13, the accepted h+7=295 bound after102 steps leaves
at least282 rooms after the next inspection. A proposed206-day schedule
would indeed give two anticomplete103-day postinspection halves, so s=6
is admissible. The conclusions about minority sizes at most36 and the
synchronized31--36 band follow. This does not exclude a monochromatic
half obtainable in103 days, nor the low-minority or localized mixed
alternatives. The source note states these limitations accurately.

No new computational search was required for this proof review.

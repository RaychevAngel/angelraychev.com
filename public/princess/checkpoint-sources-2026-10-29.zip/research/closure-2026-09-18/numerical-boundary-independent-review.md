# Independent review of boundary accounting

18 September 2026. Reviewer: arithmetic lane; distinct implementation from
the boundary lane's diagnostic code. No new optimality claim.

## Conclusion

Accepted the ordinary proofs of movement identity (1), daily/cumulative
accounting (2)--(3), local exchanges in the smooth subclass, envelope
commutation (4), and unrestricted hole-corrected accounting (5)--(6).
No mathematical gap found in their stated domain w,n>=2.

The crucial envelope identity survives arbitrary holes because each target
column's highest neighbor depends only on source-column highest rooms.
At a top source room, reflection gives n-2; lower same-color rooms cannot
produce a higher target. At the bottom, the two canonical empty sentinels
and the isolated-bottom indicator correctly distinguish an absent source
from a source at height zero. Neighborhoods of filled parity prefixes are
again filled prefixes, so equality of column tops proves set equality.

The hole sign in (5) is correct: removing an interior room can create a
hole while leaving the envelope fixed, which increases useful inspections.
In (6), adding and subtracting the next actual belief's hole count telescopes
to q(A_T)-q(A_0). Neither hole drift nor healing-minus-regulator has a fixed
sign, and the note correctly declines to infer a lower bound from identity
alone.

## Independent checks

`src/closure_20260918_numeric_boundary_review.py` uses literal four-neighbor
sets; it imports none of the boundary lane's routines.

- 3,096 arbitrary monochromatic supports across tall, wide, transposed,
  odd, and even boards: checked envelope commutation, the cutoff movement
  formula, and the corrected cardinality surplus.
- 774 arbitrary pairs B subset A, with no prefix assumption: checked the
  useful-inspection formula (5) directly.
- 840 legal local-maximum removals in smooth fronts: checked the three
  exchange cases directly (193 top, 454 interior, 193 bottom).

All passed, including empty supports, singletons at the physical top,
complete columns, alternating empty columns, and final capture.

Minor expository clarification only: the cumulative identities use T
updates indexed t=0,...,T-1; “capture on day T” is then the last of those
T inspections. This is consistent with a_T being the final empty belief,
but the indexing could be stated explicitly to avoid a reader interpreting
sum_t as t=0,...,T inclusive.

## Follow-up: accepted slack rigidity and stability

Independently read `boundary-slack-rigidity.md` and accepted its exact local
nonnegative slack decomposition, equality characterization, and exceptional-
column bound. The floating odd-fiber argument correctly uses w>=2: a
zero-slack odd fiber beginning above height1 forces every neighboring even
fiber to have positive slack, so deleting positive-slack columns and their
neighbors removes it. A remaining large cutoff jump forces positive
transverse spill at its lower endpoint, including the empty odd-fiber case.

The independent code additionally checked1,432 arbitrary supports, including
transposed boards and width5. All local slack identities, equality iff smooth
pyramid, and the <=3*sigma deleted-column conclusion passed. There were218
equality supports. These checks support the proof and do not establish any
new global boundary-credit or capture-time bound.

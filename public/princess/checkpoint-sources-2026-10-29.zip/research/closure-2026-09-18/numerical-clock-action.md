# Whole minimum-budget clock: the Josephus action survives the terminal tail

18 September 2026. Arithmetic lane of the authorized closure work.
This is a private research result and diagnostic, not a bounded-operation solution.
No manuscript, website, or formal-source claim is changed.

## Statement and scope

Let `b>=2`, `m=b+1`, and let `L_b` be the accepted minimum-budget
corner clock in `paper/sections/odd-minimum-budget.tex`. Define

```
N = b-1+[b odd],
U = b²/4+b/2       if b is even,
U = (b²-1)/4       if b is odd,
e_1=0, e_D=(e_(D-1)-b) mod D  (2<=D<=N),
c_D=(b+e_D-e_(D-1))/D-[D even],
P_b=sum_(D=2)^N c_D.
```
Empty sums are zero. Define `K_b(y)` as the number of steps until zero
under the actual alternating post-inspection survivor dynamics, starting
with the pronic phase:

```
y' = max(0, y+Q(y)-m), then max(0, y+R(y)-m), alternately,
Q(y)=least j>=1 with y<=j(j-1),
R(y)=ceil(sqrt(y)).
```
The value at zero is zero; no root at zero is evaluated.
Then the following exact identity and bound hold:

```
L_b = 2P_b + K_b(U-e_N),
K_b(U)-2 <= K_b(U-e_N) <= K_b(U).
```
Thus the lower tail can cancel at most **two days** of dependence on the
terminal upper-segment residue. It cannot automatically cancel the
unbounded weighted-history correction by a large change of tail duration.
This is not an impossibility theorem about other identities or the desired
O(1) expression. `K_b(U)` still depends on b and might have a new identity.

## Derivation of the decomposition

The accepted inverse-duality lemma identifies `L_b+1` with the greedy
clearing time from a minority prefix of `b²+1` cells. Its first inspection
leaves `b(b-1)` survivors. Starting there, the next expansions and
inspections alternate the displayed Q and R maps. Hence their remaining
clearing duration is exactly `L_b`.

For a complete pair, while both intermediate survivor counts are positive,

```
P_m(y)=y-2m+Q(y)+R(y+Q(y)-m).
```
In the upper-root portion its consecutive translation bands have decrements
`D=2,3,...,N`. Their widths are `b-D` at even D and `b` at odd D. If the
entry overshoot is `e_(D-1)`, the number of pairs spent in the band is

```
c_D=ceil((b-D[D even]-e_(D-1))/D),
e_D=e_(D-1)+D*c_D-b+D[D even].
```
The overshoot lies in `[0,D-1]`, giving the stated modulo recurrence and
count formula, including zero-count skipped bands.

The next band's upper endpoint is U. For even b=2h, the two root bounds
there are Q(U)=h+1 and R(U+Q(U)-m)=h at U=h(h+1). For odd b=2h+1,
U=h(h+1) and the same root bounds hold (with the small b=3 endpoint
interpreted directly). This gives the two displayed expressions for U.
The actual survivor value after all these pairs is U-e_N. This proves the
identity.

## Why the entire tail changes by at most two days

Both one-step maps, with their zero truncation, are nondecreasing.
For every y<=U, a complete untruncated pair loses at least

```
b+1, if b is even,
b+2, if b is odd.
```
Indeed the two roots are bounded above by their values at U, whose sum is
b+1 in the even case and b in the odd case; subtract that sum from 2m.
If an intermediate step captures, the claimed comparison is easier.
Since `e_N<=N-1<b`, two steps from U either capture or reach a value
strictly below U-e_N. The next phase is again Q. Monotonicity now gives
`K_b(U)<=2+K_b(U-e_N)`. The reverse inequality follows immediately
from `U-e_N<=U`.

This is a phase-aligned comparison. Using a one-day comparison would have
silently changed the root phase and is not justified.

## The exact action that remains

Write `H_N=sum_(j=1)^N 1/j` and

```
W_b=sum_(D=2)^(N-1) e_D/[D(D+1)].
```
Summation by parts gives

```
P_b=b(H_N-1)-floor(N/2)+e_N/N+W_b.
```
The full clock therefore has the exact representation

```
L_b = 2b(H_N-1)-2floor(N/2)+2e_N/N+2W_b+K_b(U-e_N).
```
The tail comparison shows that replacing `K_b(U-e_N)` by `K_b(U)` incurs
an error of at most two, not a variable amount that could absorb all of W_b.
The weighted action is genuinely unbounded as b varies. For any integer
j>=4, take b=j!-1. Then b=-1 modulo every D<=j, so induction gives
`e_D=D-1` throughout D=2,...,j. Consequently

```
W_b >= sum_(D=2)^j (D-1)/(D(D+1))
    = H_j+2/(j+1)-2 -> infinity.
```
This is an exact algebraic observation, requiring no large computation.
An endpoint formula for e_N alone is therefore not enough by this route.
A successful cocycle identity must evaluate the accumulated action W_b,
combine it nontrivially with the width dependence of K_b(U), or bypass
this representation entirely.

## A proved smooth leading action with an O(log b) residual

There is also a useful uniform asymptotic that follows from the decomposition,
not from fitting:

```
L_b = 2b(log(2b)+gamma-2) + 2W_b + O(1).
```
In particular `L_b=2b(log(2b)+gamma-2)+O(log b)`, because
`0<=W_b<=H_(N-1)+2/N-2` when N>=2. Here gamma is Euler's constant.
The O(1) does not depend on b. This does **not** imply a rounding formula:
W_b is still an accumulated Josephus remainder statistic.

Proof of the only nontrivial estimate: let

```
v(y)=b-sqrt(y),
F_b(y)=integral_0^y dz/v(z)
      =2b log(b/(b-sqrt(y)))-2sqrt(y).
```
For b>=8 and 0<y<=U, put `mu=v(U)>=7b/16`. Each nonterminal step
has decrease d in `[v(y)-1/2,v(y)+1]`, hence
`3b/8<=d<=9b/8`. There are at most b steps. For a nonterminal step
y to y-d, monotonicity of v gives

```
|F_b(y)-F_b(y-d)-1|
 <= 1/mu + (9b/8)*(sqrt(y)-sqrt(y-d))/mu².
```
The square-root differences telescope. Summing the first error term
contributes at most 16/7; summing the second contributes at most 162/49.
The final truncated step contributes at most 18/7. Thus
`|K_b(U)-F_b(U)|<9`.
Since U differs from b²/4 by at most b/2,
`F_b(U)=(2log2-1)b+O(1)` uniformly. The two-day tail comparison completes
the estimate. Finally `b(H_N-log b-gamma)=O(1)` and
`2floor(N/2)=b+O(1)` give the displayed asymptotic.

## Independent checks and failed simplifications

`src/closure_20260918_numeric_clock.py` independently evaluates the original
(A,B) deficit recurrence, the physical alternating survivor recursion, and
the Josephus decomposition. They agree for b=2,...,256. The two-day tail
sandwich passes on the same range. These finite checks support the algebra;
they do not replace the proof above.

A direct modulo law extending `e_D=(e_(D-1)-b) mod D` through the lower
bands fails. For b=12 (m=13), the lower band D=13 has width 11 rather than
a number congruent to b=12 modulo13. Thus a full-clock Josephus conjugacy
needs a new coordinate or new correction, not just continuation of the
upper-band formula.

The simple prospective approximation
`L_b=round(2b(log(2b)+gamma-2)+log b+C)` with a universal C also fails.
Among b=1000,...,1100 the residual after removing those two smooth terms
ranges from 0.044286 at b=1080 to 2.709950 at b=1019. No common C with
one fixed floor/ceiling/nearest-integer rounding can cover that range.
This only rejects this specific ansatz, not more elaborate bounded formulas.

## What is still missing

No bounded-operation evaluation of W_b or the whole L_b has been obtained.
No impossibility claim is made. The exact two-day stability lemma sharpens
the earlier exploratory question: cancellation through the *terminal
residue alone* cannot remove a large accumulated correction. A genuinely
useful next identity must control the action of the whole upper orbit.

The relevant primary literature remains Odlyzko-Wilf (1991),
https://doi.org/10.1017/S0017089500008272, and Halbeisen-Hungerbuehler (1997),
https://math.ch/norbert.hungerbuehler/publications/The_Josephus_problem.pdf.
Their fixed-parameter evaluation results do not supply a uniform formula
when the Josephus step b+1 itself varies.

## Exact hitting-time duality: a root-free alternative to the weighted sum

There is a precise way to replace the whole upper action by one hitting-time
problem. It does not evaluate that problem in bounded work, but identifies
which iteration theory would have to supply the missing identity.

Let

```
x_0=1,
x_(t+1)=ceil((b+1)x_t/b)=x_t+ceil(x_t/b),
s_b(N)=least t with x_t>bN.
```
Then exactly

```
s_b(N)=b+P_b+floor(N/2),
x_(s_b(N))=bN+1+e_N.
```
To prove it, partition the positive integers into bands
`((D-1)b,Db]`. In band D the increment is D. If its first state is
`(D-1)b+1+e_(D-1)`, the number of steps in that band is
`ceil((b-e_(D-1))/D)`, and the next overshoot is
`(e_(D-1)-b) mod D`. Band1 takes b steps; summing the bands proves
both statements, including skipped bands.

Thus the full clock is exactly

```
L_b=2s_b(N)-2b-2floor(N/2)
    +K_b(U-(x_(s_b(N))-bN-1)).
```
This is a direct algebraic duality, independently checked against the original
clock. It removes square/pronic phases and weighted sums from the upper
portion, but replaces them with an iterated ceiling hitting time.

Odlyzko-Wilf's ceiling-iteration theory applies to `alpha=(b+1)/b` and
provides a limiting normalization `C(alpha)` of `x_t/alpha^t`. Here alpha
varies with b. Replacing the loop by a formula that calls this unknown
parameter-dependent constant would violate the completion criterion.
The rigorous potential next target is a uniform fixed-operation expression
for the **hitting time at the specific diagonal target bN**, or a closed
identity combining this hitting time with the residual root tail. A
formula for arbitrary real-alpha iteration is not required. Conversely,
fixed-alpha formulas do not answer the diagonal question.

# Balanced anticomplete halves: a uniform stability lemma

18 September 2026. New ordinary static lemma for the even-area midpoint formulation. This is not a completed lower bound on capture time. It uses the accepted even-area neighborhood profile and the accepted strict subcritical near-square localization. Independently accepted in `boundary-balanced-stability-review.md`; no Lean claim.

## Precise statement

Let G=P_w square P_n be an even-area rectangle, 2<=w<=n. Set

    r=floor(w/2), h=wn/2.

Let s be a nonnegative integer with2s<=r. Let U,W be vertex subsets satisfying

    |U|>=h-s, |W|>=h-s, and no edge joins U to W.

Then at least one of the following alternatives holds:

1. U or W is contained in one checkerboard class.
2. There is a common physical color p such that, writing

       qU=|U intersect V_(1-p)|, qW=|W intersect V_(1-p)|,

   both qU,qW are positive and at most s^2, and color p is the majority in both U and W.

In the second alternative, if either minority exceeds s(s-1), then

    qU=qW=q, s(s-1)<q<=s^2,
    |U|=|W|=h-s.

Moreover both minorities have neighborhood surplus exactly s. Each is contained in the s-square corner triangle Q_s of one corner of its own physical color, and

    U intersect V_p = V_p minus N(W intersect V_(1-p)),
    W intersect V_p = V_p minus N(U intersect V_(1-p)).

When q=s^2, both minorities equal their respective full corner triangles.

The term Q_s means the same-color rooms at taxicab distance at most2s-2 from a corner of that color; it contains s^2 rooms. Its neighborhood has s(s+1) rooms. The lemma does not specify which of the two same-colored corners is used, nor assert that the two histories have a common anchor.

## Proof

### A. Independent-set defect bounds the minority

For an independent set I with|I|=h-delta and0<=delta<r, write A=I intersect V0, B=I intersect V1, a=|A|, b=|B|. A perfect matching implies that the surplus t=|N(A)|-a is nonnegative. Since N(A) avoids B,

    t<=h-a-b=delta.

The accepted even-area profile dichotomy at t<r gives either a<=t^2 or h-a<=t(t+1). In the first case a<=delta^2. In the second,

    b=h-a-delta<=t(t+1)-delta<=t^2<=delta^2.

Therefore min(a,b)<=delta^2. At delta=0 the independent set is exactly one whole color class. Because delta<r and h>=2r^2, the minority is unique whenever delta>0 (indeed delta^2<h/2, while |I|=h-delta and2delta^2<h-delta follows from delta<=r-1 and h>=2r^2).

### B. The cross-history independent sets

Write U_i=U intersect V_i and W_i=W intersect V_i. The anticompleteness assumption makes

    I0=U0 union W1, I1=U1 union W0

independent. By a perfect matching each has size at most h. Define delta_i=h-|I_i|. Then

    delta0,delta1>=0,
    delta0+delta1=2h-|U|-|W|<=2s<=r.

If delta_i=0, part A makes I_i one whole color class, so one of its opposite-color constituents is empty. Consequently U or W is monochromatic and alternative1 holds. This also handles the only possible critical defect delta_i=r: it forces the other defect zero. We may henceforth assume both histories have both colors. Then

    1<=delta0,delta1<=2s-1<r.

In particular s>=1, and part A applies to both cross sets.

Their two majority parts cannot belong to the same history. Otherwise the other history has size at most delta0^2+delta1^2<=4s^2, whereas

    h-s>=2r^2-s>=8s^2-s>4s^2.

Thus the majority parts belong to different histories. As I0 and I1 mix opposite colors, those two majority parts have the same physical color p. Relabel colors so p=0, and put q0=|W1|, q1=|U1|. Then

    q0<=delta0^2, q1<=delta1^2,
    |U|=h-delta0-q0+q1,
    |W|=h-delta1-q1+q0.

The half-size lower bounds give

    q0-q1<=s-delta0, q1-q0<=s-delta1.              (*)

If delta_i<=s, its minority q_i is at most s^2. If delta_i>=s+1, then delta_j<=s-1 and(*) yields

    q_i<=q_j-1<=(s-1)^2-1<s^2.

This proves the claimed s^2 bounds. They also show that color p is indeed a majority within each history itself, since

    |U_p|>=h-s-s^2>s^2>=qU

(and likewise for W), using h>=8s^2.

### C. Synchronization in the strict-square band

Suppose q_i>s(s-1). If delta_i<=s-1, then q_i<=(s-1)^2<=s(s-1), contradiction. If delta_i>=s+1, the preceding bound q_i<=(s-1)^2-1 again contradicts the assumption. Hence delta_i=s. Inequality(*) gives q_j>=q_i. As delta_j<=s and q_j>s(s-1), its quadratic bound forces delta_j=s too. The two inequalities(*) now force q_i=q_j. Substitution in the half-size identities gives|U|=|W|=h-s.

Let X be either minority. Its opposite majority has exactly h-q-s rooms and avoids N(X), so the surplus t=|N(X)|-q is at most s. If t<s, part A's profile dichotomy is impossible: the low branch q<=t^2 conflicts with q>s(s-1)>=(s-1)^2. The high branch h-q<=t(t+1) conflicts with h>=2r^2, r>=2s, and q<=s^2. Thus t=s. The opposite majority therefore fills all of V_p minus N(X).

For s=1, X is one vertex with two neighbors, hence a board corner. For s>=2, use the accepted finite corner-capacity theorem in the strict subcritical range s<r. At survivor size q>s(s-1), surplus s, and with the high branch excluded as above, the incoming-corner counts0 or2 and positive outgoing-corner counts have capacity at most s(s-1). Thus the configuration has exactly one own-colored corner and no outgoing corner. The accepted strict-square near-equality localization then places X in Q_s about that corner. This is exactly the interval-localization hypothesis already used in bridge-lower-frontier-terminal-family.md; no critical s=r theorem is needed. If q=s^2, equal cardinality forces X=Q_s.

## Sharpness and the remaining dynamic obstruction

The square bound and strict-square synchronization are sharp as static statements. Choose same-colored corner triangles X,Y with|X|=|Y|=s^2 and define

    U = X union (V_p minus N(Y)),
    W = Y union (V_p minus N(X)),

where X,Y lie in V_(1-p). Both sets have h-s rooms and are anticomplete. The two triangles may use the same corner or different corners. Thus static midpoint geometry alone cannot exclude these configurations: the next duty is to prove that both required histories cannot reach them by the proposed deadline, or provide matching histories.

## Application to the current24x24 diagnostic

Here r12,h288,k13. Existing joint lower bounds give at least295 rooms just before inspection103, hence at least282=h-6 rooms in each103-day postinspection half. A206-day strategy would make the two halves anticomplete, so use s6.

Either one half has cleared a whole initial cohort by103 days (the unresolved solo103 possibility), or both halves share a dominant physical color and each has at most36 rooms in its other color. If either minority has31..36 rooms, both have the same such number; both halves have exactly282 rooms; and each minority lies in Q6, with at most5 missing rooms. Their dominant parts are exactly the complementary neighborhoods of the other minority.

This is a uniform geometric restriction and a sharply specified reachability target. It does not prove T_13(24,24)=207. In particular, the static sharpness construction proves that additional temporal information is genuinely necessary.

## Sources and validation boundary

- paper/sections/even-rectangle-profiles.tex: exact even-area profile and dichotomy.
- research/bridge-lower-frontier-terminal-family.md: strict interval near-square localization and the distinction from critical radius.
- research/bridge-boundary-numeric-24.md: physical joint295-room bound after102 steps.
- research/closure-2026-09-18/geometry-progress.md: balanced terminal equivalence and rejected alternative routes.

Every statement above is proved from these ordinary results. The finite24-square application is a substitution into the uniform lemma, not a new search certificate. The lemma has not been integrated into the manuscript or formally verified in Lean.

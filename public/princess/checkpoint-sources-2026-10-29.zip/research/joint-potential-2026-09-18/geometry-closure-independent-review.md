# Independent review of pyramid commutation and boundary charge

18 September 2026. Accepted ordinary proofs, with the stated quota
limitations retained. No new capture-time classification follows.

Reviewed `boundary-state-potentials.md` Section3, its weighted transfer, and
the conditional midpoint dovetail. I also implemented an independent
physical-set checker in `src/joint_20260918_geometry_closure_review.py`, with
no imports from the discovery or boundary-checking modules. Its receipt is
`research/joint-potential-2026-09-18/geometry-closure-review.json`.

## Commutation

The equality `P(N(S))=N(P(S))` is correct. Both operations preserve unions,
so a singleton suffices. On `Q x P_n`, the singleton `(u,v)` generates in
column `x` a spacing-two prefix of upper height `v-d_Q(x,u)`, with the
physical cutoffs applied. After a movement, both claimed sets have upper
height `v+1-d_Q(x,u)`, again with the correct opposite-color physical
cutoff. For `x!=u`, a neighbor on a geodesic supplies this height; for
`x=u`, vertical movement supplies it. At the top it is clipped to the
highest opposite-color cell, and a putative height below the first
physical cell represents the empty fiber. Every lower cell of the target
prefix has a predecessor in the cone. These checks include singleton
sources at either boundary and the empty support.

Bipartiteness makes the parity of graph distance agree with physical
color, so the argument extends to the stated connected bipartite `Q`
with an edge. This extension is a proof observation, not a developed
higher-dimensional application.

## Exact charge

The closure `P(S)` is smooth: neighboring nonempty cone heights differ by
one, and canonical empty/top cutoffs preserve this property. Its local
roughness slack is therefore zero. Write `E(S)` for the column envelope.
The existing unrestricted neighborhood identity is

`|N(S)|-|S| = gamma_p - R_top(E(S)) - R_bot(E(S)) + sigma(S)`.

Subtract it from the same identity for `P(S)`, whose slack is zero, and
use commutation. This gives exactly

`D(N(S))-D(S) = beta(S)-tau(S)-sigma(S)`.

The signs in the proposed definitions are correct. Enlarging the envelope
to its pyramid closure preserves every top contact and cannot create an
isolated empty-bottom contact. Thus both `beta` and `tau` are nonnegative.

For `B=A\I`, the purely cardinality-based identity

`J=|P(A)\P(B)|=i+D(A)-D(B)`

then gives

`i+beta(B)=J+D(N(B))-D(A)+tau(B)+sigma(B)`.

No support-shape hypothesis or hidden normal form enters this deduction.
The independent checker verifies commutation, zero pyramid slack,
nonnegative local slack, and the deficit identity on all2736 supports of
the four cited small boards. It additionally checks the inspection charge
on12784 single-cell removal steps. The general multi-cell identity follows
from the same exact cardinality algebra, without needing iteration through
artificial movement steps.

## Weighted transfer and limits

Discrete summation by parts gives

`sum lambda_t (D_(t+1)-D_t)`
`= -lambda_0 D_0 + lambda_(T-1) D_T`
`  + sum_(t=1..T-1) (lambda_(t-1)-lambda_t) D_t`.

Hence the displayed weighted inequality has the correct signs. On a phase
with `beta=0`, nonnegative nonincreasing prices, and pyramid initial state,
all retained corrections are nonnegative. A weighted-cost lower bound
valid for every projected history on that phase therefore transfers.

The projected daily removals are nevertheless not bounded by the original
budget. The explicit `4x4` example checks exactly: deleting the single
physical cell `(0,2)` deletes four cells from its pyramid closure. Likewise
the claimed deficit growth `56 -> 59` for `(5,11)` on `12x12` checks exactly.
These examples rule out silently dropping the deficit term or assuming
same-budget compression.

The midpoint dovetail correctly reverses the *exact* beliefs of the prefix
inside the complement-neighborhood envelopes. It does not equate those
beliefs with the envelopes. Reversing a rising-price prefix gives
nonincreasing prices, as required. The two negative initial-deficit terms
and the running `beta` terms remain unpaid obligations; the other displayed
terms have favorable signs.

In particular an individually capped demand theorem cannot be applied to
the projected removals `J_t` merely because the original removals satisfy
the cap. Prefix/weighted budget bounds allow quota to move between days and
are not the separate daily cap. The text explicitly retains this gap and
makes the combined midpoint argument conditional. With that restriction,
the commutation, charge, and transfer statements are sound.

# Whole-history attempts at the exact odd-clock crossing guard

18 September2026. Follow-up arithmetic lane; no publication or main source
changes. The absolute O(1) numerical completion criterion remains unchanged.

## The exact local predicate remains available

`research/closure-2026-09-18/numerical-crossing-guard.md` gives a fixed-size
exact test of whether a synthetic old oriented source can create a crossed
exceptional successor at a specified true solo layer. Its nine-root-branch
formula avoids a parameter-sized optimization, but proving it on every
zero-start orbit remains open. Guard-safe generic capacities are not an
invariant, and four independent interlaced-spacing bounds have already
been refuted in `geometry-progress.md`.

## Attempt1: normalized Abel phase from shared-age interlacing

Put `f(z)=I_0(z+m)`, `g(z)=I_1(z+m)`, `F=f∘g`. Three genuinely
interlaced trajectories are

```
x_t=F^t(0), y_t=F^t(f(0)), z_t=F^(t+1)(0).
```
They have the SAME t and satisfy x_t<=y_t<=z_t. This is stronger than
allowing three unrelated points satisfying the individual spacing bounds.
For a truly convex increasing F, normalized phase
`theta_t=(y_t-x_t)/(z_t-x_t)` is nonincreasing, by the secant inequality.
A plausible rounded version would keep the displacement from the initial
phase within one integer:

```
|(y_t-x_t)-theta_0*(z_t-x_t)|<=1.
```
Both candidates fail on actual lower/plateau orbits, before reflected
branches can be blamed:

- Width17,budget17: theta_0=13/24, while t1 gives
  (x,y,z)=(24,35,44) and theta_1=11/20>13/24.
- Width21,length63,budget12: t2 gives (28,35,38), theta_0=9/16,
  and the displacement is11/8>1.
- Width129,length387,budget130: t5 gives(1055,1153,1244),
  theta_0=119/232, and displacement245/232>1.
- Width11,length33,budget7: t4 gives(22,22,25), theta_0=1/2,
  and displacement-3/2. The two earlier interlaced trajectories can merge.

Thus an Abel-time proof cannot simply treat the rounded maps as convex,
or use a fixed initial interpolation fraction plus a one-unit rounding
allowance. No larger arbitrary tolerance was introduced after this failure.
A real Abel coordinate would need to account for the inherited root-band
rounding. Defining that coordinate by the orbit would only rename the
missing theorem.

## Attempt2: minimum-ammunition conservation across whole histories

In a lower/plateau history, let mu_p(k) be the established minimum total
quota for reaching deficit k in color p. Any genuine two-cohort history
of t days satisfies

```
mu_0(x)+mu_1(y)<=mt.
```
Each cohort's actually spent probes bound its minimum ammunition, and the
two spent amounts sum to at most mt. This gives a legitimate whole-history
resource inequality and excludes one familiar fake history: on width11,
m7,t3, deficits(6,6) require11+12=23 probes, exceeding21.

But it does not exclude all crossed exceptional candidates. At the genuine
t4 solo layer(14,12), candidate(6,7) is numerically crossed relative to the
faster color0 and has total13>12, yet

```
mu_0(6)+mu_1(7)=11+13=24<=28.
```
The missing restriction is simultaneous timing: a cohort can lose ground
while the other is being grown. Total minimum ammunition does not encode
the overlap of their necessary probe intervals. Its failure therefore
supports an interval-demand/age or joint-history approach, not another
aggregate cost bound.

This is only an analysis of the candidate invariant. The recurrence for mu
is already established elsewhere; no new theorem is claimed here.

## Focused attempted falsification of the actual guard

A root-free/array-free test checked the diagonal family m=w-1,w,w+1 on
squares of widths257,513,1025,2049. These parameters lie near the difficult
linear-budget regime; this is not a broad catalogue search. Across7,980
retained-fastest true solo layers the exact crossing guard had no failure.
The total run took under0.1 CPU second. No theorem is inferred from this.

Reproduction and exact receipts:

- `src/joint_20260918_arithmetic_orbit.py`
- `research/joint-potential-2026-09-18/arithmetic-orbit-check.json`

## Current consequence

The actual guard survives the focused test, but neither normalized
same-age secants nor minimum-ammunition conservation proves it. The first
fails because discrete root thresholds disturb relative phase; the second
fails because two cohort demands can conflict in time despite affordable
total quota. The useful missing object is consequently an exact timing
comparison of the two whole histories, or a joint potential that charges
those conflicts. No closed evaluation of the minimum-budget ceiling
hitting time has been obtained in this pass, and the forbidden unknown
normalization constant has not been introduced as an atomic operation.

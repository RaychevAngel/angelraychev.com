# Joint temporal-potential research pass — 18 September 2026

The user authorized execution of the history-dependent joint-inequality
direction. This pass started at09:27 UTC. It continues commit1345399 and
`../closure-2026-09-18/RESEARCH_LOG.md`. Research scope remains full-start
rectangles, a constant daily budget, exact capture time and direct optimal
inspections; absolute fixed-operation numerical evaluation is still required.
Independent extensions remain parked. No submission, outreach, deployment,
manuscript rebuild, or Lean development was undertaken during this pass.

## Actual outcome

**No remaining infinite capture-time family was closed.** In particular,
24 by24 with budget13 remains206..207, and no fixed-operation replacement
for the width-dependent minimum-budget clock was found. The new progress
is a validated temporal lower-bound mechanism that surpasses the stationary
potential on known benchmarks, a rigorous reduction of its price search,
and exact geometric accounting needed to attempt its even-area counterpart.
These are tools and certificates, not a completed classification.

## 1. The successful temporal mechanism

Each checkerboard cohort receives an integer quota at most k on each day.
Keep that individual cap when minimizing its weighted total quota over all
successful complete histories. Write the two minima W_0(lambda),W_1(lambda).
Any full-board strategy must obey

    W_0(lambda)+W_1(lambda) <= k sum_t lambda_t

for every nonnegative day-price vector lambda. Strict reversal is a lower-
bound certificate. The per-day individual cap distinguishes this mechanism
from the previously rejected unrestricted weighted-ammunition argument.

The proof is elementary and independently reviewed. The meaningful new
evidence is that it proves the missing day on benchmarks where the optimal
stationary additive potential is known to stop short. Exact integer Farkas
certificates were independently checked on11-square,k7,deadline49 and
17-square,k10,deadline97. Then the optimized prices were replaced by the
simple triangle lambda_t=1+min(t,D-1-t):

- 11-square,k7,D49:2175+2330>4375, excess130.
- 17-square,k10,D97:12320+11931>24010, excess241.
- 19-square,k10,D225:64799+63707>127690, excess816.
- 21-square,k12,D133:27262+27535>53868, excess929.
- 35-square,k35,D55:13874+13759>27440, excess193.

All five individual minima were recomputed by an independent integer path
checker. These confirm existing exact values; they do not add new solved
parameter ranges. The required minimization is still an explicit algorithm,
not the user's fixed-operation numerical endpoint.

Two uniform reductions are proved: negative prices can be removed, and a
separator can be averaged with its time reverse without losing separation.
Thus nonnegative symmetric prices suffice whenever linear prices suffice.
The exact inverse-complement duality of bipartite neighborhood profiles
explains reversal of the count language; physical reversal follows directly
by reversing all evading walks. No unimodality or finite-dimensional price
family is inferred.

Authoritative proof: `weighted-temporal-demand.md`.
Independent proof/certificate review: `arithmetic-timed-flow-review.md` and
`boundary-weighted-demand-review.md`.
Further reductions and failed stronger assertions:
`arithmetic-temporal-structure.md`.

## 2. Deliberate attempts to break or simplify the temporal method

- A universal triangle fails on9 by11,k17,D7; constant prices succeed there.
- A test of triangle, flat, clipped, and offset-triangle prices found a
  certificate for846 distinct false odd deadlines on widths7..17, lengths
  w,w+2,2w+1, and every budget producing even exact time greater than2.
  Another selected-budget screen covered228 cases on widths7..35; these
  screens overlap and their counts must not be added as distinct cases.
  The finite trial family is evidence only. The checker uses exact int64
  arithmetic with a magnitude bound; four delicate clip/offset certificates
  were also independently recomputed by forward Python-integer DP.
- Summing separately minimized central-interval demands fails even on the
  initial11-square benchmark:4271<4375, whereas keeping one common history
  yields4505>4375. This is an exact explanation of the temporal coupling.
- A direct weighted telescoping identity is valid, but independently
  minimizing its intermediate-state terms is much too weak on the five
  principal benchmarks. Its failed margins are preserved.
- Endpoint concentration is false even for k<=w+1. On7 by9,k8,D11, larger
  cohort triangular cost165 requires a split that beats every single
  consecutive positive block, whose minimum is168. Seven-row odd rectangles
  are already classified; this is a counterexample to a proposed uniform
  proof shortcut, not a new unresolved instance.
- Successful quota words fail the generalized-polymatroid simultaneous
  exchange axiom already on3-square,k2,D7. Thus the standard intersection
  theorem cannot simply be imported for these untransformed word sets.
- Whole-clock normalized Abel phase, a one-unit secant correction, and
  total minimum-ammunition invariants fail on explicit true or synthetic
  examples described in `arithmetic-orbit-attempts.md`. The already-proved
  local orientation guard survived7,980 targeted actual layers, which is
  bounded evidence rather than a global invariant proof.

The useful surviving obligation is to prove the weighted inequality from
a uniform analytic potential while allowing arbitrary temporal splits.
Neither exact minimizer classification nor an exact LP-integrality theorem
for arbitrary partial states is required by the rectangle objective.

## 3. Geometry: useful accounting and decisive information loss

The coupled downward-pyramid closure P commutes with neighborhood:

    P(N(S))=N(P(S)).

For closure deficit D(S)=|P(S)|-|S|, the exact drift is

    D(N(S))-D(S)=beta(S)-tau(S)-sigma(S),

where beta is the bottom boundary credit removed by closure, tau the added
top boundary charge, and sigma the previously established nonnegative
roughness term. This gives a weighted transfer with explicit deficit and
boundary corrections. It handles arbitrary holes and nonsmooth supports.

The crucial limitation is retained: projected smooth histories can require
more than k inspections on an individual day. The new temporal certificate
depends on precisely this daily cap, so it cannot be applied to projected
histories without carrying or bounding the deficit correction. The note
states the exact two-sided midpoint gluing obligation, without claiming it.

Other informative results of this lane:

- Subadditive capture potentials are bounded at full start by partitioning
  into pieces of size at most k. Separate column scores cannot prove the
  24-square solo104 target.
- Combining the existing forward and reverse scalar/corner clocks cannot
  produce a104-day first-crossing proof: on every edge of the known104-day
  witness, the required combined threshold fails.
- A cubic adjacent-strip potential has an exact6-day solo certificate on
  4-square,k3. Two independent physical transition checkers verify it. That
  value was already proved by the scalar clock; this is an ansatz test.
- The known25 by26 solo188 witness is smooth in at least one orientation
  at every survivor, but not one fixed orientation:97 original-only,
  78 transpose-only,13 both. It refutes fixed-axis smoothness, not adaptive
  orientation. Any adaptive-potential proof needs a valid switching charge.

Authoritative note: `boundary-state-potentials.md`.
Independent review: `geometry-closure-independent-review.md`, including
2,736 literal supports and12,784 single-removal charge checks. The cubic
certificate has its separate `geometry-cubic-independent-review.md`.

Paired matching and balanced-cover quantities satisfy valid uniform local
inequalities, but even all four color counts together with three such ranks
lose essential shape history. A3 by4,k2 example admits a chain of individually
legal abstract transitions predicting10 days although the exact time is16.
The false chain resets an intermediate shape while preserving every proposed
statistic. This is a precise obstruction to that compressed proof class.
See `geometry-matching-potential.md` and its exact collision receipt.

## 4. Proof and verification boundary

- Ordinary uniform arguments: weighted necessary condition, price reductions,
  inverse-complement duality, closure commutation and charge identity, stated
  matching inequalities, and impossibility of the stated additive ansatz.
- Exact finite certificates: listed weighted path minima/Farkas inequalities,
  cubic potential, literal geometric counterexamples and witness replays.
- Diagnostics only: floating LP optimality values, finite price-family
  screens, and absence of guard failures on tested true orbits.
- Not proved: uniform price choice or weighted separation at all false
  deadlines; a globally quota-preserving smooth reduction; optimality of
  the24-square upper; fixed-operation whole clocks; new Lean coverage.

The main manuscript, public website and83-module formal artifact retain the
September13 release boundary. These private notes are deliberately not
promoted to published classification claims.

## 5. Next research obligations, in priority order

1. **Odd-board matching bounds:** derive a nonnegative symmetric price rule
   and a compatible-history lower potential that proves the necessary
   demand inequality at the unresolved false central deadlines. It must
   survive the explicit split-word examples; independent interval or state
   minima have already been rejected. Proving sufficient separation is
   enough; classifying all weighted optimizers would expand the objective.
2. **Even-area matching bounds:** combine geometric closure/radius information
   with the actual corrected per-day budget. Control both the paired
   midpoint deficits and weighted bottom-credit terms; their exact signs
   and the daily-cap failure are now explicit. Static matching ranks cannot
   replace that information.
3. **Numerical closure:** only after or alongside these comparisons, eliminate
   the remaining parameter-length clocks. No iteration, flow optimizer,
   path minimum, or unknown normalization is an allowed atomic operation.

This pass is mathematical tool development, not scope separation and not
mathematical supersession of the remaining family classifications.

## Final verification

All new Python sources compile. Dependency-free independent temporal,
matching-collision, cubic, and closure checkers were rerun successfully.
All JSON receipts parse. The runtime discovery used cached SciPy1.18.1 with
one solver worker; several deliberately bounded solver attempts timed out
and are marked as such rather than treated as mathematical evidence.
`verification-manifest.json` freezes the new notes, scripts, receipts, and
their direct pre-existing profile/witness dependencies by SHA-256.

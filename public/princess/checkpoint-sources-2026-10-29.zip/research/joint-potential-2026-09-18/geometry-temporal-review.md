# Independent audit of capped triangular temporal certificates

18 September 2026. Accepted as finite lower-bound certificates. No new
parameter range, uniform price theorem, or fixed-operation formula follows.

## Producer method

I inspected `src/joint_20260918_triangle_probe.py`. For each initial color,
its backward integer dynamic program starts with cost zero only at terminal
count zero. It considers every daily quota `0,...,k`, applies the appropriate
physical-color neighborhood profile to the surviving count, and charges the
selected day's nonnegative weight. The color of the terminal array is
`initial_color xor deadline_parity`; the alternating array dimensions and
maps agree. The final value is the minimum cost from the entire starting
color class. Replaying the attaining quota word checks its final zero state
and its cost. Wasted quotas are permitted, which cannot invalidate a lower
bound. The harmless neighborhood after the final successful inspection maps
empty to empty and does not add an inspection day.

The enumeration is a shortest-path dynamic program with parameter-dependent
states, quotas, and time. It is not a fixed-size numerical formula.

The stored 846-case receipt has 846 distinct parameter triples, no failures,
and positive exact margins throughout. It covers widths 7,9,11,13,15,17 and,
for each width `w`, lengths `w,w+2,2w+1`, restricted to the tested feasible
budgets whose existing exact evaluator gives an even capture time greater
than two. Thus “all budgets” describes the loop before its deadline filter;
it does not assert that all budgets of every odd rectangle were tested.

All arithmetic in the saved screen is safely within the integer/sentinel
range: the largest stored capacity is 1,447,209, the largest reported cohort
minimum is 728,985, and the largest deadline is 801. The producer has also resolved the magnitude-check issue found during
review: it now checks `k*sum(actual_weights)<INF/10` after constructing the
weights and validates nonnegative offset and clip parameters. This includes
the offset contribution. The change does not alter the saved finite costs.

## Independent four-case replay

My checker imports neither the producer nor its rectangle class or an
optimization library. It reconstructs the accepted odd-rectangle profiles
by enumerating the least surplus permitted by square/pronic capacities
(including the full-majority surplus -1), then runs a forward dictionary
shortest-path calculation using unbounded Python integers. This reverses
the producer's DP direction and avoids its root formulas, int64 arrays, and
sentinel. Attaining words are independently replayed.

Results exactly match the receipt:

* `9x19,k17,D13`, triangle clipped at 2: cohort minima 204 and 205,
  capacity 408, positive excess 1.
* `11x11,k15,D11`, triangle clipped at 3: minima 204 and 202,
  capacity 405, excess 1.
* `7x7,k18,D3`, offset 4: weights `(4,5,4)`, minima 122 and 117,
  capacity 234, excess 5.
* `17x19,k52,D7`, offset 8: weights `(8,9,10,11,10,9,8)`, minima
  1699 and 1701, capacity 3380, excess 20.

The independent checker is
`src/joint_20260918_geometry_temporal_review.py`, with receipt
`research/joint-potential-2026-09-18/geometry-temporal-review.json`.
I independently recomputed these four cases, not all 846; the broader
receipt received a method, uniqueness, margin, and arithmetic-range audit.

## What a positive certificate proves, and the unresolved sharpness issue

A physical winning schedule supplies two individually capped successful
quota words whose daily sum is at most `k`. Therefore any pair of minimum
weighted costs whose sum exceeds the available weighted capacity excludes
that physical deadline. Every positive certificate above is a genuine
physical lower bound, conditional only on the accepted neighborhood-profile
lower theorem. Together with existing constructions it independently
certifies the already-established respective capture times 14,12,4,8.

The converse has not been established. Failure to find separating weights
can occur because distributions over individually successful quota words
have compatible *means*. Their means may hide incompatible timing choices:
that does not produce two actual words respecting the daily sum, much less
a physical strategy if the count model itself has incompatible shapes.
Convex separation characterizes this mean relaxation and the power of
nonnegative time-price certificates exactly; it does not identify that
relaxation with the physical game.

The 846 successes are consequently evidence for an analytic time-price
principle at these deadlines. They do not establish such a principle for
all odd rectangles, decide a new infinite parameter family, close even-area
geometry, or evaluate the certificate costs in a fixed number of numerical
operations. The individual cap `q_t<=k` is essential: dropping it returns
to the previously rejected unrestricted ammunition argument.

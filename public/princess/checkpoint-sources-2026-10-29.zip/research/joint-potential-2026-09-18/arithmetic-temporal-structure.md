# Temporal price structure: proved reductions and failed concentration — 18 September 2026

This continues the independent timed-flow review. Its purpose is to find a usable uniform weighted lower bound, not to characterize optimal single-cohort words for its own sake.

## 1. Two exact reductions of the linear-price proof class

Fix a deadline `T`, a daily bound `k`, and the two full-color initial cohorts. Let `Q_c` be the successful quota words for cohort `c`, and put

`W_c(lambda) = min_(q in Q_c) sum_t lambda_t q_t`,

`D(lambda) = W_0(lambda)+W_1(lambda)-k sum_t lambda_t`.

If either language is empty, infeasibility already follows without a price vector; assume both nonempty. Positive `D(lambda)` excludes full-board capture.

### Negative prices can be removed

Each language `Q_c` is coordinatewise upward-closed inside `{0,...,k}^T`: increasing any inspection quota cannot prevent capture. Set `lambda^+_t=max(lambda_t,0)` and `N=sum_(lambda_t<0) lambda_t`. Then

`W_c(lambda) = W_c(lambda^+) + k N`.

For the lower inequality, every negative-priced coordinate satisfies `lambda_t q_t >= lambda_t k`, while the remaining cost is at least `W_c(lambda^+)`. For the upper inequality, take an optimizer for `lambda^+` and raise every negative-priced coordinate to `k`; this remains successful and does not change its `lambda^+` cost.

Consequently `D(lambda)=D(lambda^+)+kN <= D(lambda^+)`. Every separating linear price vector may therefore be replaced by a nonnegative one without losing separation.

### Time symmetry can be imposed

For the physical game on any undirected bipartite graph, a successful inspection sequence hits every `(T-1)`-edge walk starting in the selected color. Reversing all walks and all inspection days shows that reversing a successful quota word sends cohort `c` to cohort `c xor ((T-1) mod 2)`. This physical argument applies directly whenever the quota language means realizable physical schedules.

For the canonical count language the same statement follows independently from the complementary inverse identity for exact minimum-neighborhood profiles

`I_p(C_(1-p)-u) = C_p-g_(1-p)(u)`.

This identity holds for every finite bipartite graph: a set `S` of color `p` has at most `z` neighbors exactly when one can choose `C_(1-p)-z` vertices of the opposite color with no edges into `S`. Maximizing the size of `S` is therefore equivalent to minimizing the neighborhood of that opposite-color set.

For reversal of the canonical count recurrence, assume no isolated vertices, as is true for the nontrivial rectangles considered here. Then a full color class has the whole opposite class as its neighborhood, and a nonempty set has a nonempty neighborhood. The backward viable capacities satisfy

`v_T=0`, `v_t=min(C_p,q_t+I_p(v_(t+1)))`, with `p=c xor(t mod 2)`.

Writing `u_t=C_p-v_t` gives

`u_t=max(0,g_(1-p)(u_(t+1))-q_t)`.

This is the reverse process with movement before inspection. Its first movement maps a full color class to the full opposite color class; its final count zero is equivalent to the reversed word succeeding. Thus the canonical language has exactly the same reversal rule. No explicit root formula or compatible-prefix realization is needed for this argument. The universal inverse identity itself remains valid even when isolated vertices exist, but the stated canonical reversal argument uses their absence.

Let `R lambda` denote the reversed price vector and `lambda^sym=(lambda+R lambda)/2`. Reversal gives

`W_c(R lambda)=W_(c xor((T-1) mod 2))(lambda)`.

Because a minimum of linear functions is concave,

`W_c(lambda^sym) >= (W_c(lambda)+W_c(R lambda))/2`.

Summing over the two cohorts yields `D(lambda^sym)>=D(lambda)`. Combining the two reductions, every mean-flow separator may be chosen **nonnegative and symmetric in time**. This holds for either parity of `T`; even `T` swaps the cohorts, but their sum is unchanged.

This does not justify unimodality, a triangular shape, a bounded number of price values, or a fixed-size numerical formula. Those remain separate assertions.

Independent checks covered 602 profile-complement identity points on six rectangles and all 10,920 quota/cohort words of lengths 1 through 6 with budget 3 on the 3 by 3 board. These are checks of the written argument, not substitutes for it.

## 2. Endpoint concentration fails in the requested low-budget regime

A precise weak version of endpoint concentration would say that a triangular-price optimum can use a single consecutive block of positive quotas, with zero quotas outside that block. This already fails; hence the stronger requirement that this block touch an endpoint also fails.

On the 3 by 5 board, `k=4,T=5`, larger initial color, weights `(1,2,3,2,1)`, the unrestricted minimum is 20 via quotas

`(0,4,0,4,4)`.

The best single positive block costs 21, via `(0,0,3,4,4)`.

The failure also occurs on the 7 by 9 board, `k=8,T=11`, larger initial color, triangular weights, the unrestricted minimum is 165 via

`(8,8,8,8,0,0,1,8,8,8,8)`.

Its canonical count history is

`(32,26,22,17,13,16,20,22,18,13,8,0)`.

The best single consecutive positive block costs 168; six final quotas of 8 attain that value. This is within the low-budget request `r+1<=k<=w+1` and the original family-4 parameter box (`r=3,k=8<=r^2`). It is not a currently unresolved instance: the seven-row odd case has subsequently been closed across all budgets. It still refutes the proposed uniform concentration statement over the requested range.

These minima were computed independently by an integer dynamic program. The restricted computation carries a three-state flag (waiting, inside the positive block, finished), so it minimizes over every single positive block, not merely a selected schedule. Source: `src/joint_20260918_arithmetic_concentration.py`; receipt: `arithmetic-concentration-tests.json`.

Crucially the needed weighted lower bound still succeeds on the second example: the two unrestricted demands are 165 and 168, exceeding available weighted budget 288 by 45. Exact single-cohort normal forms are therefore stronger than needed and should not become another project obligation.

## 3. A valid but usually insufficient Abel bound

For a canonical path with state `s_t` before inspection, the inverse-profile inequality gives

`q_t >= s_t-I_(c xor(t mod 2))(s_(t+1))`.

For nonnegative weights, summing and telescoping gives

`sum_t lambda_t q_t >= lambda_0 C_c + sum_(t=1)^(T-1) [(lambda_t-lambda_(t-1))s_t + lambda_(t-1)(s_t-I_(previous phase)(s_t))]`.

Each intermediate state lies between the survivor count after `t` full-budget days and the maximum count clearable in the remaining `T-t` days. Minimizing each displayed summand independently over that interval gives a rigorous lower bound using only scalar root-band terms.

This independent-state minimization loses too much history. For the five initial targets 11 by 11, 17 by 17, 19 by 19, 21 by 21, and 35 by 35 from the review note, its separation margins are respectively

`-1340, -9875, -86609, -24201, -6524`.

It does succeed on 7 by 9, `k=8,T=11`, with margin 6. Thus the algebraic identity is sound, but unconstrained minimization of its state terms does not supply the needed uniform theorem. Source: `src/joint_20260918_arithmetic_abel.py`; receipt: `arithmetic-abel-tests.json`.

## 4. Consequence for the next proof attempt

The defensible reduced search space is nonnegative symmetric day prices. The task is to prove `W_0+W_1 > k sum lambda` at false deadlines while permitting arbitrary temporal splits. Both the interval-by-interval minimization and the state-by-state Abel minimization fail because they allow incompatible local minimizers. An argument must preserve at least the compatibility linking those minima, for example through a calibrated root-band potential or paired forward/backward frontier accounting. A new conjecture that all optimizers have one or two blocks is neither established nor required.

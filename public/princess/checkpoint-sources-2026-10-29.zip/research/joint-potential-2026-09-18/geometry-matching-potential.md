# A nonlinear paired matching potential, and its temporal obstruction

18 September 2026. Research diagnostic, not a rectangle classification.
The uniform inequalities below have ordinary proofs and were independently
checked by the boundary-accounting agent. The finite counterexample is checked
by `src/joint_20260918_geometry_matching_collision.py`. No Lean additions.

## Histories and the terminal condition

Write `U -> N(U) \ S` for a postinspection history, with at most `k` deletions
in each step and `U_0=V`. Two independent, equally long such histories are the
forward and reversed halves of an even deadline. Their terminal sets must be
anticomplete. Both histories retain their own daily quota; they do not share a
single quota of `2k` that can be assigned arbitrarily.

The two-copy cross graph `H(U,W)` has a left copy of `U`, a right copy of `W`,
and an edge between copies precisely when the physical vertices are adjacent.
Define

* `D(U,W)`: maximum matching size in this graph;
* `eta(U,W)`: minimum `max(|S|,|T|)` over vertex covers with
  `S` in the first copy and `T` in the second;
* `C(U,W)`: maximum, over matchings `M` in the physical graph, of
  `sum_{uv in M}(1_U(u)1_W(v)+1_U(v)1_W(u))`.

Thus `D` permits the two replica copies of a physical vertex to participate in
different matching edges; `C` imposes one shared physical matching. Always
`D>=C`. No fixed matching or matching-compatible nesting is assumed.
Each quantity is zero exactly at anticomplete pairs.

## Uniform one-step inequalities

For every undirected graph and arbitrary sets,

`D(N(U),N(W)) >= D(U,W)` and `eta(N(U),N(W)) >= eta(U,W)`.

For `D`, reverse the endpoints of every old matched edge. The resulting
edges belong to the new cross graph and their endpoints are still distinct
within each replica. For `eta`, a cover `(S,T)` of the new graph pulls back to
`(T intersect U, S intersect W)` in the old graph: each old edge reversed is
a new edge, so at least one of these pulled-back endpoints covers it.
The maximum of the two cover sizes cannot increase on pulling back.

Deleting at most `k` vertices in each replica gives

`D(N(U)\S,N(W)\T) >= D(U,W)-2k`,

`eta(N(U)\S,N(W)\T) >= eta(U,W)-k`.

For matching, every deleted replica vertex destroys at most one chosen
matching edge. For covers, restore the deleted vertices to the respective
parts of a surviving cover, increasing each part by at most `k`.

The same movement and `2k` deletion inequalities hold for `C`: reverse the
directed contribution on every physical matching edge. A deleted vertex in
one replica destroys at most one such directed contribution. Finally, all
three statements remain valid after minimizing the quantity over a fixed
group of automorphisms applied to `W`; movement commutes with each symmetry
and the deletion cardinalities are unchanged. Our small screens use the four
coordinate reflections. We do not call this the full square symmetry group.

These are nonlinear spatial quantities and valid simultaneous-step
inequalities. The numerical inequalities alone are only counting bounds;
the hoped-for additional content was a sharper exact transition profile.

## What the exact small screens establish

The checker enumerates every pair of sets, every physical matching, and every
separate pair of legal deletions on the stated small boards. It computes the
minimum possible next score for each current score. This is the strongest
one-step scalar lower profile of that score, but its minimizers need not be
mutually reachable on successive days.

For the reflection-minimized `C` and `D` on `2x4,k=2`, the profile at scores
`0,...,8` is

`0,0,0,1,1,2,3,4,4`.

It excludes an anticomplete pair before three paired rounds, matching the
known six-day optimum on this board. The one-probe profiles also retain
positive invariants on `2x2`, `2x3`, and `2x4`, correctly detecting
infeasibility. These are finite diagnostics, not new uniform classifications.

On `3x3,k=2`, however, both matching profiles are

`0,0,0,1,2,2,3,4,4` at scores `0,...,8`.

They permit `8 -> 4 -> 2 -> 0` in three paired rounds, whereas the proved
capture time is ten days. The balanced-cover scalar similarly permits
`4 -> 2 -> 1 -> 0`. Every local transition is realizable with both quotas,
but the realizing sets cannot be spliced into a full-start history.

The genuine `3x3,k=2` histories have the following minima at paired times
`0,...,5`:

* postinspection size: `9,7,6,6,5,5`;
* reflection-minimized replica matching: `8,4,4,2,2,0`.

Adding those exact time-dependent size lower bounds to the scalar matching
profile recovers this small example. This does not prove that size plus
matching rank is a sufficient abstraction. The next counterexample rules
out that stronger claim.

## A precise collision even after keeping all color counts

Consider `3x4,k=2`; both colors have `h=6` vertices. Its already-proved exact
capture time is `16`, from the three-row formula `T_2(3,n)=6n-8`.

For a set `A` in one color and the entire opposite color `V_p`, let
`U=W=V_p union A`, with `|A|=q`. Then

`C(U,U)=D(U,U)=2q`, and `eta(U,U)=q`.

For the upper bounds, a physical matching can contribute only when one
endpoint is in `A`, hence at most twice per vertex of `A`. In the cross
graph, `A` in each replica is a vertex cover, of total size `2q` and balanced
cost `q`. For the lower bounds, restrict any perfect physical matching to
edges touching `A`: it gives score `2q` and a replica matching of size `2q`.
Every cover must meet these `2q` replica edges, so its larger part has at
least `q` vertices. The same equalities hold after minimizing over relative
reflections: the fixed perfect matching lower bound
`C(U,sigma U)>=|U|+|sigma U|-12=2q` remains valid.

Consequently this entire family is indistinguishable to the signature
consisting of the four physical color counts of `(U,W)`, together with
`C,D,eta` (raw or reflection-minimized).

For every `q=1,2,3,4`, each physical color in `3x4` contains a set `A_q` with
`|N(A_q)|=q+1`. Start by deleting two cells from one full color and keep a
chosen `A_4`. Subsequently, from `V_p union A_q`, movement gives the entire
opposite color together with `N(A_q)`. Deleting two cells there leaves a
minority of size `q-1`. Therefore the exact one-step signature relation
admits the chain

`(6,6) -> (6,4) -> (6,3) -> (6,2) -> (6,1) -> (6,0)`,

with the physical dominant color alternating. Use the identical chain for
both histories. Every step uses exactly two deletions in each history;
the first source is the actual full board and the last pair is
anticomplete. But at intermediate points the realizing minority sets must
be replaced by different sets having the same signature. The checker saves
all five legal transitions and checks every signature equality across a
replacement. Replacements occur before steps 3, 4, and 5.

For reproducibility, with row-major bit masks these transitions are

`4095 -> 2943`,
`2943 -> 1471`,
`3565 -> 2686`,
`2907 -> 1447`,
`1453 -> 2650`.

The mismatched connecting pairs have identical signatures. In particular
this is **not** a five-round physical history. It is an exact obstruction to
any universally valid one-step necessary model using only that signature:
that model must admit these transitions, hence cannot exclude ten full
days on a board whose true optimum is sixteen.

The failure is structural. Matching and balanced-cover ranks collapse on a
full color plus a small minority. They do not detect the incompatible
successive corner locations that the established three-row historical-rank
argument detects. A useful next joint calibration must retain an actual
history variable or some geometric information distinguishing these sets.

## The 24x24,k13 diagnostic, including both endpoint types

The accepted joint lower bound implies that a hypothetical 206-day schedule
would give two 103-step postinspection histories of sizes at least 282.
The balanced-half stability lemma leaves both of the following genuine
static endpoint types; none may be silently excluded in a temporal proof.

1. Solo-degenerate type: both sets may be subsets of one physical color,
   each of size at least 282. They are anticomplete and all three ranks are
   zero. Whether the corresponding full-start histories are attainable by
   time 103 is still the solo-time issue.
2. Mixed type: let `Q_6` be the 36 vertices of a corner of one color at
   distance at most ten from that same-colored corner. Its neighborhood
   has 42 vertices. Then
   `U=W=Q_6 union (V_other \ N(Q_6))`
   is independent and has size `36+288-42=282`, with 36 minority and 246
   majority vertices. Again all ranks are zero. This is an exact static
   endpoint, not a claimed reachable 103-step history.

Thus terminal size and any of these zero tests alone cannot settle the
206-versus-207 question. The new matching inequalities do not establish a
new lower bound for it.

## The uncollapsed two-quota object

The natural object behind `D` and `eta` is the upward-closed set

`Gamma(U,W)={(p,q): H(U,W) has a cover using <=p first-copy and <=q second-copy vertices}`.

The same proof gives the exact necessary inclusion

`Gamma(N(U),N(W)) subset transpose Gamma(U,W)`.

After deleting at most `k` vertices on each side,

`Gamma(U_next,W_next)+(k,k) subset transpose Gamma(U,W)`.

This retains the two quotas rather than replacing them by a total or a
maximum. Equivalently its lower frontier is

`g_UW(p)=min_{X subset U, |U\X|<=p}|N(X) intersect W|`.

We have **not** proved that this full frontier closes under a useful
parameter-independent recurrence, or that it solves the compatibility
problem. Iterating only the displayed inclusion discards strict movement
expansion and therefore does not by itself improve counting. It is a
possible language for a stronger history-sensitive potential, not a new
solution or a disguised closed formula.

## Artifacts

- `src/joint_20260918_geometry_matching_gate.py`: exhaustive small profile
  checks, movement inequalities, optional genuine-history comparison.
- `src/joint_20260918_geometry_matching_collision.py`: explicit checked
  five-step signature collision on `3x4,k2`.
- `research/joint-potential-2026-09-18/geometry-matching-collision.json`:
  all sets, deletions, signatures and resets in that collision.
- `geometry-matching-gate*.json`, `geometry-replica-matching-gate-2x4.json`,
  `geometry-balanced-cover-gate.json`, `geometry-matching-history-3x3.json`:
  bounded computational receipts. A sentinel above the maximum score in
  a profile means that score is unattainable; it is not a transition value.

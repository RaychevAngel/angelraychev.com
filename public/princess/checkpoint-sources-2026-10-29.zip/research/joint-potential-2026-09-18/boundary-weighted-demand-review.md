# Independent review: weighted temporal demand

18 September 2026. Reviewed `weighted-temporal-demand.md` independently of its numerical producers. This review accepts the ordinary general theorem, not a uniform theorem evaluating the demands or certifying every false rectangle deadline.

For each actual cohort, induction gives canonical count no larger than physical belief size. The inspection quota must be counted by physical color on that day, so the two origin-cohort quotas sum to at most `k`. Wasted quota causes no problem. A physical win makes both canonical words successful, including the formal last empty-neighborhood update. Nonnegative day prices then give `W_0+W_1<=k sum lambda`. The separate bound `q_t<=k` is preserved in this argument and is indispensable.

The dynamic-programming potential statement follows. Its value is monotone in the input count: a quota word successful from a larger count is successful from a smaller one by monotonicity of every transition. Thus for a physical successor `s'` greater than or equal to the canonical successor, `F_t(s)<=lambda_t q+F_(t+1)(s')` still holds. Write this additive inequality rather than subtracting extended-infinite values.

The convex-separation characterization is exact for this proof class. Assuming both successful-word sets are nonempty, their convex hulls are compact and the sum with the nonnegative orthant is a closed convex upward set. If `k*1` lies outside it, strict separation by a nonnegative normal follows; a negative coordinate in a lower-separating normal would make the infimum over the upward set minus infinity. The minimum support value splits as `W_0+W_1`. Conversely a point below `k*1` defeats every nonnegative separator. Empty successful-word sets give the trivial infeasible case before this argument.

Suggested precision: explicitly make the profile integer-valued and bounded by the opposite color size, as needed for a finite count-state model. All profiles actually used have these properties. These are exposition clarifications, not counterexamples to the intended statement.

Boundary integration must retain the daily cap. The exact pyramid-closure correction changes projected quotas by `J_t=i_t+D(A_t)-D(B_t)`; temporal weighted transfer alone cannot justify evaluating the capped `W` on `J`. The conditional dovetail and its two unmet obligations are recorded in `boundary-state-potentials.md`.

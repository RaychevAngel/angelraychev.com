# Independent timed-flow and weighted-demand review — 18 September 2026

This note records a separate review of `src/joint_20260918_timed_flow.py` and an independently implemented exact checker. No publication, manuscript, or formal source was changed. The new uniform mathematical lemma below is elementary; the numerical separations are exact computational certificates, not Lean proofs or a uniform rectangle classification.

## 1. Necessary condition supplied by the physical game

Let an odd rectangle have sides `w <= n`, `b=(w-1)/2`, and color-class sizes `C_0=E=(wn+1)/2`, `C_1=M=E-1`. A cohort means the possible princess positions that began in one fixed color. On day `t=0,...,T-1`, cohort `c` occupies color `c xor (t mod 2)`.

Write `g_p(s)` for the exact minimum neighborhood size of an `s`-element subset of color `p`. The independent implementation uses the explicit odd-rectangle formulas, with `g_p(0)=0`:

- `g_0(s) = s + min(ceil(sqrt(s)), b, ceil(sqrt(E-s))-1)`;
- `g_1(s) = s + min(rho(s)+1, b+1, rho(M-s)+1)`, where `rho(x)` is the least integer `r>=0` with `x<=r(r+1)`.

Given a daily quota word `q=(q_0,...,q_(T-1))` with `0<=q_t<=k`, the canonical one-cohort count obeys

`z_0=C_c`, `z_(t+1)=g_(c xor(t mod 2))((z_t-q_t)_+)`.

If a physical strategy clears cohort `c` by day `T`, its canonical count also ends at zero. Indeed, after inspecting at most `q_t` cohort rooms, the actual remaining count is at least `(s_t-q_t)_+`; its next neighborhood has at least `g_p((s_t-q_t)_+)` cells. Induct on `t`, using monotonicity of `g_p`.

Unused inspection budget can be padded by abstract dummy quota. Thus every successful full-board strategy gives two successful canonical words `q^(0),q^(1)` satisfying

`q_t^(0)+q_t^(1)=k` for every day `t`.

No assertion that every canonical count history is physically attainable is required for this lower-bound implication. Empty cohorts remain empty. Applying the otherwise irrelevant final movement after capture also leaves the terminal count zero. Adaptive physical strategies cause no difficulty: before capture their only observation is that every preceding inspection failed, so they specify one such quota word along that branch.

## 2. What the two relaxations mean

The producer constructs the full forward-reachable, backward-terminal-viable directed acyclic graph for each individual cohort. A unit nonnegative source-to-terminal flow is exactly a probability distribution on complete successful canonical quota words. This follows from finite acyclic flow decomposition.

- **Marginal mode:** for each day and each quota `q`, the probability that cohort 0 receives `q` equals the probability that cohort 1 receives `k-q`.
- **Mean mode:** only the expected quotas are required to sum to `k` on each day.

Both are necessary conditions for a physical capture strategy. Mean mode is the weaker relaxation. They do not synchronize complete quota histories; even marginal mode may pair different histories inconsistently on different days. Feasibility therefore supplies neither a physical strategy nor an exact capture time. Exact infeasibility proves a lower bound.

The source/flow signs, phase convention, quota indices, terminal treatment, and conservation constraints in the reviewed producer are consistent with this interpretation. The producer's feasible-flow exact checker validates marginal mode; it does not yet certify a feasible mean-mode receipt. That limitation does not affect the infeasibility certificates reviewed here.

## 3. Exact weighted temporal-demand lemma

For arbitrary fixed real weights `w_0,...,w_(T-1)`, define

`A_c(w) = min { sum_t w_t q_t : q is a successful canonical word for cohort c }`.

If a physical capture strategy exists by day `T`, then

`A_0(w)+A_1(w) <= k sum_t w_t`.

Proof: its two quota words have cost at least their respective minima, while their costs sum to the right-hand side by daily quota complementarity. Therefore strict reverse inequality excludes capture.

This is a history-dependent lower-bound tool even though the price at any one day is linear in quota. Each minimum ranges over an entire successful history, so the same path must satisfy the requirements of all the weighted days. It is stronger than an unweighted total-ammunition bound.

For the marginal relaxation, replace the linear price `w_t q` by any quota price `lambda_t(q)`, and minimize `+lambda_t(q)` for cohort 0 and `-lambda_t(k-q)` for cohort 1. Positive sum of those two minima excludes capture. Exact backward path dynamic programming evaluates these minima and yields valid node potentials automatically.

This lemma does not assert that some weights always separate every infeasible deadline. Such a uniform separation theorem remains unproved.

## 4. Independent exact checks

The independent scripts import neither the producer nor its profile module, use no optimization library, regenerate the profiles and all canonical path edges, and use integer/rational arithmetic throughout:

- `src/joint_20260918_arithmetic_flow_review.py`: marginal receipt replay and exact path-price minima.
- `src/joint_20260918_arithmetic_weights.py`: mean receipt replay and exact weighted path minima.

For the producer's 11 by 11, budget 7, deadline 49 marginal receipt, all 20,856 edge inequalities pass, with minimum edge slack 0 and source-potential sum -999902. Independently recomputed minimum complete-path prices are 1383753 and 289498, summing to the strictly positive 1673251. Projecting each quota-price row to its endpoint-linear slope still gives positive separation 10656895; symmetrizing those slopes gives 22525894.

The mean-mode receipt for the same board passes all 20,856 exact edge inequalities with right-hand side -999616. Its independently recomputed weighted-demand separation is 1131485.

The 17 by 17, budget 10, deadline 97 mean receipt passes all 140,555 edge inequalities, minimum slack 0, right-hand side -998986. Independent weighted minima are 36851613 and 34747975; available weighted budget is 70430470, leaving separation 1169118.

The producer's integer repair is valid: after uniformly scaling and rounding its candidate dual, adding `repair*(T-t)` to every layer-`t` node potential raises each one-day edge slack by exactly `repair`. It increases the two-source dual objective by `2*T*repair`; the final exact check must still find a negative objective. This was checked independently above rather than inferred from floating solver status.

## 5. Simple triangular prices succeed on all five initial difficult targets

No optimized weights are needed for these particular targets. Take

`w_t = 1 + min(t,T-1-t)`.

Every deadline here is odd, `T=2h-1`, so the available weighted budget is `k*h^2`. Exact individual weighted minima give:

- 11 by 11, `k=7,T=49`: `2175+2330-4375=130`.
- 17 by 17, `k=10,T=97`: `12320+11931-24010=241`.
- 19 by 19, `k=10,T=225`: `64799+63707-127690=816`.
- 21 by 21, `k=12,T=133`: `27262+27535-53868=929`.
- 35 by 35, `k=35,T=55`: `13874+13759-27440=193`.

Each positive difference excludes the displayed deadline. These five computations strengthen the evidence for a simple uniform temporal inequality, but do not establish it.

The triangular optimum in each of these ten single-cohort runs can be chosen supported in one consecutive suffix, starting at or just before the midpoint. Most positive quotas are `k`, with a few smaller root-boundary or final quotas. This motivates an endpoint-concentration argument in the difficult low-budget region, but the universal version is false: see the next section.

Receipts: `arithmetic-weighted-path-independent.json`, `arithmetic-triangle-targets.json`, `arithmetic-timed-flow-independent.json`.

## 6. Failed simplifications and exact counterexamples

### Independent interval demands cannot just be summed

The triangle is the sum of indicators of the nested central intervals `[j,T-1-j]`. Nevertheless, replacing the minimum of the total weighted cost by the sum of the individual interval-cost minima is too weak. That replacement lets each interval select a different history.

On the five targets above, the sums of the independently minimized interval demands minus available weighted budget are respectively

`-104, -602, -421, -686, -4687`.

Thus the useful positive triangular separation depends on compatibility of a single cohort history across the intervals. A uniform proof must retain this coupling. Receipt: `arithmetic-central-intervals.json`.

### Universal triangular prices and universal endpoint concentration fail

Root found the 9 by 11, `k=17,T=7` counterexample. Independently replaying it gives triangular minima `127+126`, below the available `272`. Winning single-cohort words can split their effort between the two cheap ends, so a universal endpoint-concentration theorem would be false.

This case is nevertheless excluded by flat prices: minima `61+61 > 119`. Truncating the triangle at height 2 yields `106+107 > 204`. Heights 3 and 4 fail with margins -2 and -19. This is evidence for varying the temporal weight shape with the budget/clock regime, not a proof that a fixed finite family always suffices.

### Successful quota words do not form an integral generalized polymatroid

The usual simultaneous exchange axiom already fails at minimum budget. On the 3 by 3 board, `k=2,T=7`, consider the cohort starting in the smaller color class, of size 4. Two successful words are

`x=(2,2,1,2,2,2,2)`, `y=(0,0,2,2,2,2,2)`.

Their count histories are respectively

`(4,4,3,4,3,3,2,0)` and `(4,5,4,4,3,3,2,0)`.

Both are coordinatewise minimal successful words, with totals 13 and 10. At coordinate `i=0`, reducing `x_i` by one makes it fail. The only coordinate with `x_j<y_j` is `j=2`. Although `x-e_0+e_2` succeeds, `y+e_0-e_2=(1,0,1,2,2,2,2)` has count history `(4,5,4,5,4,4,3,3)` and fails. Hence neither allowed simultaneous exchange exists.

The axiom and its connection with integral generalized polymatroids are given in Murota and Shioura, [M-Convex Function on Generalized Polymatroid](https://pubsonline.informs.org/doi/10.1287/moor.24.1.95) (1999), and in Fujishige's [Submodularity and Discrete Convexity](https://www.kurims.kyoto-u.ac.jp/~fujishig/nips2.pdf) exposition. This explicit failure blocks an automatic appeal to generalized-polymatroid intersection for the untransformed quota-word sets. It does not refute a different transformed state space, a special paired-horizon theorem, or mean-flow exactness itself.

Receipts: `arithmetic-polymatroid-tests.json`, `arithmetic-polymatroid-lowbudget-tests.json`.

## 7. What would close a genuine family gap

A useful uniform theorem would explicitly prescribe day weights from the rectangle, budget, and proposed deadline, and prove the two weighted demands exceed the available weighted budget exactly at the unresolved false deadlines. A slightly more general route would prove that the mean-flow relaxation is exact for this specific pair of full-board cohort languages, then derive a structural dual. Generic automaton and generalized-polymatroid results do not supply that theorem automatically.

For the numerical completion criterion, even uniform exactness of the relaxation is insufficient by itself: the resulting optimization must still be reduced to a fixed-size expression using standard numerical operations, and direct optimal inspections must be supplied separately. No new O(1) formula or new complete Lean theorem is claimed here.

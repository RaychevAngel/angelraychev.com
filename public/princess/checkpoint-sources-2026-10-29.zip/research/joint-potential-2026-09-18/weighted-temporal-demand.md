# Weighted temporal demand with an individual daily cap

18 September 2026. A sound lower-bound framework, exact finite certificates,
and an unproved uniform direction. This is private research. The numerical
completion criterion remains an absolute fixed number of standard operations.
Neither the path minimization below nor the certificate generator meets it.

## General statement and proof

Let a finite bipartite graph have checkerboard classes V_0,V_1 of sizes C_0,C_1.
Let g_p(s) be an integer-valued nondecreasing lower bound on the size of the neighborhood of
any s-element subset of V_p, with g_p(0)=0. Fix deadline D, budget k, and
nonnegative day weights lambda_0,...,lambda_(D-1).

For origin color c, a quota word q=(q_0,...,q_(D-1)) has integer entries
0<=q_t<=k. Define its canonical count trajectory by

    s_0=C_c,
    s_(t+1)=g_(c xor (t mod2))(max(0,s_t-q_t)).

Call the word successful if s_D=0, and let

    W_c(lambda)=min { sum_t lambda_t q_t : q is successful },

with minimum infinity when there is no successful word. If the physical
full-uncertainty game can be won by D days, then

    W_0(lambda)+W_1(lambda) <= k sum_t lambda_t.             (1)

Proof. Split each day's inspected cells according to the cohort they could
contain: initial color c occupies physical color c xor(t mod2). The resulting
quota words have q_0,t+q_1,t<=k and each coordinate at most k. By induction,
the canonical count is at most the physical cohort size: after inspections,
at least max(0,physical size-q_t) possible cells survive, and their neighborhood
has at least the corresponding g-value. Monotonicity of g completes the
induction. Thus physical capture makes both canonical words successful.
Their weighted costs sum to at most the right side of (1), because the
weights are nonnegative. Each cost is at least its own minimum. QED.

The harmless last neighborhood update preserves the empty set, so D is the
number of inspections, not inspections plus an extra movement day. The model
allows wasted quotas; this strengthens the necessary condition and cannot
make a lower-bound certificate unsound.

The condition q_t<=k is essential. The earlier failure of arbitrary weighted
ammunition bounds allowed spending the whole board size on one cheap day.
Those words are excluded here. This is the precise difference from that
previously rejected proof class.

## Equivalent time-dependent potential

Define F_(c,t)(s) as the minimum weighted quota cost of reaching zero by D
from count s at time t, under the same daily cap. Terminal values are
F_(c,D)(0)=0 and infinity otherwise, and

    F_(c,t)(s)=min_(0<=q<=k)
      [lambda_t q + F_(c,t+1)(g_(c xor(t mod2))(max(0,s-q)))].

For any canonical step, F_(c,t)(s)<=lambda_t q+F_(c,t+1)(s').
The same inequality holds for a larger physical successor because F is
nondecreasing in its count argument. Using this form avoids infinity minus
infinity; only finite successful histories are telescoped.
Summing both cohorts and telescoping gives (1). This formulation explains
what the certificate proves; defining F by a dynamic program does not count
as the desired final explicit potential or fixed-size numerical answer.

## Exact boundary of this proof class

Let Q_c be the finite set of successful quota words and P_c its convex hull.
If Q_c is empty for either color, impossibility is already immediate; assume
both are nonempty in the convex argument.
If there are x in P_0,y in P_1 with x+y<=k coordinatewise, no nonnegative
day weights can contradict (1). Conversely, if no such pair exists, convex
separation supplies nonnegative weights with strict violation of (1).
Indeed, k times the all-ones vector lies outside the closed upward polyhedron
P_0+P_1+R^D_(>=0); a separating functional must be nonnegative because that
polyhedron is upward closed. Its minimum on the two polytopes is W_0+W_1.

This is a theorem about the proof class, not a theorem that it always detects
physical impossibility. A feasible pair of distributions of successful words
does not provide two compatible actual words. Its means can hide temporal
correlations. Proving that this relaxation is exact at the relevant rectangle
deadlines, or constructing prices directly without needing that stronger
claim, is a remaining task.

## A genuine reduction: nonnegative symmetric prices suffice

For the physical successful quota-word languages on any undirected bipartite
graph without isolated vertices, the day-price search can be restricted to nonnegative time-symmetric
prices. Here a quota word prescribes allowed inspections, so its successful
language is upward closed within the box0<=q_t<=k.

First, negative prices are unnecessary. At a negative-price coordinate an
optimal word may be increased to k without harming success. Replacing all
negative prices by zero therefore changes each W_c by exactly the opposite
of k times their sum. Consequently it cannot decrease the separation gap
W_0+W_1-k sum lambda.

Second, reverse the inspection sequence and every possible surviving walk.
A successful D-day word for origin color c becomes a successful reversed
word for origin color c xor((D-1) mod2). This uses D inspected positions
along a walk of D-1 edges. Therefore reversal either preserves or swaps the
two minimum-cost functions. Each W_c is concave in the day prices, being a
minimum of linear functions. Averaging a price vector with its reversal
cannot decrease W_0+W_1, and leaves the available weighted budget unchanged.
Thus any separating prices have nonnegative symmetric separating prices.

For odd rectangles the accepted compatible-prefix realization makes the
canonical quota language exact, so this also applies to the numerical
oracle used here. The independent review gives the direct inverse-profile
proof. For a generic loose neighborhood lower bound, reversal of its relaxed
word language must be checked rather than assumed.

This removes unnecessary sign and time-asymmetry choices. It does not prove
that unimodal, triangular, clipped, or finitely parameterized prices always
suffice, nor that every impossible deadline has a linear-price separator.

## Checked odd-rectangle certificates

Use the accepted exact odd-rectangle profiles in supersession_solo_bands.py.
All figures below are integer shortest-path minima, independently recomputed
by a checker that imports neither the producer nor an optimization library.
For the simple triangle lambda_t=1+min(t,D-1-t):

- 11 by11, k7, D49: W_0=2175, W_1=2330, available4375, excess130.
- 17 by17, k10, D97: W_0=12320, W_1=11931, available24010, excess241.
- 19 by19, k10, D225: W_0=64799, W_1=63707, available127690, excess816.
- 21 by21, k12, D133: W_0=27262, W_1=27535, available53868, excess929.
- 35 by35, k35, D55: W_0=13874, W_1=13759, available27440, excess193.

These exclude the listed deadlines. They agree with existing exact times
50,98,226,134,56, respectively. They are new certificates and evidence for a
method, not new numerical classifications. In particular they exceed the
earlier optimal stationary-potential bounds on the11 and17 square benchmarks.

The independent certificates are arithmetic-triangle-targets.json and
arithmetic-weighted-path-independent.json. Separately, exact integer Farkas
certificates for unrestricted day prices were checked edge by edge on
11 by11 and17 by17 (20,856 and140,555 transition inequalities). A larger
19-square LP hit its deliberately short time limit; the simple triangle
certificate settles that diagnostic without the LP.

## Attacks and failures

1. Triangle weights are NOT universally sufficient. On9 by11,k17,D7,
   W_0=127 and W_1=126, below the available272. Both minimizing words split
   inspections between the beginning and end. Constant weights do exclude
   this deadline:61+61>119. A triangle clipped at2 also works:106+107>204.

2. Different central intervals cannot be minimized independently and then
   summed. On11 by11,k7,D49 that weaker sum is4271<4375; minimizing the
   whole triangle on a SINGLE history gives4505>4375. The time coupling
   within each cohort is essential, even before coupling the two cohorts.

3. A generic generalized-polymatroid justification is unavailable: actual
   successful quota words already violate the necessary simultaneous
   exchange property on3 by3,k2,D7. See the independent review for words.

4. Endpoint concentration fails inside the difficult budget range too:
   on7 by9,k8,D11 the larger cohort has triangular cost165 using two separated
   blocks; every single consecutive positive block costs at least168.
   The direct Abel summation bound that minimizes each time's state term
   independently is also too weak on the five main benchmarks. Neither
   failure refutes the weighted lower-bound framework.

5. On even-area rectangles, cardinality profiles alone allow incompatible
   shapes to be substituted between steps. No choice of day prices can
   repair an actual successful pair in that relaxed count model. Geometric
   transition information is still required there. The matching-rank
   collision in geometry-matching-potential.md illustrates this explicitly.

## Reproduction and next proof obligation

- src/joint_20260918_timed_flow.py: quota-marginal and mean-quota flow LPs;
  optional direct Farkas search; exact integer rounding with drift repair.
- src/joint_20260918_price_cuts.py: small day-price master problem with
  exact cohort-path separation; integer certificate replay.
- src/joint_20260918_arithmetic_weights.py: independent profile construction,
  exact weighted path minima and mean-certificate validation.
- src/joint_20260918_triangle_probe.py: exact int64 falsification of simple
  weights, with explicit magnitude bound and attaining-word replay.

The promising next statement is an analytic comparison for the same complete
cohort history under a suitable simple day-weight profile. A proof cannot
replace that history by independently optimal paths for its constituent
time intervals. Endpoint concentration for the low-budget profiles remains
a candidate and must be attacked before being used. The high-budget example
above refutes its unrestricted version. No new Lean coverage is claimed.

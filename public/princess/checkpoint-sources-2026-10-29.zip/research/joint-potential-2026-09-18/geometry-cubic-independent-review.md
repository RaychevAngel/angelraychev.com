# Independent review of the adjacent-strip cubic certificate

18 September 2026. Accepted as an exact finite solo-game certificate.

I independently reconstructed the 13 integer orbit coefficients of `4 Psi`
from `src/joint_20260918_boundary_exact.py`, expanded their square-symmetry
orbits by rotation and reflection rather than the discovery code's canonical
orbit representative, and used a separate bit-mask neighborhood and
inspection enumerator. No discovery matrix, floating-point optimizer, or
boundary helper was imported.

The independent checker is
`src/joint_20260918_geometry_cubic_review.py`; its receipt is
`research/joint-potential-2026-09-18/geometry-cubic-review.json`.

Exact results:

* There are 82 nonzero physical monomials in the 13 specified orbits. Every
  representative lies within two adjacent rows or two adjacent columns;
  this property survives the square symmetries.
* All 512 single-color physical supports and all 5,062 distinct physical
  transitions with at most three inspections, including both empty loops,
  satisfy `4 Psi(A)-4 Psi(N(A\I)) <= 4`.
* The empty potential is zero. Both full colors have scaled potential 24.
  Telescoping therefore proves at least six solo inspection days.
* A separate breadth-first reachability calculation finds an attaining
  six-day history. Its physical belief masks are
  `42405,23114,42400,23104,42240,20992,0` in row-major `4x4` encoding.

The minimum scaled potential on the enumerated supports is -4. This does
not invalidate the telescoping argument: only the specified initial and
terminal values and the step inequality are required.

The certificate establishes the exact solo value on `4x4,k=3`. It is a
constructive proof that a cubic geometric interaction can recover the sharp
clock where the tested linear and quadratic polynomial potentials fall
short. It is not yet a formula or a parameter-uniform potential. Its
adjacent-strip locality restricts one coordinate; some monomials span most
of the other coordinate of this small board. No bounded longitudinal
interaction range for arbitrarily large boards follows. Finally, summing
two such solo lower bounds does not automatically prove a shared-budget
full-game lower bound; the daily quota allocation still needs its own
argument.

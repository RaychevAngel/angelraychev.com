# Rectangle checkpoint: reconciliation against the fixed objective

## Publication checkpoint: 29 October 2026

Current accepted research: `research/paired-regional-2026-10-28/RESULTS.md` and its `CHECKPOINT.md`. Whole-domain computable gap is at most TWO, not zero. Every odd width at least8193 and every even length is exact at all budgets; all earlier exact regimes remain. Actual reshaping proves T_48(64,93)=285 and T_72(102,124)=413. Uniform paired boundary reachability remains open. Expression simplification is deferred.

This publication pass synchronizes the manuscript, website and packages and adds a narrowly scoped Lean paired-compression theorem. It does not claim complete Lean verification of the new rectangle results. See `research/publication-2026-10-29/` for compilation/release receipts and `research/deployment-verification.json` for actual live publication evidence. Historical entries below describe their own dates.


## Latest private research continuation: 25 October 2026

Current accepted results: `research/boundary-reachability-2026-10-25/RESULTS.md`.
Restart: `research/boundary-reachability-2026-10-25/CHECKPOINT.md`.

A new history-dependent surplus bound controls EVERY intermediate shape
of near-optimal prefixes, including mixed states and retreats. Exact literal
cutset transitions and endpoint intersections now supply reviewed capture
evaluators across the stated even- and odd-width budget ranges. At high
budget the simpler whole-word expansion identity removes the endpoint join
entirely. See the results index for exact parameter guards and costs.

These are structured exact algorithms, with real sub-area complexity in
specified regimes; at some parameters they can degenerate to the generic
power-set search. No large capture graph has been evaluated. The inexpensive
uniform ceilings remain3 overall,2 at every width>=64, and1 in the retained
high-budget range. This is not a claim that the old scalar bounds match or
that the final O(1) expression/direct inspection rule has been obtained.

New proofs and independent receipts are private. The public website,
manuscript/PDFs, downloads and83 Lean sources remain unchanged; no new
compilation or deployment is claimed. Earlier dated accounts below remain
history. Expression simplification is still deferred until uniform gap zero.

## Previous private research continuation: 24 October 2026

The current mathematical status is
`research/phase-compatibility-2026-10-24/RESULTS.md`; restart from its
`CHECKPOINT.md`. The former candidate is independently verified. The
whole-domain gap improves from four to THREE, and every width at least64
has gap at most TWO. A new physical odd-width join is exact at all even
lengths and all b<k<3b under its genuine span certificate, unconditionally
for b>=10^18. Exact even transport, odd-by-odd and all earlier cases remain.
New even history/geometry reductions do not yet close global gap zero.

The public release described below is unchanged and now predates these
private advances. Its four-day/candidate-unverified language describes that
release, not current private mathematics. No new Lean theorem or compilation
is claimed. Numerical-expression simplification remains deferred until gap
zero for every w,n and feasible k. Subsequent dated material is preserved
history; the current research status and exact limitations are in the linked
continuation summary.


## Publication synchronization: 24 October 2026

Publication synchronization is complete and live-verified. The website,
164-page rectangle manuscript, 29-page parked companion, source downloads,
and formalization-coverage records now agree with the accepted October
checkpoint. Both downloaded LaTeX packages compile independently; 915 local
links and anchors passed, and all 160 live pages/assets checked match the
verified release byte-for-byte. Website commit: `bbab144073e765c42f973ee0159cc573afe08541`.

The accepted uniform gap remains at most four; global gap zero remains open.
The 751-profile comparison closure is explicitly unverified and excluded from
all accepted bounds. All 83 canonical Lean sources match the historical
compiler receipt; no new Lean theorem or compilation is claimed. This pass
synchronized publication artifacts without further mathematical research.
See `research/checkpoint-publication-completion-2026-10-24.json`,
`research/publication-package-verification.json`, and
`research/deployment-verification.json` for final verification evidence.

Current source of mathematical status:
`research/phase-dependencies-2026-10-24/RESULTS.md`. Current publication and
evidence map: `publication/CHECKPOINT_EVIDENCE.md`, plus the refreshed coverage,
gaps and reconciliation assessments. The previous public rectangle release
is preserved in `archive/2026-09-13-pre-october-release/`; the private frozen
research archive remains unchanged.

All dated accounts below are historical. Their statements that artifacts
have not been synchronized describe their own original research pass, not
the status of this publication pass. No new mathematical unification is
claimed by this synchronization.

Frozen at the user's 24 October wrap-up request. The authoritative summary
of this private pass is `research/phase-dependencies-2026-10-24/RESULTS.md`;
restart obligations are in `ROOT-RESTART.md` and the three lane checkpoints.
Research is stopped. Public artifacts and Lean retain their previous scope.

Latest private research (24 October2026, phase/dependency continuation):
read `research/phase-dependencies-2026-10-24/CHECKPOINT.md` and
`root-uniform-four.md` there. The accepted computable/constructive gap is
now at most FOUR for every rectangle and feasible budget. Both ordinary
boundary clocks are physically necessary with no extra day. Exact even-width
transport families now include b>=32, minimum budget at all lengths and
2<=d<=b-1 at n>=2b+2d-2. The accepted genuine-orbit refinement in
`root-large-excess-one-middle.md` gives gap<=2 at EVERY even width>=64 and
every feasible budget, and at odd widths2b+1>=65 for k>=2b. A reviewed
12-threshold localized-successor evaluator further improves necessary
bounds. The independently reviewed common-cut argument now gives exact
capture for odd w=2b+1, even n=2ell, k=b+d whenever b>=4d+8 and
(2b+1)(ell-b)>2d^2; in particular all lengths when also b>=d^2.
The stronger genuine-span criterion and independent minimum-budget proof
are recorded in the current research checkpoint. The all-budget ceiling
remains four. Gap zero
globally remains open; the next research task is
middle phase/shape compatibility. No expression simplification, new Lean
coverage, or public-artifact synchronization is claimed for this pass.
Earlier checkpoint paragraphs below are preserved history.

## October 24 private research update

For the current mathematical status, read
`research/overnight-uniform-2026-10-24/CHECKPOINT.md`. The computable necessary
lower and constructive upper bounds now have a proved gap of at most8 for
EVERY w<=n and feasible k>=floor(w/2)+1, down from the prior uniform25
(23 at even width). All older exact and sharper bounds remain available.
The new proof and complete parameter coverage have independent reviews.

Matching bounds everywhere remain open. The user's current priority is
uniform bound tightening with recurrences/preprocessing permitted; work on
the final O(1)-operation expression is deferred until gap zero is proved
throughout the domain. Guarded boundary improvements and explicit four-day
transport families are recorded in the linked checkpoint. Finite diagnostic
maxima must not be read as unbounded-parameter theorems.

These are private ordinary proofs and exact computational certificates,
not newly completed Lean formalizations. The website, manuscript, PDFs,
and public release have not been synchronized to this research checkpoint.
The September material below is retained historical release documentation;
its descriptions of then-current gaps are superseded where indicated above.

18 September 2026. Research resumed with explicit user authorization. The
completion criterion is unchanged. No arXiv submission or outreach occurred.
Independent extensions remain parked.

## September 18 private research addendum

The latest follow-up is `research/joint-potential-2026-09-18/RESEARCH_LOG.md`.
It proves a capped weighted temporal-demand lower-bound framework, reduces
its price search to nonnegative symmetric prices, and independently certifies
the missing lower-bound day on known benchmarks. Exact pyramid-closure
charging identifies the remaining daily-budget correction on arbitrary
physical supports. Static matching ranks and several temporal normal forms
were refuted by exact examples. This improves the proof tools, not the set
of fully classified parameter families or the fixed-operation clock coverage.

The preceding pass is recorded in `research/closure-2026-09-18/RESEARCH_LOG.md`.
It proves and independently reviews new boundary/slack identities for arbitrary
physical supports, a uniform stability theorem for two balanced middle states,
a fixed-size evaluator for the local odd orientation guard, and an exact
ceiling-iteration representation of the difficult whole-clock contribution.
The latter is still an iteration, not the required bounded numerical answer.

Several candidate global inductions were falsified, including one that survived
millions of random transitions before a targeted boundary check broke it.
Counterexamples to synthetic-state induction are explicitly separated from
actual reachable-state counterexamples. The remaining true-orbit and global
boundary-credit obligations are stated in the research log.

**No new exact capture-time range is claimed by this pass.** In particular
24x24 at budget13 remains206..207; all four original residual families retain
an unfilled part. The new tools are ordinary proofs with independent review,
not new Lean theorems. Public artifacts below refer to the September 13 release
and have not been rebuilt or redeployed during this research pass.

## Read this assessment first

`research/BOX_RECONCILIATION.md` compares the current results with commit
`d38c1b0`, the completed scope separation and absolute O(1) reassessment.
Unchanged baseline files are preserved in `archive/2026-09-13-scope-baseline/`.
This includes both research passes since that baseline. Do not count the
older minimum-budget odd theorem, feasibility or exact evaluators again.

For every positive rectangle a,b and constant daily budget k>=0, determine
T_k(a,b)=T_k(b,a), infinity included, using a fixed-size O(1) number of
standard numerical operations independent of all parameters. Specify optimal
inspections directly and prove capture and minimality. Initial uncertainty
is the full board; inspections are simultaneous; movement after a miss is
compulsory along one edge. Printing the sequence need not take O(1).
Recurrences and parameter-dependent optimization remain intermediate results.

## September 13 coverage changes since the baseline

None of the four original infinite residual families has been fully removed.
The main advance is matching bounds and direct strategies on broad odd-board
budget regions; the advance to fixed-size numerical answers is narrower.
A global percentage would have no specified measure on the infinite domain.

- Every seven-row odd-length board now has a fixed-size formula at every
  budget. Seven-row even-length boards are not thereby complete.
- For even width2r>=6, the entire budget boundary k=r(r-1) has a fixed-size
  exact formula and direct optimal inspections at every length. The sixteen-
  row exceptional residue needed a real shape-change improvement of the upper.
- T_13(25,n)=50n-925 for every even n>=26, with direct optimal inspections,
  a uniform geometric proof and independently checked finite certificates.
- At odd width2r+1 and every odd length, the solo central test is exact at
  every feasible k>=r+1 satisfying k<=2r or27k^3<=r^4. This gives direct
  optimal strategies. Width-dependent clocks still obstruct the numerical
  completion criterion throughout parts of these regions.
- Fixed49-block odd clocks and fixed168-block even bound evaluators yield
  additional exact O(1) regions under their stated inequalities and matching
  conditions. See `research/RECTANGLE_COVERAGE.md`; these are actual fixed
  operation counts, not variable-length algorithms named as one operation.
- Even-area bounds are within one day above the uniform linear budget
  threshold ceil(4w/3), sharpened to ceil(13w/10) at even widths. This does
  not settle the day or cover every feasible budget.
- Minimum-budget even widths have a uniform prescribed corner-change upper
  construction. Its width constant is iterative and optimality remains open.
  At w24,k13:24n-370<=T<=24n-369 for even n; at odd n>=25 the upper is
  24n-368. In particular24x24 remains206 versus207.
- Odd minimum-budget widths>=17 still have the old exact width recurrence
  and direct strategy. Its missing fixed-size width constant has not been
  obtained: the third original numerical gap remains.

Persistent corner radii, whole near-extremal intervals, critical geometry,
exact corner-ball intersections and a clipped Bellman potential strengthen
the common lower theory. Sharp-event charge and odd orientation preservation
remain conjectural. Finite diagnostics do not prove their uniform versions.
The accepted proofs, rejected approaches and provenance are in
`research/bridge-family-independent-review.md`,
`research/bridge-reconciliation-review.md`, and the private
`research/bridge-research-log.md`.

## Artifacts and proof boundary

Main manuscript:164 pages, six figures. Parked companion:30 pages, two
figures. This is an expanded research checkpoint, not a compact journal-ready
paper. The original combined128-page release is frozen unchanged.

There is no new complete physical-game Lean classification. The83 canonical
formal modules are unchanged:43 main,51 companion,11 shared. Complete main
physical classifications remain paths and two rows. Source hashes and local
import closures are checked against the historical compilation receipt;
this is not a new compiler run or verification of the new general theorems.

Both PDFs compile cleanly. All194 pages received visual review, with full
page inspection of the new proof sections. The website overview and new
reconciliation page passed a local browser review. Both extracted TeX
archives compile independently; local links, source closure and frozen
assets pass. Final package and live-delivery receipts are recorded below.

## Verified delivery

Website commit `2929eb6794e9068f0cc26170329af163e84b4907` is live.
GitHub Pages workflow34770364209 succeeded. All143 checked live pages,
downloads and assets match the reviewed local build byte for byte.
Both isolated TeX source packages compile,865 local links/anchors pass,
and the historical combined archive is unchanged.

- `research/publication-package-verification.json`: extracted builds and links.
- `research/pdf-layout-verification.json` and `research/bridge-pdf-*-review.md`:
  all-page render and visual reviews bound to the delivered PDFs.
- `research/deployment-verification.json`: complete live readback and hashes.
- `research/separation-lean-verification.json`: unchanged compiler inputs/imports.

https://angelraychev.com/princess/reconciliation/
https://angelraychev.com/princess/coverage/
https://angelraychev.com/princess/gaps/
https://angelraychev.com/princess/paper/
https://angelraychev.com/princess/extensions/

The latest Cop/Prisoner publication was preserved. The temporary browser
preview, server and dependency symlink were removed. No mathematical search
or Lean compiler remains running from this pass.

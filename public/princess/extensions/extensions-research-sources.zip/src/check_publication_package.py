"""Check both scoped packages, all Princess links, and independent TeX builds."""
from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urlparse,unquote,urljoin
import json,hashlib,zipfile,subprocess,tempfile,re
from publication_paths import SITE
ROOT=Path(__file__).resolve().parents[1];DIST=SITE/'dist';PUBLIC=SITE/'public/princess'
class Page(HTMLParser):
 def __init__(self,path):
  super().__init__();self.ids=set();self.links=[];self.errors=[];self.feed(path.read_text())
 def handle_starttag(self,tag,attrs):
  a=dict(attrs)
  if 'id' in a:self.ids.add(a['id'])
  if tag=='a' and 'href' in a:self.links.append(a['href'])
  if 'katex-error' in a.get('class',''):self.errors.append(a)
pages={p:Page(p) for p in (DIST/'princess').rglob('index.html')}
required=['princess/index.html','princess/proofs/index.html','princess/lean/index.html','princess/paper/index.html','princess/coverage/index.html','princess/gaps/index.html','princess/reconciliation/index.html','princess/extensions/index.html','princess/extensions/proofs/index.html','princess/extensions/lean/index.html','princess/archive/2026-09-13-combined/index.html']
for name in required:assert DIST/name in pages,name
issues=[];checked=0
for path,page in list(pages.items()):
 assert not page.errors,str(path)
 base='https://local/'+str(path.relative_to(DIST))
 for href in page.links:
  u=urlparse(urljoin(base,href))
  if u.netloc not in ('local','angelraychev.com') or not u.path.startswith('/princess'):continue
  target=DIST/unquote(u.path.lstrip('/'))
  if target.is_dir():target=target/'index.html'
  if not target.exists():issues.append((str(path),href,'missing file'));continue
  if u.fragment and target.suffix=='.html':
   if target not in pages:pages[target]=Page(target)
   if unquote(u.fragment) not in pages[target].ids:issues.append((str(path),href,'missing anchor'))
  checked+=1
assert not issues,issues
assert checked>100
scope=json.loads((ROOT/'publication/lean-scope.json').read_text());membership=json.loads((ROOT/'publication/artifact-manifest.json').read_text())['files']
full=json.loads((ROOT/'research/lean-verification.json').read_text());byname={Path(r['file']).stem:r for r in full['files']}
tex=Path('/Users/angel/Library/TinyTeX/bin/universal-darwin');results={}
configs={'main':(PUBLIC,'main','manuscript-source.zip','lean-proofs.zip','research-sources.zip',{'main','shared'}),'extensions':(PUBLIC/'extensions','extensions','extensions-source.zip','extensions-lean-proofs.zip','extensions-research-sources.zip',{'parked','shared'})}
from pypdf import PdfReader
for key,(pub,stem,sourcezip,leanzip,researchzip,kinds) in configs.items():
 release=json.loads((pub/'release.json').read_text())
 for name,row in release['files'].items():assert hashlib.sha256((pub/name).read_bytes()).hexdigest()==row['sha256']
 expected={n for n,r in scope['modules'].items() if r['scope'] in kinds}
 with zipfile.ZipFile(pub/leanzip) as z:
  assert z.testzip() is None
  assert {Path(n).stem for n in z.namelist() if n.endswith('.lean')}==expected
  for n in expected:
   row=byname[n];assert hashlib.sha256(z.read(row['file'])).hexdigest()==row['sha256'];assert set(scope['modules'][n]['imports'])<=expected
  r=json.loads(z.read('research/lean-verification.json'));assert r['new_compilation'];assert r['checked_at_utc']==full['checked_at_utc'];assert len(r['files'])==len(expected)
 with zipfile.ZipFile(pub/researchzip) as z:
  assert z.testzip() is None
  members=set(z.namelist())
  assert not any('intake' in n or 'student-comparison' in n or 'source-inventory' in n for n in members)
  for n in members:
   if n in membership:assert membership[n]['scope'] in kinds,(key,n)
  for n in members:
   if n in membership:
    for dep in membership[n].get('local_imports',[]):assert dep in members,(key,n,dep)
 with tempfile.TemporaryDirectory(prefix=f'princess-{key}-package-',dir=ROOT/'tmp') as td:
  with zipfile.ZipFile(pub/sourcezip) as z:z.extractall(td)
  for command in [('pdflatex','-interaction=nonstopmode','-halt-on-error',stem+'.tex'),('bibtex',stem),('pdflatex','-interaction=nonstopmode','-halt-on-error',stem+'.tex'),('pdflatex','-interaction=nonstopmode','-halt-on-error',stem+'.tex')]:
   r=subprocess.run([str(tex/command[0]),*command[1:]],cwd=td,capture_output=True,text=True);assert r.returncode==0,r.stdout[-5000:]+r.stderr
  log=(Path(td)/(stem+'.log')).read_text();assert not re.search(r'Overfull|undefined references|undefined citations|Citation .* undefined|Reference .* undefined',log),log[-5000:]
  assert len(PdfReader(Path(td)/(stem+'.pdf')).pages)==release['pages']
 results[key]={'isolated_latex_compilation':True,'source_entrypoint':stem+'.tex','lean_modules':len(expected),'unchanged_source_hashes_and_import_closure':True,'new_lean_compilation':True,'archive_hashes':release['files']}
# Every historical file is an exact byte copy; private checkpoint/log files are not published.
old=ROOT/'archive/2026-09-13-combined';published=PUBLIC/'archive/2026-09-13-combined';frozen=json.loads((published/'archive-manifest.json').read_text())
for name,sha in frozen['files'].items():assert hashlib.sha256((published/name).read_bytes()).hexdigest()==sha
assert not any((published/name).exists() for name in ('RESEARCH_LOG.md','CURRENT_CHECKPOINT.md','README.md','RESEARCH_HISTORY.md'))
old=ROOT/'archive/2026-09-13-pre-october-release';published=PUBLIC/'archive'/old.name
frozen=json.loads((published/'archive-manifest.json').read_text())
for name,sha in frozen['files'].items():assert hashlib.sha256((published/name).read_bytes()).hexdigest()==sha
with zipfile.ZipFile(published/'proofs-source.zip') as z:assert z.read('proofs.html')==(old/'proofs.html').read_bytes()
claims=json.loads((ROOT/'research/checkpoint-publication-claims-audit-2026-10-29.json').read_text())
assert claims['status']=='PASS'
for name,sha in claims['reviewed_artifact_sha256'].items():assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==sha,name
assert (PUBLIC/'checkpoint-publication-claims-audit-2026-10-29.json').read_bytes()==(ROOT/'research/checkpoint-publication-claims-audit-2026-10-29.json').read_bytes()
with zipfile.ZipFile(PUBLIC/'checkpoint-sources-2026-10-29.zip') as z:
 checkpoint=json.loads(z.read('source-manifest.json'))
 assert checkpoint['checkpoint']=='2026-10-29'
 for name,sha in checkpoint['files'].items():
  assert hashlib.sha256(z.read(name)).hexdigest()==sha
  assert membership.get(name,{}).get('scope') not in {'private','parked'},name
  if name.startswith('lean/') and name.endswith('.lean'):
   assert scope['modules'][Path(name).stem]['scope'] in {'main','shared'},name
 assert z.read('READ_ME_FIRST.md')==(ROOT/'publication/CHECKPOINT_EVIDENCE.md').read_bytes()
# The October 24 immediately preceding release is retained byte for byte.
prior=PUBLIC/'archive/2026-10-24-pre-october29-release'
prior_source=ROOT/'archive/2026-10-24-pre-october29-release'
prior_manifest=json.loads((prior/'archive-manifest.json').read_text())
for name,digest in prior_manifest['files'].items():assert hashlib.sha256((prior/name).read_bytes()).hexdigest()==digest,name
with zipfile.ZipFile(prior/'proofs-source.zip') as z:assert z.read('proofs.html')==(prior_source/'proofs.html').read_bytes()
assert len(full['files'])==84 and full['all_passed']
assert full['checked_at_utc'].startswith('2026-10-29')
assert len([r for r in scope['modules'].values() if r['scope'] in {'main','shared'}])==44
assert len([r for r in scope['modules'].values() if r['scope'] in {'parked','shared'}])==51
current_release=json.loads((PUBLIC/'release.json').read_text())
assert current_release['research_checkpoint']=='2026-10-29' and current_release['accepted_uniform_gap']==2
paired_review=json.loads((ROOT/'research/publication-2026-10-29/packaging-lean-source-review.json').read_text())
assert hashlib.sha256((ROOT/paired_review['source']).read_bytes()).hexdigest()==paired_review['sha256']
assert (PUBLIC/'checkpoint-source-manifest.json').read_bytes()==(ROOT/'publication/checkpoint-source-manifest.json').read_bytes()
assets=json.loads((PUBLIC/'served-assets.json').read_text())['assets']
for path in PUBLIC.rglob('*'):
 if path.is_file() and path.name!='served-assets.json':assert '/princess/'+str(path.relative_to(PUBLIC)) in assets,path
receipt={'all_passed':True,'html_pages':len(pages),'local_links_and_anchors_checked':checked,'publications':results,'historical_archive_unchanged':True,'pre_october_release_preserved':True,'october24_release_preserved':True,'checkpoint_source_files_checked':len(checkpoint['files']),'publication_claim_audit_matches_current_sources':True,'public_asset_inventory_complete':True,'lean_evidence':'All 84 canonical modules freshly compiled; packaged sources match that receipt and satisfy local import closure. New PairedCompression is an abstract interface, not a rectangle gap theorem.'}
(ROOT/'research/publication-package-verification.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if k!='publications'},indent=2))

"""Generate both proof pages from their canonical TeX and preserve moved anchors."""
from pathlib import Path
import subprocess, json, re, html
from html.parser import HTMLParser
import pypandoc
from publication_paths import SITE
ROOT=Path(__file__).resolve().parents[1]
TMP=ROOT/'tmp';TMP.mkdir(exist_ok=True)
PANDOC=pypandoc.get_pandoc_path()
DOCS={'main':{'route':'/princess/proofs/','output':'princess-proofs.html','title':'Rectangle searches: detailed proofs','pdf':'/princess/princess-searches.pdf'},'extensions':{'route':'/princess/extensions/proofs/','output':'princess-extensions-proofs.html','title':'Princess searches: parked companion proofs','pdf':'/princess/extensions/princess-extensions.pdf'}}
labels={n:dict(re.findall(r'\\newlabel\{([^}]+)\}\{\{([^}]+)\}',(ROOT/'paper'/f'{n}.aux').read_text())) for n in DOCS}
allids={}
shared_aliases=json.loads((ROOT/'publication/manuscript-scope.json').read_text()).get('shared_reference_aliases',[])
class Ids(HTMLParser):
 def __init__(self,text):
  super().__init__();self.ids=set();self.feed(text)
 def handle_starttag(self,tag,attrs):
  for k,v in attrs:
   if k=='id':self.ids.add(v)
def inline_text(nodes):
 return ''.join(n['c'] if n['t']=='Str' else ' ' if n['t'] in ('Space','SoftBreak') else inline_text(n['c']) if isinstance(n.get('c'),list) and n['t'] in ('Emph','Strong') else '' for n in nodes)
def build(name,doc):
 ast=json.loads(subprocess.run([PANDOC,name+'.tex','--from=latex','--to=json','--citeproc','--bibliography=references.bib'],cwd=ROOT/'paper',check=True,capture_output=True,text=True).stdout)
 maths=[];toc=[];section=0;theorem=0
 def walk(node):
  nonlocal section,theorem
  if isinstance(node,list):return [walk(n) for n in node]
  if not isinstance(node,dict):return node
  t=node.get('t');c=node.get('c')
  if t=='Header':
   if c[0]==1:
    if 'unnumbered' not in c[1][1]:section+=1;theorem=0
    toc.append((c[1][0],inline_text(c[2])))
   c[0]=min(c[0]+1,6)
  if t=='Div' and any(x in c[0][1] for x in ('theorem','lemma','proposition','corollary','definition','remark')):
   theorem+=1
   first=c[1][0]['c'][0]
   if first['t'] in ('Strong','Emph'):first['c'][-1]={'t':'Str','c':f'{section}.{theorem}'}
  if t=='Link':
   attrs=dict(c[0][2]);key=attrs.get('reference');targetdoc=name;targetkey=key
   if key and key.startswith('main-'):targetdoc='main';targetkey=key[5:]
   elif name=='extensions' and key in shared_aliases:targetdoc='main'
   if targetkey in labels[targetdoc]:
    num=labels[targetdoc][targetkey]
    c[1]=[{'t':'Str','c':f'({num})' if attrs.get('reference-type')=='eqref' else num}]
    if targetdoc!=name:c[2][0]=DOCS[targetdoc]['route']+'#'+targetkey
  if t=='Image':
   target=c[2][0]
   if target.startswith('figures/') and target.endswith('.pdf'):c[2][0]='/princess/'+target[:-4]+'.svg'
  if t=='Math':
   display=c[0]['t']=='DisplayMath';source=c[1];keys=re.findall(r'\\label\{([^}]+)\}',source)
   source=re.sub(r'\\label\{[^}]+\}','',source);source=re.sub(r'\\(?:begin|end)\{equation\*?\}','',source)
   source=source.replace('{align*}','{aligned}').replace('{align}','{aligned}')
   # KaTeX accepts the mathematical array but not TeX-only intercolumn glue.
   source=source.replace(r'@{\qquad}', '')
   i=len(maths);maths.append({'source':source,'display':display,'keys':keys})
   return {'t':'RawInline','c':['html',f'PRINCESSMATHPLACEHOLDER{i}END']}
  if 'c' in node:node['c']=walk(c)
  return node
 ast['blocks']=walk(ast['blocks']);astpath=TMP/f'{name}-web-ast.json';mathpath=TMP/f'{name}-web-math.json';renderpath=TMP/f'{name}-web-rendered.json'
 astpath.write_text(json.dumps(ast));mathpath.write_text(json.dumps(maths))
 script=TMP/'render-paper-math.cjs';script.write_text(r'''
const fs=require('fs');const{createRequire}=require('module');const requireSite=createRequire(process.argv[2]+'/package.json');const katex=requireSite('katex');const rows=JSON.parse(fs.readFileSync(process.argv[3],'utf8'));const out=rows.map((r,i)=>{try{return katex.renderToString(r.source,{displayMode:r.display,throwOnError:true,strict:'error'});}catch(e){throw new Error('Formula '+i+': '+r.source+'\n'+e.message);}});fs.writeFileSync(process.argv[4],JSON.stringify(out));
''')
 subprocess.run(['node',str(script),str(SITE),str(mathpath),str(renderpath)],check=True)
 rendered=json.loads(renderpath.read_text());body=subprocess.run([PANDOC,str(astpath),'--from=json','--to=html5','--wrap=none'],check=True,capture_output=True,text=True).stdout
 for i,(record,markup) in enumerate(zip(maths,rendered)):
  anchors=''.join(f'<span id="{html.escape(k)}"></span>' for k in record['keys']);nums=[labels[name][k] for k in record['keys'] if k in labels[name]]
  tag=('<span class="note">('+', '.join(nums)+')</span>') if nums else ''
  body=body.replace(f'PRINCESSMATHPLACEHOLDER{i}END',anchors+markup+tag)
 body=re.sub(r'(<table(?:\s[^>]*)?>)',r'<div class="tablewrap">\1',body).replace('</table>','</table></div>').replace('<img ','<img loading="lazy" ')
 nav='<nav aria-label="Proof contents"><p><strong>Contents</strong></p><ol>'+''.join(f'<li><a href="#{html.escape(k)}">{html.escape(title)}</a></li>' for k,title in toc)+'</ol></nav>'
 allids[name]=Ids(body).ids
 print(f'{name}: {len(maths)} strict formulas; {len(toc)} sections')
 return nav+'\n'+body
bodies={n:build(n,d) for n,d in DOCS.items()}
# Historical incoming anchors remain useful after moving theorem text.
old=ROOT/'archive/2026-09-13-combined/proofs.html';legacy=[];migration={}
if old.exists():
 for key in sorted(Ids(old.read_text()).ids-allids['main']):
  target=DOCS['extensions']['route']+'#'+key if key in allids['extensions'] else '/princess/archive/2026-09-13-combined/proofs.html#'+key
  migration[key]=target;legacy.append(f'<p id="{html.escape(key)}"><a href="{html.escape(target)}">Moved reference: {html.escape(key)}</a></p>')
if legacy:bodies['main']+='\n<details><summary>References from the historical combined manuscript</summary>'+''.join(legacy)+'</details>'
(ROOT/'publication/proof-anchor-migration.json').write_text(json.dumps(migration,indent=2)+'\n')
for name,doc in DOCS.items():
 dest=SITE/'src/content/generated'/doc['output'];dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text('\n'.join(x.rstrip() for x in bodies[name].splitlines())+'\n')
 if name=='main':
  page=SITE/'src/pages/princess/proofs.astro';relative='../..';intro='The active manuscript concerns two-dimensional rectangles, constant daily budgets, and full initial uncertainty. Exact evaluators are distinguished from the intended explicit value-and-strategy endpoint. The complete classification remains open.'
 else:
  page=SITE/'src/pages/princess/extensions/proofs.astro';relative='../../..';intro='This companion preserves independent extensions and their existing proofs. It is parked: these open directions are not requirements for completing the rectangle project. Relevant fixed-deadline rectangle consequences remain with the main manuscript.'
 page.parent.mkdir(parents=True,exist_ok=True)
 page.write_text(f'''---
import Post from "{relative}/layouts/Post.astro";
import proofHtml from "{relative}/content/generated/{doc['output']}?raw";
---
<Post title="{doc['title']}" description="{intro}" updated="2026-09-13">
  <p>{intro}</p>
  <p><a href="/princess/">Rectangle overview</a> · <a href="/princess/reconciliation/">Progress reconciliation</a> · <a href="/princess/coverage/">Coverage and remaining gaps</a> · <a href="/princess/extensions/">Parked companion</a> · <a href="{doc['pdf']}">PDF from the same source</a></p>
  <Fragment set:html={{proofHtml}} />
</Post>
''')

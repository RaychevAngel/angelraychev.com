"""Literal support and sequence audit; proof is upper-whole-front-overlap.md."""
import hashlib,itertools,json,random,time
from pathlib import Path
rng=random.Random(20261024)
checks=0
for b in range(1,5):
 W=2*b+1
 for steps in itertools.product((-1,0,1),repeat=W-1):
  z=[0]
  for s in steps:z.append(z[-1]+s)
  for shift in range(-max(z)-1,-min(z)+2):
   zz=[x+shift for x in z];P=sum(max(x,0)for x in zz);N=sum(max(-x,0)for x in zz)
   assert min(P,N)<=b*(b+1)//2,(b,zz,P,N)
   checks+=1
literal=0
for b in range(2,8):
 W=2*b+1;n=4*W+4
 vertices={(x,y)for x in range(W)for y in range(n)}
 nei={v:{(v[0]+dx,v[1]+dy)for dx,dy in((1,0),(-1,0),(0,1),(0,-1))}&vertices for v in vertices}
 def support(h):return {(x,y)for x,hi in enumerate(h)for y in range(hi%2,hi+1,2)if y>=0}
 for _ in range(100):
  ages=[rng.randrange(2*b+1),rng.randrange(2*b+1)];fronts=[];kept=[]
  for age in ages:
   h=[2*W+(age%2)]
   for x in range(1,W):h.append(h[-1]+rng.choice((-1,1)))
   F=support(h);K=support([z-age for z in h]);E=F
   color=next(iter(E));parity=sum(color)%2
   for j in range(age):
    parity=1-parity;E={v for v in vertices if sum(v)%2==parity and nei[v]<=E}
   assert K<=E,(b,age)
   assert len(K)>=len(F)-W*((age+1)//2)
   fronts.append(F);kept.append(K)
  bound=min(len(fronts[i])-W*((ages[i]+1)//2)for i in range(2))-b*(b+1)//2
  assert len(kept[0]&kept[1])>=bound,(b,ages,bound,len(kept[0]&kept[1]))
  literal+=1
p=Path(__file__);r=dict(status='PASS independent literal checks, supporting the analytic proof',integer_lipschitz_sequences=checks,actual_front_pairs=literal,source_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),proof_sha256=hashlib.sha256(p.with_name('upper-whole-front-overlap.md').read_bytes()).hexdigest())
p.with_suffix('.json').write_text(json.dumps(r,indent=2)+'\n');print(r)

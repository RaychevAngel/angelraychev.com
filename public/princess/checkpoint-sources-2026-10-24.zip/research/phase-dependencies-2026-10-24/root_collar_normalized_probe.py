"""Exact real-arithmetic challenge of a conditional asymptotic collar model.
No finite-b capture theorem: endpoint corrections and physical hypotheses omitted.
"""
from pathlib import Path
import json,time,sys
import z3 as z
r1,r2,a1,a2,e1,e2,g=z.Reals('r1 r2 a1 a2 e1 e2 g')
s=z.SolverFor('QF_NRA');s.set(timeout=20000)
s.add(g>=0,g<=z.RealVal('1/4'),e1>=0,e2>=0,e1+e2<=g)
for r,a,e in [(r1,a1,e1),(r2,a2,e2)]:
 s.add(r>=0,r<=1,a>=0,a<=2*(1-r+e),a<=z.RealVal('3/2')*r-2*g+2*e)
 s.add(r*r+a*(z.RealVal('5/4')-r)>=1)
bound=sys.argv[1] if len(sys.argv)>1 else '9/8'
s.add(r1+r2-(a1+a2)/2<z.RealVal(bound))
t=time.process_time();result=s.check()
out={'claim':'conditional normalized half-radius sum at least '+bound,'status':str(result),'cpu_seconds':time.process_time()-t,'scope':'Conditional asymptotic algebra model only; no finite-b physical theorem.'}
if result==z.sat:out['counterexample']={str(v):str(s.model().eval(v)) for v in [r1,r2,a1,a2,e1,e2,g]}
if result==z.unknown:out['reason']=s.reason_unknown()
Path(__file__).with_name('root-collar-normalized-'+bound.replace('/','-')+'.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out))

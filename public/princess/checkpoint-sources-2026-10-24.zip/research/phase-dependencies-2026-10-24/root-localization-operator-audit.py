"""Independent finite audit of the threshold relaxation, not physical proof.

Enumerates every target size and survivor size admitted by the underlying
static capacity, applying the localized-shape horizon guards literally.
The proposed threshold operator may be larger, but must never be smaller.
"""
import json, random, time, hashlib
from pathlib import Path
import comparison_localization_flags as op

def forced(b,q,T,i,u,j,v):
    r=T-q
    if i==0 and j==1 and 2<=r<=b and (r-1)*(r-2)<q<=r*(r-1):
        return 'forbidden' if v!=0 else 'P'
    if i==1 and j==0 and v==1 and 2<=r<=b:
        if ((r-1)**2<q<=r*r) if r<b else (r*(r-1)<q<=r*r):
            return 'S' if r<b else 'C'
    return None

def literal_caps(w,n,B,flags):
    out={};b=w//2
    for j,v in op.F:
        for i in range(v+1):
            for u in range(j+1):
                best=0
                for T in range(1,B[j,v]+1):
                    high=op.m.band.survivor(w,n,T,i,u,j,v)
                    for q in range(max(0,high),best,-1):
                        label=forced(b,q,T,i,u,j,v)
                        if label=='forbidden' or (label and T>flags[label]):
                            continue
                        best=q;break
                out[i,u,j,v]=best
    return out

def main():
    rng=random.Random(241026);start=time.process_time();count=0;checks=0
    for w,n in ((9,10),(11,12),(17,18)):
        h=w*n//2
        for _ in range(12):
            k=rng.randrange(w//2+1,2*w)
            B={f:rng.randrange(h-4+sum(f)+1) for f in op.F}
            flags={'P':rng.randrange(B[1,0]+1),
                   'S':rng.randrange(B[0,1]+1),
                   'C':rng.randrange(B[0,1]+1)}
            ordinary,aux=op.step(w,n,k,B,flags)
            cap=literal_caps(w,n,B,flags)
            def direct(f,pred=lambda j,v:True):
                return min(h-4+sum(f),k+max([0]+[
                    cap[i,u,j,v] for i,u,j,v,cost in op.er.OPTIONS[f]
                    if cost<=k and pred(j,v)]))
            expected={f:direct(f) for f in op.F}
            ea={'P':direct((1,0),lambda j,v:j==0 and v<=1),
                'S':direct((0,1),lambda j,v:j<=1 and v==0),
                'C':direct((0,1),lambda j,v:v==0)}
            for f in op.F:
                assert ordinary[f]>=expected[f],(w,n,k,B,flags,f,ordinary,expected)
                checks+=1
            for f in ea:
                assert aux[f]>=ea[f],(w,n,k,B,flags,f,aux,ea)
                checks+=1
            count+=1
    source=Path(op.__file__)
    out={'status':'PASS finite implementation audit; physical localization and merger proofs separate',
         'cases':count,'scalar_checks':checks,'widths':[9,11,17],
         'method':'literal target and survivor enumeration; direct surplus recovery rather than inverse-root trigger',
         'operator_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
         'CPU_seconds':time.process_time()-start}
    Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))

if __name__=='__main__':main()

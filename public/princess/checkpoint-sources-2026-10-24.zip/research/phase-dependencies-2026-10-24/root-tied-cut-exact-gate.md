# An exact gate clock from one tied intermediate time

24 October 2026. Proposed ordinary theorem for independent review. It uses
the accepted capped early and signed late necessities, including their
independently replayed finite arithmetic bases. No new Lean claim.

Let w=2b+1, n>=w be even, h=wn/2, k=b+d, and

    b>=max(32,4d+8), d>=1.

Put U=h-b(b+1), A=U-d, Z=h-b^2. Let C_t be the genuine capped forward
pair from zero in `lower-capped-critical-continuation.md`, extended to this
range by `lower-capped-critical-finite-base.md`:

    C_0=(0,0),
    C_(t+1)=(max(C_t[1]+k-rho(C_t[1]+k),C_t[1]+d),
               max(C_t[0]+k-R(C_t[0]+k),C_t[0]+d-1)).

Suppose at some time t_* it has a TIED pair

    C_(t_*)=(q,q),             b^2<q<A.                (1)

For a terminal quota 0<=c<=k, define the genuine physical backward prefix
pair X^c from (c,c), with all outputs capped at h:

    X'0=min(h,k+X1-min(rho(X1),R(h-X1),b)),
    X'1=min(h,k+X0-min(R(X0),1+rho(h-X0),b+1)).

Use the absorbing value h once a coordinate reaches h. Let

    P(c)=min{r:max X^c_r=h}.

Then the minimum number of unsuccessful updates from full uncertainty to
signed gate c is EXACTLY P(c). A canonical physical prefix construction
attains it. In particular, for d=1 such a tied time always exists, so this
conclusion holds for EVERY b>=32 and every even n>=2b+1 at minimum budget.

## 1. The two physical comparisons used at the cut

The accepted safe early clipping gives, for every actual full-origin history,

    min(Q_t,A)<=min(max C_t,A),

where Q_t is the total actual hole count. At the time in(1), therefore
Q_(t_*)<=q and its signed mass m=h-Q satisfies m>=h-q.
No actual history has been replaced by a prefix in this necessary statement.

Let F_t denote the genuine physical forward prefix hole pair. The finite
board's far-boundary cost can only improve on the two capped quadrant/width
maps, so F_(t_*) dominates (q,q). Equivalently, one may use exact equality
up to this cut: all relevant target counts are below U and its co-small
boundary is inactive. The accepted exact prefix adjunction says

    P(c)<=t+r iff max_p(F_t[p xor 1]+X^c_r[p])>=h.     (2)

This is an adjunction for the same physical prefix dynamics; it is not an
assumption that prefixes are optimal among arbitrary inspection strategies.
It also shows that whenever q+max X^c_r>=h at a tied lower head (1), a real
prefix word of length t_*+r reaches the gate.

The capped signed late theorem, with its separately reviewed seeded finite
base, gives for a normalized actual suffix of r updates ending at gate c

    min(max(m,0),Z)<=max V^c_r,                       (3)

where V^c is its capped backward pair. Until a physical X^c coordinate
reaches Z, X^c and V^c are IDENTICAL. For an input x<Z we have h-x>b^2;
therefore R(h-x)>=b+1 and 1+rho(h-x)>=b+1. Neither far-boundary term can
improve on the width caps b and b+1. This verifies the identical updates
directly, without using prefix optimality.

## 2. Any shorter arbitrary strategy contradicts the same-time bounds

Suppose a full-origin strategy reaches gate c in T<P(c) updates. Apply the
accepted gate-preserving finite-prefix normalization first; all early and
late comparisons below refer to THIS SINGLE normalized physical history.

If T<t_*, monotonicity of C gives max C_T<=q<A. Early clipping then gives
Q_T<=q. But the terminal gate requires Q_T>=h-c>A, a contradiction.
Here h-c-A=b(b+1)+d-c>=b^2>0.

Thus r=T-t_*>=0. Equation(2) and F_(t_*)>=(q,q) imply

    max X^c_r<h-q<Z,                                (4)

where the second strict inequality uses q>b^2. Physical monotonicity puts
all earlier X^c states below Z too, so X^c_r=V^c_r. At the very same actual
time t_*, early necessity gives m>=h-q. Hence

    min(max(m,0),Z)>=h-q>max V^c_r,

contradicting(3). Therefore no arbitrary gate history is shorter than P(c).
The defining physical prefix construction supplies the reverse inequality.

## 3. Minimum budget supplies a tied time uniformly

Set d=1. The capped pair is nondecreasing and globally interlaced. Once
both coordinates are at least b^2, its update is exactly

    (x,y) -> (y+1,x).                                (5)

The pair eventually passes b^2 because every two applications of the
capped maps increase both coordinates by at least one. At the first time
its maximum is b^2+1, its minimum is at least b^2: the preceding maximum
is b^2 by the exact one-room progress at this threshold, and interlacing
applies. The first pair is thus (b^2+1,b^2), or already tied at b^2+1.
The opposite-leading possibility is excluded by interlacing of its next
iterate under(5). One further update in the first case gives the tie

    q=b^2+1.

On the shortest admissible board h=2b^2+3b+1, so
A=U-1=b^2+2b. Thus b^2<q<A for every b>=32, and the interval only grows
with n. The theorem applies simultaneously to every terminal c<=k.

## 4. Exact full-board capture time

The physical gate recurrence has P(0)=P(k)+1 and
P(k)<=P(floor(k/2))<=P(k)+1. The accepted final shared-quota lower bound
and the physical concatenation/palindrome constructions give respectively

    T>=max(2P(k)+1,2P(floor(k/2))),
    T<=min(2P(k)+2,2P(floor(k/2))+1).

They coincide, yielding

    T_k(2b+1,n)=P(k)+P(floor(k/2))+1.                 (6)

The corresponding construction is selected by whether the two gate clocks
are equal. This is an exact computable value with an attaining inspection
rule. It is not an O(1)-operation numerical expression.

## Boundary of the conclusion

For d>1, condition(1) is a genuine additional hypothesis, checked on the
genuine capped orbit. The central update sends the signed phase difference
delta to 1-delta; it does not force a tie from arbitrary entry data. This
note does not claim all budgets are resolved or improve the global four-day
ceiling by itself. The uniform d=1 consequence is a whole unbounded-width,
unbounded-length family, not a finite collection of board checks.

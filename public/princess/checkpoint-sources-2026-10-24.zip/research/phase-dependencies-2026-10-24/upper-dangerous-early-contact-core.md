# An actual early core whenever the boundary phase matters

24 October2026. Stronger-scope companion to the accepted exact-contact theorem.
Proposed for independent review. The core bound is one or two moves weaker,
but equality with the larger ordinary capacity is no longer required.

Use b,d,k,L=(b-1)²,H=b(b-1) and Rstar from
`upper-early-last-root-core.md`, with

    k>=100,   k>d²+4d+3.

Suppose the actual total hole history stays at most H through time t and

    H-d+1<=Q_t<=H,       Q_t>min P_t.                    (1)

Then actual holes in one cohort contain a corner core of radius at least

    Rstar(b-1)-(2d+2)-floor((Q_t-L+d-1)/d).              (2)

Round down to the current relative corner parity when using a prescribed
radius. This applies precisely to endpoints for which only one ordinary
phase has enough numerical capacity, including endpoints with slack below
the larger capacity.

## Proof

Let j be the first actual critical target Q_j>L. The accepted ordinary
head theorem controls Q_s<=max P_s through time t. As in the exact-contact
proof, any later subcritical retreat is below both phases forever, so it
cannot precede the dangerous final state(1). Thus all j,...,t targets are
critical, and Q_(j-1)>=L-d+1 is itself dangerous.

The last-good ancestral argument is unchanged. Every intervening step
before j is B-bad, the predecessor endpoint is at least L-d+1, and the
same strict polynomial exclusion forces its last good root to be b-1.
Its core reaches the first critical target after at most2d+2 moves.

It remains to bound the time spent in the neutral critical lower half-bin.
Put M_s=max P_s. Global interlacing gives

    M_(t-1)<=min P_t<Q_t<=H.

Thus M_s<H for every s<t. Since M_j>=Q_j>L, each update from j through
t-1 increases the maximum by exactly d, except that the final update
may lose one room at the upper inverse-rounding endpoint. Precisely,

    M_t >= M_j+(t-j)d-1 >= L+(t-j)d.                  (3)

No assertion of monotonic actual progress is used here.

A second interlacing inequality is M_t<=G(min P_t). Exact inversion of G
therefore gives

    min P_t+k >= M_t+ceil(sqrt(M_t)).

Since M_t>=Q_t>L, its square root is at least b. Consequently

    M_t-min P_t<=d,     M_t<=Q_t+d-1.                  (4)

Combining(3)--(4) yields

    t-j<=floor((Q_t-L+d-1)/d).

Erosion of the old actual core now proves(2).

The assumption Q_t>min P_t automatically makes the ordinary pair unequal.
It does not force Q_t=max P_t, and the proof never makes that replacement.
A state below both phases needs no such phase-restriction lemma.

## Intended interface

Combine this actual early core with an actual late core or a reverse allowed
late core carrying a quantified size defect. The existing adjacent-corner
intersection formula then tests the compatibility of the two phase choices
for arbitrary middle histories. The present note alone does not establish
that every optimum has a dangerous endpoint or that a particular lower-clock
minimizer is physically realizable.

# Exact early contact retains a large core through the critical lower half-bin

24 October 2026. Physical refinement proposed for independent review.
It retains an actual corner/cohort label at a unique ordinary-capacity contact;
it does not assert that every early endpoint is an exact contact.

Let w<=n have even area, b=floor(w/2), k=b+d, and assume

    k>=100,   k>d²+4d+3,   d>=1.

Set L=(b-1)², H=b(b-1). Let the actual total hole history from full
uncertainty stay at most H through time t. Let P be the genuine ordinary
early pair from zero. Suppose

    H-d+1<=Q_t=max P_t<=H,
    P_t has a unique larger coordinate.                       (1)

Define

    Rstar(r)=min(2r-2-2m(2r-2),
                 2r-3-2m(r-2), 2r-4),
    m(z)=max{j>=0:j(j+1)/2<=z}.

Then some ACTUAL cohort's holes at time t contain an actual corner core
of radius at least

    Rstar(b-1) -(2d+2) - floor((Q_t-L-1+1_{Q_t=H})/d).                 (2)

A prescribed lower-bound radius must be rounded down to the corner's current
checkerboard parity; a negative radius asserts no nonempty core.

## 1. An exact dangerous contact cannot hide a retreat

Use the accepted ordinary early theorem and its terminology. A state is
both-phase controlled when Q_s<=min P_s. A later subcritical target after
any critical target Q_j>L is automatically both-phase controlled, because
min P_(j+1)>=max P_j>=Q_j>L and the ordinary pair is nondecreasing.
A critical target <=H obeys the smaller map F. Consequently once both-phase
control occurs after the first critical target, it persists to time t.
That is incompatible with(1).

Let j be the first actual time Q_j>L. Such j exists by(1), because the
parameter guard implies d<b-1. Every actual target j,...,t is critical,
with Q_s>L. Every critical step satisfies

    Q_s<=Q_(s-1)+d,                                    (3)

because its original surplus is at least b.

All ordinary maxima up to t are at most H. For x>L, both root maps give
x+d whenever their output is below H. At the upper endpoint there is one
inverse-rounding exception: if x+d=H+1, then F(x)=H while G(x)=H+1.
There is no other exception with output at most H.

Let M_s=max P_s. A unique larger coordinate at time t rules out M_s=H
at any earlier s<t: interlacing would give min P_(s+1)>=H, and monotonicity
would make both final coordinates at least H. Hence

    M_(s+1)=M_s+d                  for j<=s<t-1,
    M_t>=M_(t-1)+d-1_{Q_t=H}       if j<t.

The larger input yields the stated output; monotonicity controls the other
coordinate. Since M_j>=Q_j>=L+1, this proves

    t-j <= floor((Q_t-L-1+1_{Q_t=H})/d).                 (5)

The possible final one-room rounding loss is retained explicitly; exact
contact does not justify asserting full progress at every critical step.

Also Q_(j-1)>=Q_j-d>=L-d+1. It must exceed min P_(j-1), since an F move
from both-phase control remains below BOTH ordinary output coordinates.

## 2. The last subcritical good ancestor has root b-1

Let u<=j-1 be the last actual zero-good event. It exists: without one,
B steps and tiny resets from zero stay below both ordinary phases. No
critical event precedes j. A tiny or both-phase reset after u would also
contradict the danger at j-1. Hence all j-1-u intermediate steps obey B.

Write r for the root of Q_u, e=Q_u-min P_u>0 and delta=j-1-u. The accepted
mixing and genuine-origin estimates give

    delta<=2e-1,   e<=k-r,
    e<=3r/4+1 for r>=20,
    delta<=2r-4 for r<20.

The identical ancestral-growth argument of
`lower-late-last-root-core.md`, Sections1--3, applies to the endpoint
q=Q_(j-1)>=L-d+1. It requires only a genuine ordinary (or seeded ordinary)
orbit and a final dangerous B suffix, not a late physical interpretation.
For clarity its decisive inequalities are

    q<=r²+delta(k-r-1),
    q>4k²/5,
    r>2k/3,
    q<=f(k-r),  f(a)=k²-2ka+3a²-3a+1.

If r<=b-2, then a>=d+2 and

    f(d+2)-(L-d)=-2k+2d²+8d+6<0,

contradicting q>=L-d+1. Therefore r=b-1 and delta<=2d+1.
The good event u contains a raw core of radius at least Rstar(b-1).
There are delta+1<=2d+2 moves from u to the first critical target j,
followed by at most(5) more. Hole erosion retains the core with one radius
lost per move, proving(2). No new corner is chosen in this argument.

## Use and limitations

This is an early counterpart of the accepted exact late last-root theorem.
For moderate d its actual core has radius 2b-O(sqrt(b)+d+b/d).
It can be combined with an actual late core by the two-core overlap lemma;
no prefix-shape assumption or allowed-set equality is needed for that use.

The hypotheses include exact contact with the UNIQUE larger ordinary
coordinate. An endpoint below capacity, a tied ordinary pair, or a history
that previously exceeded H is not covered. Those cases require retaining
capacity slack or another argument; this theorem does not remove them.

# A coupled two-ancestor inequality with a positive overlap margin

24 October 2026. Ordinary algebraic lemma submitted for review. This is a
CONDITIONAL normalized model, not yet a finite-board capture theorem.
The finite-b endpoint corrections and physical ancestor hypotheses still
have to be supplied. A stronger proposed 9/8 bound was falsified; the
following 17/16 bound has an elementary proof.

Let 0<=g<=1/4, e1,e2>=0, e1+e2<=g. For i=1,2 suppose

    0<=r_i<=1, a_i>=0,
    a_i<=2(1-r_i+e_i),
    a_i<=3r_i/2-2g+2e_i,
    r_i^2+a_i(5/4-r_i)>=1.                         (1)

Then

    (r1-a1/2)+(r2-a2/2) > 17/16.                   (2)

The variables model root/b, age/b, and the two deficits/b, with shared
phase gap g. In the intended application the last inequality relaxes
growth using d/b<=1/4. It is important that the negative -2g term in each
age bound is retained.

## Reduce to two scalar half-radii

Put t_i=r_i-a_i/2. Since e_i<=g, the second age bound gives
0<=r_i/4<=t_i<=r_i<=1. Substituting a_i=2(r_i-t_i) into the growth
inequality gives

    r_i >= 5/4+t_i-sqrt(t_i^2+9/16).

Both age bounds now imply

    e_i>=f(t_i),        e_i>=g+j(t_i),

where

    f(t)=3/2+t-2sqrt(t^2+9/16),
    j(t)=5/16-3t/4-sqrt(t^2+9/16)/4.

On [0,1], f is nonnegative and strictly concave, while j is strictly
decreasing. The shared slack therefore implies

    f(t1)+f(t2)<=1/4,
    j(t1)+f(t2)<=0,       j(t2)+f(t1)<=0.            (3)

Order x=min(t1,t2), y=max(t1,t2), and suppose x+y<=17/16.

## Three elementary cases contradict (3)

First x>1/8, because j(1/8)=(7-sqrt(37))/32>0 and f(y)>=0.

If x<=1/5 and y<=15/16, concavity gives
f(y)>=min(f(x),f(15/16))=f(15/16), since x lies in[1/8,1/5].
Monotonicity of j then gives

    j(x)+f(y)>=j(1/5)+f(15/16)>0,

contradicting (3). Thus y>15/16, and x>1/8 gives x+y>17/16.

If 1/5<=x<=1/4 and y<=13/15, the same concavity argument gives
f(y)>=f(13/15). Hence

    j(x)+f(y)>=j(1/4)+f(13/15)>0.

So y>13/15, giving x+y>1/5+13/15=16/15>17/16.

Finally, if x>=1/4, the constraints x<=y and x+y<=17/16 form a triangle
with vertices

    (1/4,1/4), (1/4,13/16), (17/32,17/32).

The concave function f(x)+f(y) is greater than1/4 at all three vertices,
hence throughout the triangle. This contradicts (3) and proves (2).

## Exact checks used above

The scalar comparisons involve positive square roots and can be checked
by squaring rational bounds. For explicit reproducibility, the two sums
in the first cases are

    j(1/5)+f(15/16)=(208-sqrt(241)-10sqrt(369))/80>0,
    j(1/4)+f(13/15)=(598-8sqrt(4729)-15sqrt(10))/240>0.

For the first, use sqrt(241)<1553/100 and sqrt(369)<1921/100.
For the second, use sqrt(4729)<6877/100 and sqrt(10)<3163/1000.
Each upper bound has square strictly exceeding its radicand and makes
the displayed numerator positive.

The nontrivial vertex comparison is

    f(1/4)+f(13/16)-1/4=(61-8sqrt(10)-2sqrt(313))/16>0,

using sqrt(10)<3163/1000 and sqrt(313)<4423/250.
The equal-coordinate vertex comparisons follow directly by squaring.
The concavity endpoint minima f(x)>=f(15/16) on[1/8,1/5] and
f(x)>=f(13/15) on[1/5,1/4] follow by the same endpoint checks.

## Failed stronger claim and scope

The 9/8 replacement fails at the exact rational tuple

    r1=91/128, r2=249/256, a1=59/64, a2=101/512,
    e1=713/4096, e2=147/2048, g=63/256.

The accompanying exact-real solver challenge is
`root_collar_normalized_probe.py`; its result is supplementary to this
ordinary proof. This tuple is a counterexample to the relaxed algebraic
claim, not a physically realizable princess strategy. Inequality (2)
leaves a positive quadratic triangle-lens margin in the normalized model.
Converting it into a uniform physical overlap theorem, including integer
endpoint errors and the mixed localized/full-front case, remains open.

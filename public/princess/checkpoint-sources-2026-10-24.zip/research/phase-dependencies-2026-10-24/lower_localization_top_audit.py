"""Independent audit of the maximal-survivor repair's target minimality."""
from pathlib import Path
import sys,hashlib,json,time
sys.path.insert(0,str(Path(__file__).resolve().parent))
import comparison_localization_flags as a
m=a.m
count=0;per={};start=time.process_time()
for b in range(2,11):
 for n in (2*b+2,2*b+4):
  w=2*b+1;h=w*n//2;events=0
  for j,v in a.F:
   for i in range(v+1):
    for u in range(j+1):
     last=-1
     for T in range(1,h+1):
      q=m.band.survivor(w,n,T,i,u,j,v)
      typ=None;r=m.R(T)
      if i==0 and j==1 and 2<=r<=b and (r-1)*(r-2)<q<=r*(r-1) and T-q==r:typ='P'
      r=m.rho(T)
      if i==1 and j==0 and v==1 and 2<=r<=b and T-q==r and (((r-1)**2<q<=r*r)if r<b else(r*(r-1)<q<=r*r)):typ='S'if r<b else'C'
      if typ:
       # All smaller target capacities are bounded by the previous maximum;
       # this uses an independent accumulated maximum, not an interval claim.
       assert q>last,(w,n,T,i,u,j,v,typ,q,last)
       events+=1;count+=1
      last=max(last,q)
  per[f'{w}x{n}']=events
p=Path(__file__).resolve();d=p.parent
out={'status':'all maximal reset candidates have no smaller admitted target; exhaustive feature audit','cases':per,'events':count,'CPU_seconds':time.process_time()-start,'sources':{str(x.name):hashlib.sha256(x.read_bytes()).hexdigest()for x in[p,d/'comparison_localization_flags.py',d/'comparison-localization-flags.md']}}
p.with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))

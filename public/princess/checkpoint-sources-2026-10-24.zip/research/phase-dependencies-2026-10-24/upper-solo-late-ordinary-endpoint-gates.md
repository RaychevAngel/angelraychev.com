# Exact ordinary solo late capacity at the two endpoint gates

24 October 2026. Proposed physical corollary for independent review of the
accepted `lower-ordinary-early-boundary-theorem.md`. This is an arbitrary-
shape solo statement; it does not assume a fixed corner is optimal for a
whole full-origin game or replace a signed two-cohort terminal gate by a solo
terminal set.

Let w<=n be even-area, b=floor(w/2), k>=max(13,b+1), and assume

    A=b^2-k+1>=1.

Let S be ANY set in one checkerboard color, with

    |S|<=b^2+1=k+A.

Suppose a legal budget-k solo inspection word brings S, after s unsuccessful
inspection-and-movement updates, into a set of at most c rooms, where

    c=0 or c=k.

Let V^c be the genuine ordinary quadrant backward pair, initialized at(c,c):

    V_(j+1)^c=(k+V_j^c[1]-rho(V_j^c[1]),
               k+V_j^c[0]-ceil(sqrt(V_j^c[0]))).

Then

    |S|<=max V_s^c.                                  (1)

Thus the ordinary MAX gate clock is a necessary solo late clock throughout
this range, even for arbitrary initial shapes and arbitrary intermediate
excursions. It is attained by the corresponding corner prefix whenever that
prefix and its relevant neighborhoods fit the finite board; the necessity
statement itself does not require selecting such a shape for S.

## Proof by exact reversal and all-time clipping

The case s=0 is immediate. For s>=1 let D be the actual terminal set, enlarged
if convenient without exceeding c. Reverse the inspection word and put

    C_0=D, C_(j+1)=I_(s-1-j) union E(C_j), H_j=E(C_j).

The exact predecessor recursion gives S subset C_s and

    |S|<=k+|H_(s-1)|.                                (2)

The H recursion is H_(j+1)=E(H_j union I_(s-1-j)). If c=k, H_0=E(D)
is obtained from full uncertainty by a first inspection D of at most k
rooms. Hence H_(s-1) is the hole set in one actual cohort after s ordinary
budget-k moves; the other cohort is left uninspected. If c=0, H_0 is empty,
so H_(s-1) is obtained after s-1 such moves.

Let P be the ordinary zero-origin forward pair and set t=s for c=k,
t=s-1 for c=0. The accepted all-time clipped early theorem gives

    min(|H_(s-1)|,A)<=min(max P_t,A).                  (3)

This explicitly handles reversed histories which leave the pronic region
and later return; no stay-below assumption on the reversed word is needed.
Combining the initial-size hypothesis with(2),(3),

    |S|<=min(k+|H_(s-1)|,k+A)
         <=k+min(max P_t,A)<=k+max P_t.               (4)

The exact ordinary recurrences give, for s>=1,

    V_s^k=(k,k)+P_s,
    V_s^0=(k,k)+P_(s-1).

Substitution into(4) proves(1). The two coordinates refer to the appropriate
source phases; taking MAX makes no artificial phase choice or claim that
both phases capture S.

## Precise remaining seed and signed-mass issues

For 0<c<k the same reversal begins with one initial quota c followed by
constant quota k. Its genuine forward seed is

    (c-rho(c),c-ceil(sqrt(c))),

rather than a zero-origin k word. A version of the early physical theorem
for this one unequal initial quota would give the analogous solo conclusion
immediately. It has NOT been silently assumed here; in particular small
initial roots need their own phase initialization argument.

A two-cohort terminal condition |B0|+|B1|-h<=c likewise does not supply a
solo terminal set of size c. The partner can have holes, so the distinguished
cohort can retain c plus that deficit. The signed two-cohort late theorem
still requires its own activation/cancellation interface, as explained in
`upper-late-reversal-seed-interface.md`.

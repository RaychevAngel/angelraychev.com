# A cost-free central corner swap is impossible on short higher-budget squares

24 October 2026. Proposed uniform physical obstruction for independent review.
This concerns a specified source/target strategy family, not arbitrary optimal
histories. It does not prove a stronger capture-time lower bound.

Let w=n=2b with b>=27, k=b+d and8<=d<=b-1. Put h=2b² and H=b(b-1).
Choose any of the usual integer pronic-cut endpoints

    H-d+1<=Q<=H,     H+1<=Y<=H+d+1,
    M=h-Q,          tau=ceil((M-Y)/d).                    (1)

Let a left prefix mean the first M vertices of one checkerboard color in
increasing x+y order from the corner(0,0); the order within a diagonal is
irrelevant to this result. Let a right prefix be the analogous prefix of
size Y based at the corner(2b-1,0), in the appropriate final color.

**Theorem.** No solo inspection strategy with daily budget k can take that
left prefix to a subset of the right prefix in tau inspection-and-movement
updates. In particular, replacing the actual middle by an arbitrary free
choice of these opposite-corner phases is not a valid construction at the
standard drift-d time in this uniform family.

## 1. A physical matching bound on every strategy

Fix the horizontal perfect matching f of the square. If S_j is the actual
solo possible set, then

    S_(j+1)=N(S_j minus I_j) contains f(S_j minus I_j).

Iterating this inclusion gives

    |S_0 minus f^tau(S_tau)| <= sum_j |I_j| <= tau*k.     (2)

Equivalently, each initial position outside the matched image of the final
set requires an inspection on its fixed matching trajectory. Because f is
an involution, f^tau is either the identity or ONE application of f, not
a displacement growing with tau. Equation(2) is valid for every possible
inspection word, not only descending height-walk words.

## 2. A triangle that must be inspected

The source size satisfies M>=b²+b. It therefore contains every vertex of
its color in

    x+y<=2b-1.                                          (3)

Indeed the two color counts in this triangle are b² and b(b+1).
The target has size Y<=b². A right prefix of either color with at most b²
vertices lies inside the right-corner ball of radius2b-1. Applying f at
most once expands that containing ball to radius2b. Hence every vertex
of S_0 satisfying

    x+y<=2b-1,       y>=x+2                              (4)

lies OUTSIDE f^tau(S_tau): its distance from the right corner is
2b-1-x+y>=2b+1. For either source color, region(4) has exactly

    b(b-1)/2                                           (5)

vertices. For the even color this is half of the b² triangle after removing
its b diagonal vertices. For the odd color it is half of the b(b+1)
triangle after additionally removing the b vertices on y=x+1.
Thus(2) forces

    tau*k >= b(b-1)/2.                                 (6)

## 3. The benchmark middle has too few inspections

From the endpoint ranges,

    M-Y<=2b+d-2,
    tau<=2b/d+2.

Consequently, using d>=8 and d<=b-1<b,

    tau*k <=(2b/d+2)(b+d)
           =2b²/d+4b+2d
           <=b²/4+6b
           < b(b-1)/2,                                (7)

where the last strict inequality is equivalent to b>26. This contradicts(6)
and proves the theorem.

The lower matching count itself is stronger than the simple sufficient
parameter range above: whenever the exact tau from(1) satisfies
k*tau<b(b-1)/2, the same obstruction applies, without requiring d>=8.
For a rectangle2b by n>=2b, the same proof of(6) holds with h=bn and the
same endpoint ranges; the inequality test then depends explicitly on n.

## Consequence and boundary

This closes the proposed shortcut of making the accepted long-board central
phase bridge free on all short higher-budget squares. The obstruction is
not peculiar to one flip order or one finite example.

It does NOT prove that a globally optimal strategy must remain at one corner,
that all head/tail phase choices are impossible, or that tau itself is the
true minimum for an arbitrary middle history. In particular it cannot yet
be turned into a stronger lower bound by minimizing only over compatible
PREFIX phases: doing so would require a separate physical normalization
showing that all optimal histories can use those prefixes. A different
head shape, starting a transfer before the cut, or retaining phase/time
credit jointly across both boundaries remains possible.

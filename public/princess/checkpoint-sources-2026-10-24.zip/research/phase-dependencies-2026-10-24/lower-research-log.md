# Lower-bound phase and causal-dependence research log

24 October 2026, sustained post-checkpoint pass. Scope: ordinary physical
boundary necessity and eventual exact full-rectangle capture bounds. No
public artifact or Lean claim is changed by this working folder.

## Accepted structural result: shared ancestors have an exact ledger

`lower-causal-overlap-ledger.md` derives the exact budget savings when two
terminal targets share backward required ancestors. Total duplicated quota
is the lifetime surplus of their intersection plus fork production. The
per-step identity and telescoping are independently accepted in
`upper-causal-overlap-review.json`.

This is a useful replacement for informal independent-cone arguments. It is
NOT an uncrossing theorem: positive overlap savings may be real, and moving
quota between days is forbidden. First spatial backward meeting is not
necessarily paid by an inspection that day. A small floating component may
connect distant dependencies without ever having near-square mass.

## Accepted necessary reduction; scalar exclusion disproved

`lower-sensitive-switch-obstruction.md` isolates opposite-color, odd-time
switches between sensitive exact-surplus corner events. It preserves the
old ordinary coordinate, both endpoint roots and the final sensitive bin.
The exact lens yields both an elapsed-inspection charge and an accumulated
surplus charge. Upper independently checked the physical proof and38,024
adjacent-lens instances.

The proposed standalone exclusion is FALSE. Root's k200 witness and
comparison's unbounded symbolic plateau family satisfy every scalar/charge
condition and lead by one room over the matching ordinary phase. These are
not physical histories. They discard all intermediate near-extremal corner
labels; their uniformly cheap steps cannot simply relocate a large set.
The proof note now explicitly records this failure rather than preserving
an obsolete open-conjecture label.

## New physical restriction: persistent full cores

`lower-persistent-sensitive-core.md` shows that a sensitive event with
root r and defect delta=r²-Q contains a full corner ball of radius
2r-2-2m(delta), tri(m)<=delta. This uses the accepted raw full-layer lemma,
with its origin hypothesis supplied by the punctured-quadrant profile.
Erosion can shrink this ball by only one layer per move regardless of
inspections. A later subcritical event at another corner excludes the
original corner and its neighbors. Therefore an opposite-color switch
requires Delta>=2r-2m(delta)-1.

This rules out the current relaxed counterexamples by a large margin:
k200 requires387 moves, whereas its relaxed tuple uses103. The symbolic
plateau family requires2k-9, whereas it uses k/2+1. Independent review is
accepted in `upper-persistent-sensitive-core-review.json`. Whether these strengthened numerical constraints now exclude
all first matching failures remains open.

Do not extend full-core existence automatically to slack-good events.
A large triangle with its origin removed remains slack-two good but has
no full origin-containing core. A generalized stability or punctured-core
argument would require its own proof.

## Where the old slow history proof is exact already

If an ordinary matching reference is initialized at a genuine good event
and the later targets remain in the accepted slow root interval, paid bad
blocks/rewinds do not require a new extra day. The old one-day allowance
comes from making BOTH phases available at a fast entry. First-sensitive
and first-zero-good initialization are exact, so a proof must retain that
origin and handle later fast entry labels, not repeatedly charge a new
boundary day.

A true retreat FROM a controlled slow count Q>C to Q'<=C can be free when
absolute ordinary interlacing holds: min P_(t+1)>=max P_t then makes both
phases exceed C thereafter. This does not give an unconditional repeated
fast-region invariant from one matching coordinate. Root and comparison
are maintaining that distinction in their interlacing notes.

## Independent reviews completed in this pass

- `upper-fold-axis-rigidity.md`: every finite-periodic monotone,
  cardinality-preserving, neighborhood-subcommuting factor map on the
  one-loop-ended path is identity. This excludes independent folded-axis
  compressions only, not coupled coordinate/layer/history normal forms.
- `upper-short-square-phase-obstruction.md`: the proposed cost-free
  opposite-corner prefix transfer on2b squares is uniformly impossible
  for b>=27 and8<=d<b at the standard central drift time. It is a fixed
  source/target obstruction, not a full-game lower bound.
- `upper-ordinary-boundary-exact-interface.md`: in the accepted even-width
  transport families, proving genuine same-time ordinary early and late
  necessity would close both final-quota cases exactly. The constructive
  and conditional assembly are accepted; the two physical hypotheses
  are still unproved.

## Next proof obligations

1. Challenge the sensitive switch scalar system with the persistent-core
   lower bound, retaining the old defect and exact current-phase orbit.
2. If that is still insufficient, retain the whole sequence of zero-good
   or slack-good dominant corner labels; do not return to a scalar F-only
   relaxation known to discard the obstruction.
3. For causal decomposition, charge or remove shared ancestry by the exact
   per-day overlap ledger. Total surplus alone is not a quota-preserving
   decomposition.
4. Preserve clipped-history/prior-excursion guards. A theorem only while
   all counts stay below the pronic cut is not yet the necessary boundary
   statement used by the full-game assembly.

## Accepted extension: all zero-good events retain a raw core

Upper extended the physical persistence argument in
`upper-zero-good-core-persistence.md`; independent acceptance is saved in
`lower-zero-good-core-review.json`. With zero original slack, every target
has at most one outlier. The own/opposite full-layer defects give explicit
cores, and the exceptional own split is a full(r-1)-triangle plus singleton.
Any later different dominant cohort/corner must wait at least Rcore moves:
before that at least two old near-corner cells persist, but the later event
can accommodate at most one such outlier. This applies through arbitrary
intervening shapes and retains the lower-half labels omitted by scalar
F-only mixing. No corresponding uniform numerical clock theorem is yet proved.

## Further failure shield: preserve the genuine ordinary origin

The strengthened core-delay scalar exclusion cannot be asserted for every
abstract interlacing pair. At k100, hypothetical initial pair(91,89),
old sensitive q91/root10 has defect9 and core-delay13. After13 alternating
updates the hypothetical ordinary pair is(1060,1064), whereas twelve F
updates followed by G give1062, a sensitive target. This initial pair is
not a genuine zero-origin ordinary state. Thus even global interlacing
and a short span are not sufficient substitutes for the true origin in
any future mixing proof. The comparison lane has tested genuine ordinary
orbits with the persistence guard without finding a violation so far;
that evidence is not a uniform proof.

## Breakthrough: exact ordinary early boundary necessity

The complete physical theorem in `lower-ordinary-early-boundary-theorem.md`
is independently accepted by root and upper (their source-hashed receipts
are `root-ordinary-early-boundary-review.json` and
`upper-ordinary-early-boundary-review.json`). For every even-area rectangle,
k>=max(13,floor(w/2)+1), and every history staying below H=b(b-1), the total
holes are at most the genuine ordinary zero-origin maximum at the SAME day.
At every zero-slack good event the actual dominant corner/cohort also has
its matching phase inequality. No fast scalar reset or extra day remains.

The new mechanism is full physical core persistence plus two-step B mixing.
Each change of actual good identity is delayed until both ordinary phases
are available. Large roots are covered analytically; all small roots reduce
to100105 exact arithmetic seeds, independently reproduced. Tiny targets,
critical-root targets, arbitrary retreats and the true first-cut overshoot
are included. The accepted clipped consequence gives the exact ordinary
head clock at A=b^2-k+1, with overshoot at most H.

This supersedes the earlier list of unresolved sensitive-switch and
prior-excursion obligations for the EARLY boundary. It does not prove late
signed necessity, arbitrary middle compatibility, or the whole capture
time theorem. The next focused route is extending the same proof to a
first quota c<=k, which gives an unequal ordinary seed and would cover the
solo late gate by exact time reversal. The signed two-cohort gate remains
a distinct physical issue; it cannot be replaced by a fictitious c-room
terminal set.

## First-quota seed and the signed late splice

The exact early core mechanism extends to a first quota c<=k: its genuine
seed is (c-rho(c),c-ceil(sqrt(c))). Large-root mixing has only one extra
initial span room and remains paid at root100. The complete small-root
certificate checks41944610 dangerous seeds across all admissible(k,c),
with no board dimension sampling. At the first state, the only asymmetric
danger is an own-sensitive component. The tiny core-zero exceptions are
resolved by the old origin being outside the neighborhood of a different
next good component: one old room is unusable, exactly paying the gap.
Source: `lower-first-quota-ordinary-boundary.md`; combined independent review
is pending at this log entry.

The shifted genuine-origin continuation is explicit in
`lower-shifted-seed-continuation.md`. An actual terminal set bounded by BOTH
ordinary late coordinates initializes matching good or both-phase bad
erosion at the correct later orbit index. Clipping handles all excursions.
No artificial first quota equal to that terminal set's size is introduced.

Upper's signed activation splice is independently accepted by lower in
`lower-signed-late-splice-review.json`, conditional on the seeded theorem.
Last-full normalization is applied to the finite gate prefix, with terminal
time allowed as its last full day. At activation PRE-state the real smaller
set is controlled by BOTH late capacities, because the mixed comparison
already applies to the activation POST-inspection survivors. Reverse only
the preceding solo word and use shifted-origin continuation. The normalized
initial mass is clipped, so normalization is not assumed to preserve every
intermediate signed mass. This removes the late phase day without equating
a signed gate to a fictitious small terminal set.

The resulting proposed uniform gap4 assembly was independently checked in
`lower-uniform-four-review.json`. It remains contingent on final seeded and
splice review completion; it is not gapzero, new Lean coverage, or a closed
formula. In the already constructive even-width transport families the
same exact boundaries can instead match the bounds completely.

## Reviewed ordinary boundaries and exact transport families

The first-quota theorem is now independently accepted after upper's
separate integer-inversion implementation reproduced all41944610 dangerous
seeds, including every per-budget count. The signed late splice and its
finite-prefix normalization are independently accepted. Thus the formerly
conditional uniform-gap4 assembly now has its boundary inputs; no public
or Lean promotion is implied by these ordinary research receipts.

The accepted even-width transport construction matches the ordinary bound
exactly for b>=32: minimum budget k=b+1 at every length, and budgets b+d
with2<=d<=b-1 at all n>=2b+2d-2. The exact time is the algorithmic expression
J(k)+J(floor(k/2))+1. See `upper-exact-even-transport-families.md` and
`lower-exact-even-transport-review.json`. This is real mathematical
completion of these uniform families, distinct from source consolidation.

## Actual cores and feature interfaces after the boundary proof

`lower-middle-core-overlap.md` gives a raw physical two-front obstruction,
including exact adjacent-corner triangular overlap and an explicit slack
charge when only a reverse allowed set contains the later core. Same-corner
and distinct-corner formulas are kept separate. Numerical capacity never
silently supplies an actual core.

`lower-late-capacity-marker.md` proves that exact unique-phase late capacity
below the clipping cap is attained only before activation; equality in the
real reversed word then puts its actual erosion marker inside the actual
source belief. A missing required corner/erosion marker costs at least one
room. Upper independently accepted both notes.

`lower-late-last-root-core.md` strengthens this at pronic late contact:
under k>=100 and k>d^2+4d+3, the last good ancestor has root exactly b-1 and
age at most2d+1. The source belief therefore contains a radius
R_*(b-1)-2d-1 core. The algebra handles growing d, rather than treating it
as a constant. Upper independently accepted the proof, including the
pre-inspection source timing.

The first forward-nine feature recurrence was independently accepted in
`lower-forward-marker-review.json`. It remains too weak because numerical
phase mixing does not erase actual geometry. The new uniform constraint
`lower-core-dissipation-head.md` retains the LAST actual good event and its
size-dependent core radius through every later B step. A cornerless head
must wait until that core is completely gone. On the one existing127x128,
k64,t373 obstruction, its cornerless hole cap is3785 instead of3843; the
other two marker faces retain the expected3843/3844 values. This targeted
receipt tests the mechanism, not a family-level time claim. Comparison is
integrating the accepted envelope and checking all retained head times.

## Critical geometry and one-step localization memory

The accepted `lower-critical-core-or-frontier.md` extends the actual-set
separator dichotomy to the odd-width critical surplus b: a small collar
state is either genuinely corner-localized (with its raw core), the unique
triangle-plus-singleton equality case, or an oriented full-span prefix
frontier. This is a static classification, not yet a phase-continuity
theorem.

The twelve-threshold recurrence in `comparison-localization-flags.md` and
`comparison_localization_flags.py` is independently accepted in
`lower-localization-flags-review.json`. Three one-step geometric flags
retain pronic and square localization through the next transition. The
maximal-survivor removal is justified by a symbolic lower bound on its
necessary surplus, without assuming all feasible targets form an interval.
A separate exhaustive labelled audit checked1,530 reset-top events. The
existing127 and419 obstruction clocks close under this uniform mechanism;
this is not a new all-parameter exactness theorem.

Independent reviews also accept the actual opposite-frontier quadratic
inspection charge and the early exact-contact last-root core. The latter
retains the sole one-room inverse-rounding exception at final Q=H and
charges the extra movement into the critical collar. Reviews are
`lower-opposite-frontier-review.json` and
`lower-early-last-root-review.json`.

## Matched ordinary phase now persists through the odd critical collar

`lower-capped-critical-continuation.md` is independently accepted by root
and upper. For odd width2b+1, every even length, and b>=max(200,4d+8),
k=b+d, it controls actual total holes by the capped ordinary pair throughout
Q<h-b(b+1), and retains the actual cohort/longitudinal-end phase at every
minimal-surplus good event. Full-span critical frontiers contain endpoint
cores of radius at least2d+2; a different phase cannot appear before
capped bad steps have erased the mismatch. This extends the existing
small-corner history proof through the center without an extra phase day.

A complete independently reproduced arithmetic cap-transfer base removes
the analytic200 guard: `lower-capped-critical-finite-base.md` gives
b>=max(32,4d+8). Both implementations check all1,154,597 dangerous seeds
over4,452 finite cap/budget pairs, with minimum margin4. No board length
or selected physical-instance scan is used.

The separate safe first-cut corollary takes A=h-b(b+1)-d, ensuring the
first overshoot remains strictly below the critical upper collar. It does
not infer control at the co-small endpoint from a mere scalar surplus
bound. The arbitrary-seed and signed-late analogues remain separate work.


## Complete capped seeded continuation and exact odd minimum budget

The independent target-profile-inversion audit reproduced every row of the
complete capped first-quota base:160,021,649 dangerous seeds for32<=b<200,
and130,966 additional seeds for12<=b<32. Receipts are
`lower-capped-seeded-review.json` and
`lower-capped-small-width-seeded-review.json`. All first quotas0..k and
all genuine orbit times/target sizes are included; no rectangle lengths
or selected physical boards were scanned.

`lower-capped-natural-range.md`, independently accepted by upper, audits
all nonnumerical guards and unifies the capped zero-origin, first-quota,
shifted initialization, marker, safe-cut and signed-late theorems under
b>=4d+8. The inherited cutoffs32 and200 are no longer needed.

`root-tied-cut-exact-gate.md` is independently accepted in
`lower-tied-cut-exact-gate-review.json`. One tied capped head strictly
between b^2 and A=U-d forces arbitrary physical gate clocks to equal the
physical prefix clock, because the SAME actual split is bounded from
both ends and physical/capped late maps agree below Z=h-b^2. At d=1,
the capped orbit necessarily ties at b^2+1. Hence every odd width2b+1,
b>=12, every even lengthn>=w, and minimum budgetk=b+1 has exact signed
gate clocks for every terminalquota0..k, and exact capture time
P(k)+P(floor(k/2))+1. This is algorithmic evaluation and an attaining
physical rule, not a fixed-operation expression or new Lean proof.

A second independent route through the reviewed twelve-state symbolic
middle certificate is accepted in
`lower-minimum-budget-exact-gate-review.json` for b>=32. Its tied central
split is forced by the actual physical prefix clock, rather than chosen
independently for the two phases. The simpler root tied-cut proof extends
the conclusion to the natural range and does not need that automaton.

The next larger-budget interface is physical whole-front overlap.
`upper-whole-front-overlap.md` is independently accepted in
`lower-whole-front-overlap-review.json`: two same-end critical fronts,
retained through ages<=2d, overlap by more than d under b>=4d+8, including
an explicit reverse-allowed-set defect. This is a conditional geometry
lemma; supplying full-front ancestors and their ages remains necessary.
The new `lower-critical-exact-contact-ancestry.md` isolates a current or
one-step-old actual full front at exact central contact, with explicit
affine predecessor guards; it is submitted for independent review.


## Whole-front overlap now yields an exact odd-width parameter family

`lower-full-front-exact-gates.md` is independently accepted by upper.
For w=2b+1,n=2ell>=w,k=b+d with b>=4d+8 and the explicit strict guard
(2b+1)(ell-b)>2d^2, every arbitrary full-origin signed gate clock equals
the attained physical prefix clock P(c), for every terminalquota0..k.
The exact full capture evaluator is P(k)+P(floor(k/2))+1. In particular
EVERY length is covered if b>=d^2 as well as b>=4d+8.

The proof chooses a cut from the actual normalized history where the early
whole-front criterion is barely positive. Global interlacing makes its
overshoot at mostd. Failed physical meeting forces BOTH early and late
states to be phase-sensitive and their leaders to have the same phase.
The numerical deficits and reverse allowed-set defect share one budget
at mostd-1. The explicit length condition then forces both real whole-front
ancestors to have ages at most2d-1. Their same-end overlap exceedsd, while
actual holes can intersect the allowed reverse set only in its at mostd-1
extra cells. This contradiction matches the existing physical construction.

This is a full quantified family, not certification of chosen widths. It
retains exact gate indices and actual cohort/end labels, and never places
an allowed reverse frontier into the actual survivor. The uncovered short
boards with larger excess and the natural-range restriction remain real
limitations. The all-age localized erosion-defect lemma being developed
by root/upper may strengthen that entry boundary; no such extension is
included in the accepted theorem.


## Wrap-up: accepted even classification and actual-span exact criterion

Stopped research at the user wrap-up instruction. Accepted even critical classification covers n>=2b+2, with the separate n=2b+1 extension also independently accepted; square separator analysis is saved as UNREVIEWED restart progress. The genuine central span criterion was independently reviewed and preserves the strict actual-orbit guard. `lower-wrap-checkpoint.md` is the lane status record. No public or Lean edits.

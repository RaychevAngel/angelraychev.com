"""Falsification panel of ordinary boundary clocks and phase-compatible bounds.
Not a finite proof of the uniform theorem. No game search or expression work.
"""
from pathlib import Path
from math import isqrt
from functools import lru_cache
from bisect import bisect_left
import importlib.util,json,time
P=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('oldshift',P.parent/'overnight-uniform-2026-10-24/root-shifted-clock.py')
old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
def R(x):return isqrt(x-1)+1 if x else 0
def rho(x):
 r=(isqrt(4*x+1)-1)//2
 return r+(r*(r+1)<x)
@lru_cache(None)
def early(b,d):
 k=b+d;H=b*(b-1);x=y=0;mx=[0]
 while mx[-1]<H:
  x,y=y+k-rho(y+k),x+k-R(x+k);mx.append(max(x,y))
 return endpoints(mx,H-d+1,H)
@lru_cache(None)
def late(b,d,c):
 k=b+d;H=b*(b-1);x=y=c;mx=[c]
 while mx[-1]<H+d+1:
  x,y=k+y-rho(y),k+x-R(x);mx.append(max(x,y))
 return endpoints(mx,H+1,H+d+1)
def endpoints(mx,lo,hi):
 # All clock blocks retained, with their largest endpoint. The middle clock
 # is nonincreasing in either endpoint, so all omitted points are dominated.
 by={}
 for q in range(lo,hi+1):by[bisect_left(mx,q)]=q
 return tuple((q,t) for t,q in by.items())
def joint(w,n,k,c):
 b=w//2;d=k-b;h=w*n//2
 return min(e+ell+old.faster_middle(b,d,h,q,y,w%2)
            for q,e in early(b,d) for y,ell in late(b,d,c))
def upper(w,n,k):
 b=w//2;h=w*n//2
 def step(x):
  out=[]
  for p in (0,1):
   t=x[1-p]
   if t==h:out.append(h);continue
   low=rho(t) if p==0 else R(t)
   high=(R(h-t) if p==0 else 1+rho(h-t)) if w%2 else (R(h-t) if 1-p==n%2 else 1+rho(h-t))
   out.append(min(h,k+t-min(low,high,b+(w%2 and p==1))))
  return tuple(out)
 X=(0,0);Y=(k//2,k//2);t=0;ans=None
 while ans is None:
  if max(X)==h:ans=2*t
  if max(Y)==h:ans=min(ans or (2*t+1),2*t+1)
  if ans is not None:return ans
  X=step(X);Y=step(Y);t+=1
if __name__=='__main__':
 start=time.process_time();cases=set()
 for a in json.loads((P/'root-finite-simple-late-diagnostic.json').read_text())['rows']:
  cases.add((a['w'],a['n'],a['k']))
 for b in (32,33,50,64,100,200,500,1000):
  for d in sorted({1,2,3,7,19,b-1}):
   for w in (2*b,2*b+1):
    for n0 in (w,w+1,w+5,w+2*d-2,2*w,3*w):
     n=n0+(w*n0%2)
     cases.add((w,n,b+d))
 rows=[];hist={}
 for w,n,k in sorted(cases):
  J=joint(w,n,k,k);Jhalf=joint(w,n,k,k//2);Jzero=joint(w,n,k,0)
  assert Jzero==J+1 and J<=Jhalf<=J+1,(w,n,k,J,Jhalf,Jzero)
  L=max(2*J+1,2*Jhalf);U=upper(w,n,k)
  alpha=2 if w%2 else 1
  assert 0<=U-L<=2*alpha,(w,n,k,J,Jhalf,L,U)
  row=dict(w=w,n=n,k=k,J=J,Jhalf=Jhalf,lower=L,upper=U,gap=U-L)
  rows.append(row);hist[str((w%2,U-L))]=hist.get(str((w%2,U-L)),0)+1
 out=dict(status='PASS diagnostic only; uniform mathematical reduction is separate',cases=len(rows),maximum_gap=max(a['gap']for a in rows),histogram=hist,CPU_seconds=time.process_time()-start,rows=rows)
 P.joinpath('root-ordinary-joint-diagnostic.json').write_text(json.dumps(out,indent=2)+'\n')
 print({k:v for k,v in out.items()if k!='rows'})

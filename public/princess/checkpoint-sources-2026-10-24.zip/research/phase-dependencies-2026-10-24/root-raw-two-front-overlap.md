# Raw two-front overlap, with the unused-capacity credit retained

24 October 2026. Elementary necessary-history lemma. This is a research
interface, not yet an exact middle evaluator or an improvement beyond the
accepted four-day global bracket.

Fix one initial-parity cohort. At a physical time t let S_t be its possible
positions and H_t its complement within the current color class. Then
H_(t+1)=E(H_t union I_t), where I_t denotes the inspected cells in this
cohort, and E is open-neighborhood erosion into the opposite color.

Suppose H_u contains the full parity-restricted corner ball B_R(C).
At v=u+Delta with Delta<=R, erosion persistence gives

    B_(R-Delta)(C) subset H_v.                         (1)

Now take ANY set D and ANY future inspection word from time v such that the
actual cohort is guaranteed either to be inspected or to end in D.
Let C_v be its exact reverse allowed set, formed by repeatedly applying
C_prev=I_prev union E(C_next), starting at D. Then S_v subset C_v, hence

    |C_v intersect H_v| = |C_v|-|S_v|.                 (2)

If C_v also contains a full same-color ball B_S(C'), then

    |B_(R-Delta)(C) intersect B_S(C')|
         <= |C_v|-|S_v|.                              (3)

The right side is an actual capacity credit, not a freely reusable daily
inspection allowance. Equations(1)--(3) use arbitrary shapes, arbitrary
quota allocations, and the real remaining word. In particular one must NOT
infer that S_v itself contains the core seen in C_v. Extra allowed cells can
lie in positions already ruled out by the earlier history; exactly that
possibility is charged by the right side of (3).

If a real later survivor/belief itself contains B_S(C'), use its disjointness
from H_v directly: the intersection on the left must be empty. This is the
stronger zero-credit case, with the appropriate before/after-inspection time.

## Exact adjacent-corner count, without an asymptotic shortcut

For a w by n board with adjacent corners C=(0,0), C'=(w-1,0), and current
color x+y=p mod2, set r=R-Delta>=0 and s=S. On row y the intersection has

    lo=max(0,w-1+y-s), hi=min(w-1,r-y).

If lo>hi it contributes zero. Otherwise its exact contribution is

    floor((hi+y-p)/2)-floor((lo-1+y-p)/2).

Sum this over y=0,...,n-1. This finite evaluator is only a necessary
compatibility test at present. It does not meet, and is not proposed as,
the final bounded-operation numerical goal.

The corresponding count for any two board corners is obtained by the same
coordinate inequalities or literal set intersection. At zero credit,
compatible parity radii show that overlap occurs when the two balls reach
a common point on a shortest corner-to-corner path. A safe formulation is
the exact count above; no unchecked parity rounding is hidden in a distance
inequality.

## What remains before this can close a capture-time gap

The new boundary proofs identify actual cores at zero-good events, and
retain matching ordinary phase at such events. This lemma is useful only
if that geometric information and the credit |C_v|-|S_v| are linked to the
actual endpoints used by the necessary middle clock. The late scalar MAX
bound alone does not identify a core inside S_v. Nor may the reverse allowed
set be given an uncapped ordinary cardinality bound beyond the proved
boundary range.

Two possible rigorous inputs are (i) actual localized late survivors, with
zero overlap allowance, or (ii) a reverse-core event with a proved capacity
excess, charged by (3). Critical-root passages, unused shots, overshoot, and
activation time must all be retained. No prefix normal form follows from
this lemma, and no new global numerical gap is asserted.

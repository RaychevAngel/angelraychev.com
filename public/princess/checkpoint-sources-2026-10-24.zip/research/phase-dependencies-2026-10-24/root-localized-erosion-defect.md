# Raw localized fronts lose no additional area defect under erosion

24 October 2026. New ordinary lemma, submitted for independent review.
This does not assume row-prefix or column-prefix compression of the raw set.

Let the corner quadrant be x,y>=0, let R>=0, and let B_R consist of all
cells x+y<=R having parity R. On each occupied diagonal l=R mod2,
l+2,...,R, suppose a raw set S has the nonempty interval

    I_l=[alpha_l,beta_l] of x coordinates, 0<=alpha_l<=beta_l<=l.

Write gamma_l=l-beta_l. Assume that each of alpha and gamma obeys the
following condition between consecutive diagonals:

    z_(l+2)=0 implies z_l=0;
    z_(l+2)>0 implies z_(l+2)>=z_l+1.                 (1)

Put delta=|B_R|-|S|=sum_l(alpha_l+gamma_l). For every integer 0<=t<=R,
the actual t-fold graph erosion satisfies

    |B_(R-t) minus E^t(S)| <= delta.                  (2)

More precisely, it is EXACTLY the set K_t whose interval on diagonal
j=R-t mod2,...,R-t is

    [alpha_(j+t), beta_(j+t)-t],                      (3)

interpreted as empty if the endpoints are reversed. Formula (3) remains
valid when an intermediate eroded set has empty internal layers. No
assumption that intermediate sets are again zero-good is necessary.

## Proof of the literal set identity

We prove K_t subset E(K_(t-1)). Let (x,y) in K_t, j=x+y, l=j+t.
Its two neighbors of distance j+1 belong to K_(t-1): they use the SAME
original interval I_l, and x and x+1 both lie in
[alpha_l,beta_l-(t-1)].

For a lower neighbor, use I_(l-2). If x>0, its x coordinate x-1 is at
least alpha_(l-2): either alpha_l>0 and (1) gives this, or alpha_l=0
and then alpha_(l-2)=0. The upper coordinate requirement for that neighbor
is automatic from beta_l<=beta_(l-2)+1, unless gamma_l=0. In that latter
case beta_l=l, beta_(l-2)=l-2, and x<=j implies
x-1<=j-1=beta_(l-2)-(t-1).

For the other lower neighbor, which exists only if y>0, the lower bound
x>=alpha_(l-2) follows from (1). If gamma_l>0, (1) gives
beta_l<=beta_(l-2)+1 and hence
x<=beta_l-t<=beta_(l-2)-(t-1). If gamma_l=0, the condition y>0 gives
x<=j-1=beta_(l-2)-(t-1). All needed lower neighbors are present.
When j=0 there are no lower neighbors; otherwise I_(l-2) exists.
This proves the inclusion, including empty-layer cases. As K_0=S,
induction gives K_t subset E^t(S).

Conversely, if a cell belongs to E^t(S), every endpoint of a length-t walk
from it belongs to S. In particular the two outward paths ending at
(x+t,y) and (x,y+t) lie on original diagonal j+t. They force
alpha_(j+t)<=x and x+t<=beta_(j+t). Also j+t<=R. These are exactly (3).
Thus E^t(S)=K_t.

The number of missing cells on diagonal j of B_(R-t) is

    min(j+1, alpha_(j+t)+gamma_(j+t)).

Summing over the subset of original diagonal indices j+t proves (2).
Inside a rectangular board containing B_R, retain the inclusion
K_t subset E_board^t(S), hence the same defect inequality (2). Removing
neighbors beyond the board can only enlarge erosion. We do not need or
assert the stronger rectangular equality with K_t: the exact identity
above concerns the infinite quadrant. The localized critical and
subcritical balls in the accepted classification fit inside the board.

## Why genuine localized zero-good sets satisfy the hypothesis

Use the occupied-layer and outer-radius conclusions already proved in
`upper-zero-good-core-persistence.md` and
`lower-critical-core-or-frontier.md`. With no singleton outlier, an own
corner event of surplus r has r nonempty layers, ending at R=2r-2;
an opposite-corner event has r-1 layers ending at R=2r-3.

For a nonempty x-set I on a diagonal, its upper shadow I union (I+1)
has at least |I|+1 cells, with equality precisely when I is an integer
interval. In the own case the r upper-shadow layers already contribute
|S|+r to |N(S)|. In the opposite case the additional origin plus the
r-1 upper-shadow layers contribute the same total. Exact surplus r
therefore forces interval equality on EVERY layer, and forces the down
shadow of every subsequent layer to be contained in the preceding upper
shadow. The left and right endpoint conditions for that containment are
exactly (1). Thus (2) holds with respectively

    delta=r^2-|S|,          delta=r(r-1)-|S|.

For the singleton-outlier alternative, apply the lemma to its full
dominant triangle with delta=0; retain the outlier separately if useful.

## Consequence for overlapping physical dependencies

If a localized actual set has canonical enclosing triangle B_R and defect
delta, its retained descendants miss at most delta cells of B_(R-t).
For two such retained sets, canonical intersection minus delta_1-delta_2
is a valid lower bound on their intersection. A whole-front/triangle
comparison similarly subtracts the localized delta only. Allowed-set
excess must still be charged separately against the shared deficit budget.

This replaces the earlier conversion of delta into a lost radius of
order sqrt(delta), which could lose order b sqrt(delta) cells at a join.
It does not itself prove that the needed ancestors occur, establish their
ages, or imply a new capture-time bound. Independent proof review is pending.

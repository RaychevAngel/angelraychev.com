"""Falsify the sensitive-only phase-switch comparison, not the physical game.

Uses exact integer inverse maps. Tests the weakest board-dependent lens by
choosing b=r_new+1; actual boards with larger b only strengthen the charge.
"""
from math import isqrt
import json,time
from pathlib import Path

def root(z):return isqrt(z-1)+1 if z else 0
def rho(z):
 r=(isqrt(4*z+1)-1)//2
 return r+(r*(r+1)<z)
def F(x,k):return x+k-root(x+k)
def G(x,k):return x+k-rho(x+k)
def sensitive_below(q):
 r=root(q)
 return q if q>r*(r-1) else (r-1)**2 if r else 0

def run(top):
 count=0;nearest=None;st=time.process_time()
 for k in range(4,top+1):
  cap=(k-2)**2;P=[(0,0)]
  while min(P[-1])<cap:
   a,b=P[-1];v=(G(b,k),F(a,k));P.append(v)
   if v==(a,b):break
  for u,(a,b) in enumerate(P):
   q=sensitive_below(min(a,cap))
   if not q or q<=b:continue
   rold=root(q);x=q
   for dt in range(1,len(P)-u):
    target=sensitive_below(min(G(x,k),cap))
    if dt%2 and target>P[u+dt][0]:
     r=root(target);board_b=r+1;over=max(0,rold+r-board_b)
     lens=over*(over+1)//2;required=target+r-lens
     count+=1;margin=required-dt*k
     row=dict(k=k,u=u,dt=dt,start=q,target=target,r_old=rold,r_new=r,
              ordinary_start=P[u],ordinary_end=P[u+dt],b=board_b,
              minimum_shots=required,available=dt*k,margin=margin)
     if nearest is None or margin<nearest['margin']:nearest=row
     if margin<=0:
      return dict(status='COUNTEREXAMPLE TO RELAXED SENSITIVE SWITCH INEQUALITY',witness=row,checks=count,CPU_seconds=time.process_time()-st)
    x=F(x,k)
    if x<=min(P[u+dt]):break
 return dict(status='NO COUNTEREXAMPLE IN FINITE ALGEBRAIC TEST',maximum_k=top,checks=count,nearest=nearest,CPU_seconds=time.process_time()-st)
if __name__=='__main__':
 import sys
 out=run(int(sys.argv[1])if len(sys.argv)>1 else 2000)
 Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))

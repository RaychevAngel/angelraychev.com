# One middle day at every large excess

24 October 2026. Proposed uniform comparison for independent review.
This uses the genuine ordinary terminal orbit. Its smaller inherited phase
spread removes one of the two middle days in the previous comparison.

Let w<=n, wn even, b=floor(w/2)>=32, 2b<=k<3b, d=k-b, and h=wn/2.
Put H=(b-6)^2 and use the complete endpoint ranges

    H<=Q<=H-1+k-rho(H-1+k),
    H<Y<=H+k-rho(H)=H+d+6.

For 0<=c<=k let V^c be the ordinary late pair from(c,c), and let ell be
its first maximum hitting time of Y. Set C=V^c_ell. Let tau be the accepted
necessary BAND9 middle clock from equal seed Y to maximum M=h-Q. If Phi
is the actual finite-board backward prefix operator, then

    min Phi^(tau+1)(C) >= M.                         (1)

Thus the combined full-board bounds in this parameter range have gap at
most TWO. The theorem covers both width parities and every n>=w of even
area. No fixed-width sampling or final-expression simplification is used.

## 1. The actual late seed has a much smaller spread

The two ordinary scalar maps are F(x)=k+x-ceil(sqrt(x)) and
G(x)=k+x-rho(x). They are nondecreasing and1-Lipschitz, and
0<=G(x)-F(x)<=1. The pair update is(G(y),F(x)). Starting from a tied pair,
the signed difference at time t belongs to

    [-floor(t/2), ceil(t/2)].

Indeed a nonnegative previous difference Delta produces a new difference
between -Delta and1; a negative one produces a difference between0 and
1-Delta. Induction gives the displayed bounds. In particular

    span V^c_t <= ceil(t/2).                         (2)

Before the first maximum reaches Y, both inputs are below Y<b^2, so both
root costs are at most b. Every coordinate after t steps is therefore at
least c+td until that crossing. Consequently

    ell <= ceil(Y/d)
        <= ceil(1+((b-6)^2+6)/b) <= b-9.

The last inequality uses b>=32 (indeed42/b<=2 suffices). Writing
s=span C, we have

    s<=ceil((b-9)/2),   d-s>=floor((b+9)/2)>=20.      (3)

This is a genuine-origin bound. It need not hold for an arbitrary hybrid
seed with the same first maximum. Also min C>=Y-s.

## 2. Reuse the accepted three-region comparison with one extra update

Use the faster necessary comparator and its low, central and high regions
from `../joint-history-2026-10-24/lower-large-excess-middle-two.md`.
Its region step counts total at most tau. All endpoint and root-bin guards
there remain unchanged: d>=b>=32 satisfies its d>=26 assumption, and
k<3b is retained. The only modified inputs are the smaller initial debt
s in (3), and the number of extra physical updates.

The low region has at most six one-room injections and at most one room
of span at its exit. Comparing with the virtual physical pair(Y-s,Y-s)
therefore gives, at the actual low exit maximum z1,

    both physical coordinates >= z1-s-7.

Perform exactly ONE extra physical update at this point. The universal
width caps give a gain of at least d-1 in each coordinate, clipped at h,
for both parities (even width has the stronger gain d). Thus both physical
coordinates dominate the reset equal seed z1 with room credit at least

    d-s-8 >=12.                                     (4)

The accepted central-region proof consumes at most THREE rooms, including
the odd square endpoint, its possible exceptional transition, and exit
alignment. The accepted high-region proof consumes at most SEVEN rooms,
including all root-bin clamps and terminal alignment. These are the
conservative original constants; no sharper parity refinement is needed.
The twelve rooms in (4) pay all ten rooms and leave a positive margin.

If a region is skipped or the target is reached early, its unused charge
is omitted. Physical clipping at h already wins. The argument uses the
same actual times and the same fixed phase labels as the accepted proof;
no corner reset is supplied for free. Coordinatewise time monotonicity of
the ordinary physical orbit gives (1) at tau+1 even when the faster
comparator uses fewer than tau steps.

## 3. Whole-game consequence and exact scope

In `root-uniform-four.md`, use the same ordinary necessary endpoint minimum
J(c) and replace alpha=2 by alpha=1 for2b<=k<3b. The early and late physical
necessity proofs, endpoint minimization and terminal-quota argument are
unchanged. The construction meeting follows from (1), regardless of the
early maximizing phase. With J=J(k), Jhalf=J(floor(k/2)),

    L=max(2J+1,2Jhalf),
    U=min(2J+4,2Jhalf+3),

and Jhalf belongs to{J,J+1}. Hence U-L<=2.

Together with the accepted pronic even-width comparison, this gives gap<=2
for EVERY even width w=2b with b>=32 and every feasible budget: b<k<2b
uses that earlier comparison,2b<=k<3b uses this theorem, and k>=3b retains
the stronger old one-day bound. Odd width gains the same two-day bracket
throughout2b<=k<3b. Odd-by-odd exact evaluation and all prior smaller-width
bounds remain in force.

The overall uniform ceiling remains four until the low-budget odd-width
range b<k<2b is improved. This is ordinary proof progress, not new Lean
coverage or a claim of gap zero.

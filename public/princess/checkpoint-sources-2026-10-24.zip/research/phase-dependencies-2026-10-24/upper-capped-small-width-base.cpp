// Complete first-quota cap-transfer base, not a rectangle/state panel.
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <iostream>
#include <vector>
using namespace std;
static constexpr int LIMIT=200000;
static int rt[LIMIT+1],pr[LIMIT+1],tri[LIMIT+1];
int main(){
  for(int x=0,r=0,p=0,m=0;x<=LIMIT;++x){
    while(r*r<x) ++r;
    while(p*(p+1)<x) ++p;
    while((m+1)*(m+2)/2<=x) ++m;
    rt[x]=r;pr[x]=p;tri[x]=m;
  }
  clock_t start=clock(); long long totalSeeds=0,orbits=0,states=0;
  int params=0,globalMargin=100000;
  array<int,10>worst{};
  cout << "{\"status\":\"PASS\",\"b_range\":[12,31],\"guard\":\"1<=d; 4d+8<=b; all 0<=c<=k\",\"rows\":[";
  bool comma=false;
  for(int b=12;b<32;++b) for(int d=1;4*d+8<=b;++d){
    ++params;int k=b+d,cap=min((b-1)*(b-1),99*99);
    auto G=[&](int x){if(x<0||x+k>LIMIT) abort();return max(x+k-pr[x+k],x+d);};
    auto F=[&](int x){if(x<0||x+k>LIMIT) abort();return max(x+k-rt[x+k],x+d-1);};
    long long seeds=0,nstates=0;int marginMin=100000;
    for(int c=0;c<=k;++c){
      ++orbits;
      vector<array<int,2>> W{{c-pr[c],c-rt[c]}};
      auto extend=[&](){auto z=W.back();W.push_back({G(z[1]),F(z[0])});};
      while(min(W.back()[0],W.back()[1])<cap) extend();
      int last=(int)W.size()-1;
      for(int j=0;j<200;++j)extend();
      for(int u=1;u<last;++u){
        ++states;++nstates;
        for(int phase=0;phase<2;++phase){
          for(int q=W[u][1-phase]+1;q<=min(cap,W[u][phase]);++q){
            int r=rt[q];
            if(r<4 || (phase && q>r*(r-1)))continue;
            int core=2*r-2-phase-2*tri[r*(r-phase)-q];
            if(!phase&&q==(r-1)*(r-1)+1)core=min(core,2*r-4);
            int x=q,age=0;
            while(x>min(W[u+age][0],W[u+age][1])&&age<core){x=G(x-1);++age;}
            int margin=core-1-age;
            if(margin<0){cerr<<"FAIL "<<b<<' '<<d<<' '<<c<<' '<<u<<' '<<phase<<' '<<q<<' '<<core<<' '<<age<<'\n';return 1;}
            if(margin<globalMargin){globalMargin=margin;worst={b,d,c,u,phase,q,r,core,age,margin};}
            marginMin=min(marginMin,margin);++seeds;++totalSeeds;
          }
        }
      }
    }
    if(comma)cout<<',';comma=true;
    cout<<"{\"b\":"<<b<<",\"d\":"<<d<<",\"seeds\":"<<seeds<<",\"time_states\":"<<nstates<<",\"minimum_margin\":"<<marginMin<<'}';
  }
  cout<<"],\"parameters\":"<<params<<",\"orbits\":"<<orbits<<",\"time_states\":"<<states<<",\"dangerous_seeds\":"<<totalSeeds<<",\"minimum_margin\":"<<globalMargin<<",\"worst\":[";
  for(int i=0;i<10;++i){if(i)cout<<',';cout<<worst[i];}
  cout<<"],\"cpu_seconds\":"<<double(clock()-start)/CLOCKS_PER_SEC<<"}\n";
}

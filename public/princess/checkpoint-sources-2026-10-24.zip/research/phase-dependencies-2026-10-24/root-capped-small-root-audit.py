"""Complete finite cap-transfer audit; scalar arithmetic only.

Analytic reduction proposed by lower covers b>=200. This checks every
b<200 with b>=4d+8 and b>=32, all dangerous ordinary seeds of root<100.
It does not enumerate rectangles or infer physical reachability.
"""
from math import isqrt
from pathlib import Path
import hashlib
import json
import time


def R(x):
    return isqrt(x - 1) + 1 if x else 0


def rho(x):
    z = (isqrt(4 * x + 1) - 1) // 2
    return z + (z * (z + 1) < x)


def m(x):
    return (isqrt(8 * x + 1) - 1) // 2


def check(b, d):
    k = b + d
    cap = min((b - 1) ** 2, 99 ** 2)
    def G(x):
        return max(x + k - rho(x + k), x + d)
    def F(x):
        return max(x + k - R(x + k), x + d - 1)
    def B(x):
        return G(x - 1)
    pairs = [(0, 0)]
    def extend():
        x, y = pairs[-1]
        pairs.append((G(y), F(x)))
    while min(pairs[-1]) < cap:
        extend()
    last = len(pairs) - 1
    seeds = 0
    minimum = None
    for u in range(1, last):
        for phase in (0, 1):
            for q in range(pairs[u][1 - phase] + 1,
                           min(cap, pairs[u][phase]) + 1):
                r = R(q)
                if r < 4 or phase and q > r * (r - 1):
                    continue
                core = 2 * r - 2 - phase - 2 * m(r * (r - phase) - q)
                if phase == 0 and q == (r - 1) ** 2 + 1:
                    core = min(core, 2 * r - 4)
                x, age = q, 0
                while x > min(pairs[u + age]) and age < core:
                    x, age = B(x), age + 1
                    if u + age >= len(pairs):
                        extend()
                margin = core - 1 - age
                assert margin >= 0, (b, d, u, phase, q, r, core, age)
                row = dict(b=b, d=d, u=u, phase=phase, q=q, root=r,
                           core=core, mixing_age=age, margin=margin)
                if minimum is None or margin < minimum['margin']:
                    minimum = row
                seeds += 1
    return dict(b=b, d=d, seeds=seeds, worst=minimum)


if __name__ == '__main__':
    start = time.process_time()
    rows = [check(b, d) for b in range(32, 200)
            for d in range(1, (b - 8) // 4 + 1)]
    path = Path(__file__)
    result = dict(status='PASS complete finite arithmetic cap-transfer base',
                  b_range=[32, 199], guard='1<=d and 4d+8<=b',
                  parameters=len(rows), seeds=sum(x['seeds'] for x in rows),
                  minimum_margin=min(x['worst']['margin'] for x in rows
                                     if x['worst']),
                  CPU_seconds=time.process_time() - start,
                  source_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                  rows=rows)
    path.with_suffix('.json').write_text(json.dumps(result, indent=2) + '\n')
    print({key: value for key, value in result.items() if key != 'rows'})

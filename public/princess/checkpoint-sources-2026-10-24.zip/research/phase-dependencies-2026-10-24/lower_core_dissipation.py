"""Literal last-good/core-age necessary head envelope, not an exact game solver."""
from math import isqrt
import json,hashlib,time
from pathlib import Path

def R(q):return isqrt(q-1)+1 if q else 0
def rho(q):
 r=(isqrt(4*q+1)-1)//2
 return r+(r*(r+1)<q)
def m(z):return (isqrt(8*z+1)-1)//2
def B(x,k):return x+k-1-rho(x+k-1)
def ordinary(k,t):
 p=[(0,0)]
 for _ in range(t):
  x,y=p[-1];p.append((y+k-rho(y+k),x+k-R(x+k)))
 return p

def types(q):
 r=R(q)
 if r<4:return []
 ans=[(0,2*r-2-2*m(r*r-q))]
 if q<=r*(r-1):ans.append((1,2*r-3-2*m(r*(r-1)-q)))
 if q==(r-1)**2+1:ans.append((0,2*r-4))
 return ans

def capacity(b,k,t,feature=(2,2),with_witness=False):
 assert k>=max(13,b+1)
 L=(b-1)**2;fixed=(k-2)**2;P=ordinary(k,t)
 # Binary composition of B on its invariant finite interval.
 maps=[list(map(lambda q:B(q,k),range(fixed+1)))]
 for _ in range(max(0,t.bit_length()-1)):
  a=maps[-1];maps.append([a[a[q]]for q in range(fixed+1)])
 def iterate(q,d):
  j=0
  while d:
   if d&1:q=maps[j][q]
   j+=1;d>>=1
  return q
 best=iterate(0,t);witness=dict(kind='no_good',value=best)
 alltypes=[types(q)for q in range(L+1)]
 c,e=feature
 for u in range(1,t+1):
  delta=t-u;bestq=-1;wt=None
  for q in range(min(L,max(P[u])),9,-1):
   if any(q<=P[u][p]and(delta>=rad+1 or ((p+delta)%2==0 and c<=1)or((p+delta)%2==1 and e<=1))for p,rad in alltypes[q]):
    bestq=q;wt=[(p,rad)for p,rad in alltypes[q]if q<=P[u][p]and(delta>=rad+1 or ((p+delta)%2==0 and c<=1)or((p+delta)%2==1 and e<=1))];break
  if bestq>=0:
   value=iterate(bestq,delta)
   if value>best:best=value;witness=dict(kind='last_good',u=u,delta=delta,q=bestq,types=wt,ordinary=P[u],value=value)
 out=dict(b=b,k=k,t=t,feature=feature,capacity=min(L,best),ordinary=P[-1])
 if with_witness:out['witness']=witness
 return out
if __name__=='__main__':
 start=time.process_time();rows=[capacity(63,64,373,f,True)for f in[(2,2),(2,1),(1,2)]]
 p=Path(__file__);out=dict(status='targeted diagnostic of a uniform necessary formula; not a family result',rows=rows,cpu_seconds=time.process_time()-start,source_sha256=hashlib.sha256(p.read_bytes()).hexdigest())
 p.with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))

"""Finite independent audits of the uniform matching obstruction."""
from pathlib import Path
import hashlib,json
geometric=0;arithmetic=0
for b in range(1,101):
 for phase in (0,1):
  triangle=[(x,y)for x in range(2*b)for y in range(2*b-x)if(x+y)%2==phase]
  assert len(triangle)==(b*b if phase==0 else b*(b+1))
  excluded=[(x,y)for x,y in triangle if y>=x+2]
  assert len(excluded)==b*(b-1)//2
  assert all((2*b-1-x+y)>2*b for x,y in excluded)
  geometric+=1
for b in range(27,2001):
 for d in range(8,b):
  # Largest endpoint duration occurs at the smallest Q and Y.
  tau=(2*b+d-2+d-1)//d
  assert tau*(b+d)<b*(b-1)//2,(b,d,tau)
  arithmetic+=1
p=Path(__file__).parent
names=['upper-short-square-phase-obstruction.md','upper_short_square_phase_check.py']
out={'status':'PASS; uniform proof separate','triangle_phase_cases':geometric,'all_endpoint_arithmetic_cases':arithmetic,'source_sha256':{n:hashlib.sha256((p/n).read_bytes()).hexdigest()for n in names}}
(p/'upper-short-square-phase-check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))

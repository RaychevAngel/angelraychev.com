# Shifted genuine ordinary seeds and arbitrary terminal shapes

24 October 2026. Corollary proposed for independent review, using the
first-quota ordinary boundary theorem and its genuine-origin mixing guard.
This does not replace the genuine orbit by a pair with a similar span.

Let k>=max(13,b+1),0<=c<=k, A=b²-k+1>=1. Let V^c be the ordinary backward
pair from(c,c), and use exactly the convention

    W_j=V_(j+1)^c-(k,k).

Thus W_0=(c-rho(c),c-ceil(sqrt(c))) and W_(j+1)=H_k(W_j).
Let ell>=0 and let D be ANY one-color set satisfying

    |D|<=min V_ell^c.

Start a reversed erosion history from J_0=E(D), with arbitrary quota-k
updates J_(i+1)=E(J_i union I_i). Then

    min(|J_i|,A)<=min(max W_(ell+i),A)                 (1)

for every i>=0, including histories that leave the boundary and return.

## Initialization at the actual shifted orbit time

If max W_ell>=A, (1) is immediate for all later times by monotonicity.
If ell=0, the first-quota theorem directly applies because |D|<=c.
Hence assume ell>=1, max W_ell<A, and put Z=|D|, q=|E(D)|.
Since W_ell>=P_ell, its minimum is at least9, so A>=10; the positive
inverse formulas used below do not encounter the exceptional zero fiber.

Since both V_ell coordinates are at least Z, both W_ell coordinates are
at least Z-ceil(sqrt(Z)). The latter must be smaller than A. Exact integer
inversion gives

    Z<=A+rho(A-1)<=A+b-1<=b²-1.                      (2)

Thus q<=b². The small/co-small square bound applied to the one-shot
erosion E(D) gives q<=Z-rho(Z). Since coordinate0 of W_ell is at least
Z-rho(Z), we have q<A. In particular the actual initial erosion is inside
the physical boundary range; this was not assumed about the shape D.

Tiny q<=9 is below both W coordinates. For a non-tiny
non-good subcritical erosion event, its original one-shot surplus is
Z-q>=ceil(sqrt(q))+1, hence q<=Z-ceil(sqrt(Z)) and is below BOTH W
coordinates. For a critical-root event the same worse-phase bound follows
from q<=H and surplus>=b>=1+rho(q).

At a zero-good initial erosion, its genuine actual corner/cohort has the
exact own or opposite phase profile. Therefore q is below the MATCHING
W_ell coordinate, because |D| is below BOTH V_ell coordinates. The initial
shape need not be a prefix. Its full core is a physical core of E(D).

## Continuation does not require a fictitious earlier physical history

The proof of the ordinary boundary theorem starts at this initial state.
The numerical orbit index is ell. At any later good event its matching
coordinate is W_(ell+i); the uniform mixing inequality is valid at every
genuine orbit time, including this shifted one. Core persistence depends
only on actual future holes. Consequently consecutive different identities
can be handled exactly as before, without reconstructing a physical past
whose counts equal W. Tiny and critical resets remain valid.

This proves (1) while all relevant hole counts remain at most H. For the
clipped assertion, suppose a first violation occurs while the ordinary
maximum is below A. Every preceding actual count must then be below A;
otherwise an earlier violation would already have occurred. Its possible
first overshoot is at most G_k(A-1)=H, by the accepted original-surplus
square profile. The boundary argument therefore applies through that
first crossing, a contradiction. This proves the claimed all-time form.

## A clipped arbitrary-shape solo consequence

Suppose a budget-k solo word takes an arbitrary starting set S through s
unsuccessful inspection-and-movement updates to a terminal D satisfying
|D|<=min V_ell^c. Then

    min(|S|,b²+1)<=max V_(ell+s)^c.                    (3)

For s0 this is immediate from |S|<=min V_ell. For s>=1, exact reversal gives
S subset C_s and |S|<=k+|J_(s-1)|. Apply (1):

    min(|S|,k+A)
      <=k+min(|J_(s-1)|,A)
      <=k+min(max W_(ell+s-1),A)
      <=max V_(ell+s)^c.

The shift is ell+s-1 before adding k, hence the final index ell+s. No
extra inspection day is inserted. The left side may be clipped further
at any smaller cap. This is the exact form needed when last-full temporal
normalization increases the initial signed mass of a late segment.

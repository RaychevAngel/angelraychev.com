# Attaching actual endpoint cores to a critical orientation

24 October 2026. Physical interface lemmas proposed for independent review.
These attach labels to the orientation-cost identity in
`upper-critical-orientation-charge.md`; they do not assert that all its
endpoint hypotheses are automatically met at an optimal clock.

The board is (2b+1) by 2L. A strict-middle survivor has
b²<q<h-b(b+1). If its surplus is b, the sharp classification makes it
a prefix or suffix along the long direction. Call the containing end
its NEAR side and the opposite end its FAR side. Its actual current-color
support contains the WHOLE near physical endpoint row and omits the WHOLE
far current-color endpoint row.

For example, in phase0 the majority contracted fibers U are nonempty
prefixes and every fiber has length at most L-1. The y=0 physical row
of that color uses U, hence is present. The y=2L-1 row uses V, hence
is absent. Longitudinal reflection proves the other phase. Only the
critical survivor itself is used; the next belief need not omit every
far paired-fiber endpoint.

## 1. An earlier hole core forbids the same critical orientation

Follow one fixed cohort. Suppose its actual holes at pre-inspection time
u contain a one-color corner ball of raw radius R at corner C. At later
time v, let S_v be a strict-middle surplus-b survivor, after inspection.
If v-u<=R, its NEAR side cannot be the endpoint side containing C.

Indeed the retained hole core has radius R-(v-u)>=0 and the same current
color as S_v. It contains a current-color cell of the endpoint row through
C: the corner itself in own phase, or the neighboring row cell in the
opposite phase. Every such row cell belongs to S_v if that row is its
near side. This contradicts holes being disjoint from the survivor.
The parity-normalized nonempty opposite core has radius at least1.

Thus a first critical orientation can be forced by an actual early core
without requiring the whole critical set to be a corner triangle. The
elapsed age is v-u; no extra movement or inspection is inserted.

## 2. The late interface needs an allowed-set defect, not false persistence

Suppose the actual pre-inspection belief A_v contains a corner core of
radius R at C, and u<v. Reverse the ACTUAL inspection word after day u,
but regard its initial state as the POST-inspection survivor S_u.
Define allowed sets backwards by

    D_(v-1)=E(A_v),
    D_s=E(I_(s+1) union D_(s+1)),  s=v-2,...,u.

Then S_u subset D_u. The radius-R core in A_v gives the contained core
of radius r=R-(v-u) in D_u when r>=0. This is a core of D_u, NOT a core
of the actual earlier survivor. The probes on day u are not in this
recurrence; S_u is already post-inspection.

Suppose S_u is strict-middle critical, the corner C lies on its FAR side,
and 0<=r<=2b. Set eta=|D_u|-|S_u|. Its whole far current-color endpoint
row is absent from S_u. The retained core contributes exactly

    floor(r/2)+1

current-color vertices on that row, all in D_u. Therefore

    eta>=floor(r/2)+1.                               (1)

The count is valid in both phases: along the row the core contains even
distances0,2,...,r or odd distances1,3,...,r, respectively. The required
parity of r selects the appropriate case. If r>2b, replace the count
by the actual number of current-color row vertices, or retain any
smaller parity-compatible radius at most2b.

In particular, if D_u=S_u, a nonempty retained late core forbids placing
its corner on the far side of this critical orientation. More generally,
an alleged orientation mismatch must supply the explicit unused allowed
capacity in(1). It is invalid to set eta=0 solely from a numerical late
bound or from equality at a different time.

## What is still needed

The early direction uses only actual forward hole persistence. The late
direction has a genuinely different logical interface: reverse allowed
sets may be larger than the actual earlier support. To obtain a new
whole-board bound, a proof must either show the relevant reverse step is
tight, or bound/charge eta using its actual quota and expansion history.
The exact orientation ledger may then charge an unavoidable change of
side between properly attached endpoints. No duplicate charge for the
same unused rooms or nonclean events is authorized by these lemmas.

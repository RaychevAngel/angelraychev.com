# Zero-good persistence pays phase mixing at every large root

24 October 2026. Uniform algebraic proof submitted for independent review.
This supplies the large-root part of the all-zero-good history contract.
Small roots require the separate exact finite arithmetic base; no width or
length cutoff is introduced by this split.

Fix k>=13. Define, on the nonnegative range in use,

    F(x)=x+k-ceil(sqrt(x+k)),
    G(x)=x+k-rho(x+k),
    B(x)=x+k-1-rho(x+k-1)=G(x-1),

and P_0=(0,0), P_(t+1)=(G(P_t[1]),F(P_t[0])). A nonzero-good physical
target with root r and surplus at least r+1 obeys the inverse bound B.
The existing tiny-root reset and critical-root handling are separate from
that assertion; they belong to the physical assembly.

Both F,G are monotone and1-Lipschitz, and satisfy

    F(x)<=G(x)<=F(x)+1,       G(x-1)<=F(x).            (1)

These integer root identities are the same interlacing used by the accepted
ordinary pair proofs. The pair remains in[0,k(k-1)]², where both scalar maps
are inflationary. Monotone iteration from zero and inflationarity therefore
give the GLOBAL interlacing

    min P_(t+1)>=max P_t.                            (2)

## 1. Two bad steps remove one room of phase mismatch

For x>=1,

    B²(x)=G(G(x-1)-1)
          <=G(F(x-1)),
    B²(x)<=F(G(x-1)).                                (3)

The first inequality uses G(z)-1<=F(z) and monotonicity of G. The second
uses G(z-1)<=F(z), with z=G(x-1). Thus B²(x) is bounded by EACH coordinate
of the ordinary two-step map evaluated at equal seed x-1.

Suppose x<=min P_u+e, with integer e>=1. The two ordinary two-step scalar
maps GF and FG are monotone and1-Lipschitz, so(3) gives

    B²(x)<=min P_(u+2)+e-1.                          (4)

If x already lies below min P_u, one bad update preserves this two-phase
domination because B<=F<=G. Induction therefore proves the exact mixing bound

    B^(2e)(x)<=min P_(u+2e).                         (5)

No actual zero-origin assumption is needed for(3)--(5) beyond comparing
to a pair obeying the ordinary update. The origin becomes relevant in
bounding e below. In particular, failure of a bare one-step wedge invariant
does not obstruct this two-step argument.

## 2. An elementary uniform bound for the actual ordinary mismatch

Let u>=1 and let q be an integer with

    min P_u < q <= P_u[p],
    r=ceil(sqrt(q)),     4<=r<=k-2.

Put e=q-min P_u. We claim, for r>=20,

    e<=3r/4.                                         (6)

First, write z=min P_u. From(2), max P_u<=min P_(u+1)<=G(z).
Thus q<=G(z). The exact inverse is

    G(z)>=q  iff  z+k>=q+ceil(sqrt(q)).

Consequently

    e<=k-r.                                          (7)

Second, the accepted elementary phase-span induction gives
|P_u[0]-P_u[1]|<=ceil(u/2), hence e<=ceil(u/2). For clarity: an own-leading
pair produces either an opposite-leading span no larger than the old one,
or an own-leading span at most1; an opposite-leading pair produces an
own-leading span at most old+1. Induction gives the oriented ceil/floor
bounds and the displayed absolute bound.

Let v=k-ceil(sqrt(r²-1+k)). As long as min P_j<r², monotonicity gives

    min P_(j+1)>=F(min P_j)>=min P_j+v.

Since min P_u<q<=r², it follows that u*v<r² when v>0.

If k<=7r/4, (7) immediately gives(6). If k>=ceil(7r/4), the function
k-ceil(sqrt(r²-1+k)) is nondecreasing in the integer k. At k0=ceil(7r/4),
k0<=2r+1 and therefore ceil(sqrt(r²-1+k0))<=r+1. Hence

    v>=3r/4-1>0,
    e<=ceil(u/2)<r²/(2v)+1/2
                     <=r²/(3r/2-2)+1/2<=3r/4.

The last inequality is equivalent to r²-18r+8>=0, valid for r>=20.
This proves(6) for every k, without an asymptotic estimate or parameter scan.

## 3. Every zero-good core with r>=100 survives through the mixing

At a zero-good event with root r, the accepted raw core has one of the
following radii, with m(delta) the largest integer having tri(m)<=delta:

    own, no outlier: R=2r-2-2m(r²-q);
    opposite:       R=2r-3-2m(r(r-1)-q);
    own outlier:    R=2r-4.

For the own case delta<=2r-2. For the opposite case delta<=r-2. Thus
m(delta)<=2sqrt(r) is a safe common bound. All three cases satisfy

    R-1>=2r-4-4sqrt(r).                              (8)

For every r>=100,

    2r-4-4sqrt(r)>=3r/2,

because r/2-4sqrt(r)-4 is already6 at100 and increasing thereafter.
Together with(5),(6), this proves

    B^(R-1)(q)<=min P_(u+R-1).                       (9)

A later zero-good identity change needs at least R actual steps by the
accepted persistence theorem. Therefore the R-1 intervening bad steps
already make BOTH ordinary phases available before the final good update.
The phase can change without any extra reference day. Same-identity good
steps were already controlled in their fixed phase.

This is a uniform analytic proof of the bad-mixing guard for ALL roots
r>=100 and ALL budgets admitting them.

## 4. The remaining base is finite in numerical parameters, not in boards

For4<=r<=99, a nontrivial seed requires min P_u<q<=r². Since u>=1 and
min P_1=k-ceil(sqrt(k)), monotonicity forces

    k-ceil(sqrt(k))<r², hence k<=r²+r<=9900.          (10)

Thus the remaining guard needs only exact arithmetic for13<=k<=9900,
4<=r<=min(99,k-2), all ordinary times before min P reaches the corresponding
small-root cap, both phases, and every integer q between the two ordinary
coordinates in the valid zero-good phase range. One must check the ACTUAL
B-mixing time here; the sufficient2e estimate can be one step loose at tiny
roots. No finite result is inferred in this note until that independent
certificate is supplied and reviewed.

The complete physical necessity theorem still needs its explicit handling
of tiny targets, critical roots, and arbitrary retreat/pronic crossings.
This algebraic result does not silently replace those physical interfaces.

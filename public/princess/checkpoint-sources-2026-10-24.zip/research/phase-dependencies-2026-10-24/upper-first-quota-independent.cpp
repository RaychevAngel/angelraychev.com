// Independent literal-inverse audit of the complete seeded mixing base.
// Every numerical map is built from its defining inequality by an integer
// increasing pointer. No square-root formula or original map code is used.
#include <algorithm>
#include <fstream>
#include <iostream>
#include <vector>
using namespace std;
int main(){
 constexpr int LIM=2000000;
 vector<int> R(LIM+1),rho(LIM+1),tri(LIM+1),own(LIM+1),opp(LIM+1),bad(LIM+1);
 int r=0,s=0,t=0,a=0,b=0,c=0;
 for(int z=0;z<=LIM;z++){
  while(1LL*r*r<z)++r; while(1LL*s*(s+1)<z)++s;
  while(1LL*(t+1)*(t+2)/2<=z)++t;
  R[z]=r;rho[z]=s;tri[z]=t;
 }
 for(int z=0;z<=LIM;z++){
  while(a+1<=LIM && a+1+R[a+1]<=z)++a;
  while(b+1<=LIM && b+2+rho[b+1]<=z)++b;
  while(c+1<=LIM && c+2+R[c+1]<=z)++c;
  own[z]=a;opp[z]=b;bad[z]=c;
 }
 long long seeds=0,orbits=0,times=0,updates=0;int margin=100000;
 cout<<"{\"per_budget\":[";
 for(int k=13;k<=9900;k++){
  const int cap=min(9801,(k-2)*(k-2));long long sk=0,ok=0;
  for(int first=0;first<=k;first++){
   int x=own[opp[first]+k],y=opp[own[first]+k];
   if(min(x,y)>=cap)break;
   ++orbits;++ok;
   while(min(x,y)<cap){
    ++times;
    for(int p=0;p<2;p++){
     int top=p?y:x,bot=p?x:y;
     for(int q=bot+1;q<=min(top,cap);q++){
      int rt=R[q];if(rt<4||rt>99||rt>k-2||q>rt*(rt-p))continue;
      int core=2*rt-2-p-2*tri[rt*(rt-p)-q];
      if(!p && q==(rt-1)*(rt-1)+1)core=min(core,2*rt-4);
      int z=q,xx=x,yy=y,j=0;
      while(z>min(xx,yy)&&j<core){
       if(max({z+k,xx+k,yy+k})>LIM)return 3;
       z=bad[z+k];int nx=own[yy+k],ny=opp[xx+k];xx=nx;yy=ny;++j;++updates;
      }
      if(j>=core){cerr<<"FAIL "<<k<<" "<<first<<" "<<p<<" "<<q<<"\n";return 1;}
      ++seeds;++sk;margin=min(margin,core-1-j);
     }
    }
    int nx=own[y+k],ny=opp[x+k];if(nx<x||ny<y)return 2;x=nx;y=ny;
   }
  }
  if(k>13)cout<<",";cout<<"["<<k<<","<<sk<<","<<ok<<"]";
 }
 cout<<"],\"seeds\":"<<seeds<<",\"orbits\":"<<orbits<<",\"time_states\":"<<times<<",\"bad_steps\":"<<updates<<",\"minimum_margin\":"<<margin<<"}\n";
}

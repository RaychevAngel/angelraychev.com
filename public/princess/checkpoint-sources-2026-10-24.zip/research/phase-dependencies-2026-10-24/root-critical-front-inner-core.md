# A uniform inner core in an oriented critical frontier

24 October 2026. Proposed geometric lemma for independent review. It applies
to the actual full-span frontier in `lower-critical-core-or-frontier.md`;
it does not assert a new capture-time bound.

Let the odd width be 2b+1. In the prefix phase, write a_i for the lengths of
the majority fibers x=2i, 0<=i<=b, and v_i for the intervening minority
fiber lengths. The critical-frontier relations are

    v_i <= a_i,a_(i+1) <= v_i+1.

Thus |a_(i+1)-a_i|<=1. Set m=max(a_0,a_b), and let q be the total number
of selected cells. The endpoint Lipschitz bounds imply

    a_i <= m+min(i,b-i),
    v_i <= m+min(i,b-i-1),            0<=i<b.

Summing both families gives

    q <= (2b+1)m + b(b-1)/2.                       (1)

The sum of the two tent profiles is b(b-1)/2 for either parity of b.
Consequently some actual own-colored board corner has majority length at
least

    m0 = ceil((q-b(b-1)/2)/(2b+1)).                 (2)

At an endpoint of length m, the actual physical support contains every
cell of its color in the corner ball of radius 2m-2. Indeed, at x=2i the
majority length is at least m-i, so its last selected physical row is at
least 2m-2-2i. At x=2i+1, v_i>=a_i-1>=m-i-1, so its last selected row is
at least 2m-3-2i. These are exactly the required diagonal bounds. Empty
rows beyond the radius impose no condition. Reflection handles the other
endpoint and the suffix phase.

Therefore every such frontier contains an actual corner core of radius

    max(0, 2m0-2),                                 (3)

where the maximum only weakens the statement when (2) is <=1; the actual
own corner is present because full-span majority fibers are nonempty.
For q>(b-1)^2 the resulting radius is of order b/2, uniformly in the longer
side. It is weaker than the near-square localized-core radius, but does not
assume that the frontier itself lies in one corner quadrant.

## Potential use and unresolved interface

An old raw core persists under hole erosion independently of inspections.
Thus (3) supplies a real persistence interval when the critical dichotomy
produces a full-span frontier. For small excess d=k-b, the ordinary phase
spread near this cut is at most d. If the accepted bad-step mixing proof
still applies across the critical bin, a radius >=2d+1 would outlast its
two-steps-per-room phase-mixing requirement. This is a proposed interface,
not a proved extension of the ordinary matched-phase theorem: critical
transition and guarded-merger hypotheses must be checked explicitly.

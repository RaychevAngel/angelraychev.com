# Persistent cores at every zero-slack good event

24 October 2026. Physical lemma proposed for independent review. This
extends the accepted sensitive-core restriction to the nonsensitive good
states inside a cheap F plateau. It is not yet a capture-clock theorem.

Let w<=n have even area, b=floor(w/2). At a physical joint update let total
holes Q have r=ceil(sqrt(Q)),4<=r<=b-1, and original total survivor surplus
sigma=r. The accepted zero-good concentration theorem gives a unique
dominant two-step connected component, actual cohort, and actual corner C;
at most one hole is outside that component. Write p=0 for its corner's own
color and p=1 for its opposite color. Put

    m(delta)=max{j>=0:j(j+1)/2<=delta}.

## An explicit full raw core

The dominant component contains the full one-color corner ball B_R(C), with
one of these valid radii:

    no outlier, p=0: R=2r-2-2m(r²-Q);
    no outlier, p=1: R=2r-3-2m(r(r-1)-Q);
    an outlier:     R=2r-4.                              (1)

In the last case necessarily p=0, Q=(r-1)²+1, and the dominant component
is exactly the full own-color triangle of surplus r-1. The one remaining
hole is a distinct corner singleton. These statements concern the original
physical set, not a compressed representative.

**Proof.** The accepted concentration result gives remainder allowance<=1.
If there is an outlier, its allowance is1 and the dominant surplus is r-1.
The bound Q<=(r-1)²+1 and the definition Q>(r-1)² force equality in both
component capacities. Opposite phase would instead give
Q<=(r-1)(r-2)+1<(r-1)², impossible for r>=4. Thus the dominant triangle is
full and has radius2r-4, proving the third line.

Suppose there is no outlier. The component's intrinsic surplus is exactly r:
its cardinality exceeds(r-1)², while its surplus is at most the original r.
Its canonical quadrant is genuine and its occupied diagonal layers are
consecutive. The accepted punctured-layer proof has a full diagonal branch,
because Q>(r-1)²>r(r-1)/2 for r>=4. If h is its first occupied distance
and L its number of occupied distance layers, that proof gives L<=r-h.
The full capacity of those L diagonals is L(h+L), so

    Q<=L(h+L)<=r(r-h).                                  (2)

If p=0 and h>=2, or if p=1 and h>=3, the last bound is at most r(r-2),
which is smaller than(r-1)². Hence h=p. In particular the own origin is
present when p0. The same layer estimate bounds the last occupied distance
by2r-2-p. The exact phase capacity gives Q<=r(r-p).

The quantitative full-layer lemma in
`../uniform-history-2026-10-23/lower-dual-bin-stability.md`, Section1,
therefore applies with L=r-p and defect r(r-p)-Q. Its hypotheses on size
hold: Q>(r-1)² also exceeds(r-1)(r-2) when p1. It gives precisely the
first two radii in(1). All their layer counts belong to the raw set.

## A different good identity cannot appear before the core shrinks

Let u be such an event with radius R from(1), and let v=u+Delta be any
later zero-good event with root4<=s<=b-1. Intermediate events may have any
shape, size, or surplus. Suppose the later dominant identity (actual cohort
and actual corner) differs. Then necessarily

    Delta>=max(1,R).                                   (3)

Indeed each cohort's holes evolve by H_next=E(H union I), so monotonicity
retains B_(R-j)(C) after j updates whenever R-j>=0. If Delta<R, the
remaining radius is at least1. In its current parity this ball contains
at least two cells at distance at most2 from the old corner: two neighbors
in odd parity, or the origin and distance-two cells in even parity.

If the later dominant cohort is different, all these retained old-cohort
holes are outside its dominant component. If the cohort is unchanged but
its corner C' differs, every such cell lies outside the new component:
corner distance is at least w-1>=2b-1, while the new containing radius is
at most2s-2<=2b-4, and

    distance(cell,C')>=2b-1-2=2b-3>2b-4.

Both cases contradict the at-most-one-hole remainder at the later good
event. This proves(3). Polarization is not needed for this identity-change
restriction; if used, it separately fixes the dominant cohort permanently.

## Relation to sensitive persistence

If the later event is sensitive, it has NO outlier. The same reasoning
then excludes even a sole retained old corner cell and can give the stronger
parity-rounded bound from `lower-persistent-sensitive-core.md`. For arbitrary
zero-good targets, one remaining corner singleton can legitimately be the
new outlier, so(3) is the safe uniform statement.

For a nonsensitive opposite-phase event in the lower square half-bin,
defect r(r-1)-Q is at most r-2. Thus its forced core is large even though
the sensitive-only abstraction omitted this event entirely. An arbitrary
F-only block cannot silently relocate all those successive cores.

This supplies a necessary geometric constraint across arbitrary intervening
history. No numerical theorem yet proves that these constraints pay every
reference rewind, and no statement beyond the subcritical good ranges or
new Lean coverage is inferred.

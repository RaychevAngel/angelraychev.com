# All-shape phase incompatibility at sharp short-square boundary contacts

24 October2026. Conditional physical consequence submitted for review.
The early-contact input is `upper-early-last-root-core.md`; the late input
is the independently reviewed `lower-late-last-root-core.md`.
This is not a new uniform capture-time bound.

Consider a square 2b by2b, k=b+d, h=2b², H=b(b-1), L=(b-1)².
A normalized actual history has an early pre-inspection hole time u and
later pre-inspection signed-belief time v. Assume:

* all actual total holes through u are at most H;
* Q=Q_u=max P_u is a UNIQUE ordinary maximum and H-d+1<=Q<=H;
* Y=m_v=max V_t^c is a UNIQUE ordinary late maximum for the actual remaining
  gate-c horizon t, and H+1<=Y<H+d+1;
* k>=100 and k>d²+4d+3.

Here c can be any0<=c<=k. The last strict inequality on Y is important:
it places the late contact below Zcap=L+k=H+d+1.
Polarization fixes the early dominant holes and late small belief in the
same permanently smaller cohort, as in the accepted two-core lemma.
Let Ce and Cl be the actual corners supplied by the two core theorems.

Define

    E=Rstar(b-1)-(2d+2)-floor((Q-L-1+1_{Q=H})/d),
    F=Rstar(b-1)-(2d+1),

where Rstar is the exact minimum raw core radius in the cited sources.
If Ce,Cl have opposite physical checkerboard colors, they are adjacent
corners of this even square. Then the actual elapsed middle duration
Delta=v-u necessarily satisfies

    Delta >= max(0,E+F-2b).                            (1)

This holds for ARBITRARY actual intermediate shapes and inspections.

Indeed the two actual cores have radii at least E-1 and F-1 after rounding
down to their current checkerboard parity. The early core survives in the
later holes with one radius lost per move. The late core lies in the actual
pre-inspection belief, which is disjoint from those holes. Their corner
distance is 2b-1, so the accepted two-core delay gives

    Delta >= (E-1)+(F-1)-(2b-1)+1=E+F-2b.

The exact parity-rounded radii may sharpen(1). There is no deletion allowance
at day v because both sets here are pre-inspection sets.

## A uniform family where the drift-time phase flip is impossible

Suppose in addition

    b>=100,    8<=d,    b>d²+3d+3.                    (2)

Then a history satisfying the above endpoint contacts cannot have opposite
corner colors and at the same time traverse its middle in

    tau=ceil((h-Q-Y)/d)                               (3)

updates. This is a uniform family statement, not a finite-width check.

To verify it, the endpoint intervals imply

    tau <= 2b/d+2.

The elementary triangular-defect bounds give, for b>=5,

    Rstar(b-1) >= 2b-6-4sqrt(b).

For the own term use m(2b-4)<=2sqrt(b); for the opposite term use
m(b-3)<=sqrt(2b); the singleton term is2b-6. Therefore

    E+F-2b >= 2b-15-8sqrt(b)-4d-b/d.

Since(2) implies d<sqrt(b) and d>=8, subtracting the upper bound on tau
leaves strictly more than

    13b/8-12sqrt(b)-17 > 0.

The last expression is positive at b=100 and strictly increasing thereafter.
Thus(1) rules out Delta=tau (and all smaller durations).

## Scope of the conclusion

This upgrades the earlier prefix-endpoint obstruction to actual physical
histories at the stated exact, unique-phase boundary contacts. No normal
form for their supports or middle path is assumed.

It does NOT exclude a history with unused boundary capacity, a tied ordinary
pair, a late endpoint at Zcap, or an earlier departure above the early cap.
Nor does it assert that the drift benchmark is the exact necessary middle
clock in every instance. To turn(1) into a sharper capture lower bound, the
boundary evaluator must preserve these contact/defect conditions and the
actual relative corner colors, allowing other cases separately.

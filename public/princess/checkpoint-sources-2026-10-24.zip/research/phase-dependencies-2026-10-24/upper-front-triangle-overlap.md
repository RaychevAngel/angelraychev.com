# A whole height front cannot avoid a same-end corner triangle cheaply

24 October2026. New geometric lemma proposed for independent review.
This handles the mixed full-front/localized-ancestor case without assigning
a row-prefix shape to a raw localized set.

Use an odd transverse width W+1=2b+1. Let F be a same-color prefix front
toward y=0, with literal virtual fiber cutoffs a_x,0<=x<=W, satisfying
|a_(x+1)-a_x|=1. Empty fibers are allowed, with cutoff s_x-2 where
s_x in{0,1} is their checkerboard starting height. Put q=|F|.
Let T be the same-color corner triangle of radius R at(0,0), with
0<=R<=W-1 and the appropriate current corner parity. Put

    j=R+1, N=W+1, L=W-j, I=|F intersect T|.

For any real D>=0, the following explicit conditions imply I>D:

    D < floor(j²/4)/2,
    q > D + N(1+sqrt(8D+4))/2 + L(L+1)/4.             (1)

Reflecting the short axis gives the same result for the other same-end
corner. The estimate is deliberately conservative. Its point is that
when the front area exceeds the outside-triangle capacity by a fixed
positive multiple of b², the overlap exceeds any O(b) raw area defect
for sufficiently large b.

## Literal fiber proof

Write f_x=a_x+2. Then f_x>=0, |f_(x+1)-f_x|=1, and the fiber cardinality
is (f_x-s_x)/2. Let c=f_j. By the slope bound,

    f_x<=c+|x-j|,       f_x>=c-|x-j|.

For0<=x<=j the triangle virtual height plus2 equals j+1-x; at x=j
this is the empty opposite-parity fiber. Hence the excess of the F fiber
over the triangle fiber is at most max(0,c-1)/2. For x>j the triangle
fiber is empty and the F fiber has at most(c+x-j)/2 cells. Summing gives

    q <= I + N c/2 + L(L+1)/4.                       (2)

Now put z=j-x for0<=z<=j. The F fiber contains at least
max(0,(c-z-1)/2) cells, and the triangle fiber contains at least z/2 cells.
Therefore

    I >= (1/2) sum_(z=0)^j min(z,max(0,c-z-1)).       (3)

This lower bound is monotone in c. If c>=j+1, it gives
I>=floor(j²/4)/2. Under I<=D and the first condition in(1), this is
impossible, so c<j+1. In that case the nonzero summands in(3) are all
contained in0<=z<=c-1, and their sum is floor((c-1)²/4), when c>=1.
Thus I<=D implies

    c <= 1+sqrt(8D+4),

also trivially when c=0. Substitute this in(2), contradicting the second
condition in(1). This proves the claim using literal discrete fibers.

## Physical dependency interface

Suppose a retained actual or reverse-allowed localized zero-good support
misses at most epsilon cells of T, as proved by
`root-localized-erosion-defect.md`. Suppose F is a canonical retained
whole front contained in actual holes, and the localized support is in
an allowed set C with actual source S subset C and eta=|C minus S|.
Then physical disjointness forces

    |F intersect T| <= epsilon+eta.

Taking D=epsilon+eta in(1) therefore excludes that configuration. The
same reasoning applies after exchanging the two roles. No unproved
physical ancestor, age, phase or same-end condition is supplied by this
lemma; those remain explicit prerequisites.

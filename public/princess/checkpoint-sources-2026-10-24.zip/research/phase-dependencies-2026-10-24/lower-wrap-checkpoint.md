# Lower lane wrap-up: accepted progress and exact boundaries

24 October 2026. Research stopped at the user's wrap-up instruction.
No public artifacts or Lean sources were changed in this lane.

## New exact numerical families

1. `lower-full-front-exact-gates.md`: for w=2b+1, n=2ell>=w, k=b+d,
   b>=4d+8 and (2b+1)(ell-b)>2d², every full-origin signed gate c in[0,k]
   has exact physical prefix clock P(c). Hence
   T=P(k)+P(floor(k/2))+1. The formula is an exact recurrence evaluator,
   not a bounded-operation expression. In particular all lengths are
   covered when b>=d². Independent reviews:
   `upper-full-front-exact-review.json`, `root-full-front-exact-review.json`.
   `lower-capped-physical-agreement.md` records the explicit no-jump
   physical/capped interface, including equality at the collar endpoint.

2. `upper-central-span-exact-gates.md` strengthens that range using the
   genuine central two-phase maximum span G. Its sufficient length guard
   is A-b²>2G(d-1)+d, A=h-b²-k. G is defined from the genuine capped
   recurrence, not independently optimized. All lengths are exact if G<=3
   under b>=4d+8. Independent review:
   `lower-central-span-exact-gates-review.json`.

3. The natural-range result `lower-capped-natural-range.md`, supported by
   complete all-c arithmetic bases and independent replay, removes the
   inherited32/200 cutoff: b>=4d+8 is sufficient. Consequently the accepted
   tied-cut minimum-budget theorem covers all odd widths2b+1 with b>=12,
   every even length, k=b+1. Parent's `root-tied-cut-exact-gate.md` and
   `lower-tied-cut-exact-gate-review.json` preserve that route. The separate
   twelve-state symbolic exact-gate argument remains independently checked
   in `lower-minimum-budget-exact-gate-review.json`.

## Accepted physical structure

* `lower-critical-exact-contact-ancestry.md`: exact central contacts have
  an actual full frontier now or one step earlier, with the shifted-start
  exception handled explicitly. Review: `upper-critical-contact-ancestry-review.json`.
* `lower-central-deficit-ledger.md` and `upper-central-deficit-ledger.md`:
  early endpoint deficit, late erosion deficit and allowed-set excess share
  ONE slack budget; central bad-step age and the whole-front ancestor
  criterion are retained. These are the physical inputs to the exact cut.
* `upper-whole-front-overlap.md` and `upper-whole-front-sum-overlap.md`:
  actual same-end fronts have quantitative overlap after erosion; the latter
  retains both cardinalities and the sum of age losses. Independent lower
  receipts are `lower-whole-front-overlap-review.json` and
  `lower-whole-front-sum-overlap-review.json`.
* `lower-even-critical-fronts.md`: for even width2b,b>=4,n>=2b+2, and
  (b-1)^2<q<h-b(b+1) at surplus b, the ACTUAL set is localized, rigid
  triangle-plus-singleton, or a long-axis end-facing pyramid in either
  orientation. Review: `upper-even-critical-fronts-review.json`.
* `lower-even-one-longer-critical.md`: the n=2b+1 case has the same
  alternatives, allowing a pyramid along either axis. Review:
  `upper-even-one-longer-review.json`.
* Small literal failure check of the even classification:
  `lower-even-critical-fronts-audit.json`,33,726,456 subsets and398 qualifying
  events. This is supplemental evidence, not the source of uniformity.

## Remaining obligations

* No global zero-gap claim. The odd common-cut proof retains its explicit
  actual-G length guard and the geometric guard b>=4d+8.
* Removing the short-board collar needs localized raw ancestors and a
  coupled erosion/area-defect argument, or a better genuine-orbit phase-span
  bound. A generic arbitrary interlaced-pair span invariant is false.
* The exact even-square static equality branch is UNREVIEWED progress in
  `lower-even-square-restart.md`; it must not be counted as proved.
* Even after that classification, actual endpoint-phase compatibility
  remains a dynamic obligation. The classification is not a pyramid
  compression theorem and does not itself tighten a numerical capture bound.
* No newly developed result here is claimed as a complete physical-game
  Lean formalization, and no recurrence evaluator is called an O(1) formula.

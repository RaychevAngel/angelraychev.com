# Actual central deficit pays the age of a whole frontier

24 October2026. Physical accounting lemma independently accepted by the lower lane.
Use the accepted capped odd-width continuation under b>=4d+8, k=b+d,
U=h-b(b+1). P is its genuine zero-origin or first-quota reference pair;
the actual hole history remains below U and has its accepted matched-good
invariant. A shifted activation start needs its separately proved initial
invariant, not a fictitious preceding physical history.

Suppose an actual endpoint is dangerous, with

    min P_t < Q_t <= max P_t,     delta=max P_t-Q_t,
    Q_t > b^2+(2delta+1)(d-1).                       (1)

Then the actual history has a critical FULL-SPAN good event at a time
u<=t, whose whole-front erosion of age a=t-u is contained in the current
holes, with

    a<=2delta+1,
    Q_u>=Q_t-a(d-1)>b^2.                             (2)

The source phase of that full front, advanced by a parity changes, is the
unique larger phase of P_t. This is an actual shape/age conclusion; no
canonical shape is assigned to a nongood intermediate state.

## 1. Exact deficit identity along a bad central block

Follow the branch whose phase p_j alternates each day and agrees with a
preceding actual good event. The accepted good/bad induction maintains
Q_j<=P_j[p_j], including all intervening bad steps. Write

    D_j=P_j[p_j]-Q_j.

Whenever the actual target is central, b^2<Q_j<U, its dominating numerical
output also exceeds b^2. The exact inverse of either capped map therefore
puts THAT branch in its affine tail, even if its preceding input was not
assumed to be central. Its increment is d for p_j=0 and d-1 for p_j=1.

Let i_j<=k be the actual useful inspection count and sigma_j the original
sum of the survivor surpluses. The exact hole identity is
Q_j-Q_(j-1)=i_j-sigma_j. If the target is nongood, sigma_j>=b+1. Hence

    D_j-D_(j-1)
      =(k-i_j)+(sigma_j-b-1)+1_{p_j=0}.               (3)

Every summand is nonnegative. In a consecutive block of a such targets,
at least floor(a/2) have own incoming phase, so

    D_end>=D_start+floor(a/2).                        (4)

At a dangerous endpoint the carried branch must be its unique leading
coordinate; otherwise Q_t would be at most min P_t. Thus D_end=delta and
(4) implies a<=2delta+1. Unused inspections and surplus above b+1 can only
shorten this age allowance.

## 2. The whole-front ancestor is forced to occur after the last crossing

Let j be the last actual time at or below b^2 before t. Such a time exists
for a zero-origin or first-quota history, because its initial count is at
most k<b^2. Every subsequent actual target is central. Suppose there were
no good event from j+1 through t. Carry the old matching branch across this
block; if there has not yet been any good event, the established both-phase
initial invariant permits either branch. Equation(4) gives t-j<=2delta+1.
Every bad central move increases the actual count by at most d-1, so

    Q_t<=b^2+(t-j)(d-1)
        <=b^2+(2delta+1)(d-1),

contradicting(1). Therefore at least one good event occurs after j.
Let u be the last. Its count exceeds b^2, so the accepted critical
core-or-frontier theorem excludes the localized and singleton cases:
it is an ACTUAL full-span frontier at its actual longitudinal end.

All a=t-u later targets are bad and central. Apply(4) again and sum their
actual increments to obtain(2). Hole erosion retains E^a of that entire
front. The matching branch from u identifies its actual current phase.

For a shifted-start history whose initial count is already above b^2,
the accepted initialization gives two alternatives. An initial good state
is already a full-span frontier and can serve as u. An initial nongood
state is bounded by BOTH numerical coordinates; the nongood induction
preserves that stronger bound until a good event occurs. It therefore
cannot reach the dangerous endpoint without a good event. If there is
no later crossing of b^2 that first good is central and full-span; if
there is such a crossing, the preceding last-crossing argument applies.
Thus the accepted shifted-start invariant supplies the same conclusion
without inventing a physical prehistory.

## 3. A late reversal shares its deficit with its allowed-set defect

Suppose a reverse word at the relevant source time has S subset C=I union J,
|I|<=k, while the numerical source maximum is M and its erosion reference
maximum is M-k. If |S|=M-delta, put

    delta_J=(M-k)-|J|,        eta=|C minus S|.

Whenever delta_J>=0 (as supplied by capped necessity), the exact inequality

    delta_J+eta
       <=(M-k-|J|)+(k+|J|-|S|)=delta                  (5)

holds. Thus numerical erosion deficit and allowed-set defect consume the
SAME endpoint slack. A full-front age bound should use delta_J, while a
spatial intersection bound uses eta; they may not independently spend the
entire source delta twice.

This is bookkeeping for a genuine reverse set. It neither puts an allowed
front into the actual survivor nor assumes that every reverse initial
activation state already has a prior full-span ancestor.

# The exact boundary contract needed by the even-width transport construction

24 October 2026. Conditional assembly and explicit research target. The
boundary necessity hypotheses below are NOT proved here. This does not
claim a new exact capture-time classification or change the accepted gap8.

Use the already accepted transport families:

* w=2b, b>=200, k=b+1, all n>=2b;
* w=2b, b>=200, k=b+d, 2<=d<=19, n>=2b+2d-2.

Put h=bn and H=b(b-1). Define the genuine ordinary quadrant hole pair
A_0=(0,0) and genuine gate-c pair V_0^c=(c,c), for0<=c<=k, by

    A_(t+1)=(A_t[1]+k-rho(A_t[1]+k),
             A_t[0]+k-ceil(sqrt(A_t[0]+k))),
    V_(t+1)^c=(k+V_t^c[1]-rho(V_t^c[1]),
               k+V_t^c[0]-ceil(sqrt(V_t^c[0]))).

Here rho(x) is the smallest r with x<=r(r+1). Let

    e_ord(Q)=min{t:max A_t>=Q},
    ell_ord(c,Y)=min{t:max V_t^c>=Y},
    J_ord(c)=min_{H-d+1<=Q<=H, H+1<=Y<=H+d+1}
      [e_ord(Q)+ceil((h-Q-Y)/d)+ell_ord(c,Y)].             (1)

All endpoints are integers. This evaluator contains no free phase reset:
each boundary coordinate is attained by an ordinary prefix from its true
initial condition. The maximum is a choice of its initial corner phase.

## Unconditional constructive statement within these families

There is a physical full-color solo strategy reaching residual at most c in

    P_c <= J_ord(c)                                    (2)

complete unsuccessful inspection-and-movement updates. To prove this,
choose a minimizing endpoint pair and an ordinary head attaining Q holes
in e_ord(Q) updates. Choose the better ordinary tail phase attaining the
Y threshold in ell_ord(c,Y) updates. The already proved cut-phase bridge
connects those two ACTUAL phase choices within exactly
ceil((h-Q-Y)/d) updates. It permits both relative tail phases at the same
elapsed time and with no larger residual. There is no extra boundary day.

The first head entrance and possible overshoot are handled by the existing
bridge proof: minimum budget enters its cut exactly; the higher-budget
entrance has residual at least M-d+1 and the bridge plus continuation
finishes at most Y. The tail clocks are genuine quadrant constructions in
the permitted small corner range. Neither an independently selected
unrealized hybrid coordinate nor a formal swap of two numbers is used.

Consequently the explicit full-board upper bound is

    U_ord=min(2J_ord(k)+2, 2J_ord(floor(k/2))+1).         (3)

The first term captures each initial cohort with an ordinary final shot;
the second joins a solo word and its reflected reverse with one common
inspection of the two terminal sets, whose combined size is at most k.

## The precise lower-bound obligation

It would suffice to prove the following same-time boundary conditions,
with all actual-history retreats and first-crossing overshoots included:

1. At the accepted early cut, Q holes after t moves satisfy
   Q<=max A_t. A stronger matching-phase version is welcome but not needed
   by the bridge in these two parameter families.
2. An actual late segment from the accepted residual Y to gate c in s moves
   satisfies Y<=max V_s^c. This is a statement about the signed two-cohort
   residual and arbitrary physical histories, not just a chosen corner set.

Together with the accepted cut ranges and necessary central drift d, these
would give the necessary full-origin gate clock J_ord(c). One must prove
the conditions at the selected cuts; an isolated local shape comparison or
a statement only before a prior excursion does not establish them.

The current capped hybrids prove weaker conditions and can lie above both
ordinary coordinates. They cannot simply be replaced in a lower bound.
For example, accepted variable-cut data k220,b201 gives an ordinary-MAX
hybrid pair(40193,40194) versus ordinary(40191,40193) near the cut.
This is an obstruction to algebraically deleting the extra day, not a
physical strategy counterexample to conditions1 or2.

## If the obligation is proved, the final quota closes the gap exactly

Suppose the necessary gate clocks in(1) are valid. The accepted terminal
intersection bound gives

    L_ord=max(2J_ord(k)+1, 2J_ord(floor(k/2))).          (4)

The endpoint domain is the same for every c. Since the ordinary gate-zero
pair takes one update to(k,k), exactly

    J_ord(0)=J_ord(k)+1.

Monotonicity in c then gives J_ord(floor(k/2)) in{J_ord(k),J_ord(k)+1}.
If it equals J_ord(k), both(3) and(4) equal2J_ord(k)+1.
If it equals J_ord(k)+1, both equal2J_ord(k)+2.
Thus under the stated physical necessity obligations the bounds coincide,
including the final inspection. There is no remaining independent one-day
loss in the transport or final-quota construction.

This identifies what an exact lower proof would buy. It is not a proof of
those physical necessity obligations, nor does it cover short higher-budget
even rectangles or the odd-width phase obstruction.

# Whole-front overlap retaining both areas and the sum of erosion losses

24 October2026. Analytic strengthening of `upper-whole-front-overlap.md`.
Use the same actual same-end, same-current-color front hypotheses. Put
N=2b+1, let q1,q2 be their cardinalities, S=|q1-q2|, and
tri(x)=x(x+1)/2 for real x>=0.

If S<=Nb, their intersection obeys

    I >= (q1+q2)/2 - tri(b) - S^2/(2N^2).             (1)

If S>Nb, one front contains the other, so I=min(q1,q2).
These are real lower bounds for an integer intersection; ceilings may
be taken when useful. No arbitrary shape compression is asserted.

## Proof

The fiber-count difference z_i is integer1-Lipschitz. Suppose its positive
and negative parts have sums P,M and support sizes p,n. If both signs occur,
there is at least one zero, so p+n<=2b. Each sign component of length j
has sum at most tri(j), by its adjacent zero and1-Lipschitzness. Therefore,
after naming the positive part so P-M=S>=0,

    M<=tri(n),          M<=tri(2b-n)-S.

For real n in[0,2b], the first bound increases and the second decreases.
Their equality occurs exactly at n*=b-S/N, because

    tri(2b-n)-tri(n)=N(b-n).

When0<=S<=Nb, it follows that M<=tri(b-S/N). The exact intersection is
min(q1,q2)-M. Substituting min(q1,q2)=(q1+q2-S)/2 and expanding the triangle
expression gives(1). If only one sign occurs, intersection=min(q1,q2),
which also satisfies(1) because tri(b-S/N)>=0. Finally both signs imply
S<=P<=tri(2b)=Nb, proving the stated containment when S>Nb.

## Erosion and localized raw sets

For actual critical full fronts F1,F2 of sizes Q1,Q2 and ages a1,a2, use
the canonical retained fronts K1,K2 from `upper-whole-front-overlap.md`:

    |Ki|>=Qi-N ceil(ai/2).

Apply(1) to their ACTUAL cardinalities. The sum term loses only
N(ceil(a1/2)+ceil(a2/2))/2, so a coupled age budget is retained instead
of paying two independent worst-case ages. The difference term must still
be bounded from the genuine retained areas; it is not legitimate to
replace both areas by their separate lower bounds inside S.

A localized raw zero-good set may instead use its canonical eroded triangle
and original area defect, by `root-localized-erosion-defect.md`. Such a raw
set need not itself be a fiber front. Apply(1) only to the canonical
triangles/fronts, then subtract the localized area defects and any genuine
allowed-set excess eta. This preserves the distinction between actual
support and canonical container.

This lemma does not establish the existence, identities or ages of the
required actual ancestors. Those remain history obligations.

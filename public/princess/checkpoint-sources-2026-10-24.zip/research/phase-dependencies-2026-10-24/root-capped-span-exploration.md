# Capped phase-span exploration

24 October 2026. Diagnostic and failed invariant, not a theorem.

The true capped zero-origin pair has a much smaller span in the tested critical collar than the available bound d. The deliberate parameter diagnostic is in `root-capped-critical-span-diagnostic.json`; tested spans are compatible with a bound of order sqrt(k), and the actual critical-front core exceeds twice the span in every listed case. This is only evidence.

A bare span wedge does not prove such a bound. Even with global interlacing and inputs in the critical scale, the two-step ordinary update can increase a span ceil(sqrt(k)) by one. For k=100, take (x,y)=(2567,2557). Its span is10, it is interlaced, but (G(F(x)),F(G(y))) has span11. This pair has not been shown reachable from zero. Thus any stronger span proof must retain genuine origin/history information, rather than treating every interlaced pair as reachable.

The accepted small-excess critical continuation avoids this unresolved arithmetic issue by using e<=d and an actual geometric core of radius at least2d+2. The independent finite cap-transfer audit closes its small-root arithmetic for b32..199 under b>=4d+8.

# Upper / independent-review research log: phase dependencies

24 October 2026. Private research only. Current accepted whole-domain result
is uniform gap4; exact even transport families are also proved. Earlier gap8
and weaker construction sources remain preserved. No public or Lean claims changed.

## Uniform results and decisive restrictions

* `upper-fold-axis-rigidity.md`: every monotone cardinality-preserving
  neighborhood-subcommuting map on a path looped at one endpoint is identity.
  The same holds for every finite periodic family of such alternating maps.
  Independently accepted by the lower agent; explicit set identities and all
  small maps/pairs were checked. Thus an independent fold-axis compression,
  even alternating with time, cannot create the desired normal form. A coupled
  row/layer compression or a weaker history simulation is still possible.
* `upper-short-square-phase-obstruction.md`: for2b by2b, b>=27 and
  k=b+d,8<=d<=b-1, the prescribed opposite-corner prefix transfer at the
  standard pronic middle time is physically impossible. Every inspection word
  requires at least b(b-1)/2 probes on fixed matching trajectories, whereas
  the available budget is strictly smaller. Independently accepted by the
  lower agent. This rules out the indiscriminate free-middle-phase shortcut,
  not arbitrary optimum histories or transfers begun outside the cut.
* `upper-ordinary-boundary-exact-interface.md`: the existing even-width
  transport families already realize ordinary head + middle + ordinary tail
  without either boundary comparison allowance. If the SAME-TIME genuine
  ordinary boundary clocks were necessary at the actual selected cuts, final
  quota would make lower and upper exactly equal. This conditional assembly
  is independently accepted; neither physical boundary necessity is claimed.

* `upper-zero-good-core-persistence.md`: explicit raw full cores at ALL
  zero-slack good events, including both corner phases and the exceptional
  triangle-plus-singleton mixture. A later different dominant corner/cohort
  cannot occur before the core radius many moves. Independently accepted by
  the lower agent; this supplies the omitted intermediate plateau geometry.

## Failed / unproductive routes kept explicit

* An asymmetric terminal splice inside a fixed solo strategy family gives
  no new clock improvement: before its best solo capture time P, every
  residual at time<=P-2 exceeds k. Thus only balanced2P-1 or complete2P
  concatenation can improve that family's full-game schedule. Actual new
  shapes or mixed histories are needed.
* A moving notch confined to the ordinary downward height-walk family cannot
  freely exchange odd-width strip phase costs: those costs are shape-independent
  within the accepted family. This is an assessment from existing results,
  not a new impossibility theorem for arbitrary shapes.
* The proposed odd-axis compression orthogonal to the fold was already proved
  in the old odd-cylinder exact recurrence. It was not counted as new scope.
* The endpoint-only sensitive switch scalar comparison is false, including
  an unbounded symbolic k divisible4 counterfamily. Intermediate cheap F
  steps are themselves localized zero-good states and their anchors cannot
  be discarded. New persistence of actual old inner holes eliminates those
  particular fake switches; a uniform clock comparison remains to prove.

## Independent reviews completed

* Exact causal overlap ledger and submodularity: `upper-causal-overlap-review.json`.
  Shared inspection quota telescopes to intersection surplus plus fork cells.
  No daily quota reallocation or uncrossing follows automatically.
* Sensitive-switch geometry / exact lens / mass balance:
  `upper-sensitive-switch-review.json`, refreshed after scalar refutation.
* First zero-good initialization and symbolic plateau obstruction:
  `upper-first-good-and-plateau-review.json`.
* Fast-cap phase interlacing: `upper-fast-interlacing-review.json`.
  The multi-step consequence was corrected: the general one-step decreasing
  retreat does not alone dominate arbitrary subsequent growth; source above
  the cap or separate both-phase cap domination is required.
* Global ordinary interlacing: `upper-global-interlacing-review.json`.
  Monotone inflationary swap maps from a tied seed give min(next)>=max(now)
  globally, superseding the fast guard. The physical matching premise is
  still required; this only makes actual retreats free to realign.
* Raw sensitive-core persistence: `upper-persistent-sensitive-core-review.json`.
  Forced inner corner cells erode at speed at most one independent of quota;
  opposite-color sensitive relocation requires at least its core radius+1.

## Next constructive obligation

For short higher-budget even rectangles and odd widths, a correct exact
upper/lower comparison must preserve phase-compatible boundary choices or
charge the actual time/shape cost of relocating a front. The existing
independent head/tail maxima are too permissive. The current productive
lower direction retains every zero-good corner label, its persistent core,
and the time-distributed overlap ledger; an exact prefix normalization is
not assumed. No new final-expression work is being attempted.


## Later accepted consolidation in this pass

* Genuine same-time ordinary early necessity is accepted in
  `lower-ordinary-early-boundary-theorem.md`, with matching zero-good phases.
  Review: `upper-ordinary-early-boundary-review.json`.
* The seeded first-quota extension has a complete independent arithmetic
  replay: `upper-first-quota-independent.cpp/.json`, covering41,944,610
  dangerous seeds. Combined proof review:
  `upper-first-quota-boundary-review.json`.
* `upper-signed-late-ordinary-splice.md` proves ordinary late MAX necessity
  for the actual signed two-cohort history below its explicit cap. Finite-prefix
  polarization and last-full normalization preserve terminal quota and time.
  The splice uses actual activation sets, genuine seeded continuation and
  explicit clipping, with no free phase choice. Independently accepted by
  lower/root and reviewed by comparison.
* `upper-exact-even-transport-families.md` makes the former conditional
  interface exact: for b>=32, even width2b, all lengths at k=b+1, and
  k=b+d with2<=d<=b-1 and n>=2b+2d-2, exact value is
  J(k)+J(floor(k/2))+1 with the stated ordinary evaluators and physical
  phase-changing bridge. Lower independently accepted; no O(1) or Lean claim.
* `root-uniform-four.md` assembles global gap4 across all rectangle parameters.
  Independent assembly review: `upper-uniform-four-review.json`. The old
  finite-width65..399 patch is no longer needed by this stronger assembly.

## Actual middle geometry retained beyond boundary counts

* `upper-critical-orientation-charge.md`: exact strict-middle rank identity,
  with unused quota and00-day costs. Opposite orientations between consecutive
  critical events require a distinct00-day. Root/lower independently accepted.
  This charge is already part of the00 slack and must not be counted twice.
* `upper-critical-endpoint-core-attachment.md`: actual early core forbids a
  critical frontier's wrong near endpoint while it survives. A reverse allowed
  late core forces explicit unused-set defect on the wrong far endpoint; it
  is never silently moved into the actual survivor. Independently accepted.
* `upper-opposite-frontier-charge.md`: proposed stronger uniform physical
  charge Delta*k>=floor(b²/2)+1-floor((b²+2b)/3) for opposite strict-middle
  critical frontiers, via matching trajectories and Lipschitz majority fibers.
  For consecutive critical events the resulting Delta-2 slack replaces the
  earlier unit flip charge. Independently accepted by lower; no boundary-collar assertion.
* `upper-early-last-root-core.md`: proposed actual large core at an exact
  unique-phase early pronic contact. The critical neutral-bin age includes
  the final inverse-rounding exception at Q=H. Independently accepted.
* `upper-short-square-core-compatibility.md`: proposed all-shape consequence
  of the early and late contact cores. At b>=100,8<=d,b>d²+3d+3, opposite
  actual corner colors cannot traverse the standard drift-time middle on
  an even square, provided both contacts are exact and uniquely phased and
  the late contact is strictly below its cap. Independently accepted; ties/slack/cap endpoint remain.

## Additional independent reviews

* `upper-middle-marker-review.json`: exact raw two-core overlap, allowed-set
  defect, and exact late capacity contact marker.
* `upper-late-last-root-review.json`: late unique contact retains an actual
  pre-inspection core of root b-1 with age at most2d+1.
* `upper-core-dissipation-review.json`: last-actual-zero-good head envelope,
  with80 independent full candidate enumerations checking its optimized code.
* `upper-critical-core-or-frontier-review.json`: critical root b classification
  into one actual corner core, the rigid singleton exception, or a genuinely
  full-span oriented frontier. Static classification only.
* `upper-critical-front-inner-core-review.json`: every full-span critical
  frontier still contains a genuine own-corner core of radius of order b/2.
* `upper-localization-flags-review.json`: sound12-threshold necessary operator
  retaining one successor of pronic/subcritical square/critical square
  localization. Independent19,590 top-threshold checks and552 literal ball
  successor checks passed. Targeted numerical improvements are not a new
  uniform capture theorem.


## Capped physical continuation and dual activation (latest)

* `upper-capped-critical-continuation-review.json` independently accepts the
  lower lane's actual side/cohort continuity through Q<U=h-b(b+1). Full-span
  critical frontiers carry a real core; this is the key physical renewal.
* `upper-capped-first-quota-continuation.md` extends that proof to every
  first quota0<=c<=k and to arbitrary actual terminal sets at genuine shifted
  orbit indices. Lower independently accepted the analytic b>=200 source.
* `upper-capped-signed-late-splice.md` uses the exact mixed central barrier
  to extend BOTH-phase mixed comparison to Z=h-b², then reverses the actual
  last-full solo segment. It proves clipped signed MAX necessity up to that
  cap, with no added day and no arbitrary-state prefix assumption. Lower
  independently accepted.
* `upper-capped-seeded-finite-base.cpp/.json/.md` completes the missing
  all-c cap-transfer base for b32..199:160,021,649 dangerous seeds, margin4.
  Lower independently reproduced every parameter row through inverse target
  profiles. Thus both new theorems hold at b>=max(32,4d+8).
* `upper-capped-small-width-base.cpp/.json` checks the additional60 pairs
  b12..31, all c and genuine times:130,966 dangerous seeds, margin0. The
  natural b>=4d+8 geometric extension is awaiting independent guard audit.
* Parent identified a promising exact d1 closure: use a TIED actual central
  head state, then the dual capped MAX theorem contradicts every shorter
  canonical gate horizon via exact two-front adjunction. I independently
  checked the phase/equality mechanism; the assembled theorem remains the
  parent's responsibility and is not silently promoted here.

## Other accepted uniform refinements

* `upper-large-excess-one-middle-review.json` accepts one middle alignment
  for every2b<=k<3b,b>=32 using the genuine late span bound. Combined with
  the existing pronic and high-budget cases, every even width>=64 now has
  gap<=2 for all feasible k; odd widths have gap<=2 when k>=2b.
* `upper-minimum-budget-one-day-review.json` independently replays and
  accepts the symbolic396-entry/22-physical-cost certificate and all six
  arbitrary-band translation stages for the odd minimum-budget one-day
  face comparison. This is a valid comparator, not by itself exact capture.
* `upper-dangerous-early-contact-core.md` and the short-square compatibility
  note are now independently accepted. They preserve actual cores beyond
  exact equality, but have not been used to claim a new uniform time bound.

## Exact minimum-budget closure and full-front intersection

* `upper-capped-natural-range-review.json` accepts the separate natural
  range b>=4d+8 (hence b>=12,k>=13) for every capped early/seeded/signed
  theorem. Lower independently replayed all130,966 extra small-width seeds;
  none of the physical guards needs32.
* `upper-tied-cut-exact-review.json` accepts parent's general tied-cut exact
  gate theorem. At d1 a tied capped head q=b²+1 always exists inside the
  overlap; signed late necessity excludes every shorter canonical gate
  horizon. The final-quota construction then gives exact capture
  T=P(k)+P(floor(k/2))+1. With the natural-range corollary this covers every
  odd width>=25 and every even length. This is an algorithmic exact result,
  not the deferred fixed-operation formula objective.
* `upper-whole-front-overlap.md` is independently accepted by lower. The
  difference of two same-end, same-current-color prefix-front fiber arrays
  is integer1-Lipschitz, yielding the sharp overlap loss tri(b). The family
  remains valid after erosion and clipping. Two original full fronts of
  area>L and ages<=2d have overlap>(d) throughout b>=4d+8, even with an
  explicit allowed-set defect eta<=d. A42,558-sequence/600-literal-front
  audit supports the proof. Actual full-front ancestry/ages remain explicit
  application premises; arbitrary localized raw supports are NOT assumed
  to be prefix fronts.

## Whole-front exact range and raw erosion (24 October)

Independently accepted lower-full-front-exact-gates.md: exact canonical gates and full capture for odd width2b+1, even length2ell, budgetb+d whenever b>=4d+8 and (2b+1)(ell-b)>2d². This includes every length if b>=d². The proof couples the two actual deficits and allowed-set excess at one common cut, forces full-front ancestors, and contradicts whole-front overlap. No new Lean/public claim.

Independently accepted root-localized-erosion-defect.md. A raw zero-good support need not be a fiber prefix, but its diagonal endpoint deficits are preserved under all erosion ages. Its descendants omit at most the original area defect from the canonical eroded triangle. Independent literal audit:2620 supports,26209 erosion states.

## Further accepted scope and proof tools

upper-central-span-exact-gates.md strengthens the exact odd family using its genuine central two-phase spanG; ifA−b²>2G(d−1)+d all gates are exact, andG<=3 suffices at every length throughoutb>=4d+8. Independently accepted by lower.

Independent reviews accepted the all-wall phase-gap variation identity and the even-width critical physical classification for n>=2b+2. These are retained as tools, not a new global exact claim.

## Wrap-up requested

Stopped new research and savedUPPER-CHECKPOINT.md plusupper-checkpoint-manifest.json. Current completed review receipts pass the source-hash audit. The proposed all-parameter comparison closure remains unreviewed/candidate. Finite-b collar conversion, exact-square orientation and mixed-ancestor physical bookkeeping remain explicit obligations.

"""Independent complete cap-transfer base via inversion of target costs."""
from math import isqrt
from functools import lru_cache
from pathlib import Path
import hashlib,json,time

def root(q):
    r=isqrt(q)
    return r+(r*r<q)
def rho(q):
    lo,hi=0,root(q)
    while lo<hi:
        m=(lo+hi)//2
        if m*(m+1)>=q:hi=m
        else:lo=m+1
    return lo

def check(b,d):
    k=b+d;cap=min((b-1)**2,99**2)
    @lru_cache(None)
    def inverse(total,which):
        lo,hi=0,total
        while lo<hi:
            q=(lo+hi+1)//2
            s=min(root(q),b) if which!=1 else min(1+rho(q),b+1)
            cost=q+s+(which==2)
            if cost<=total:lo=q
            else:hi=q-1
        return lo
    pair=[(0,0)]
    def extend():
        x,y=pair[-1];pair.append((inverse(y+k,0),inverse(x+k,1)))
    while min(pair[-1])<cap:extend()
    last=len(pair)-1;count=0;minimum=10**9
    for r in range(4,min(99,b-1)+1):
        for u in range(1,last):
            if min(pair[u])>=r*r:break
            for p in (0,1):
                qlo=max((r-1)**2+1,pair[u][1-p]+1)
                qhi=min(r*(r-p),pair[u][p])
                for q in range(qlo,qhi+1):
                    defect=r*(r-p)-q;m=0
                    while (m+1)*(m+2)//2<=defect:m+=1
                    radius=2*r-2-p-2*m
                    if p==0 and q==(r-1)**2+1:radius=min(radius,2*r-4)
                    x=q;age=0
                    while x>min(pair[u+age]):
                        assert age<radius,(b,d,r,u,p,q)
                        x=inverse(x+k,2);age+=1
                        while u+age>=len(pair):extend()
                    assert age<=radius-1
                    minimum=min(minimum,radius-1-age);count+=1
    return count,minimum if count else None

if __name__=='__main__':
    start=time.process_time();base=Path(__file__).parent
    reference=json.loads((base/'root-capped-small-root-audit.json').read_text())
    expected={(r['b'],r['d']):r['seeds'] for r in reference['rows']}
    total=0;minimum=10**9
    for (b,d),want in expected.items():
        count,margin=check(b,d);assert count==want,(b,d,count,want)
        total+=count
        if margin is not None:minimum=min(minimum,margin)
    assert total==1154597 and minimum==4
    sources=['root-capped-small-root-audit.py','root-capped-small-root-audit.json',Path(__file__).name]
    result={'status':'PASS independently reproduced complete arithmetic base','reviewer':'uniform_lower','parameters':len(expected),'seeds':total,'minimum_margin':minimum,'CPU_seconds':time.process_time()-start,'method':'root-first enumeration and binary inversion of defining target costs; all per-parameter counts compared','sources':{s:hashlib.sha256((base/s).read_bytes()).hexdigest() for s in sources}}
    (base/'lower-capped-small-root-review.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))

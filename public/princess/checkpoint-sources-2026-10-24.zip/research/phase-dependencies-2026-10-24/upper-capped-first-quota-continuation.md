# Capped critical continuation from a genuine first quota

24 October 2026. Physical theorem submitted for independent review. This
extends the accepted zero-origin capped theorem, not its finite base.

Let w=2b+1, n=2ell>=w, h=wn/2, k=b+d, d>=1, and

    b>=max(200,4d+8),       0<=c<=k.

Put L=(b-1)^2, U=h-b(b+1), A=U-d, Z=k+A=U+b. Write
R(x)=ceil(sqrt(x)) and rho(x)=min{r:x<=r(r+1)}. Define

    Gc(x)=max(x+k-rho(x+k),x+d),
    Fc(x)=max(x+k-R(x+k),x+d-1),
    W_0=(c-rho(c),c-R(c)),
    W_(j+1)=(Gc(W_j[1]),Fc(W_j[0])).                 (1)

For a physical hole history after a first inspection quota at most c and
later quotas at most k, if every count through time j is less than U, then

    Q_j<=max W_j.                                    (2)

At each good event, the actual cohort and longitudinal end give the SAME
matching-coordinate inequality as in `lower-capped-critical-continuation.md`.
The good definitions, raw cores, and side/cohort persistence are unchanged.
The all-time clipped version holds at A=U-d, including arbitrary excursions.

## 1. The only changes to the accepted proof are numerical seeds

The first c-shot erosion is in the old small corner regime: c<=k<=5b/4-2,
so its total holes are smaller than L. The proof of
`lower-first-quota-ordinary-boundary.md` therefore gives exactly the initial
invariant: either both coordinates dominate, or the actual state is a
sensitive own-corner component of size W_0[0]=W_0[1]+1, with its origin
present and the matching phase. No arbitrary unequal pair is substituted.

The capped pair is nondecreasing and globally interlaced. Indeed the seed
has span at most one, lies below k, and its first image dominates the seed;
then use monotonicity and the inflationary capped maps. Its oriented span
obeys the same half-frequency bound

    |W_j[0]-W_j[1]|<=ceil((j+1)/2).                  (3)

For completeness, if x>=y, the new own-leading gap Gc(y)-Fc(x)
is at most1, while any opposite-leading gap is at most x-y. If y>x,
the next pair is own-leading with gap at most y-x+1. These inequalities
use only monotonicity,1-Lipschitzness, and Fc<=Gc<=Fc+1; they give the
oriented half-frequency induction from the initial own-leading gap1.

For a dangerous critical good seed q>L, the accepted inverse calculation
is independent of origin:

    q<=max W_j<=Gc(min W_j),  hence q-min W_j<=d.

The actual core radius is at least2d+2, enough to pay every changed identity
through the accepted Bc^2 input-shift contraction.

For a dangerous subcritical seed with r>=100, the seeded genuine-origin
argument gives e<=3r/4+1. The actual raw core satisfies Rcore-1>=2e.
The first-quota source proves this using (3), the drift bound Fc>=F, and
W_j>=P_j. These inequalities all remain valid for the capped pair.

For4<=r<=99, a dangerous capped seed still coincides with its UNCAPPED
first-quota pair. At the first difference of the pairs, the preceding
maximum is at least b^2-d+1>L. Global interlacing puts every subsequent
capped minimum above L, so no later dangerous subcritical seed remains.
The accepted analytic cap-transfer inequality, valid for r<=99,b>=200,
keeps every one of its first Rcore-1 bad iterates below b^2-d+1. Thus Bc=B
through the entire certified mixing suffix. The complete accepted seeded
small-root certificate applies at precisely that genuine seed. There is no
new numerical enumeration in this analytic range.

At the exceptional initial j0 seed the capped functions coincide with the
ordinary functions in all tiny cases. One bad step already mixes the
one-room mismatch, since Gc(q-1)<=min Hc(q,q-1). A changed good identity
at the immediately following step cannot be critical: q<=c<=k and its new
count is at most2k<L. The accepted tiny-origin argument therefore applies
literally. Its old origin is unusable by a differently anchored/cohorted
new subcritical good target and supplies the one missing source room.

These checks justify the SAME physical good-event induction as the
accepted capped theorem. They prove (2) and the matching statement.

## 2. Safe clipping and shifted genuine times

The accepted first-crossing proof at A=U-d is independent of the origin
of the physical word. At the first crossing after an old count<A, the raw
count is at most U+b-1. Surplus below b would force either small size<=L
or co-small size>=U+2b, so the crossing surplus is at least b. Its target
is therefore at most U-1. The initial c-shot state is below A. Hence

    min(Q_j,A)<=min(max W_j,A)                        (4)

for all times, even after an excursion above the collar.

There is also a shifted-start version. Define the late pair

    V_0=(c,c),
    V_(j+1)[0]=max(k+V_j[1]-rho(V_j[1]),V_j[1]+d),
    V_(j+1)[1]=max(k+V_j[0]-R(V_j[0]),V_j[0]+d-1).

Its exact conjugacy is W_j=V_(j+1)-(k,k). Let r>=0, and let D be ANY
actual one-color set with |D|<=min V_r. For reversed erosion J_0=E(D),
J_(i+1)=E(J_i union I_i), |I_i|<=k, the conclusion is

    min(|J_i|,A)<=min(max W_(r+i),A).                 (5)

If max W_r>=A this is tautological for every later time. Otherwise, if
r0, use the actual first-quota theorem. For r>=1, write M=|D|. If
M>=Z=U+b, the capped affine inverse gives both W_r coordinates at least
M-b-1>=A: here d>=1. This contradicts max W_r<A. Hence M<Z.

For q=|E(D)|, its original one-shot surplus is exactly M-q. If q>L and
this surplus were below b, the subcritical separator alternatives would
force q>=U+2b>M; therefore the surplus is at least b and q<=M-b<U.
If q<=L it is already within the collar. Thus initialization is genuinely
inside U, not an unproved arbitrary-shape assumption.

The one-shot target obeys the same capped actual phase profiles as the
forward theorem. A good target is below its matching W_r coordinate; a
nongood target has the additional original surplus and is below BOTH.
Tiny targets are below both because r>=1 and W_r>=P_1. In particular the
initial q is below max W_r<A. The actual core exists in E(D), independently
of its earlier history. All later mixing inequalities apply at the genuine
index r+i, so no fictitious physical prefix is needed. The same first-cut
argument now proves (5).

## Scope

The b>=200 bound here is intentional. The unseeded b32..199 cap-transfer
certificate does NOT cover every first quota c or every shifted seeded
orbit. Extending that finite range requires its own seeded arithmetic
certificate, or an analytic comparison that supplies exactly those cases.
This theorem concerns ordinary proofs only; it does not claim a new
capture formula or Lean formalization.

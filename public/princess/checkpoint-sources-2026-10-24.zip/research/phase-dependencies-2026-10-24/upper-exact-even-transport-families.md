# Exact capture time in the even-width transport families

24 October 2026. Proposed assembled theorem for independent review. It uses
the newly proved ordinary early and signed late necessities, together with
the earlier explicit physical reflection bridge. The old four-day statement
is preserved unchanged. No bounded-operation expression or new Lean claim
is asserted.

Let w=2b and work in either family:

* b>=32, k=b+1, every n>=2b;
* b>=32, k=b+d, 2<=d<=b-1, every n>=2b+2d-2.

Put h=bn and H=b(b-1). Define the genuine ordinary early pair A from(0,0)
and the genuine ordinary gate-c backward pair V^c from(c,c):

    A_(j+1)=(A_j[1]+k-rho(A_j[1]+k),
              A_j[0]+k-ceil(sqrt(A_j[0]+k))),
    V_(j+1)^c=(k+V_j^c[1]-rho(V_j^c[1]),
                k+V_j^c[0]-ceil(sqrt(V_j^c[0]))).

All maps are defined at0 with both roots0. Let

    e(Q)=min{j:max A_j>=Q},
    ell_c(Y)=min{j:max V_j^c>=Y},
    tau(Q,Y)=ceil((h-Q-Y)/d),

and take the finite integer endpoint domain

    H-d+1<=Q<=H,       H+1<=Y<=H+d+1.

The numerator h-Q-Y is strictly positive. For each integer gate0<=c<=k put

    J(c)=min_(Q,Y) [e(Q)+tau(Q,Y)+ell_c(Y)].           (1)

Then, with c=floor(k/2), the EXACT full-board capture time is

    T_k(2b,n)=J(k)+J(c)+1.                           (2)

In particular J(c) is either J(k) or J(k)+1, so(2) determines both the
optimal value and its parity. The recurrence and finite minimum in(1) are
an exact algorithmic answer, not the final fixed-size numerical expression.

## 1. The necessary full-origin gate clock is exactly the displayed minimum

The ordinary early theorem bounds the actual first crossing of
A_cut=b²-k+1=H-d+1, including its overshoot Q<=H, by the genuine head clock
e(Q). The new signed late theorem is valid up to

    min((b-1)²+k,b²+1)=H+d+1,

since d<=b-1 implies k<2b. Apply it to the actual pre-entry late mass Y>H.
The standard final-crossing inverse bound is Y<=H+k-rho(H)=H+d+1.
It supplies ell_c(Y) without a fast-boundary or phase-reset allowance.

For these even-width pronic endpoints, the accepted ordinary necessary
middle frontier has first-hit clock exactly ceil((h-Q-Y)/d). Throughout
this middle passage its effective inverse costs and width cap are b;
the constant-cost branch attains this frontier. The substitutions require
only Q>(b-1)², Y<=b², and Q+Y<h. They hold for b>=32, d<=b-1 and n>=2b.
No b>=200 or fixed-excess restriction remains. The earlier physical merger
and crossing proof is unchanged, including arbitrary retreats.

The gate-preserving normalization corollary in
`upper-signed-late-ordinary-splice.md` applies to ANY finite full-origin
prefix ending at signed gate c. Thus(1) is a necessary gate time for every
full-origin strategy, rather than merely for a selected normalized example.
Retaining stronger earlier necessary bounds is harmless.

## 2. The explicit bridge attains J(c) as a genuine solo gate clock

Fix any endpoints Q,Y and choose an ordinary full-start head attaining
size at most M=h-Q in e(Q) moves. Choose a better-phase ordinary gate-c tail
from Y taking ell_c(Y) moves. The reflection bridge realizes their required
relative phase at no additional middle time.

At d=1, Q=H and the explicit bridge in
`../overnight-uniform-2026-10-24/upper-cut-phase-bridge.md` has t=2b-3.
The first entrance to M is exact. Since M-Y>=2b-2>t, either the bridge or
ordinary continuation, followed by the remaining M-Y-t moves, reaches size
at most Y after exactly tau=M-Y moves, with either desired corner-relative
phase. The bridge geometry requires only b>=4, already satisfied.

At d>=2 use the general bridge of duration t=2b-1. Its construction condition
is automatic: t+2 floor(dt/(2b))>=2b+1. The length assumption yields

    h-2H-d-1>d(t-1),

so tau>=t. An ordinary full-start head first entering size<=M has entrance
q>=M-d+1. Also M-Y>d(t-1) and Y>=H+1>=2d-2 imply q>=dt, so the bridge is
well defined. Transport for t moves, then continue for tau-t ordinary moves.
Each ordinary move decreases size by at least d. Both routes finish with
size at most q-d*t-d*(tau-t)<=M-d*tau<=Y. Their relative corner phases are
opposite at the same elapsed time, so the prescribed tail is available.

The geometric transport theorem itself has no excess<=19 restriction.
That cutoff in the old four-day corollary came solely from its former
boundary necessity theorem. The present argument permits every d<=b-1
in the displayed length range.

Thus a directly specified physical solo history reaches gate c in at most
J(c) moves. Since a solo history with a full untouched partner is itself a
full-origin signed-gate strategy, the necessary bound in Section1 shows
that its optimum is exactly J(c).

## 3. The final shared quota closes the full-board bounds exactly

The genuine ordinary backward pair from seed0 makes its first update(k,k).
Therefore V_(j+1)^0=V_j^k, and the unchanged endpoint domain gives

    J(0)=J(k)+1,       J(k)<=J(c)<=J(k)+1.              (3)

The accepted terminal-intersection and reversed-walk cuts give

    T>=max(2J(k)+1,2J(c)).                            (4)

Two genuine full-board constructions give

    T<=min(2J(k)+2,2J(c)+1).                          (5)

For the first, append a capture inspection to the optimal gate-k solo word
and concatenate the appropriate reversed solo word for the other cohort.
For the second, use the optimal gate-c word and its reflected time reverse,
with one central inspection covering both residual sets; their total size
is at most2c<=k. These are the established physical concatenation/palindrome
constructions, not choices among unrealized phase labels.

If J(c)=J(k), both bounds equal2J(k)+1. If J(c)=J(k)+1, both equal2J(k)+2.
This proves(2). Selecting the corresponding construction gives a direct
optimal inspection rule once the explicit integer recurrences and endpoint
minimum have been evaluated.

## Boundary of the result

This is exact in BOTH displayed unbounded families, including all lengths
at minimum feasible budget. It does not settle short even-width rectangles
at higher excess, odd-width even-area rectangles, or the remaining global
phase compatibility question. The lower and upper sources are ordinary
proofs with an independently replayed finite arithmetic base; this statement
does not increase the project's Lean coverage.

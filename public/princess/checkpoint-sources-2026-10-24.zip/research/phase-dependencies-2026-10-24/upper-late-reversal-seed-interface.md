# Exact late reversal and its nonzero seed obligation

24 October 2026. Algebraic/physical reduction for independent review. This
identifies the interface needed to transfer early corner control to the late
boundary. It does not assume a signed two-cohort gate is a solo terminal set.

## 1. Exact reversal of a solo segment

Let a solo belief evolve for s moves by S_(j+1)=N(S_j minus I_j), with
at most k inspections per move, and suppose S_s is contained in a prescribed
terminal set D of size at most c. Reverse the word and define

    C_0=D,       C_(j+1)=I_(s-1-j) union E(C_j),           (1)

where E(A) consists of the opposite-color vertices whose entire neighborhood
lies in A. Then S_0 is contained in C_s. Conversely C_s is exactly the set
of initial positions guaranteed either to be inspected during the word or
to end inside D. This follows one step at a time: a vertex is allowed if
inspected now, or if all its next positions lie in the next allowed set.
Inspections already in E(C_j) can be removed without changing the union.

Put H_j=E(C_j). Equation(1) becomes

    H_(j+1)=E(H_j union I_(s-1-j)),
    |C_(j+1)|<=k+|H_j|.                                 (2)

Thus the reversed erosion states have EXACTLY the early hole dynamics.
However their initial state is H_0=E(D), not the empty set.

## 2. The genuine ordinary seed is an unequal pair

Write rho(x)=min{r:x<=r(r+1)}, R(x)=ceil(sqrt(x)), and define the ordinary
late pair from V_0^c=(c,c) by

    V_(j+1)^c=(k+V_j^c[1]-rho(V_j^c[1]),
               k+V_j^c[0]-R(V_j^c[0])).

For j>=0 define W_j=V_(j+1)^c-(k,k). Then exactly

    W_0=(c-rho(c), c-R(c)),
    W_(j+1)=(W_j[1]+k-rho(W_j[1]+k),
             W_j[0]+k-R(W_j[0]+k)).                     (3)

This is the ordinary early pair map, but with the indicated UNEQUAL seed,
whose gap is at most one. An equivalent physical description is an empty
hole history with one initial inspection of size c, followed by constant
budget k. The initial one-shot set is D. It need not be a corner prefix.

The unequal pair is not an arbitrary algebraic artifact. If H_0 is a
localized zero-good component of own/opposite phase p, then N(H_0) is
contained in D and its exact phase profile gives

    |H_0|<=c-rho(c) when p0,
    |H_0|<=c-R(c)   when p1.                             (4)

Thus the same-time matching initial coordinate is available at a good
initial erosion event. At a nongood event, the worse-profile inequality,
when its hypotheses apply, controls both coordinates. Small-root exceptions
and mixed components require their stated profile arguments; they may not
be suppressed by replacing W_0 with its larger coordinate twice.

Consequently an early matched-phase theorem that starts from this physically
admissible one-shot seed, tracks every later good core, and handles retreats
would imply a corresponding SOLO late boundary theorem, without the old +1.
The existing empty-origin theorem alone does not yet establish that seed
extension. For c=k it is a one-step shift of the ordinary zero-origin word;
for c=0 it is the empty erosion seed; c=floor(k/2) has a genuinely different
first quota and is essential to the final-quota exactness criterion.

## 3. Why a signed two-cohort terminal gate is not this seed

The actual late quantity is

    m=|S_small|+|S_large|-h=|S_small|-D_large,

where D_large is the number of holes in the larger cohort. A signed terminal
gate m<=c gives only |S_small|<=c+D_large. It does NOT provide a terminal
set of size c for the distinguished cohort, and |S_small| can be much larger
than c. Applying(1) with a fictitious c-room terminal set is invalid.

At a zero-slack late good event, the accepted localization theorem does give
an EXACTLY full partner. From that event forward, however, the partner may
become proper. The old causal late-capacity proof avoided an artificial seed
by following the SAME actual small cohort inside one genuine quadrant for
the entire remaining suffix: its cardinality dominates signed survivor mass,
and the other cohort's nonnegative surplus supplies the comparison. Without
that full-suffix localization, reversal alone does not replace the argument.

The accepted permanently mixed theorem provides a different useful endpoint:
for k<Z<=min(h,(b-1)^2+k), BOTH corner phases from size Z require no more
moves to gate k than a permanently mixed signed history starting at m>=Z.
Its same proof extends to any0<=c<=k: continue the comparison with clipped
actual signed mass; if the reference has size<=k but still exceeds c, its
next update inspects that whole set and becomes0. Whenever the reference
exceeds k the original positive-survivor argument applies unchanged. Thus
the reference is at most c by the actual gate-c time as well.
At such a suffix entrance, this yields the stronger numerical ceiling
Z<=min V_t^c. But it does not automatically provide a physical terminal set
of that size for the preceding solo history. The activation transition and
its shape must still be reconciled.

## Exact remaining alternatives

A sufficient late proof could do either of the following:

* Extend the same-cohort quadrant comparison through all relevant corner
  changes using a late history invariant, retaining the partner's deficit
  as a quantity that pays any extra freedom.
* Prove a valid solo-to-permanently-mixed replacement/uncrossing at the actual
  activation event, preserving each daily quota and the appropriate incoming
  phase. Then combine the solo unequal-seed theorem with the already exact
  mixed suffix comparison.

Neither is supplied by a scalar signed-mass subtraction, by global ordinary
interlacing alone, or by the early hole-core persistence theorem applied to
forward beliefs. Forward beliefs can have their inner cells deleted by
inspections; hole cores persist under erosion, which is a different process.
This note records the precise distinction rather than asserting a false
late symmetry.

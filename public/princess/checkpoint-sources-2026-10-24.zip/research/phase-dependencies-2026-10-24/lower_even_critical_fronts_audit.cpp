#include <algorithm>
#include <bit>
#include <cstdint>
#include <iostream>
#include <vector>
using namespace std;
int main(){
 uint64_t total=0,events=0;
 for(auto [b,n]:vector<pair<int,int>>{{2,6},{2,7},{2,8},{3,8}}){
  int w=2*b,h=b*n; uint32_t N=1u<<h; uint64_t ec=0;
  for(int p=0;p<2;p++){
   vector<pair<int,int>> pts,opp; vector<vector<int>> id(w,vector<int>(n,-1)),oid=id;
   for(int x=0;x<w;x++)for(int y=0;y<n;y++)if((x+y)%2==p){id[x][y]=pts.size();pts.push_back({x,y});}else{oid[x][y]=opp.size();opp.push_back({x,y});}
   vector<uint32_t> adj(h), neigh(N); vector<pair<int,int>> corners{{0,0},{0,n-1},{w-1,0},{w-1,n-1}};
   vector<uint32_t> balls, exceptions;
   for(auto [cx,cy]:corners){int own=(cx+cy)%2==p;uint32_t ball=0,tri=0;for(int i=0;i<h;i++){auto[x,y]=pts[i];int dist=abs(x-cx)+abs(y-cy);if(dist<=2*b-3+own)ball|=1u<<i;if(own&&dist<=2*b-4)tri|=1u<<i;}balls.push_back(ball);if(own)for(auto [dx,dy]:corners)if((dx+dy)%2==p&&(dx!=cx||dy!=cy))exceptions.push_back(tri|(1u<<id[dx][dy]));}
   vector<vector<uint32_t>> pred(2,vector<uint32_t>(h));
   for(int i=0;i<h;i++){auto[x,y]=pts[i];for(auto [dx,dy]:vector<pair<int,int>>{{1,0},{-1,0},{0,1},{0,-1}}){int xx=x+dx,yy=y+dy;if(xx>=0&&xx<w&&yy>=0&&yy<n)adj[i]|=1u<<oid[xx][yy];}for(int side=0;side<2;side++){int yy=y+(side?1:-1);if(yy>=0&&yy<n)for(int xx:{x-1,x+1})if(xx>=0&&xx<w)pred[side][i]|=1u<<id[xx][yy];}}
   for(uint32_t s=1;s<N;s++){
    uint32_t l=s&-s;int i=countr_zero(l);neigh[s]=neigh[s^l]|adj[i];int q=popcount(s);
    if(q<=(b-1)*(b-1)||q>=h-b*(b+1)||popcount(neigh[s])-q!=b)continue;
    ec++;bool okay=false;for(uint32_t ball:balls)if(!(s&~ball))okay=true;for(uint32_t ex:exceptions)if(s==ex)okay=true;
    for(int side=0;side<2&&!okay;side++){bool py=true;for(uint32_t z=s;z;z&=z-1){int v=countr_zero(z);if(pred[side][v]&~s){py=false;break;}}okay=py;}
    if(!okay){cerr<<"FAIL "<<b<<" "<<n<<" "<<p<<" "<<s<<" "<<q<<"\n";return 1;}
   }
   total+=N-1;
  }
  events+=ec;cout<<b<<" "<<n<<" "<<ec<<"\n";
 }
 cout<<"TOTAL "<<total<<" EVENTS "<<events<<"\n";
}

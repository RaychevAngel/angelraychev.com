// Diagnostic only: exact integer attack on the all-zero-good mixing contract.
// No physical strategy enumeration or finite-to-infinite inference.
#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <iostream>
#include <vector>
using I=long long;
I root(I x){if(x<=0)return 0; I r=std::sqrt((long double)x);while(r*r<x)++r;while((r-1)*(r-1)>=x)--r;return r;}
I rho(I x){if(x<=0)return 0;I r=(std::sqrt((long double)(4*x+1))-1)/2;while(r*(r+1)<x)++r;while(r>0&&(r-1)*r>=x)--r;return r;}
I triinv(I x){I m=(std::sqrt((long double)(8*x+1))-1)/2;while((m+1)*(m+2)/2<=x)++m;while(m*(m+1)/2>x)--m;return m;}
I F(I x,I k){return x+k-root(x+k);}
I G(I x,I k){return x+k-rho(x+k);}
I B(I x,I k){return x+k-1-rho(x+k-1);}
int main(int argc,char**argv){
 std::vector<I>ks;for(I k=13;k<=300;++k)ks.push_back(k);
 for(int i=1;i<argc;++i)ks.push_back(std::stoll(argv[i]));
 I total=0,badsteps=0,worstmargin=1000000000,maxmixminus2error=-1000000000;std::array<I,8>worst{};
 for(I k:ks){
  I cap=(k-2)*(k-2);std::vector<std::array<I,2>>P{{0,0}};
  while(std::min(P.back()[0],P.back()[1])<cap){auto p=P.back();auto n=std::array<I,2>{G(p[1],k),F(p[0],k)};P.push_back(n);if(n==p)break;}
  for(I u=1;u<(I)P.size();++u)for(int p=0;p<2;++p){
   for(I q=P[u][1-p]+1;q<=std::min(cap,P[u][p]);++q){
    I r=root(q);if(r<4||r>=k-1||(p&&q>r*(r-1)))continue;
    I core=2*r-2-p-2*triinv(r*(r-p)-q);
    if(p==0&&q==(r-1)*(r-1)+1)core=std::min(core,2*r-4);
    I x=q,m=0;
    while(u+m<(I)P.size()&&x>std::min(P[u+m][0],P[u+m][1])){x=B(x,k);++m;++badsteps;}
    ++total;
    maxmixminus2error=std::max(maxmixminus2error,m-2*(q-P[u][1-p]));
    I margin=core-1-m;
    if(margin<worstmargin){worstmargin=margin;worst={k,u,p,q,r,core,m,x};}
    if(margin<0){std::cout<<"{\"status\":\"FAILED SUFFICIENT ALGEBRAIC CONTRACT; not a physical counterexample\",\"k\":"<<k<<",\"u\":"<<u<<",\"p\":"<<p<<",\"q\":"<<q<<",\"r\":"<<r<<",\"core\":"<<core<<",\"mixing_steps\":"<<m<<",\"checks\":"<<total<<"}\n";return 0;}
   }
  }
 }
 std::cout<<"{\"status\":\"FINITE ALGEBRAIC CHECK PASSED; not a uniform theorem\",\"budgets\":"<<ks.size()<<",\"checks\":"<<total<<",\"bad_steps\":"<<badsteps<<",\"max_mixing_minus_twice_initial_error\":"<<maxmixminus2error<<",\"minimum_margin\":"<<worstmargin<<",\"worst\":[";
 for(int i=0;i<8;++i){if(i)std::cout<<',';std::cout<<worst[i];}std::cout<<"]}\n";
}

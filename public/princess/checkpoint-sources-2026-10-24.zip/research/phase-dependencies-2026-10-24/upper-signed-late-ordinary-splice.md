# Ordinary late necessity through the actual activation point

24 October 2026. Proposed physical theorem for independent review. The
arbitrary-gate version uses the separately reviewed first-quota ordinary
core-mixing theorem and its finite arithmetic base. For c=0,k the already
accepted constant-quota ordinary theorem supplies that algebra directly.

Let w<=n be even-area, b=floor(w/2), h=wn/2, and

    max(13,b+1)<=k<=b^2,       0<=c<=k.

Write L=(b-1)^2, A=b^2-k+1>=1, Dcap=min(L,A), and
Zcap=k+Dcap=min((b-1)^2+k,b^2+1). Consider a last-full normalized history,
with permanently nested cohorts as in the accepted temporal normalization.
At any pre-inspection day s, let m_s be its signed mass. If after t further
unsuccessful inspection-and-movement updates its signed mass is at most c,
then

    min(max(m_s,0),Zcap)<=max V_t^c,                                  (T)

where V_0^c=(c,c) and

    V_(j+1)^c=(k+V_j^c[1]-rho(V_j^c[1]),
               k+V_j^c[0]-ceil(sqrt(V_j^c[0]))).

This permits arbitrary retreats, geometry, and activation time. It is an
ordinary MAX necessary clock, not a claim that both fixed phases can follow
the actual initial shape. The normalization is essential to the statement:
it can be imposed on a full-origin strategy without increasing any daily
quota, but is not an arbitrary-state replacement preserving every earlier
signed mass of an unnormalized history. The displayed CLIPPING allows the
normalized solo mass to exceed Zcap; no hidden initial-size assumption is
made at a cut before activation.

## 0. Normalization also preserves a finite terminal signed gate

The two accepted normalization arguments apply to a finite full-origin
prefix ending at a pre-inspection signed gate, even if that prefix is not a
complete capture word. Alternating polarization maintains a new actual
belief contained in the cardinality-preserving compression of the old one
at EVERY time. Therefore its terminal cardinality, hence signed mass, does
not increase; each daily quota and the number of moves are preserved.

In this nested prefix, choose the LAST pre-inspection time a with the larger
belief full, allowing the terminal time itself in the choice. Replace all
larger-cohort survivors before a by the full cohort. This uses no extra
inspections, leaves the smaller history unchanged, and agrees with the old
nested history from time a onward. In particular the terminal signed gate
is preserved. If a is terminal, the entire prefix is solo; otherwise the
activation day has proper larger survivor and every later survivor is proper.

Thus every full-origin gate-c prefix of length g has a normalized gate-c
prefix of the SAME length g and no larger daily quota. Applying the present
necessary boundary theorem within that normalized prefix gives a universal
necessary full-origin gate clock. It is not necessary, and is not claimed,
that normalization preserve every original intermediate signed mass. This
is the interface needed by the terminal-intersection lower bound.

## 1. The mixed comparison includes the activation inspection

In a normalized history, before activation the larger cohort is completely
full and uninspected. On the activation day its PRE-inspection belief is
still full, but its survivor is proper. Every later survivor is proper.
The smaller survivor is nested inside it and hence proper too.

The accepted proof of `lower-mixed-boundary-domination.md` uses properness
only of these POST-inspection survivors. Therefore its exact comparison
starts already at the activation PRE-state, not one day later. Extended to
gate c by the zero-clipped reference rule, it says: for any starting signed
mass m>=Z, with k<Z<=Zcap<=(b-1)^2+k, each ordinary corner phase from Z reaches gate c
no later than the actual mixed suffix. For Z<=k the same statement follows
by inspecting the reference completely on its next move; if the suffix has
zero moves, the terminal signed gate itself gives Z<=c.

Consequently an r-move mixed suffix starting at signed mass m satisfies

    min(m,Zcap)<=min V_r^c.                          (1)

The statement also applies when the first move is the activation move.

If our day s is already at or after activation, apply(1) to obtain(T)
immediately; m_s<=c is trivial as well. If no activation occurs before the terminal day,
the whole suffix is genuinely solo; Section4 handles that case.

## 2. Reverse only the solo segment, with its real terminal set

Suppose activation occurs a moves after s, with 0<a<t. Let r=t-a>=1
be the number of remaining moves INCLUDING activation. At the activation
PRE-state the smaller cohort is an actual set D, the partner is full,
and the signed mass is exactly |D|. By(1),

    min(|D|,Zcap)<=min V_r^c.                        (2)

If min V_r^c>=Zcap, monotonicity already gives max V_t^c>=Zcap, proving(T).
Otherwise (2) forces

    |D|<=min V_r^c.                                 (3)

The preceding a moves form a real solo word from an initial set S of size
|S|=m_s to D. Reverse that word:

    C_0=D,
    C_(j+1)=I_(a-1-j) union E(C_j),
    H_j=E(C_j).

Then S subset C_a and, for a>=1,

    |S|<=k+|H_(a-1)|.                               (4)

The H states obey the exact early hole dynamics E(H union I). Nothing has
replaced the signed gate by a fictitious small terminal set: D is the real
solo terminal set at the full-to-mixed boundary.

## 3. Initialize and continue the reversed core argument at the genuine time

Define W_j=V_(j+1)^c-(k,k). This is the genuine first-quota-c forward orbit
with W_0=(c-rho(c),c-ceil(sqrt(c))). Its update is the ordinary early swap.
We compare H_j to W_(r+j), so the actual continuation time r is retained.

Put M=|D| and q=|E(D)|. Condition(3) initializes the exact geometric
invariant as follows. If q is below both reference coordinates there is
nothing to prove. Otherwise realize E(D) as the holes produced by the one-shot survivor
V minus D. Its ORIGINAL neighborhood surplus is exactly sigma=M-q, because
the complement of N(V minus D) is E(D). The dual surplus |N(E(D))|-q may
be smaller; it is not equated with M-q. In the subcritical range the original
sigma>=ceil(sqrt(q)), and equality r forces the dual surplus to equal r too.
Thus an original-zero-good own/opposite initial event gives respectively

    q<=M-rho(M)<=W_r[0],
    q<=M-ceil(sqrt(M))<=W_r[1].                      (5)

A nongood event has one additional ORIGINAL surplus and gives the worse
bound q<=M-ceil(sqrt(M)), hence BOTH coordinates. Tiny initial q<=9 is
already below both because r>=1 and min W_r>=k-ceil(sqrt(k))>=9. An initial
critical root b is also below BOTH: integer M<Zcap<=b^2+1 gives M<=b^2,
and sigma>=b implies q<=M-b<=M-ceil(sqrt(M)). Subsequent critical targets
use the usual F-step/reset argument.

The raw core and its identity are actual physical properties of E(D),
independent of how D was obtained. All later H steps are ordinary hole
erosion updates. Therefore the established core-persistence/mixing induction
runs from this initialized time exactly as before: same identities follow
the matching branch; a changed identity cannot arrive until the true B-bad
steps have mixed the discrepancy below BOTH reference coordinates. The
mixing inequalities are valid at every genuine W time, including r+j.

Only clipping is needed. Since Zcap<=b^2+1, any relevant initial M is at
most b^2+1; if min V_r>=Zcap we already stopped. Thus M<Zcap<=b^2+1,
so q<=M<=b^2. If initial q>=Dcap, the ordinary square bound gives
q<=M-rho(M)<=max W_r, so max W_r>=Dcap and all later clipped comparisons are
tautological. Otherwise follow the induction until the first H target >=Dcap.
Its predecessor is <=Dcap-1, so its raw size is at most Dcap-1+k<=b^2. The exact
square inverse gives its size at most

    G_k(Dcap-1)<=G_k(b^2-k)=b(b-1),                     (6)

where Dcap<=A=b^2-k+1 by definition. Thus the entire pre-crossing induction stays
inside the accepted pronic boundary. At the crossing the ordinary maximum
is at least Dcap and remains so. Consequently, at every j>=0,

    min(|H_j|,Dcap)<=min(max W_(r+j),Dcap).                (7)

Combining(4) and(7) at j=a-1,

    min(|S|,Zcap)<=k+min(|H_(a-1)|,Dcap)
         <=k+max W_(r+a-1)=max V_t^c,

which proves(T).

## 4. Entirely solo suffixes and the unequal terminal seed

If no activation occurs, the partner stays full through the terminal day,
so the actual smaller terminal set has size <=c. Reverse the complete solo
word (or use an arbitrary initial subset of size Zcap if the solo set
exceeds Zcap). The initial erosion is obtained from full uncertainty by a first
inspection of size at most c, followed by budget k. The accepted first-quota
ordinary theorem gives its all-time clipped bound, again at Dcap<=b^2-k+1.
Equation(4) and the same V/W identity then prove(T).

For c=k this is an ordinary zero-origin k word shifted by one update; for
c=0 its initial erosion is empty. Those two cases need no new unequal-seed
base. For general c the small initial roots of the first quota must be
handled exactly as in `lower-first-quota-ordinary-boundary.md`; replacing
that seed by its larger coordinate twice would invalidate this argument.

## Scope and use

For k<=2b the theorem covers the entire pronic late starting interval
m<=Zcap=b(b-1)+(k-b)+1. For 2b<k<=b^2 it instead covers m<=b^2+1,
which still contains every older six-root late endpoint at b>=32,k<3b.
Thus the bound serves both the pronic and older large-excess middle regimes.
It is a physical necessity statement on normalized full-origin histories,
with an arbitrary terminal gate c. Its proof does not identify a generic
signed state with a solo set, grant a free phase switch, or assume that
fixed-corner prefixes are optimal on arbitrary larger boards.

An independent audit of the seeded arithmetic theorem and this activation
splice is required before using(T) to strengthen the full-game lower bound.
No new Lean or public classification is asserted.

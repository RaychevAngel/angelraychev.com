# Complete capped first-quota arithmetic base

24 October2026. Complete finite arithmetic certificate; independent replay
requested. This replaces only the b>=200 cap-transfer step in
`upper-capped-first-quota-continuation.md`.

For every b,d with32<=b<=199, d>=1,4d+8<=b, every integer first quota
0<=c<=k=b+d, form the GENUINE capped seeded orbit

    W_0=(c-rho(c),c-R(c)),
    W_(u+1)=(Gc(W_u[1]),Fc(W_u[0])).

The exact C++ certificate `upper-capped-seeded-base.cpp` checks every time
u>=1 before its minimum reaches min((b-1)^2,99^2), every phase p, and every
integer q satisfying

    min W_u<q<=W_u[p],
    4<=r=R(q)<=min(99,b-1),
    q<=r(r-p).

The actual raw core radius is

    K=2r-2-p-2mtri(r(r-p)-q),

with the minimum with2r-4 at the own singleton exception q=(r-1)^2+1.
The checked assertion is exactly

    Bc^(K-1)(q)<=min W_(u+K-1).

The program records the first age when domination occurs. Once below both
coordinates, every subsequent bad step preserves domination. Thus checking
that first age<=K-1 is equivalent to the stated inequality and does not
replace it by an arbitrary seed or empirical width estimate.

The complete receipt contains4,452 parameter pairs,690,942 first-quota
orbits,83,272,718 time states, and160,021,649 dangerous phase/size seeds.
Every check passes; the minimum core-minus-mixing margin is4. Root functions
are precomputed by monotone integer loops, with no floating arithmetic.

Coverage is finite for a proved reason. Both capped maps are inflationary,
and the genuine pair is coordinatewise nondecreasing; after its minimum
reaches the cap, no later dangerous root<=99 and<=b-1 can occur. Initial
u0 is handled analytically by the one-room sensitive seed argument. All
r>=100 are handled by the accepted seeded large-root inequality. All
b>=200 use the accepted analytic cap-transfer comparison. The extension
therefore covers every missing parameter, not selected board instances.

After independent acceptance of this certificate, the conclusions of
`upper-capped-first-quota-continuation.md` and
`upper-capped-signed-late-splice.md` hold under

    b>=max(32,4d+8),        d>=1,

with all their other quantifiers and strict collar/terminal gates unchanged.
No mathematical source or older certificate is overwritten by this base.

# Exact odd-width gates using the genuine central phase span

24 October2026. Separate strengthening of the accepted
`lower-full-front-exact-gates.md`; its sources remain unchanged.

Let w=2b+1, n=2ell>=w, k=b+d, with d>=1 and b>=4d+8. Put

    h=(2b+1)ell, U=h-b(b+1), A=U-d.

Let C be the genuine capped early orbit from zero. At its first time s
with min C_s>b², write D=C_s[0]-C_s[1] and define

    G=max(|D|,|1-D|).

The central affine update sends D to1-D. Thus G is the maximum span
across its two alternating phase states and is constant throughout the
central strip. Global interlacing gives1<=G<=d.

If

    A-b² > 2G(d-1)+d,                              (1)

then every full-origin signed gate c,0<=c<=k, has exact minimum time P(c),
where P(c) is the canonical physical prefix gate clock. In particular

    T_k(w,n)=P(k)+P(floor(k/2))+1.

The orbit condition is evaluated from the genuine parameter-dependent
ordinary/capped recurrence. It is not an O(1)-operation numerical formula,
and G is not an arbitrary independently chosen phase-gap parameter.

## Proof changes relative to the accepted whole-front theorem

Suppose a faster actual gate exists and use the SAME normalized history
and all physical/capped comparison interfaces of the accepted theorem.
At every eligible central cut, failed physical adjunction forces both
actual endpoints to be dangerous. Their combined slack satisfies

    delta_E+delta_L<G,  hence delta_E+delta_J+eta<=G-1.             (2)

The actual early ancestor criterion remains

    D_E=Q-b²-(2delta_E+1)(d-1).

At the initial central time s, positive D_E is at most d. Later it
increases by at most d per step, with arbitrary retreats covered by the
same actual deficit ledger. Set

    B=b²+(2d-1)G-d+1.

Since delta_E<=G-1, the criterion is positive as soon as max C>=B.
Its first crossing at or after s has maximum at most

    max(B+d-1,b²+2d-1) <= b²+(2d-1)G,

including G=1. Condition(1) puts this bound strictly below A, because

    2G(d-1)+d-(2d-1)G=d-G>=0.

Thus the first positive criterion occurs at a real eligible cut with
0<D_E<=d. The corresponding late erosion criterion obeys

    D_E+D_J >=h-k-2b²-2G(d-1)>d.

It follows that D_J>0. Both actual endpoints therefore have full-span
ancestors of ages at most2delta_E+1 and2delta_J+1, each at most2G-1<=2d-1.
Their current phases coincide, so the same-end whole-front overlap is
strictly greater than d, whereas their genuine allowed-set excess is at
most eta<=G-1<=d-1. This is the same contradiction as in the accepted
proof. The canonical gate construction and final-quota identity complete
the conclusion.

If a numerical tie occurs at an eligible cut, physical adjunction and the
two necessary maximum bounds already give the contradiction; the proof
does not try to assign a unique leader to that tied state.

## Explicit consequences

Taking G<=d recovers the accepted sufficient condition
(2b+1)(ell-b)>2d². Retaining the actual G can strictly enlarge that range.
For G<=3 the new condition holds for EVERY length n>=w under the natural
guard b>=4d+8: at the shortest length,

    A-b²=2b+1-d>=7d+17>7d-6>=2G(d-1)+d.

Thus every natural-range board whose genuine central span is at most3 is
exact, without a further length restriction. No claim is made that G<=3
always holds, nor that the remaining larger-span cases are impossible.

"""Complete finite small-root base for the proposed uniform mixing lemma.

All arithmetic is integral. This checks scalar inequalities, not physical
strategies. The analytic argument reduces roots 4..99 to budgets 13..9900.
"""
from math import isqrt
from pathlib import Path
import hashlib, json, time

def root(z): return isqrt(z-1)+1 if z else 0
def rho(z):
    a=(isqrt(4*z+1)-1)//2
    return a+(a*(a+1)<z)
def triinv(z): return (isqrt(8*z+1)-1)//2
def F(x,k): return x+k-root(x+k)
def G(x,k): return x+k-rho(x+k)
def B(x,k): return x+k-1-rho(x+k-1)

def check(k):
    cap=min((k-2)**2,99**2)
    pairs=[(0,0)]
    def extend():
        x,y=pairs[-1]
        pairs.append((G(y,k),F(x,k)))
    while min(pairs[-1])<cap: extend()
    last=len(pairs)-1
    count=0; worst=None; margins=[]
    for u in range(1,last):
        for p in (0,1):
            lo=pairs[u][1-p]+1; hi=min(cap,pairs[u][p])
            for q in range(lo,hi+1):
                r=root(q)
                if not (4<=r<=99 and r<=k-2): continue
                if p and q>r*(r-1): continue
                core=2*r-2-p-2*triinv(r*(r-p)-q)
                if p==0 and q==(r-1)**2+1:
                    core=min(core,2*r-4)
                assert core>=1,(k,u,p,q,core)
                x=q; j=0
                while x>min(pairs[u+j]) and j<core:
                    x=B(x,k); j+=1
                    if u+j>=len(pairs): extend()
                margin=core-1-j
                assert margin>=0,(k,u,p,q,r,core,j,x,pairs[u+j])
                row=dict(k=k,u=u,phase=p,q=q,r=r,core=core,
                         initial_excess=q-pairs[u][1-p],mixing_steps=j,
                         margin=margin)
                if worst is None or margin<worst['margin']: worst=row
                margins.append(margin);count+=1
    return dict(k=k,seeds=count,minimum_margin=min(margins) if margins else None,
                last_relevant_time=last,worst=worst)

if __name__=='__main__':
    start=time.process_time()
    rows=[check(k) for k in range(13,9901)]
    path=Path(__file__)
    result=dict(status='PASS: complete finite base, conditional on the stated analytic reduction',
                budgets=[13,9900],roots=[4,99],budget_count=len(rows),
                seeds=sum(x['seeds'] for x in rows),
                minimum_margin=min(x['minimum_margin'] for x in rows if x['seeds']),
                source_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                CPU_seconds=time.process_time()-start,rows=rows)
    path.with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
    print({k:v for k,v in result.items() if k!='rows'})

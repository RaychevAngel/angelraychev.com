"""Independent finite sanity checks for the uniform loop-path rigidity proof."""
from pathlib import Path
from itertools import product
import json,hashlib

def data(b):
 adj=[]
 for i in range(b):
  a=0
  if i:a|=1<<(i-1)
  if i+1<b:a|=1<<(i+1)
  if i==b-1:a|=1<<i
  adj.append(a)
 N=[0]*(1<<b)
 for s in range(1,1<<b):
  bit=s&-s;N[s]=N[s^bit]|adj[bit.bit_length()-1]
 return adj,N

identities=0
for b in range(2,129):
 # This check uses explicit sets rather than the full subset table.
 adj=[({i-1} if i else set())|({i+1} if i+1<b else {i}) for i in range(b)]
 F=[{0}]
 for j in range(b):F.append(set().union(*(adj[i] for i in F[-1])))
 assert F[b-1]&F[b]=={b-1}
 for j in range(b-2,-1,-1):assert adj[j+1]&F[j]=={j}
 identities+=b

# Enumerate EVERY cardinality-preserving map for b<=3, and test both
# monotonicity and neighborhood subcommutation independently.
counts=[]
periodic_counts=[]
for b in range(1,4):
 adj,N=data(b);V=1<<b
 choices=[[t for t in range(V) if t.bit_count()==s.bit_count()] for s in range(V)]
 passing=[];tested=0;monotone=[]
 for C in product(*choices):
  tested+=1
  if any(C[s]&~C[t] for s in range(V) for t in range(V) if s&~t==0):continue
  monotone.append(C)
  if any(N[C[s]]&~C[N[s]] for s in range(V)):continue
  passing.append(C)
 assert passing==[tuple(range(V))]
 counts.append({'b':b,'all_cardinality_preserving_maps':tested,'strategy_compressions':1})
 pairs=[]
 for C,D in product(monotone,repeat=2):
  if all(not(N[C[s]]&~D[N[s]] or N[D[s]]&~C[N[s]]) for s in range(V)):pairs.append((C,D))
 assert pairs==[(tuple(range(V)),tuple(range(V)))]
 periodic_counts.append({'b':b,'all_monotone_pairs':len(monotone)**2,'alternating_strategy_pairs':1})
p=Path(__file__).parent
out={'status':'PASS independent sanity checks; uniform proof separate','set_identity_checks':identities,'fully_enumerated_small_maps':counts,'fully_enumerated_alternating_pairs':periodic_counts,'source_sha256':{n:hashlib.sha256((p/n).read_bytes()).hexdigest() for n in ['upper-fold-axis-rigidity.md','upper_fold_axis_rigidity_check.py']}}
(p/'upper-fold-axis-rigidity-check.json').write_text(json.dumps(out,indent=2)+'\n');print(out)

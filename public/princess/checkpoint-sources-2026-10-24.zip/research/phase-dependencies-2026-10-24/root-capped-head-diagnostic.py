"""Conditional new cutoff diagnostic, not a uniform exactness proof."""
from pathlib import Path
import importlib.util
import json
import time
import comparison_localization_flags as flags
from comparison_marker_clock import R, rho

P = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('ordinary', P / 'root-ordinary-joint-diagnostic.py')
ordinary = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ordinary)


def heads(w, n, k):
    b = w // 2
    d = k - b
    assert b >= max(32, 4*d + 8)
    h = w*n//2
    U = h - b*(b+1)
    A = U-d
    x, y, t = 0, 0, 0
    rows = []
    while True:
        if max(x, y) >= A:
            faces = {f: min(U-1, max(min(x, y), x if f[0] <= 1 else 0,
                                    y if f[1] <= 1 else 0))
                     for f in flags.F}
            rows.append((t, (x, y), {f:q for f,q in faces.items() if q>=A}))
        if min(x, y) >= U-1:
            break
        x, y = max(y+k-rho(y+k), y+d), max(x+k-R(x+k), x+d-1)
        t += 1
    return A, U-1, rows, None


if __name__ == '__main__':
    start = time.process_time()
    rows = []
    for b, n, d in [(32,66,1),(32,130,1),(40,162,1),(63,128,1),
                     (63,256,1),(209,420,1),(32,66,6),(64,130,14),
                     (100,202,2),(100,202,23),(100,404,23),
                     (200,402,1),(200,402,8),(200,402,48)]:
        w, k = 2*b+1, b+d
        data = heads(w,n,k)
        gates = [flags.evaluate(w,n,k,c,data)['gate_lower'] for c in (k,k//2)]
        L = max(2*gates[0]+1,2*gates[1])
        U = ordinary.upper(w,n,k)
        row = dict(w=w,n=n,k=k,gate_lower=gates,lower=L,upper=U,gap=U-L)
        assert L<=U, row
        rows.append(row)
        print(row, flush=True)
    out = dict(status='conditional head-marker interface diagnostic only',
               CPU_seconds=time.process_time()-start,rows=rows)
    P.joinpath('root-capped-head-diagnostic.json').write_text(json.dumps(out,indent=2)+'\n')

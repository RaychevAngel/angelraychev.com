# No nontrivial strategy compression exists on a loop-ended path

24 October 2026. Uniform obstruction for the proposed folded-axis approach,
submitted for independent review. This does not rule out compressions coupling
several fibers or both nested layers, nor an entirely different normal-form proof.

Let K_b have vertices0,...,b-1, ordinary path edges, and one loop at b-1.
A strategy compression is a map C on vertex subsets satisfying

    S subset T implies C(S) subset C(T),
    |C(S)|=|S|,
    N(C(S)) subset C(N(S)).

**Theorem.** Every such C is the identity. Idempotence is not required.

The case b=1 is immediate. For b>=2, vertex0 is the unique vertex with
one neighbor (a loop counts as a neighbor of its own vertex). Applying the
neighborhood inclusion to {0} shows that C({0}) has at most one neighbor,
since C(N({0})) is a singleton. Thus C({0})={0}.

Two elementary closure properties now apply. If C fixes S, then
N(S) subset C(N(S)); equal cardinalities force C to fix N(S). If it fixes
S and T, monotonicity gives C(S intersect T) subset S intersect T, and equal
cardinalities again force equality. Thus all iterated neighborhoods

    F_j=N^j({0})

are fixed. For0<=j<=b-1, F_j is precisely the spacing-two prefix
{j,j-2,...} in its parity. At the next step,

    F_b = {b-2,b-4,...} union {b-1}.

Consequently F_(b-1) intersect F_b={b-1}, so the loop endpoint is fixed.
For b=2 both singletons are now fixed. For b>=3 descend through
j=b-2,...,0. Once {j+1} is fixed, so is N({j+1}), and

    N({j+1}) intersect F_j = {j}.

This remains true at j=b-2, where the other neighbor is the loop endpoint
itself. Hence every singleton is fixed. Finally monotonicity gives
S subset C(S) for every S by taking the union of its fixed singletons;
cardinality then yields C(S)=S.

## Consequence for folded rectangles

The exact even-axis fold of a rectangle produces K_b square P_n, with
loops on the entire fold boundary. An operator obtained by applying the
SAME factor strategy compression independently in each K_b fiber cannot
simplify any state: its factor must be the identity by the theorem.

This does not say that every strategy compression of the PRODUCT is trivial.
The existing odd-axis compression works orthogonally to the fold and is
unaffected. The existing square diagonal compression couples coordinates
and is likewise outside this obstruction. It also leaves open operators
which couple the two nested cohort layers or use a weaker, history-dependent
simulation instead of one cardinality-preserving set map.

This is a failure shield for a specific proposed normal-form mechanism,
not a claim about exact capture times, the feasibility threshold, or Lean
coverage. It was proved directly from the three operator axioms; no finite
experiment substitutes for the uniform proof.

## Alternating or periodic factor compressions do not evade the obstruction

The same conclusion holds for a finite periodic family C_t satisfying

    N(C_t(S)) subset C_(t+1)(N(S)),

with indices taken modulo the period, provided every C_t is monotone and
cardinality-preserving. The unique degree-one test fixes {0} in EVERY
C_t. If a set is fixed by every C_t, the neighborhood inclusion fixes its
neighborhood in every C_t, because the time shift permutes the family.
Intersections are again fixed in every member. The preceding proof now
applies verbatim to the common fixed sets. In particular, a two-phase
compression alternating with the princess's color cannot create a
nontrivial independent fold-axis normal form.

This extension still does not exclude nonperiodic, history-dependent
state simulations or compressions coupling fibers/layers.

# Signed late necessity across the odd critical collar

24 October2026. Physical theorem submitted for independent review. It uses
`upper-capped-first-quota-continuation.md`, including its genuine shifted
seed statement; the scope below remains its analytic parameter range.

Let w=2b+1, n=2ell>=w, h=wn/2, k=b+d, and

    b>=max(200,4d+8),       d>=1,       0<=c<=k.

Put L=(b-1)^2, H=b(b-1), U=h-b(b+1), A=U-d, and

    Z=k+A=U+b=h-b^2.

Define the capped backward pair

    V_0=(c,c),
    V_(t+1)[0]=max(k+V_t[1]-rho(V_t[1]),V_t[1]+d),
    V_(t+1)[1]=max(k+V_t[0]-ceil(sqrt(V_t[0])),V_t[0]+d-1).

For ANY last-full normalized actual history, if signed mass m_s reaches
at most c after t further unsuccessful updates, then

    min(max(m_s,0),Z)<=max V_t.                      (T)

The normalized history may be obtained from an arbitrary full-origin
finite gate-c prefix without increasing its length or quotas, as already
proved in `upper-signed-late-ordinary-splice.md`, Section0. Intermediate
masses need not be preserved by normalization; statement(T) applies to
the actual normalized history used in the necessary clock.

## 1. The mixed suffix dominates both capped phases

Use the two numerical residual maps, with zero output for x<=k:

    phi_0(x)=u+min(ceil(sqrt(u)),b),   u=x-k>0,
    phi_1(x)=u+min(1+rho(u),b+1).                      (1)

Their inverse thresholds are exactly the two maps defining V. Indeed each
minimum profile is the minimum of its quadrant cost and a constant cost;
the admissible threshold is therefore the maximum of the two inverse
thresholds. This remains valid at output0, where both inverses equal k.

Consider an actual permanently mixed suffix, including its activation
inspection: both POST-inspection survivors are proper. Start either
reference phase with any 0<=x_s<=min(max(m_s,0),Z). Maintain

    x_j<=max(m_j,0).                                  (2)

If x_j<=k, its next value is zero and (2) is immediate. Otherwise let
u=x_j-k>0. The actual signed survivor mass q satisfies q>=m_j-k>=u.
The reference next value x' satisfies

    x'<=x_j-k+b+1<=Z-d+1=U+b-d+1<=Z.

If q>=x', nonnegative total surplus proves (2). Otherwise

    0<q<x'<=U+b-d+1<h-H-2=U+2b-2.                    (3)

For q>=L, the accepted strict mixed central barrier gives total original
surplus sigma>=b+1, which dominates BOTH reference costs in(1). For q<L,
u<=q and the accepted mixed small-boundary profile dominates both ordinary
quadrant costs, hence also both capped costs. Thus in either case

    m_(j+1)=q+sigma>=u+cost_p(u)=x'.

The proof allows arbitrary actual retreats and overshoots: only the
nontrivial case q<x' needs the profile, and (3) then forces q into its
proved range. It uses properness after inspection, so the very first
activation inspection is included. Consequently an r-move mixed suffix
ending at gate c satisfies

    min(max(m_s,0),Z)<=min V_r.                       (4)

The comparison uses numerical reference maps with exact inverse thresholds;
no claim that their capped continuation is an optimal physical prefix is
needed for this necessary inequality.

## 2. The actual last-full activation supplies the terminal set

If day s is already in the permanently mixed suffix, (4) proves(T).
Otherwise let activation occur a moves after s, with r=t-a>=1 moves from
its PRE-state through the gate. At activation the partner is full and the
smaller set is an actual one-color set D, so its signed mass is |D|.
Equation(4) gives

    min(|D|,Z)<=min V_r.

If min V_r>=Z, monotonicity of V proves(T) directly. Otherwise

    |D|<=min V_r<Z.                                   (5)

The preceding a moves are a genuine solo word from S to D. Reversing that
word gives C_0=D, C_(i+1)=I_(a-1-i) union E(C_i), and J_i=E(C_i).
The initial actual set satisfies S subset C_a, hence

    |S|<=k+|J_(a-1)|.                                (6)

The genuine shifted capped theorem, initialized by(5), yields

    min(|J_i|,A)<=min(max W_(r+i),A),
    W_j=V_(j+1)-(k,k).                               (7)

Combining(6) and(7) at i=a-1 proves

    min(|S|,Z)<=k+max W_(r+a-1)=max V_t.

This is(T), since the normalized source before activation is solo and its
signed mass is |S|. Normalization may have increased that source mass; the
left side remains clipped at Z throughout the argument.

If no activation occurs before the terminal day, the entire suffix is solo
and its actual terminal set has size at most c. Apply the first-quota
version of the same reversal, rather than a shifted activation set. The
same identity W_(t-1)+k=V_t gives(T). A zero-move suffix is immediate.

## 3. What the extension establishes

The old ordinary signed theorem stopped at min((b-1)^2+k,b^2+1).
The present cap is Z=h-b^2; on the shortest odd-by-even board this is
b^2+3b+1. It grows with the long side. The reversed safe hole cut A=U-d
lies beyond h/2, and its first crossing stays strictly below U.

This theorem retains the genuine first quota, actual activation set,
remaining mixed time, and numerical phase labels. It does not identify
an arbitrary signed state with a small solo set, add an uncharged phase
reset, or extend the physical core classification through the co-small
endpoint U. The capped pair supplies a necessary MAX clock. A phase-matched
meeting or exact capture theorem requires a separate endpoint/overlap
argument. No new Lean or public release claim is made.

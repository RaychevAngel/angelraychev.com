"""Independent literal quadrant erosion vs retained raw diagonal intervals."""
from pathlib import Path
import hashlib,json,random,time
D=Path(__file__).parent

def erosion(S):
    if not S:return set()
    M=max(x+y for x,y in S)
    ans=set()
    for x in range(M+2):
        for y in range(M+2-x):
            N={(a,b) for a,b in ((x-1,y),(x+1,y),(x,y-1),(x,y+1)) if a>=0 and b>=0}
            if N<=S:ans.add((x,y))
    return ans

def audit(R,rows):
    S={(x,l-x) for l,a,g in rows for x in range(a,l-g+1)}
    delta=sum(a+g for l,a,g in rows)
    cur=S
    for t in range(R+1):
        pred={(x,l-t-x) for l,a,g in rows if l>=t for x in range(a,l-g-t+1)}
        assert cur==pred,(R,rows,t,cur^pred)
        ball={(x,j-x) for j in range((R-t)%2,R-t+1,2) for x in range(j+1)}
        assert len(ball-cur)<=delta
        cur=erosion(cur)
    return R+1

def generate(R,maxdef):
    layers=list(range(R%2,R+1,2))
    def go(j,pa,pg,defect,out):
        if j==len(layers):
            yield out;return
        l=layers[j]
        for a in range(l+1):
            if j and not ((a==0 and pa==0) or (a>0 and a>=pa+1)):continue
            for g in range(l-a+1):
                if j and not ((g==0 and pg==0) or(g>0 and g>=pg+1)):continue
                if defect+a+g<=maxdef:yield from go(j+1,a,g,defect+a+g,out+[(l,a,g)])
    return go(0,0,0,0,[])

start=time.process_time();cases=steps=0;counts=[]
for r in range(2,8):
    for p in (0,1):
        R=2*r-2-p
        full=r*(r-p);previous=(r-1)*(r-1-p)
        n=0
        for rows in generate(R,full-previous-1):
            steps+=audit(R,rows);n+=1;cases+=1
        counts.append({'r':r,'parity':p,'cases':n})
# General interval hypotheses, including defects beyond the near-extremal bin.
for R in range(1,8):
    for rows in generate(R,100):
        steps+=audit(R,rows);cases+=1
payload={'status':'PASS','cases':cases,'erosion_states':steps,'near_extremal_counts':counts,'cpu_seconds':time.process_time()-start,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'proof_sha256':hashlib.sha256((D/'root-localized-erosion-defect.md').read_bytes()).hexdigest()}
(D/'upper-localized-erosion-check.json').write_text(json.dumps(payload,indent=2)+'\n')
print(json.dumps(payload))

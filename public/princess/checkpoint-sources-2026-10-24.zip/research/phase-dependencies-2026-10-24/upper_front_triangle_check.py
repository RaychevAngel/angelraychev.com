from pathlib import Path
import random,json,hashlib
p=Path(__file__).parent;rng=random.Random(2401024);cases=0
for b in range(2,22):
 W=2*b
 for _ in range(80):
  phase=rng.randrange(2);a=[2*rng.randrange(2*b+2)+phase-2]
  for x in range(1,W+1):
   s=(phase-x)%2
   a.append(rng.choice([y for y in (a[-1]-1,a[-1]+1) if y>=s-2]))
  ns=[(a[x]+2-(phase-x)%2)//2 for x in range(W+1)]
  for R in range(phase,W,2):
   j=R+1;L=W-j;c=a[j]+2
   nt=[max(0,(R-x+2-(phase-x)%2)//2) for x in range(W+1)]
   I=sum(min(x,y) for x,y in zip(ns,nt));q=sum(ns)
   assert 4*q<=4*I+2*(W+1)*c+L*(L+1)
   tent=sum(min(z,max(0,c-z-1)) for z in range(j+1))
   assert 2*I>=tent
   if c>=j+1:assert 2*I>=j*j//4
   elif c>=1:assert 2*I>=(c-1)**2//4
   cases+=1
f=p/'upper-front-triangle-overlap.md'
out={'status':'PASS','literal_front_triangle_cases':cases,'source_sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'audit_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(p/'upper-front-triangle-check.json').write_text(json.dumps(out,indent=2)+'\n');print(out)

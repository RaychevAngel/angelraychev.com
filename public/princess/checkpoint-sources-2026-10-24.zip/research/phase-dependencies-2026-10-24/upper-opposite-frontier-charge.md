# A quadratic inspection charge between opposite critical frontiers

24 October 2026. Ordinary physical inequality, proposed for independent review.
No new capture-time theorem is inferred.

On a (2b+1) by 2L rectangle let h=(2b+1)L and k be the constant inspection
budget. Let R_u and R_v be post-inspection survivor supports of the SAME
cohort, at times u<v. Both have surplus b and satisfy the sharp collar

    b² < |R_t| < h-b(b+1),              t=u,v.

Suppose their sharp critical-frontier orientations are opposite. Put

    C_b = max(0, floor(b²/2)+1-floor((b²+2b)/3)).

Then

    (v-u) k >= C_b.                                      (1)

The elapsed time is odd, because the orientation of a critical frontier
is fixed by its current physical color. Thus it is at least the smallest
positive odd integer not less than ceil(C_b/k).

## 1. Matching transport counts actual inspections

Use the vertical perfect matching (x,2j)<->(x,2j+1), denoted f. For every
post-inspection survivor R_s,

    f(R_s) minus I_(s+1) is contained in R_(s+1).

Iterating gives

    |f^(v-u)(R_u) minus R_v| <= sum_(s=u+1)^v |I_s| <= (v-u)k.       (2)

No shape, surplus, or size condition is imposed on intermediate supports.
In the contracted coordinates (x,j), f is the identity. Thus (2) compares
the two endpoint supports in the same array, without changing their fiber
lengths.

## 2. Endpoint lengths force a large set difference

Reflect longitudinally if needed so the old critical support is a prefix
and the new one a suffix. On majority fibers x=2i, 0<=i<=b, let their
lengths be l_i and m_i. Define z_i=L-m_i, the prefix length complementary
to the new suffix. The sharp critical classification gives

    |l_(i+1)-l_i| <= 1,   |z_(i+1)-z_i| <= 1.

Every old minority-fiber length is bounded by each neighboring majority
length. Every complement minority length is bounded by each neighboring
z_i plus one. Hence

    |R_u| <= 2 sum l_i,
    h-|R_v| <= 2 sum z_i + b.

The strict collar therefore gives the two integer bounds

    sum l_i >= floor(b²/2)+1,
    sum z_i >= floor(b²/2)+1.                            (3)

The endpoint set difference on majority fibers alone has size

    sum_i min(l_i,z_i).                                 (4)

Let m=b+1 and a_i=l_i-z_i. This sequence is 2-Lipschitz. With its mean
abar, convexity of absolute value and the pairwise distance bound give

    sum_i |a_i-abar|
      <= (1/m) sum_(i,j) |a_i-a_j|
      <= (2/m) sum_(i,j) |i-j|
       = 2(m²-1)/3.

Consequently

    sum |a_i| <= |sum a_i| + 2(m²-1)/3,
    sum min(l_i,z_i)
      >= min(sum l_i,sum z_i) - (m²-1)/3
      >= floor(b²/2)+1 - (b²+2b)/3.

The integer lower bound is exactly C_b. Together with (2), this proves(1).
The coefficient is deliberately conservative; no extremal optimization or
unproved rearrangement inequality is used.

## 3. Stronger use inside a strict-middle orientation ledger

If u and v are CONSECUTIVE surplus-b events in a history whose every
intermediate survivor stays strictly middle, then all intermediate labels
z are zero. A gap Delta=v-u>=3 contributes exactly Delta-2 distinct 00
label transitions. The accepted orientation ledger therefore charges at
least

    max(1, smallest_odd_integer_at_least(ceil(C_b/k))-2)

rank-slack units to this orientation change. This REPLACES the earlier
one-unit charge for that gap; it is not added a second time to the same
00 transitions. Different consecutive-event gaps use disjoint 00 days.

This shows that a sharp-middle orientation flip cannot be obtained with
only a bounded number of noncritical days as b grows and k is of order b.
It does not prevent a history from leaving the sharp collar and relocating
inside a boundary region. That remaining transition is a separate issue.

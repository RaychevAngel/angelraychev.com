"""Falsification prototype: forward time caps in a backward 12-state model.

All outputs remain conditional until the time-pruning assembly is reviewed.
Absent target states are removed explicitly, not represented as zero rank.
"""
from pathlib import Path
import json
import time
import comparison_localization_flags as loc
from comparison_marker_clock import R, rho

F = loc.F


def step(w,n,k,B,flags):
    b=w//2;h=w*n//2
    caps={(i,u,j,v):loc.m.band.survivor(w,n,T,i,u,j,v)
          for (j,v),T in B.items() for i in range(v+1) for u in range(j+1)}
    for key,q in list(caps.items()):
        i,u,j,v=key;T=B[j,v]
        r=R(T)
        if i==0 and j==1 and 2<=r<=b and (r-1)*(r-2)<q<=r*(r-1) and T-q==r:
            if v!=0 or T>flags.get('P',-1):caps[key]=q-1
        r=rho(T)
        if i==1 and j==0 and v==1 and 2<=r<=b and T-q==r:
            trigger=((r-1)**2<q<=r*r) if r<b else r*(r-1)<q<=r*r
            if trigger and T>flags.get('S' if r<b else 'C',-1):caps[key]=q-1
    def bound(f,pred=lambda j,v:True):
        cc,e=f
        vals=[caps[i,u,j,v] for i,u,j,v,cost in loc.er.OPTIONS[f]
              if cost<=k and pred(j,v) and (i,u,j,v) in caps]
        return min(h-4+cc+e,k+max(vals)) if vals else -1
    out={f:bound(f) for f in F}
    out={f:x for f,x in out.items() if x>=0}
    following={'P':bound((1,0),lambda j,v:j==0 and v<=1),
               'S':bound((0,1),lambda j,v:j<=1 and v==0),
               'C':bound((0,1),lambda j,v:v==0)}
    return out,{z:x for z,x in following.items() if x>=0}


def test(w,n,k,c,T):
    b=w//2;d=k-b;h=w*n//2;A=h-b*(b+1)-d
    assert w%2 and not n%2 and b>=max(32,4*d+8)
    P=[(0,0)]
    for t in range(T):
        x,y=P[-1]
        P.append((max(y+k-rho(y+k),y+d),max(x+k-R(x+k),x+d-1)))
    B={f:min(c,h-4+sum(f)) for f in F}
    flags={z:min(c,h-3) for z in ('P','S','C')}
    V=(c,c);trace=[];cap=min((b-1)**2+k,b*b+1)
    for r in range(T+1):
        t=T-r
        if max(V)<cap:
            ceilings={f:max(V)-int(max(V)-k>=10 and ((V[0]>V[1] and f[0]==0) or (V[1]>V[0] and f[1]==0))) for f in F}
            B={f:min(x,ceilings[f]) for f,x in B.items()}
            flags={z:min(x,ceilings[(1,0) if z=='P' else (0,1)]) for z,x in flags.items()}
        removed=[]
        if max(P[t])<A:
            x,y=P[t]
            H={f:max(min(x,y),x if f[0]<=1 else 0,y if f[1]<=1 else 0) for f in F}
            removed=[f for f,x in B.items() if x<h-H[f] or H[f]<4-sum(f)]
            B={f:x for f,x in B.items() if f not in removed}
            flags={z:x for z,x in flags.items() if x>=h-H[(1,0) if z=='P' else (0,1)]}
        if removed:trace.append(dict(day=t,remaining=r,removed=removed,B=list(B.items()),flags=flags))
        if not B:
            return dict(T=T,feasible=False,failed_day=t,prunings=trace)
        if r<T:
            B,flags=step(w,n,k,B,flags)
            V=loc.m.late_step(V,k)
    return dict(T=T,feasible=B.get((2,2),-1)>=h,prunings=trace)


if __name__=='__main__':
    start=time.process_time();rows=[]
    for w,n,k,g in [(65,66,33,614),(81,162,41,7282),(127,128,64,1374),(201,202,102,1514)]:
        for c in (k,k//2):
            out=test(w,n,k,c,g)
            row=dict(w=w,n=n,k=k,c=c,**out);rows.append(row)
            print(w,n,k,c,g,out['feasible'],out.get('failed_day'),len(out['prunings']),flush=True)
    Path(__file__).with_suffix('.json').write_text(json.dumps(dict(status='conditional diagnostic',CPU_seconds=time.process_time()-start,rows=rows),indent=2)+'\n')

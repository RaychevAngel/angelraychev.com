# A precise obstruction to the first sensitive phase failure

24 October 2026. Independently accepted physical necessary reduction.
The proposed exclusion using ONLY these scalar constraints has been FALSIFIED:
they admit tuples not ruled out by the endpoint spatial charge. These are
relaxed-history counterexamples, not physical rectangle strategies.

Let w<=n, wn even, b=floor(w/2), h=wn/2, k>=b+1. Work with a full-origin
strategy in the accepted alternating-polarization normal form. Let Q_t be
total holes after t moves, and suppose Q_s<=H=b(b-1) throughout the segment
under discussion. Define G(x)=x+k-rho(x+k), F(x)=x+k-ceil(sqrt(x+k)), and
the ordinary pair P_0=(0,0), P_(t+1)=(G(P_t[1]),F(P_t[0])).

As in the accepted first-sensitive lemma, a sensitive event at t means

    r_t=ceil(sqrt(Q_t))<b,
    r_t(r_t-1)<Q_t<=r_t²,
    original total survivor surplus sigma_t=r_t.

Every sensitive target consists of ALL holes in one actual cohort and one
actual corner component. Its corner's color is the target's own color and
its radius is at most2r_t-2. The singleton case r=1 is included directly.
Polarization fixes the active initial cohort at all such events: since
the reflected hole layers are nested and one is empty, the nonempty layer
is always the same larger-hole layer. No cohort reset is allowed.

## 1. The only possible phase-changing interval is odd

Let u<v be consecutive sensitive events, and Delta=v-u. The accepted
first-sensitive initialization controls the first one in matching phase0.
Suppose u is still controlled, Q_u<=P_u[0]. Every intervening step obeys
the phase-insensitive worst map F, so

    Q_v<=G(F^(Delta-1)(Q_u))
        <=G(F^(Delta-1)(min(P_u[0],r_u²))).          (1)

The same permanent cohort's physical color flips Delta times. Both targets
are own-colored relative to their actual corners. If the two corners have
the same physical color, Delta is even, and the ordinary trajectory matching
the old corner reaches the new event in the correct phase. Since every
intermediate F is no larger than its matching ordinary map, Q_v<=P_v[0].

Consequently any FIRST failure Q_v>P_v[0] requires corners of opposite
physical colors and Delta odd. The corners may be adjacent or diagonally
opposite; the latter case is not excluded when exactly one side is even.

## 2. Exact phase-aware spatial charge

Let r=r_u and s=r_v, and put

    ell=max(0,r+s-b),       L=ell(ell+1)/2.

Then an opposite-color switch obeys

    Delta*k >= Q_v+s-L.                            (2)

Proof: the accepted matching-block inclusion retains the complete final
neighborhood and transports the old holes by f^(Delta-1), where f is any
fixed perfect matching. Since Delta is odd, this exponent is even and the
old holes are UNCHANGED, without a radius inflation. Thus the actual cohort's
total useful inspections in the block are at least |N(U_v) minus U_u|.

The old component lies in its own-color ball of radius2r-2. The new component
has surplus exactly s, so |N(U_v)|=Q_v+s, and its neighborhood lies in the
opposite-color ball of radius2s-1. For adjacent opposite-color corners,
their distance is odd and at least2b-1. In coordinates at the new corner,
the maximal old-ball condition is x-y>=2(b-r)+1. Intersect with x+y<=2s-1,
x+y odd. Put z=(x-y-1)/2, j=(x+y-1)/2; then

    b-r<=z<=j<=s-1.

There are exactly ell(ell+1)/2 integer pairs. The genuine board only reduces
this intersection. For diagonally opposite corners the two balls are
disjoint, because their radii sum is <=4b-5 while the corner distance is
at least4b-2. This proves(2) in all cases.

The original total survivor surplus at a sensitive event equals the dual
surplus of its unique hole component: both lie between ceil(sqrt(Q_v))=s
and the original total s. This justifies |N(U_v)|=Q_v+s exactly.

Since Q_v>s(s-1), (2) in particular gives

    Delta*k >= s²+1-L.                            (3)

## 3. A direct accumulated-surplus form

If p_j is the useful TOTAL quota in the block, the exact hole mass balance is

    Q_v-Q_u = sum_(j=u..v-1) p_j - sum_(j=u..v-1) sigma_(j+1).

The same spatial proof bounds sum p_j from below by Q_v+s-L, even if some
other-cohort probes occur. Therefore

    sum_(j=u..v-1) sigma_(j+1) >= Q_u+s-L.          (4)

This is an accumulated SURPLUS charge, not just a lower bound on elapsed
time. It may be combined with a reference cost comparison only after the
corresponding exact mass-balance subtraction; it must not be added to a
second lower bound charging the same inspections independently.

## 4. Exact remaining numerical obligation

A first sensitive matching failure must therefore exhibit integers

    1<=r,s<=b-1,  u>=1, Delta>=1 odd,
    s(s-1)<Q<=s²,
    Q>P_(u+Delta)[0],
    Q<=G(F^(Delta-1)(min(P_u[0],r²))),
    Delta*k>=Q+s-tri(max(0,r+s-b)).                (5)

There are further restrictions from the actual old sensitive count and
its time, which may strengthen this necessary list. It is sound to relax
them when trying to prove that NO tuple in(5) exists. It is not sound to
interpret a feasible tuple as a physical strategy or a counterexample.

The final upper-square condition matters. An arbitrary F-only mixing time
may be long on an interval where F=G; there the final event is not sensitive
and cannot exploit the cheap phase. A proof should retain the actual root
bin instead of discarding it in a global span estimate.

This reduction is for histories remaining below H. Prior excursions above
H require a separate clipped-history argument and are not silently covered.
The inequalities in(5) do NOT rule out every phase failure: the independent
root receipt `root-sensitive-large-counter.json` gives k=200, b=199,
u=1390, Delta=103, old pair(38801,38798), old holes38801, and Q=39007.
The ending ordinary pair is(39006,39007), while the F-only transfer followed
by G attains39007 and the exact charge19899 is below the budget20600.
The comparison lane also derives an unbounded symbolic local family.

Thus the physical reduction and accumulated charge remain valid, but the
standalone scalar exclusion route is disproved. These witnesses omit the
spatial labels of all intermediate near-extremal events: their cheap F-only
steps cannot be assumed physically able to relocate the dominant corner.
Any continuation must retain those intermediate labels, daily dependence,
or another genuinely stronger constraint. Uniform exact capture remains open.

# Removing the early day without discarding the physical phase

24 October 2026. Conditional assembly for independent review. The only new
physical premise is the proposed ordinary early necessity theorem. The
middle and late comparisons cited below are already accepted. No finite
width certificate is strengthened by this argument alone.

Assume that, in every actual history used by the accepted crossing
argument, an early crossing with total holes Q in its endpoint range at
time t satisfies

    Q <= max A_t,                                    (E)

where A is the genuine ordinary forward hole pair from (0,0). The premise
must include the actual overshoot and retreat treatment; a scalar statement
only about selected monotone histories is insufficient.

## 1. The shifted-pronic middle accepts the genuine ordinary head

Use b>=200, 1<=d=k-b<=19, H=b(b-1), and the accepted endpoint intervals

    H-d+1<=Q<=H,       H-d+2<=Y<=H+2.

Let e(Q)=min{t:max A_t>=Q}. At this time put A=A_e. The ordinary swap
operator is progressive along its zero-origin orbit. Its global time
interlacing gives

    max A <= min Hf(A) <= G(min A),
    G(x)=x+k-rho(x+k).

Writing M=max A, exact inversion of G gives

    min A+k >= M+ceil(sqrt(M)).

Since M>=Q>(b-1)^2, the square root is at least b. Consequently

    spread(A)<=k-b=d.                              (1)

In particular A meets the weaker d+1 hypothesis of the accepted
`../overnight-uniform-2026-10-24/comparison-shifted-pronic-middle.md`.
That theorem explicitly accepts ANY progressive early pair with the stated
maximum and spread; it does not require a hybrid origin. Its coordinatewise
clipping at H remains valid here, since Hf(H,H)>=(H,H).

Keep the existing late hybrid C_ell at its first maximum >=Y and the same
necessary middle clock tau from equal seed Y to maximum h-Q. The accepted
middle theorem therefore yields

    max_p [Phi^(tau+2)(C_ell)[p]+A_e[p xor chi]]>=h. (2)

The late same-phase comparison is still V_(ell+1)^c>=C_ell. Applying the
exact physical two-front adjunction to (2) gives a genuine solo gate-c
trajectory in at most

    e(Q)+tau+ell(c,Y)+3                            (3)

moves. The three are TWO middle moves and ONE late move. No early move,
free phase swap, or min-versus-max inference has been inserted.

## 2. Large excess is simpler because its conclusion controls both phases

For b>=32, k<3b, use the older H=(b-6)^2 and its accepted Q,Y intervals.
The refined large-excess theorem proves

    min Phi^(tau+2)(C_ell)>=h-Q

for even width d>=18 and odd width d>=20, with any tied terminal gate
seed 0<=c<=k as audited in the eight-day assembly. Therefore ANY genuine
early pair with maximum at least Q suffices. Its spread and matching label
are immaterial: the physical middle reaches h-Q in BOTH labels.
Equation(3) follows directly, using the same late +1 comparison. No new
small-budget gate comparison is needed: this range already has k>=50,
exactly the range covered by the accepted arbitrary-seed audit.

All Q endpoints here are below the pronic early boundary b(b-1). Thus an
ordinary early necessity theorem valid through that boundary covers this
range as well, provided its stated first-crossing/overshoot convention
matches (E).

## 3. The final inspection quota gives a six-day bracket in these families

Define J_new(c) to be the minimum of

    e(Q)+tau(Q,Y)+ell(c,Y)

over the same endpoint domain as the accepted joint evaluator. Premise(E)
and the existing physical crossing/merger/late arguments make it a necessary
first-passage clock to signed gate c. Retain all older lower bounds by max.
The domain and e are independent of c, and the late zero-seed clock is an
exact one-step shift of the seed-k clock. Hence, writing J=J_new(k) and
Jhalf=J_new(floor(k/2)),

    Jhalf is J or J+1,
    T >= max(2J+1,2Jhalf).                          (4)

Equation(3) proves Pc<=J_new(c)+3, while the complete solo capture clock
P0 obeys P0<=J+4. The existing sequential and shared-central-shot physical
constructions therefore give

    U<=min(2J+8, 2Jhalf+7).                         (5)

If Jhalf=J, use U<=2J+7 and L>=2J+1. If Jhalf=J+1, use U<=2J+8 and
L>=2J+2. In either case U-L<=6.

This strengthens both analytic families uniformly in width and length,
conditional only on the exact ordinary early physical premise(E).

## 4. Scope of the resulting whole-domain statement

The accepted analytic coverage is b>=200,d=1..19 together with even d>=18
or odd d>=20 at b>=32,k<3b. Thus every even-area width at least400 is in
one of these families unless k>=3b, where the older gap<=1 bound is stronger.
Odd-by-odd rectangles retain exact evaluation; widths<=64 retain gap<=3.

The old finite certificate for even-area widths65..399 at small excess still
has maximum gap8. It is NOT automatically improved by the new early theorem:
that certificate's numerical lower evaluator has not been replaced and
rechecked. Consequently the global ceiling remains8 until that finite
family is strengthened or a new analytic proof covers it. The result here
is a safely quantified gap6 on the unbounded analytic families, not an
unjustified global deletion of two days.

The free-phase transport families have a still stronger separate interface:
ordinary early necessity saves its head day there without any middle phase
obligation, and a future ordinary late theorem would make those families
exact. This note does not assert that missing late theorem.

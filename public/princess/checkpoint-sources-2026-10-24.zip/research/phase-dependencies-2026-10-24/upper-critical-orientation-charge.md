# Exact cost of changing a strict-middle critical orientation

24 October 2026. Physical history lemma proposed for independent review.
This uses the SHARP odd-short critical classification, not the deeper
cylinder collar for the intervening-frontier theorem. No claim is made
that a surplus-b+1 intermediate support is a pyramid.

Let the board be (2b+1) by 2L, with 2L>=2b+1 and h=(2b+1)L.
Follow one fixed physical cohort through inspection-and-movement updates
t=u,...,v-1. Its pre-inspection belief is A_t, its useful inspections
have cardinality p_t<=k, its actual survivor is S_t, and

    a_t=|A_t|, q_t=|S_t|, sigma_t=|N(S_t)|-|S_t|,
    a_(t+1)=a_t-p_t+sigma_t.

Assume EVERY survivor in this segment is strictly middle:

    b²<q_t<h-b(b+1).                                  (1)

Set z_t=1 if sigma_t=b, and z_t=0 otherwise. At the left boundary
take z_(u-1)=0 unless the actual previous survivor was also strictly
middle with surplus b, in which case take z_(u-1)=1. This convention
records a genuine previous critical event, not an arbitrarily chosen bit.
Let D=2k-2b-1. The statements below apply to every k>=b+1.

## 1. The exact ledger

The sharp classification in `../uniform-odd-short-critical-frontiers.md`
gives sigma_t>=b and forbids z_(t-1)=z_t=1. Define

    epsilon_t=2 sigma_t-(2b+1)-z_(t-1)+z_t.

Every epsilon_t is nonnegative. More precisely,

* sigma_t=b: epsilon_t=0;
* sigma_t=b+1 and z_(t-1)=1: epsilon_t=0;
* sigma_t=b+1 and z_(t-1)=0: epsilon_t=1;
* sigma_t>=b+2: epsilon_t=2(sigma_t-b-1)+1-z_(t-1).

The physical mass balance gives the EXACT identity

    D(v-u)-[2(a_u-a_v)+z_(u-1)-z_(v-1)]
      =2 sum_t(k-p_t)+sum_t epsilon_t.               (2)

In particular this is an account of actual useful probes, actual expansion,
and actual time. It does not average incompatible phases or presume that
the intermediate possible sets have an optimized shape.

## 2. Every orientation change spends a distinct unit of slack

The sharp static theorem says a surplus-b support is a prefix in one
physical color and a suffix in the other, in the paired longitudinal
coordinates. Call these its left and right orientations. Thus two critical
events of this SAME cohort have different orientations exactly when their
time indices have different parity.

List the critical events in the segment, optionally including u-1 when
z_(u-1)=1. Let F be the number of consecutive pairs in this list whose
orientations differ. Such a pair has an odd time gap. The no-consecutive
critical theorem excludes gap1, so its gap is at least3. The day two after
the first event is inside the segment and has zprev=z=0. It contributes
epsilon>=1. The open gaps between consecutive critical events are disjoint,
so these charges use distinct days. Consequently

    sum_t epsilon_t>=F,

and (2) proves

    2(a_u-a_v)+z_(u-1)-z_(v-1)+F
        +2 sum_t(k-p_t) <= D(v-u).                   (3)

More finely, let B00 count days with zprev=z=0. Then the identity is

    sum_t epsilon_t
      =B00+2 sum_t max(0,sigma_t-b-1),               (4)

and F<=B00. Thus no expansion-excess term has been charged twice.

At minimum budget k=b+1, D=1: an actual change between the two critical
orientations consumes at least ONE entire additional update relative to
the exact rank-drop benchmark with the same endpoint bits. At larger
budgets the uniformly valid statement is (3), not an assertion that each
change always costs a full day after integer rounding.

If there are no critical events, (3) remains valid with F=0; indeed every
day with zprev=0 costs at least one unit in (4). If an orientation is to be
attached at an endpoint that is not itself critical, a separate physical
argument must provide that endpoint condition. No label is supplied for free.

## 3. Why this survives the sharp collar

An efficient run (epsilon_t=0 on every day) must alternate actual surplus
b and b+1. All its surplus-b events have the same parity and hence the same
actual critical orientation. This conclusion needs no information about
the geometry of the intervening b+1 supports. The old cylinder theorem,
whose proof requires all fibers nonempty and nonfull in a much deeper
collar, is therefore unnecessary for this orientation ledger.

For a whole-board improvement the remaining interface is precise: use
actual early and late markers/cores to force the orientations of critical
events at the two ends of a strict-middle segment, while accounting for
all transitions crossing its collars. If the forced orientations differ,
(3) supplies the missing positive slack. Neither a prefix normal form nor
an unrestricted exact capture formula follows from this lemma alone.

# Exact minimum-budget gates on every odd width at least 25

24 October 2026. Corollary of independently accepted ordinary proofs.

For EVERY integer b>=12, every even n>=2b+1, and k=b+1, the exact
full-board capture time is

    T_k(2b+1,n)=P(k)+P(floor(k/2))+1,

where P(c) is the physical backward prefix gate recurrence explicitly
defined in `root-tied-cut-exact-gate.md`. Its corresponding concatenation
or palindrome supplies an attaining inspection rule. This is an exact
algorithmic evaluation, not an O(1)-operation numerical expression.

Proof. `lower-capped-natural-range.md`, independently accepted in
`upper-capped-natural-range-review.json`, extends every required early,
late, seeded and clipping comparison to b>=4d+8. Substituting d=1 gives
b>=12. The tied-cut proof uses no larger hypothesis: its forced tie is
q=b^2+1, strictly between b^2 and A>=b^2+2b. Apply that proof for every
terminal quota c<=k, then its matching final shared-quota bounds.
The full extension was independently checked in
`lower-tied-cut-exact-gate-review.json`; the underlying tied-cut proof also
has `upper-tied-cut-exact-review.json`.

This does not assert a tie at higher budgets, nor solve all smaller odd
widths. The accepted global four-day ceiling and every older exact result
are retained. No new Lean verification or public release is claimed.

# A uniform four-day bracket from exact physical boundary clocks

24 October 2026. Assembly for independent review. This note requires the
first-quota, shifted-seed and signed-late proofs and the ordinary-head middle
comparison listed below to pass their independent reviews. It is not a
zero-gap theorem, a new Lean result, or a bounded-operation formula.

For every rectangle w<=n and every feasible constant budget, retain all
previous bounds. The proposed stronger combined bracket has U-L<=4.
The numerical evaluators use finite recurrences and finite endpoint minima;
all upper bounds come from actual inspection constructions.

## Boundary clocks and the necessary joint evaluator

For even area put b=floor(w/2), h=wn/2, d=k-b. Define

    E_0=(0,0), E_(t+1)=(E_t[1]+k-rho(E_t[1]+k),
                         E_t[0]+k-ceil(sqrt(E_t[0]+k))),
    V_0^c=(c,c), V_(t+1)^c=(k+V_t^c[1]-rho(V_t^c[1]),
                             k+V_t^c[0]-ceil(sqrt(V_t^c[0]))).

Let e(Q) and ell_c(Y) be their first MAX hitting times. Use the accepted
necessary BAND9 middle frontier, initialized at Y in every feature, and
let tau_Y(M) be its first maximum hitting time of M. A weaker accepted
three-corner middle may replace it wherever the cited comparison allows.

When b>=32 and b<k<2b, set H=b(b-1) and use EVERY integer endpoint

    H-d+1<=Q<=H, H+1<=Y<=H+d+1.                       (1)

When b>=32 and 2b<=k<3b, set H=(b-6)^2 and instead use

    H<=Q<=H-1+k-rho(H-1+k),
    H+1<=Y<=H+k-rho(H).                              (2)

For either domain define

    J(c)=min_(Q,Y) [e(Q)+tau_Y(h-Q)+ell_c(Y)], 0<=c<=k. (3)

This minimizes over the complete endpoint domain. It does not silently
retain only endpoints minimizing an older hybrid evaluator.

Every actual full-origin gate-c history can first be polarized and last-full
normalized without increasing any daily quota or its terminal mass; the
finite-prefix version includes a last-full terminal state. Choose the
actual early first crossing and the late last state before first crossing
below H in this normalized history. The accepted cut and merger arguments
supply exactly (1) or (2), the middle necessary duration, and no duplicated
move. The new ordinary early theorem supplies e(Q).

The signed-late splice supplies ell_c(Y), with allowed cap

    Zcap=min((b-1)^2+k,b^2+1).

For (1), k<2b and Ymax=(b-1)^2+k=Zcap. For (2),
Ymax=H+k-b+6 is below both (b-1)^2+k and b^2+1, since b>=32,k<3b.
The early endpoints of (2) and all preceding holes are below b(b-1):
Qmax<=H-1+k<b^2-9b+35<b(b-1). Thus the ordinary early theorem applies
at the actual overshoot there too. All k in these ranges exceed13.
Adding the three actual durations proves g_c>=J(c).

The existing final-inspection intersection argument therefore gives

    T>=L=max(2J(k)+1,2J(floor(k/2))).                 (4)

The endpoint domain is independent of c, and V_1^0=(k,k)=V_0^k, so
J(0)=J(k)+1. Monotonicity gives Jhalf in {J,J+1}, where J=J(k).

## Phase-compatible constructions

For (1), `comparison-ordinary-head-pronic-middle.md` gives, in the
actual compatible labels,

    max_p [Phi^(tau+alpha)(V_ell^c)[p]+E_e[p xor chi]]>=h,

with alpha=1 for even width and alpha=2 for odd width. Its input is the
genuine ordinary head, whose spread at the cut is at most d. The ordinary
late pair is progressive; finite-board physical maps can only improve it.
No artificial equal seed is treated as an actual incoming state.

For (2), the previously reviewed large-excess comparison gives the stronger
minimum-coordinate conclusion after tau+2 physical moves. Its actual-input
span proof applies to the ordinary late orbit as the injection-free case of
the old hybrid. Here d>=b>=32 exceeds both parity thresholds18 and20.

The exact two-front adjunction turns either meeting into a solo gate-c
inspection word of length Pc<=J(c)+alpha, with alpha<=2. The earlier
sequential and reflected-palindrome constructions then give

    T<=U=min(2J+2alpha+2, 2Jhalf+2alpha+1).           (5)

If Jhalf=J, use the second upper and first lower in (4)--(5). If
Jhalf=J+1, use the first upper and second lower. In either case

    U-L<=2alpha<=4.                                 (6)

Thus even-width boards with b>=32 and b<k<2b have the stronger gap<=2.
The other ranges just proved have gap<=4. Retaining all old bounds can
only decrease these gaps.

## Entire-domain coverage

Odd-by-odd rectangles retain their accepted exact evaluator. Widths at
most64 retain the old gap<=3 result. Every remaining even-area rectangle
has b>=32 and is covered by b<k<2b, 2b<=k<3b, or k>=3b. The last range
retains the old gap<=1 result. This covers all lengths n>=w and every
feasible budget. No parameter-dependent width or length exclusion remains.

The old finite-width certificate remains preserved; it is no longer needed
to patch widths65..399 if the new physical and middle lemmas pass review.
That replacement is mathematical unification, not removal of results by
scope selection. The accepted zero-gap transport subfamilies, if assembled
from the separate exact-boundary interface, strengthen but are not needed
for (6).

## Dependencies and remaining objective

New sources: lower-ordinary-early-boundary-theorem.md;
lower-first-quota-ordinary-boundary.md; lower-shifted-seed-continuation.md;
upper-signed-late-ordinary-splice.md;
comparison-ordinary-head-pronic-middle.md.
Accepted old interfaces: joint-history-2026-10-24/physical-joint-clock-review.md,
the large-excess middle and parity refinement, the two-front adjunction,
and overnight-uniform-2026-10-24/root-uniform-eight.md's final-quota assembly.
All paths above are relative to this research directory or its parent.

Gap zero remains the objective. The remaining losses here are physical
middle alignment, not independent one-day errors at the two boundaries.
An exact strategy or a sharper necessary compatibility argument is still
needed where the constructed and necessary middle clocks differ. No final
expression simplification should begin on the basis of this four-day result.

# Whole critical fronts retain quadratic overlap after erosion

24 October2026. Geometric lemma submitted for independent review. This
retains every fiber of a critical frontier instead of choosing one corner
core. Its application still requires the stated actual-front/age hypotheses.

Use an odd-width board w=2b+1 and a fixed longitudinal end. A one-color
near-end prefix front is described by its physical height h_x in each
column0<=x<=2b: it contains all cells of its color between that end and
height h_x. Assume adjacent heights differ by exactly one. Equivalently,
in an own-colored critical frontier the majority lengths a_i and minority
lengths c_i satisfy

    max(a_i,a_(i+1))-1 <= c_i <= min(a_i,a_(i+1)).     (1)

These are the actual heights supplied by the accepted critical equality
classification; no compression or fixed-prefix normal form is assumed.
The same description permits empty clipped fibers after erosion.

## 1. Exact overlap of two same-end fronts

For two such fronts of the SAME current color and the SAME longitudinal
end, let their fiber counts be l_x,m_x and total sizes q_1,q_2. Then

    |F_1 intersect F_2| >= min(q_1,q_2)-b(b+1)/2.     (2)

Proof. Both sets are prefixes in every common fiber, so their intersection
has size sum min(l_x,m_x). The difference z_x=l_x-m_x is an integer
1-Lipschitz sequence: along any fixed oriented edge the allowed change
in a fiber count is the same two-element set {0,1} or {-1,0} for both
fronts. Taking their difference gives |z_(x+1)-z_x|<=1. Clipping either
fiber count at zero preserves these allowed edge changes.

Put P=sum max(z_x,0), N=sum max(-z_x,0). If only one sign occurs, one
front is fiberwise contained in the other and (2) is immediate. Otherwise
there is at least one zero fiber. Every positive component is adjacent to
a zero on at least one side; a component of length j contributes at most
1+2+...+j. Summing components gives P<=tri(p), where p is the number of
positive fibers. Likewise N<=tri(n), where n counts negative fibers.
Because p+n<=2b, at least one of p,n is at most b. Thus

    min(P,N)<=tri(b).

Finally the exact identity

    |F_1 intersect F_2|=min(q_1,q_2)-min(P,N)

proves (2). The loss tri(b) is sharp for the affine difference sequence
-b,-b+1,...,b. This is a sign-component argument, not a mean-field estimate.

## 2. Erosion keeps the entire prefix family

For a front with heights h_x, define K_j to be the current-color prefix
with heights h_x-j, clipped below the board, after j parity changes.
Then

    K_j subset E^j(F),
    |K_j| >= |F|-(2b+1)ceil(j/2).                   (3)

For the inclusion, every neighbor of a cell at height at most h_x-j is
at height at most the corresponding h_neighbor-(j-1). Vertical neighbors
use the one-unit decrement and horizontal neighbors use the1-Lipschitz
physical heights. Missing board-edge neighbors only help. Induct on j.
The count bound follows column by column: lowering the physical height by
j and changing to the new color removes at most ceil(j/2) old-color cells.
Clipping an exhausted fiber cannot increase the loss beyond its old size.

The sets K_j still have the common two-option adjacent fiber differences
used in Section1. Therefore two eroded fronts, whose CURRENT colors agree,
satisfy the stronger bound

    |K_a(F_1) intersect K_c(F_2)|
       >= min(q_1-(2b+1)ceil(a/2),
              q_2-(2b+1)ceil(c/2))-tri(b).            (4)

It is important to apply (2) to the two eroded fronts. Subtracting BOTH
erosion losses from their original intersection is unnecessarily weaker.
The original seed colors may differ if the erosion ages have different
parities; only the current colors and near end must coincide.

## 3. Natural-range consequence with an explicit defect allowance

Let k=b+d, b>=4d+8, L=(b-1)^2. Suppose two actual critical full-span
fronts have sizes q_i>L and their retained erosion ages are at most2d.
If they have the same current color and near end, (4) gives

    intersection >= J(b,d),
    J(b,d)=L+1-(2b+1)d-b(b+1)/2
          >=(5b+16)/4 > d.                           (5)

This holds uniformly in the other side length. It is much larger than
one-cell or d-cell endpoint uncertainty, even at the natural endpoint
b=4d+8. No hypothesis about which short-axis corner has the largest height
is needed; the opposite-corner extremal ramps are already included in (2).

For a physical joining application, suppose one retained front lies in
actual holes H, and the other in an allowed set C containing the actual
same-cohort survivor/belief S. Write eta=|C minus S|. Because H and S are
disjoint,

    |K_a(F_1) intersect K_c(F_2)|<=eta.                (6)

Thus the simultaneous same-end configuration is impossible whenever
eta<J(b,d); in particular eta<=d is impossible under (5). If the second
front lies in the actual survivor itself, eta=0. This explicitly retains
the distinction between an allowed reverse set and an actual physical set.

## What remains to apply it

The lemma does not claim that every dangerous endpoint has a full-span
ancestor of age at most2d. One must establish that event type, the actual
cohort identity, both ages at the common cut, and any allowed-set defect.
Localized corner alternatives and longer bad gaps require their own bound.
Once those premises hold, neither arbitrary intermediate shapes nor a
switch between the two short-axis corners can evade the overlap in (5).

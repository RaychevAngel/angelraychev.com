// Independent complete capped seeded base via target-profile inversion.
#include <algorithm>
#include <array>
#include <cassert>
#include <iostream>
#include <vector>
using namespace std;
constexpr int LIM=65536;
int main(){
 vector<int> R(LIM+1),rho(LIM+1),tri(201);
 for(int x=1;x<=LIM;++x){int lo=1,hi=x;while(lo<hi){int m=(lo+hi)/2;if(1LL*m*m>=x)hi=m;else lo=m+1;}R[x]=lo;
 lo=0;hi=R[x];while(lo<hi){int m=(lo+hi)/2;if(1LL*m*(m+1)>=x)hi=m;else lo=m+1;}rho[x]=lo;}
 for(int x=0;x<=200;++x){int lo=0,hi=20;while(lo<hi){int m=(lo+hi+1)/2;if(m*(m+1)/2<=x)lo=m;else hi=m-1;}tri[x]=lo;}
 long long all=0,orbits=0,states=0;int marginAll=9999;
 for(int b=12;b<32;++b){
  vector<int> gi(LIM+1),fi(LIM+1);int a=0,z=0;
  for(int n=0;n<=LIM;++n){
   while(a+1+min(R[a+1],b)<=n)++a;
   while(z+1+min(1+rho[z+1],b+1)<=n)++z;
   gi[n]=a;fi[n]=z;
  }
  for(int d=1;4*d+8<=b;++d){int k=b+d,cap=min((b-1)*(b-1),9801);long long seeds=0,ns=0;int minimum=9999;
   for(int c=k;c>=0;--c){++orbits;vector<array<int,2>> pair{{gi[c],fi[c]}};
    auto extend=[&](){auto v=pair.back();assert(v[0]+k<LIM && v[1]+k<LIM);pair.push_back({gi[v[1]+k],fi[v[0]+k]});};
    while(min(pair.back()[0],pair.back()[1])<cap)extend();int end=pair.size()-1;
    for(int j=0;j<200;++j)extend();
    for(int t=1;t<end;++t){++ns;++states;int p=pair[t][0]>pair[t][1]?0:1;
     for(int q=pair[t][1-p]+1;q<=min(cap,pair[t][p]);++q){int r=R[q];if(r<4 || (p==1 && q>r*(r-1)))continue;
      int defect=r*(r-p)-q;assert(defect>=0 && defect<=200);int core=2*r-2-p-2*tri[defect];
      if(p==0 && q==(r-1)*(r-1)+1)core=min(core,2*r-4);
      int x=q,age=0;while(x>min(pair[t+age][0],pair[t+age][1])){assert(age<core && x+k-1<LIM);x=gi[x+k-1];++age;}
      assert(age<=core-1);minimum=min(minimum,core-1-age);++seeds;
     }
    }
   }
   all+=seeds;marginAll=min(marginAll,minimum);cout<<b<<' '<<d<<' '<<seeds<<' '<<ns<<' '<<minimum<<'\n';
  }
 }
 cerr<<"TOTAL "<<all<<' '<<orbits<<' '<<states<<' '<<marginAll<<'\n';
 assert(all==130966 && orbits==1650 && states==130183 && marginAll==0);
}

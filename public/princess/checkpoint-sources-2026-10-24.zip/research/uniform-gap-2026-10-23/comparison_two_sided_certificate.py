"""All-length dual-head / paired-tail certificate, with explicit meeting targets."""
from pathlib import Path
from math import gcd
import json,time,hashlib
import comparison_periodic as base
import comparison_tail_seed_certificate as seeded
import comparison_two_sided as bridge
HERE=Path(__file__).resolve().parent


def meet_bounds(w,n,k,J,H,V,defects):
    h=w*n//2;Z=seeded.seeded_initial(k,V);low=up=None;t=0;trace=[]
    while low is None or up is None:
        trace.append(Z);B,_,X,Y=Z
        if low is None and any(d is not None and B[c]>=h-d for c,d in enumerate(defects)):
            low=2*(J+H+t)-1
        if up is None:
            candidates=[]
            if max(X)==h:candidates.append(2*t)
            if max(Y)==h:candidates.append(2*t+1)
            if candidates:up=min(candidates)
        if low is not None and up is not None:break
        Z=base.advance(w,n,k,Z);t+=1
        assert t<4*w*n
    return dict(w=w,n=n,k=k,J=J,H=H,lower=low,upper=up,gap=up-low,trace=trace)


def long_certificate(w,k,J,H,parity):
    trial=bridge.run(w,k,J,H,parity)
    V=trial['tail']['paired_seed'];defects=trial['head']['defects']
    e=seeded.seeded_entry(w,k,V);r=w//2
    max_entrance=e['safe_h']-max(r*r+1,k+2)
    e['safe_h']=max(e['safe_h'],max_entrance+max(d for d in defects if d is not None)+1)
    onset=max(trial['n'],base.threshold(e,parity));P=e['length_period']
    assert w*onset//2>k*(J+H)
    assert bridge.head(w,onset,k,J)['defects']==defects
    assert bridge.head(w,onset+P,k,J)['defects']==defects
    shift=w*P//2;days=e['solo_shift'];t=e['entry_day'];rows=[]
    for n in range(onset,onset+P,2):
        a=meet_bounds(w,n,k,J,H,V,defects)
        b=meet_bounds(w,n+P,k,J,H,V,defects)
        assert a['trace'][t]==e['entry']==b['trace'][t]
        assert b['trace'][:t+1]==a['trace'][:t+1]
        assert len(b['trace'])==len(a['trace'])+days
        for old,new in zip(a['trace'][t:],b['trace'][t+days:]):
            assert new==base.translated(old,shift)
        assert b['lower']==a['lower']+e['full_shift']
        assert b['upper']==a['upper']+e['full_shift']
        rows.append(dict(representative={x:y for x,y in a.items()if x!='trace'},
                         translated_tail_states=len(a['trace'])-t))
    return dict(parity=parity,seed=trial['tail'],head=trial['head'],entry=e,
                onset=onset,representatives=rows)


def run24():
    start=time.process_time();w,k,J,H=24,13,28,28;long=[];short=[]
    for parity in(0,1):
        row=long_certificate(w,k,J,H,parity)
        for item in row['representatives']:
            a=item['representative'];assert a['lower']==a['upper']==24*a['n']-369
        long.append(row)
    for n in range(24,min(row['onset']for row in long)):
        x=bridge.dual.run(w,n,k,**bridge.FLAGS)
        assert x['complete'] and x['lower']==24*n-369,(n,x)
        assert base.bounds(w,n,k)['upper']==24*n-369
        short.append({z:x[z]for z in('w','n','k','solo','residual','lower','CPU_seconds')})
    files=['comparison-two-sided-proof.md','comparison_two_sided.py',
           'comparison_two_sided_certificate.py','comparison_tail_seed.py',
           'comparison_tail_seed_certificate.py','comparison_periodic.py',
           'root_dual_interval.py','root_interval.py','root_capacity.py',
           'lower-dual-radius-resets.md']
    return dict(status='PASS',scope=__doc__,formula='T_13(24,n)=24*n-369 for every n>=24',
                long_results=long,short_lengths=short,CPU_seconds=time.process_time()-start,
                source_sha256={x:hashlib.sha256((HERE/x).read_bytes()).hexdigest()for x in files})


if __name__=='__main__':
    result=run24();(HERE/'comparison-two-sided-certificate.json').write_text(json.dumps(result,indent=2)+'\n')
    print({k:v for k,v in result.items()if k not in('long_results','short_lengths','source_sha256')})

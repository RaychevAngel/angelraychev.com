# The same all-length period for the universal BAND9 lower

24 October 2026 UTC. Extension of the accepted comparison-periodic.md
argument to the independently reviewed universal nine-feature lower and
its static near-pronic bands and subsequent dual square bands. The
original extension was accepted in `upper-review-band9.md`; the added
square band has the same deficit-only translation property.
There are no radius certificates or history flags in this model.

Fix `w>=6`, `k>floor(w/2)`, and an admissible length parity. In particular
`k>=4`. Put `r=floor(w/2)`, `d=2k-w`, `g=gcd(w,d)`. Replace each
three-coordinate model frontier in the original joint vector by its nine
coordinates `B[c,e]`, `0<=c,e<=2`, from `lower-band9.py`. Keep the same two
physical two-phase vectors. The conclusion is unchanged:

    L9(w,n+2d/g,k)=L9(w,n,k)+4w/g,
    U(w,n+2d/g,k)=U(w,n,k)+4w/g

for every sufficiently long admissible `n`, with the explicit entrance
algorithm below. Thus a finite list gives the exact all-length maximum of
these two named bounds for each fixed `(w,k)` and length parity.

## Middle reduction

Use the conservative common low/high threshold `A=(r+4)^2`. Direct
substitution in the fixed inverse formulas gives `theta_low>=r`,
`theta_high>=r`, and both ordinary corner inverses at least `r+1` whenever
their arguments are at least `A`. All static near-pronic bands are then
inactive as well: near-pronic bands have hole count at most `r(r-1)`,
and the added dual square bands have hole count at most `(r-1)^2`.
The latter applies to target `(j,v)=(1,2)` with holes in
`((s-1)^2,s^2]`, `2<=s<r`, forcing retained survivor erosion `u=1` at
closed surplus `s`. Both kinds depend only on the target deficit and
fixed feature indices, so the same tail translation applies to either
version of the recurrence.

When every source and target cap is inactive, the maximal survivor for a
fixed target `(T,j,v)` and retained corner count `i` is therefore

    Q=T-(v-i)-cap(v,j),

where `cap` is `r` on the accepted width-dependent critical exception and
`r+1` otherwise. The short-board double exception at even width and
`n=w+1` is excluded by the stable threshold, just as in the original proof.

For fixed source `(c,e)` and target `(j,v)`, maximize at `i=min(c,v)` and
`u=0`. This choice is maximal-survivor-admissible since
`min(c,v)>=max(0,c+v-2)`; its deletion charge is `c-i+e<=4<=k`.
Consequently

    B'[c,e]=k+max_(j,v){B[j,v]-max(0,v-c)-cap(v,j)}.

The right side is independent of `e`. After one such update write
`B[c,e]=b_c`. The next update reduces exactly to the original three-corner
middle recurrence: for even width the exception `(v,j)=(1,1)` is available
at no closure cost exactly when `c>=1`; for odd width the exception
`(v,j)=(2,0)` is available at no closure cost exactly when `c=2`.
The coordinate order `b_0<=b_1<=b_2` is preserved. After at most two further
updates the same normal forms hold:

* even width: `B[c,e]=(a-1,a,a)_c`;
* odd width: `B[c,e]=(a,a,a+epsilon)_c`, `epsilon in {0,1}`.

Two middle steps then add `d` to every model and physical coordinate.

## Infinite entrance and termination

Delete the high-root terms, board-size caps and all high-hole bands while
retaining every low inverse and ordinary critical condition. Initialize
the nine capture coordinates at zero and the nine midpoint coordinates
at `floor(k/2)`. Iterate until all coordinates are at least `A` and the
normal forms above hold. This uses exactly the low-end information of
the actual model.

Here is an explicit termination argument rather than an assumption from
successful runs. After one update all model coordinates are at least `k`;
after two they are at least `r+2`, using the `(i,u,j,v)=(0,0,0,0)` option
and `rho(2r+2)<=r` when `k=r+1`. Once the minimum is at least `r+2`, every
source can use `i=u=v=0` and any outgoing `j`, giving a next value at
least `B[j,0]+k-r-1`. At even width, source `(1,0)` can use the exceptional
target `(j,v)=(1,1)` with `i=1,u=0`, so its next value is at least
`B[1,1]+k-r`. At odd width, source `(2,0)` can use `(j,v)=(0,2)` with
`i=2,u=0`, giving at least `B[0,2]+k-r`. Combining these choices shows
that the minimum of all nine coordinates gains at least one in every two
updates. Physical coordinates gain at least `d` in two updates. Therefore
entry occurs by time `2A+7`, and the implementation's `4A+20` guard is safe.

Record the largest coordinate `M` in the entrance through its first next
update and require

    h>=M+max(A,k+4).

This leaves all high filters and next-step caps inactive through that
prefix and its first middle pair. It also excludes the short-board double
critical exception. Choose the first admissible length meeting this bound.

## Insertion and finite coverage

Insert `w/g` middle pairs at entry, exactly as in the original proof.
Every coordinate gains `wd/g`; the half-area gains the same amount when
length grows by `2d/g`. Along the translated original tail, low terms stay
inactive while high-root arguments, static band tests, and source/target
caps depend only on unchanged deficits from the enlarged half-area.
Hence the entire clipped tail translates, including both capture and
midpoint clocks. This proves the period identities and the same finite
residue coverage rule.

`comparison_band9.py` checks the exact translated tails and evaluates all
finite representatives. It refines only lines whose previously certified
basic all-length gap exceeds a selected cutoff; all other lines keep their
earlier valid bounds. This is a sound way to improve a complete width panel
without recomputing already satisfactory lines.

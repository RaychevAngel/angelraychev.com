# Independent review: interval implementation of the frozen paired-radius model

24 October 2026 UTC. Upper/construction lane review.

**Verdict: the exact interval transcription and affine capacity evaluator are
sound.** They change representation, not geometric assumptions or the model's
accepted lower bounds. This review refers to `root_interval.py` and
`root_capacity.py` as read this pass; the frozen reference is
`research/all-budget-2026-10-23/lower_lens.py` and its original graph builder.

For a fixed source corner count c and source-size interval [a,b], deleting
at most k rooms and retaining i corners permits precisely

    max(1,i,a-k) <= q <= min(b-(c-i),h-2+i),

provided `c-i<=k`. Indeed a source size x must satisfy simultaneously
`a<=x<=b`, `q+c-i<=x<=q+k`; eliminating x gives exactly these inequalities.
There is no convexity approximation here.

For fixed i,j the accepted survivor-capacity function is monotone in target
size. Thus the least q in an interval supplies the entire unlabelled target
tail, except possibly its single localization-reset target. Any larger q can
repair that missing target exactly when the next q is admitted by its
capacity. Its own reset target is strictly larger, so it does not remove
the same target again. All reset-labelled targets for larger q are included
separately, preserving every alternative history. The square interval and
pronic equality events are genuinely admissible: their low inverse equals
the claimed subcritical surplus, and their sizes are safely below the
finite-board corner caps. This validates the symbolic `relation` union.

Reachable sizes are kept as exact unions of integer intervals for each
(radius0,radius1,corner-count) key. Subtracting previously visited sizes
removes only identical states reached earlier; no dominance between distinct
radius pairs is introduced. Capacity intersections truncate each size
interval exactly. The final residual is taken over all pre-capture layers,
as in the corrected frozen evaluator.

For the constant-size capacity calculation, write own-color cells as
`x=2u+p,y=2v+p`, with p in {0,1}. The own ball gives
`v<=-u+floor(R/2)-p`. Each possible opposite corner adds one affine upper
or lower bound. The board adds constant bounds. Hence each parity count is
exactly the sum of a positive part of `min(upper)-max(lower)+1` over an
integer interval. The evaluator splits at every line crossing and every
zero crossing; each remaining summand is affine with a fixed sign, so its
arithmetic-series sum is exact. The number of lines and crossings is
absolute, independent of w,n,R,S. Maximizing areas and corner counts
separately over the two opposite corners matches the frozen relaxation.

The independent verifier `upper-review-interval.py` does not reuse the new
interval union to obtain expected edges. It enumerates each original q and
target, reconstructs reset labels, and also unions original graph rows over
complete source intervals. It compares capacities with the frozen literal
Manhattan-distance histograms. Its retained receipt reports:

- 5,500 complete q-interval relation comparisons;
- 4,650 complete source-interval row-union comparisons;
- 2,416 radius-pair capacity comparisons;
- all passed in 2.52 CPU seconds.

The algebra above is the general justification; the finite checks attack
implementation errors. Neither establishes a new absolute gap theorem.

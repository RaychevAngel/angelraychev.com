"""Independent literal exact-time head and near-full capacity transport audits."""
from functools import lru_cache
from pathlib import Path
from math import isqrt
import sys,json,time,hashlib
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'src'));sys.path.insert(0,str(Path(__file__).parent))
from bridge_corner_frontier import survivor_bound
from comparison_two_sided import head

def literal_capacity(w,n,R,S):
    own=(0,0);corners=[(0,0),(w-1,0),(0,n-1),(w-1,n-1)]
    candidates=[z for z in corners if sum(z)%2]
    area=corner=0
    for ax,ay in candidates:
        area=max(area,sum((x+y)%2==0 and x+y<=R and abs(x-ax)+abs(y-ay)<=S for x in range(w)for y in range(n)))
        corner=max(corner,sum((x+y)%2==0 and x+y<=R and abs(x-ax)+abs(y-ay)<=S for x,y in corners))
    return area,corner

def literal_heads(w,n,k,J):
    h=w*n//2;b=w//2;D=w+n-2
    capacity=lru_cache(None)(lambda R,S:literal_capacity(w,n,R,S))
    @lru_cache(None)
    def successors(a,c):
        out=set()
        if a<=k:out.add((0,0,-1,-1))
        for q in range(max(1,a-k),a+1):
            for i in range(max(0,c-(a-q)),min(c,q)+1):
                for j in range(3):
                    for T in range(max(1,j),h-2+j+1):
                        if survivor_bound(w,n,i,j,T)<q:continue
                        s=T-q;which=radius=-1
                        if i==1 and j==0 and 2<=s<b and(s-1)**2<q<=s*s:which,radius=1,2*s-1
                        if i==0 and j==1 and 2<=s<b and(s-1)*(s-2)<q<=s*(s-1):which,radius=0,2*s-2
                        if i==0 and j==1 and s==b and q==b*(b-1):which,radius=0,2*b-2
                        if j==2 and 2<=s<=b and q==h-s*s:which,radius=1^(D%2),D-2*s+2
                        if i==2 and j==1 and 2<=s<b and q==h-s*(s+1):which,radius=D%2,D-2*s+1
                        out.add((T,j,which,radius))
        return out
    current={(h,2,D,D)};result=[]
    for day in range(J+1):
        d=[]
        for c in range(3):
            sizes=[a for a,z,R,S in current if z==c]
            d.append(h-min(sizes)if sizes else None)
        result.append(d)
        if day==J:break
        following=set()
        for a,c,R,S in current:
            nr,ns=min(D,S+1),min(D,R+1)
            for T,j,which,radius in successors(a,c):
                x=min(nr,radius)if which==0 else nr
                y=min(ns,radius)if which==1 else ns
                cap,cc=capacity(x,y)
                if T<=cap and j<=cc:following.add((T,j,x,y))
        current=following
    return result

start=time.process_time();head_checks=capacity_checks=0
for w,n in[(4,4),(4,5),(5,6),(6,6),(6,7),(8,8)]:
    k=w//2+1
    for J,d in enumerate(literal_heads(w,n,k,6)):
        assert head(w,n,k,J)['defects']==d,(w,n,k,J,d)
        head_checks+=1
for w in range(4,13):
    b=w//2
    for parity in((0,1)if w%2==0 else(0,)):
        n=4*b;n+=n%2!=parity
        for x in range(2*b-1):
            for y in range(2*b-1):
                expected=None
                for nn in(n,n+2,n+8):
                    h=w*nn//2;D=w+nn-2;a,c=literal_capacity(w,nn,D-x,D-y)
                    z=(h-a,c)
                    if expected is None:expected=z
                    assert z==expected,(w,n,nn,x,y,expected,z)
                    capacity_checks+=1
sources=[Path(__file__),Path(__file__).with_name('comparison_two_sided.py'),Path(__file__).with_name('comparison-two-sided-proof.md'),Path(__file__).with_name('root_dual_interval.py')]
out=dict(status='PASS',literal_exact_time_head_checks=head_checks,literal_near_full_capacity_checks=capacity_checks,CPU_seconds=time.process_time()-start,source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in sources})
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print(out)

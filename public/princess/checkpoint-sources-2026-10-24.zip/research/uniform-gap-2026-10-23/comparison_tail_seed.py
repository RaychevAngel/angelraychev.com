"""Bounded-tail seed experiment, without assuming downward closure.

Search descends from the proven ordinary necessary threshold, stopping at
the first successful paired-model start. No physical attainment is claimed.
"""
import sys,json,time
from pathlib import Path
import root_interval as lens
from bridge_corner_frontier import step
HERE=Path(__file__).resolve().parent


def model(w,n,k,H,**flags):
    h,D,capacity,relation=lens.engine(w,n,k,**flags)
    def captures(a,c):
        front={(D,D,c):[(a,a)]};seen=dict(front)
        for day in range(H+1):
            if not front:return False
            if any(parts[0][0]==0 for parts in front.values()):return True
            if day==H:return False
            remaining=H-day-1;following={}
            def add(R,S,c,lo,hi):
                cap,cc=capacity(R,S)
                lo=max(lo,c);hi=min(hi,cap,h-2+c,k*remaining)
                if c<=cc and lo<=hi:following.setdefault((R,S,c),[]).append((lo,hi))
            for(R,S,c),intervals in front.items():
                newR,newS=min(D,S+1),min(D,R+1)
                for lo,hi in intervals:
                    if lo<=k:add(newR,newS,0,0,0)
                    for i in range(c+1):
                        if c-i>k:continue
                        qa=max(1,i,lo-k);qb=min(hi-(c-i),h-2+i)
                        if qa>qb:continue
                        for j in range(3):
                            for which,radius,u,v in relation(i,j,qa,qb):
                                nr,ns=newR,newS
                                if which==0:nr=min(nr,radius)
                                if which==1:ns=min(ns,radius)
                                add(nr,ns,j,u,v)
            front={}
            for key,parts in following.items():
                merged=lens.merge(parts);new=lens.minus(merged,seen.get(key,[]))
                if new:front[key]=new;seen[key]=lens.merge(seen.get(key,[])+new)
        raise AssertionError('unreachable')
    return captures


def seed(w,k,H,parity=0,**flags):
    r=w//2;Rmax=2*r-3+H
    n=max(w,2*Rmax+2,(2*(k*H+r*r+1)+w-1)//w);n+=n%2!=parity
    h=w*n//2
    B=(0,-1,-1)
    for _ in range(H):B=step(w,n,k,B)
    captures=model(w,n,k,H,**flags)
    out=[];tests=0
    for c in range(3):
        for a in range(B[c],c-1,-1):
            tests+=1
            if captures(a,c):out.append(a);break
        else:out.append(-1)
    return dict(w=w,k=k,H=H,parity=parity,n=n,ordinary_seed=B,
                paired_seed=out,tests=tests,flags=flags)


if __name__=='__main__':
    start=time.process_time();rows=[]
    for H in [int(x)for x in sys.argv[1:]]or[10,20,40,80]:
        row=seed(44,24,H,pronic_interval=True,critical_pronic=True,wide_square=True)
        rows.append(row);print(row,flush=True)
        (HERE/'comparison-tail-seed.json').write_text(json.dumps(dict(status='EXPERIMENT',CPU_seconds=time.process_time()-start,results=rows),indent=2)+'\n')

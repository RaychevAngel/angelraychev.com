"""Independent direct edge enumeration for optional pronic interval/critical resets."""
import sys,time,json,random,hashlib
from pathlib import Path
from math import isqrt
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'src'));sys.path.insert(0,str(Path(__file__).parent))
from root_dual_interval import engine
from bridge_corner_frontier import survivor_bound

def expand(parts):
 out={}
 for d,R,a,b in parts:out.setdefault((d,R),set()).update(range(a,b+1))
 return {x:y for x,y in out.items()if y}

def literal(i,j,qa,qb,w,n,partial,critical,wide):
 h=w*n//2;b=w//2;out={}
 for q in range(qa,qb+1):
  if q<i:continue
  for T in range(max(1,j),h-2+j+1):
   if survivor_bound(w,n,i,j,T)<q:continue
   s=T-q;key=(-1,-1)
   if i==1 and j==0 and 2<=s<b and ((s-1)**2 if wide else s*(s-1))<q<=s*s:key=(1,2*s-1)
   if i==0 and j==1 and 2<=s<b:
    if q==s*(s-1)or(partial and(s-1)*(s-2)<q<=s*(s-1)):key=(0,2*s-2)
   if critical and i==0 and j==1 and s==b and q==b*(b-1):key=(0,2*b-2)
   D=w+n-2
   if j==2 and 2<=s<=b and q==h-s*s:key=(1^(D%2),D-2*s+2)
   if i==2 and j==1 and 2<=s<b and q==h-s*(s+1):key=(D%2,D-2*s+1)
   out.setdefault(key,set()).add(T)
 return out
st=time.process_time();rng=random.Random(202610242);checked=source_checked=critical_forced=0
for w,n in[(4,4),(4,5),(4,6),(5,6),(6,6),(6,7),(7,8),(8,8),(8,9),(9,10),(10,10),(12,13)]:
 h=w*n//2;b=w//2
 for j in (0,2):
  assert survivor_bound(w,n,0,j,b*b)<b*(b-1),(w,n,j)
  critical_forced+=1
 for partial in (False,True):
  for critical in (False,True):
   for wide in (False,True):
    _,_,_,relation=engine(w,n,b+1,pronic_interval=partial,critical_pronic=critical,wide_square=wide)
    for _ in range(350):
     i=rng.randrange(3);j=rng.randrange(3);qa=rng.randrange(max(1,i),h-2+i+1);qb=rng.randrange(qa,h-2+i+1)
     assert expand(relation(i,j,qa,qb))==literal(i,j,qa,qb,w,n,partial,critical,wide),(w,n,partial,critical,wide,i,j,qa,qb)
     checked+=1
    if w<=6:
     k=b+1
     for _ in range(300):
      c=rng.randrange(3);a=rng.randrange(c,h-2+c+1);bb=rng.randrange(a,h-2+c+1)
      expected={};actual={}
      for x in range(a,bb+1):
       for q in range(max(1,x-k),x+1):
        for i in range(max(0,c-x+q),c+1):
         for j in range(3):
          for key,ts in literal(i,j,q,q,w,n,partial,critical,wide).items():expected.setdefault(key,set()).update((T,j)for T in ts)
      if a<=k:expected.setdefault((-1,-1),set()).add((0,0));actual.setdefault((-1,-1),set()).add((0,0))
      for i in range(c+1):
       if c-i>k:continue
       qa=max(1,i,a-k);qb=min(bb-(c-i),h-2+i)
       if qa>qb:continue
       for j in range(3):
        for d,R,u,v in relation(i,j,qa,qb):actual.setdefault((d,R),set()).update((T,j)for T in range(u,v+1))
      assert actual==expected,(w,n,partial,critical,wide,c,a,bb)
      source_checked+=1
out=dict(status='PASS',optional_relation_unions=checked,optional_source_unions=source_checked,critical_forced_corner_checks=critical_forced,CPU_seconds=time.process_time()-st,source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in[Path(__file__),Path(__file__).with_name('root_dual_interval.py'),Path(__file__).with_name('root_capacity.py'),Path(__file__).with_name('root-pronic-radius.md'),Path(__file__).with_name('lower-wide-square.md')]})
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print(out)

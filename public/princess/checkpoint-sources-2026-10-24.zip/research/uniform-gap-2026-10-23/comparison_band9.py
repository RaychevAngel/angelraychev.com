"""Finite-residue coverage using the universal unflagged BAND9 lower."""
from pathlib import Path
import importlib.util, json, sys, time
from math import gcd
import comparison_periodic as base

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('comparison_band9_model',HERE/'lower-band9.py')
er=importlib.util.module_from_spec(spec);spec.loader.exec_module(er)
from bridge_lower_frontier_nine import theta_low
from bridge_corner_frontier import small_inverse

FEATURES=er.FEATURES
INDEX={f:z for z,f in enumerate(FEATURES)}
OPTIONS={}
for c,e in FEATURES:
    OPTIONS[c,e]=[(i,u,j,v)for i in range(c+1)for u in range(e+1)
                  for j in range(u,3)for v in range(i,3)if i>=max(0,c+v-2)]


def infinite_survivor(w,T,i,u,j,v):
    if T<=0:return 0
    r=w//2;delta=v-i
    exception=(v,j)==((1,1)if not w%2 else(2,0))
    ordinary=T-min(small_inverse(v,j,T),r+(not exception))
    if T<max(1,j)or ordinary<max(1,v):ordinary=0
    return max(0,min(T-delta-min(theta_low(T,v,u,j),r),ordinary-delta))


def infinite_step(w,k,B):
    caps={(i,u,j,v):infinite_survivor(w,B[INDEX[j,v]],i,u,j,v)
          for j,v in FEATURES for i in range(v+1)for u in range(j+1)}
    return tuple(k+max([0]+[caps[x]for x in OPTIONS[c,e]])for c,e in FEATURES)


def initial(k):
    m=k//2
    return ((0,)*9,(m,)*9,(0,0),(m,m))


def advance_infinite(w,k,Z):
    return (infinite_step(w,k,Z[0]),infinite_step(w,k,Z[1]),
            base.physical_infinite(w,k,Z[2]),base.physical_infinite(w,k,Z[3]))


def normal(w,B):
    if any(B[INDEX[c,e]]!=B[INDEX[c,0]]for c,e in FEATURES):return False
    a,b,c=(B[INDEX[j,0]]for j in range(3))
    return a==c-1 and b==c if not w%2 else a==b and c-a in(0,1)


def entry(w,k):
    assert w>=6 and k>w//2 and k>=4
    A=(w//2+4)**2;Z=initial(k);trace=[Z]
    while min(min(row)for row in Z)<A or not all(normal(w,B)for B in Z[:2]):
        Z=advance_infinite(w,k,Z);trace.append(Z)
        assert len(trace)<=4*A+20,(w,k,Z)
    first=advance_infinite(w,k,Z)
    assert advance_infinite(w,k,first)==base.translated(Z,2*k-w)
    M=max(max(row)for state in trace+[first]for row in state)
    g=gcd(w,2*k-w)
    return dict(w=w,k=k,A=A,entry_day=len(trace)-1,entry=Z,next_entry=first,
                safe_h=M+max(A,k+4),length_period=2*(2*k-w)//g,
                solo_shift=2*w//g,full_shift=4*w//g)


def advance(w,n,k,Z):
    def model(B):
        out=er.step(w,n,k,dict(zip(FEATURES,B)))
        return tuple(out[f]for f in FEATURES)
    P=base.advance(w,n,k,((0,-1,-1),(0,0,0),Z[2],Z[3]))
    return model(Z[0]),model(Z[1]),P[2],P[3]


def bounds(w,n,k,keep_trace=False):
    h=w*n//2
    if k>=h:
        t=1 if k>=2*h else 2
        return dict(w=w,n=n,k=k,lower=t,upper=t,gap=0)
    Z=initial(k);Z=(Z[0],tuple(min(x,h-4+c+e)for(c,e),x in zip(FEATURES,Z[1])),*Z[2:])
    low=up=None;t=0;trace=[]
    while low is None or up is None:
        B,C,X,Y=Z
        if keep_trace:trace.append(Z)
        if low is None and B[-1]==h:low=2*t-int(Cprev[-1]==h)
        if up is None:
            candidates=[]
            if max(X)==h:candidates.append(2*t)
            if max(Y)==h:candidates.append(2*t+1)
            if candidates:up=min(candidates)
        if low is not None and up is not None:break
        Cprev=C;Z=advance(w,n,k,Z);t+=1
        assert t<4*w*n
    out=dict(w=w,n=n,k=k,lower=low,upper=up,gap=up-low)
    assert low<=up,out
    if keep_trace:out['trace']=trace
    return out


def all_lengths(w,k,parity):
    e=entry(w,k);n0=base.threshold(e,parity);P=e['length_period']
    nmin=w+(w%2!=parity)
    rows=[bounds(w,n,k)for n in range(nmin,n0+P,2)]
    a=bounds(w,n0,k,True);b=bounds(w,n0+P,k,True)
    t=e['entry_day'];q=e['solo_shift'];shift=w*P//2
    assert a['trace'][t]==e['entry']==b['trace'][t]
    assert b['trace'][:t+1]==a['trace'][:t+1]
    assert len(b['trace'])==len(a['trace'])+q
    assert b['lower']==a['lower']+e['full_shift']
    assert b['upper']==a['upper']+e['full_shift']
    for original,later in zip(a['trace'][t:],b['trace'][t+q:]):
        assert later==base.translated(original,shift)
    gap=max(x['gap']for x in rows)
    return dict(w=w,k=k,parity=parity,first_stable_length=n0,length_period=P,
                entry=e,checked_lengths=len(rows),maximum_gap=gap,
                witnesses=[x for x in rows if x['gap']==gap],rows=rows)


if __name__=='__main__':
    cutoff=int(sys.argv[1])if len(sys.argv)>1 else 4
    source=json.loads((HERE/'comparison-complete-widths.json').read_text())
    cases=[x for x in source['results']if x['maximum_gap']>cutoff]
    start=time.process_time();rows=[]
    for row in cases:
        out=all_lengths(row['w'],row['k'],row['parity']);rows.append(out)
        print(out['w'],out['k'],out['parity'],row['maximum_gap'],out['maximum_gap'],flush=True)
        result=dict(status='PASS',scope=__doc__,baseline_gap_cutoff=cutoff,
                    refined_lines=len(rows),needed_lines=len(cases),
                    CPU_seconds=time.process_time()-start,
                    remaining_maximum_gap=max([cutoff]+[x['maximum_gap']for x in rows]),results=rows)
        (HERE/'comparison-band9-refinement.json').write_text(json.dumps(result,indent=2)+'\n')

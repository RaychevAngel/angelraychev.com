"""All-length two-day bounds on the five remaining >3-day panel lines."""
from pathlib import Path
import json,time,hashlib
import comparison_tail_envelope as env
import comparison_periodic as base
import comparison_tail_seed_certificate as seeded
import comparison_two_sided_certificate as bridge
from bridge_corner_frontier import step
HERE=Path(__file__).resolve().parent


def line(w,k,J,H,parity):
    tail=env.run(w,k,H,parity);V=tail['envelope_seed']
    head=env.head_envelope(w,k,J,parity,tail['nref']);d=head['defects']
    nmin=tail['nmin'];r=w//2;e=seeded.seeded_entry(w,k,V)
    M=e['safe_h']-max(r*r+1,k+2)
    e['safe_h']=max(e['safe_h'],M+max(d)+1,k*(J+H)+1)
    onset=base.threshold(e,parity);P=e['length_period'];rows=[]
    for n in range(nmin,onset+P,2):
        h=w*n//2;B=(0,-1,-1)
        for _ in range(J+H):B=step(w,n,k,B)
        assert B[2]<h,('windows overlap',w,n,k,J,H)
        z=bridge.meet_bounds(w,n,k,J,H,V,d)
        rows.append({a:b for a,b in z.items()if a!='trace'})
        assert z['gap']<=2,z
    for n in range(onset,onset+P,2):
        a=bridge.meet_bounds(w,n,k,J,H,V,d);b=bridge.meet_bounds(w,n+P,k,J,H,V,d)
        t=e['entry_day'];shift=w*P//2;days=e['solo_shift']
        assert a['trace'][t]==e['entry']==b['trace'][t]
        assert b['trace'][:t+1]==a['trace'][:t+1]
        assert len(b['trace'])==len(a['trace'])+days
        for old,new in zip(a['trace'][t:],b['trace'][t+days:]):
            assert new==base.translated(old,shift)
        assert b['lower']==a['lower']+e['full_shift']
        assert b['upper']==a['upper']+e['full_shift']
    slope,upper_constant={44:(22,-631),46:(46,-1607),47:(94,-3681)}[w]
    assert all(x['lower']==slope*x['n']+upper_constant-2 and
               x['upper']==slope*x['n']+upper_constant for x in rows)
    return dict(w=w,k=k,J=J,H=H,parity=parity,tail=tail,head=head,entry=e,
                onset=onset,period=P,maximum_gap=max(x['gap']for x in rows),
                checked_lengths=len(rows),rows=rows)


def run():
    st=time.process_time();rows=[]
    for w,H in((44,48),(46,80),(47,80)):
        for p in((0,1)if w%2==0 else(0,)):
            x=line(w,24,H,H,p);rows.append(x)
            print(w,p,x['onset'],x['checked_lengths'],x['maximum_gap'],flush=True)
    files=['comparison-envelope-proof.md','comparison_tail_envelope.py',
           'comparison_envelope_certificate.py','comparison-two-sided-proof.md',
           'comparison_two_sided.py','comparison_two_sided_certificate.py',
           'comparison_tail_seed.py','comparison_tail_seed_certificate.py',
           'comparison_periodic.py','root_dual_interval.py','root_interval.py',
           'root_capacity.py','lower-dual-radius-resets.md']
    result=dict(status='PASS',scope=__doc__,maximum_gap=2,
                CPU_seconds=time.process_time()-st,results=rows,
                source_sha256={x:hashlib.sha256((HERE/x).read_bytes()).hexdigest()for x in files})
    (HERE/'comparison-envelope-certificate.json').write_text(json.dumps(result,indent=2)+'\n')
    return result


if __name__=='__main__':
    r=run();print({k:v for k,v in r.items()if k not in('results','source_sha256')})

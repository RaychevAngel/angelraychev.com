"""Bounded certificate attempt for the remaining width64 three-day lines.

Combines each existing BAND9 all-length lower with the accepted common
head/tail envelope, never discarding an earlier stronger bound.
"""
from pathlib import Path
import json,time,hashlib
import comparison_tail_envelope as env
import comparison_periodic as base
import comparison_tail_seed_certificate as seeded
import comparison_two_sided_certificate as bridge
from bridge_corner_frontier import step
HERE=Path(__file__).resolve().parent


def inherited(row,n):
    d={a['n']:a for a in row['rows']};n0=row['first_stable_length'];P=row['length_period']
    j=max(0,(n-n0)//P);q=n-j*P;a=d[q]
    shift=j*row['entry']['full_shift']
    return a['lower']+shift,a['upper']+shift


def line(candidate,old):
    w,k,p,H=(candidate[a]for a in('w','k','parity','H'));J=H
    tail=env.run(w,k,H,p);V=tail['envelope_seed']
    head=env.head_envelope(w,k,J,p,tail['nref']);d=head['defects']
    nmin=tail['nmin'];r=w//2;e=seeded.seeded_entry(w,k,V)
    M=e['safe_h']-max(r*r+1,k+2)
    e['safe_h']=max(e['safe_h'],M+max(d)+1,k*(J+H)+1)
    onset=max(base.threshold(e,p),old['first_stable_length']);P=e['length_period'];rows=[]
    assert P==old['length_period']
    for n in range(nmin,onset+P,2):
        h=w*n//2;B=(0,-1,-1)
        for _ in range(J+H):B=step(w,n,k,B)
        assert B[2]<h,('windows overlap',w,n,k,J,H)
        z=bridge.meet_bounds(w,n,k,J,H,V,d)
        priorL,priorU=inherited(old,n);assert priorU==z['upper']
        row={a:b for a,b in z.items()if a!='trace'}
        row['bridge_lower']=row['lower'];row['inherited_lower']=priorL
        row['lower']=max(row['lower'],priorL);row['gap']=row['upper']-row['lower'];rows.append(row)
    for n in range(onset,onset+P,2):
        a=bridge.meet_bounds(w,n,k,J,H,V,d);b=bridge.meet_bounds(w,n+P,k,J,H,V,d)
        t=e['entry_day'];shift=w*P//2;days=e['solo_shift']
        assert a['trace'][t]==e['entry']==b['trace'][t]
        assert b['trace'][:t+1]==a['trace'][:t+1]
        assert len(b['trace'])==len(a['trace'])+days
        for oldstate,new in zip(a['trace'][t:],b['trace'][t+days:]):
            assert new==base.translated(oldstate,shift)
        assert b['lower']==a['lower']+e['full_shift']
        assert b['upper']==a['upper']+e['full_shift']
    return dict(w=w,k=k,J=J,H=H,parity=p,tail=tail,head=head,entry=e,
                onset=onset,period=P,maximum_gap=max(x['gap']for x in rows),
                checked_lengths=len(rows),rows=rows)


def run(cap_seconds=120):
    st=time.process_time();rows=[]
    candidates=json.loads((HERE/'comparison-minimized-candidates.json').read_text())['results']
    old=json.loads((HERE/'root-band9-two-day-screen.json').read_text())['results']
    lookup={(x['w'],x['k'],x['parity']):x for x in old}
    files=['comparison_remaining_panel.py','comparison_tail_envelope.py',
           'comparison-envelope-proof.md','comparison_two_sided_certificate.py',
           'comparison_tail_seed_certificate.py','comparison_periodic.py',
           'root_dual_interval.py','root_interval.py','root_capacity.py']
    for candidate in candidates:
        key=tuple(candidate[z]for z in('w','k','parity'))
        try:x=line(candidate,lookup[key])
        except AssertionError as error:
            x=dict(w=key[0],k=key[1],parity=key[2],failed_premise=repr(error))
        rows.append(x);print(key,x.get('maximum_gap'),x.get('failed_premise'),flush=True)
        result=dict(status='COMPLETE'if len(rows)==len(candidates)else'PARTIAL',scope=__doc__,
                    CPU_seconds=time.process_time()-st,needed_lines=len(candidates),
                    checked_lines=len(rows),results=rows,
                    source_sha256={f:hashlib.sha256((HERE/f).read_bytes()).hexdigest()for f in files})
        (HERE/'comparison-remaining-panel.json').write_text(json.dumps(result,indent=2)+'\n')
        if time.process_time()-st>cap_seconds:break
    return result


if __name__=='__main__':
    r=run();print({k:v for k,v in r.items()if k not in('results','source_sha256')})

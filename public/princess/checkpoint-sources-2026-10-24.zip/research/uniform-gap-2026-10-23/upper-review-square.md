# Independent review: full square-root-bin localization and static dual band

24 October 2026 UTC. Accepted as ordinary mathematics. No Lean claim.

This review covers the localization theorem, its identity-merger rule,
and the static dual `u=1` consequence in `lower-wide-square.md`, together
with the corresponding interval-reset and survivor-cap implementations.
It does not review the widened two-event temporal flag in the last section.

## Geometric localization

The argument really applies to the entire interval `(r-1)^2<q<=r^2`,
provided the observed corner counts are `(i,j)=(1,0)` and `2<=r<b`.
It is essential to retain both observations. The unique component with
the own corner has capacity `u^2`; every other component has capacity
at most `v(v-1)` and surplus at least two. The convex endpoint bound
in the note excludes any such other component. The subcritical high
alternative is unavailable because `h>=2b^2` and `r<b`. Connectedness,
the established genuine-quadrant separator, and the layer shadow count
then give radius `2r-2` about the observed corner. The radius argument
concerns the original support, rather than a compressed replacement.

The stronger reset remains an identity merger. With two positive
original surpluses, both are strictly below r. Two small components
cannot overlap in positive merged size; a mixed pair has merged size
at most `(r-1)^2`; two high components have too few total holes.
The only remaining partner is original-full-to-full. Thus the selected
corner and reset transfer without choosing an anchor for an arbitrary
synthetic support.

## Static dual rule

For target features `(j,v)=(1,2)`, the holes have one own corner and no
outgoing corner. With closed surplus r and the stated hole interval,
the localization theorem forces equality in the complement-neighborhood
bound. Their second neighborhood contains the anchor and cannot contain
the other corner of its color: its radius is at most `2r`, below the
minimum possible distance `2b`. Hence the complement of their first
neighborhood has precisely one eroded corner. Adding the source's own
corners does not alter erosion of opposite corners on these boards.
This proves the physical `u=1` rule.

For synthetic merger, `J=1,V=2` forces target feature pairs `(1,2)` and
`(2,2)`. Their high capacities are respectively `F10(s)=s^2` and
`F00(s)=C2(s)<=s(s-1)`. A positive closure slack leaves total reduced
surplus at most r-1 and cannot produce more than `(r-1)^2` holes.
With zero slack and two positive reduced surpluses, the two endpoint
bounds in the note give the same contradiction. A zero reduced-surplus
partner is closed-full and must be the target `(2,2)` component. Its
original size is `h-2+i`, so the retained upper state capacity forces
its erosion count to be two. The other component's erosion is one;
the merged value is therefore `(1+2-2)_+=1`.

The implementation's wrong-u cap
`q<=T-(v-i)-r-1` is exactly the exclusion of closed surplus at most r.
Smaller closed surpluses were already impossible by the P/F bounds:
the high capacity is below the hole count and the low capacity cannot
fit the large closed support. The cap is nondecreasing in T within
and between square-root bins. At the first subcritical bin, the old
profile already imposes the cap required for entry. Thus the initial
interval and nine-threshold arguments are preserved.

## Computational attack and implementation checks

`upper-review-square.py` enumerated 10,134,804 candidate hole supports
on both physical colors of 6x6, 6x7, 7x8, and 8x8 boards. Candidates
were restricted only by the observed corner counts, never by radius.
All 156 qualifying events had the required surplus, radius, second
neighborhood corner count, and dual erosion count. This is supplementary
evidence for the proof, not a uniform proof by enumeration.

The interval verifier `upper-review-pronic.py` now independently
enumerates all eight combinations of partial-pronic, critical-pronic,
and wide-square switches. It compares labeled edge unions against
literal q and T loops. Its JSON receipt identifies the checked sources.

The extra static band is inactive whenever holes are at least the
periodic proof's A. In the high tail it depends only on the hole count,
which is invariant under the stated length/time translation. Therefore
it preserves the unflagged BAND9 periodic reduction, with no assertion
about periodicity of paired-radius or temporal-history models.

# A uniform one-solo-day comparison is the next target

24 October 2026 UTC. Focused restart note. No theorem below is claimed
unless explicitly identified as an already accepted transfer consequence.
No new numerical search was run for this assessment.

## Desired conclusion

For every even-area rectangle `4<=w<=n` and every feasible constant budget
`k>floor(w/2)`, let `P(w,n,k)` be the smaller of the two physical solo
prefix capture clocks. Let `tau_M` be the full-start solo capture clock
of the accepted dual-radius nine-feature necessary model. The concrete
candidate is

    tau_M >= P-1.                                       (C)

This concerns full initial uncertainty. It does not assert that the model
is within one physical day from every partial state, nor that every model
path is physically attainable. The previously falsified pointwise
partial-state comparison must not be reused as a proof of (C).

The accepted guarded-merger bound gives `T>=2*tau_M-1`. The physical
prefix upper `U` is either `2P-1` or `2P`: its half-budget seed lies between
the zero seed and the first full-budget update, so it saves at most one
full-game day. Therefore (C) would give

    U-T <= 3 always, and U-T <= 2 when U is odd.

To obtain gap two also when `U=2P`, it is enough to prove the following
extra central condition: if `tau_M=P-1`, its minimum preterminal size
`f` satisfies `2f>k`. The stronger merger conclusion would then be
`T>=2*tau_M=2P-2`. This is a distinct obligation; the head/tail transfer
alone discards the central saving information.

## Exact head/tail inequality sufficient for (C)

Choose positive horizons `J,H`. They may depend on all three parameters.
Use an already accepted solo lower clock `tau_0` to certify

    J+H < tau_0 <= tau_M.                               (G)

The weaker convenience check `h>k(J+H)` is not required. Put `h=wn/2`.
Let `D_c` be the largest head deficit `h-a` among `J`-step M-reachable
states whose occupied-corner count is `c`, maximizing over erosion and
radius coordinates. Let `V_H(c)` be the largest size admitted by an
accepted H-step tail relaxation started with no radius information.
It can be the existing three-corner paired model, or a stronger separately
validated tail model with remaining features maximized out. Unreachable
corner types are omitted. Let `F` be the accepted ordinary three-corner
backward operator.

For the accepted three-corner dual model M3, the accepted two-sided
transfer implies

    tau_M >= J+H+min{t>=0: exists c, F^t(V_H)_c >= h-D_c}.

For an M9 head this additionally uses projection/nesting: nine-feature
states deliberately omit some positive feature/cardinality lower bounds,
while the three-corner graph retains them. The explicit proof in
`lower-nine-projection.md` is now independently accepted in
`upper-review-nine-projection.md`. It projects the retained survivor
corner count to `min(i,q)`, uses the one-corner Lipschitz inequality for
the ordinary inverse bound, and checks every current radius trigger.
The independent audit checked 333,936 corner inequalities and 2,269,668
labeled edges, including 15,536 nontrivial survivor-count clamps. Thus
an M9 head may now feed the accepted ordinary middle and three-corner
tail under matching reset settings. This is an explicit new projection
argument, not an inference silently attributed to the earlier transfer.

Set `m=P-J-H-2`. For `m>=0`, the following single inequality is therefore
sufficient for (C):

    max_c {D_c + F^m(V_H)_c} <= h-1.                   (HT)

Indeed no meeting occurs by middle time m; the meeting time is at least
`m+1`, and the resulting total is at least `P-1`. Horizon monotonicity of
the ordinary backward frontiers makes checking time m sufficient.
If `m<0`, condition (G) already gives the desired bound directly.

This is a uniform **boundary comparison target**, not a restatement that
requires solving the entire dual-nine graph. It asks whether bounded
head and tail information, propagated by the already understood ordinary
middle, leaves one room of separation at one explicitly chosen horizon.
It remains unproved over arbitrary w,k,n. A finite panel of widths does
not establish it.

## What an actual affine middle would simplify

Write `d=2k-w`. Suppose the tail-seeded ordinary trajectory has entered
the accepted middle normal form after e steps, and every step through
time m remains in its valid affine range. Write

    m-e=2s+p,  p in {0,1},
    E_p=F^(e+p)(V_H).

Then the accepted two-step translation gives exactly

    F^m(V_H)=E_p+s*d.

Thus (HT) becomes the bounded-dimensional arithmetic inequality

    max_c(D_c+E_p,c) + s*d <= h-1.                    (AHT)

There are only three corner coordinates and two day parities. The hard
part is bounding their jointly relevant offsets uniformly in width and
budget, not evaluating the middle recurrence. At the minimum odd-width
budget d=1; an uncontrolled error of even O(w) rooms would produce an
unbounded time gap. A coarse additive geometric estimate is therefore
insufficient precisely in the most important regime.

Do not apply (AHT) merely because the board is large. It requires `m>=e`
and that the relevant trajectory really stays between the boundary
regimes. Near-square boards can have overlapping low/high regimes and no
such middle. They remain an infinite parameter family as w varies.

## Choosing horizons without hiding the short-board problem

A useful long-board rule is to increase H until the tail-seeded ordinary
frontier enters its middle normal form, and increase J until all relevant
head-deficit coordinates have passed the high-boundary region. The known
finite inverse formulas make these stopping tests explicit; constant
choices such as `J=H=2w` are not essential. Retain (G) throughout.

If the needed windows would overlap, one must use (HT) with the exact
finite-board F, stop at the last disjoint windows allowed by (G), or prove
a direct full-start comparison for the overlapping regime. The finite-
board wrapper already accepts the ordinary-clock guard (G), which is
often much less restrictive than an area/budget bound. It does not by
itself guarantee that useful disjoint windows always exist. Proving that
the chosen windows work, including the overlap alternative, is part of
the universal lemma rather than a license to defer infinitely many short
boards to fixed-width computations.

## What complementation does and does not buy

On the actual board, holes evolve as `H'=E(H union I)`. Backward guaranteed-
capture regions instead obey `W=I union E(Wnext)`. Reversing inspection
order relates the two constructions with a first/last inspection shift.
This explains why entry and exit should be studied together, and why the
new high-side resets are the appropriate counterparts of low-side corner
localization. The exact antipodal identity now expresses both in the same
two radius coordinates.

However, complementing an arbitrary relaxed scalar transition does not
prove a reverse physical transition or a reverse model edge. Moreover,
`D_c` is a maximum over head histories and `V_H(c)` a maximum over tail
histories; their maximizing shapes, radius labels, and phases may be
incompatible. Both relaxations increase the left side of (HT). Their
errors do not cancel merely because one was called a head error and the
other a tail error. Any cancellation claim needs an inequality for the
coupled feature/phase offsets, or retained compatibility information.

## Two concrete proof routes

**1. Prove the coupled boundary-offset inequality, with phase retained.**
Work with the six values `D_c+E_p,c`, not with the independently largest
head and tail coordinates. Derive their increments as the square/pronic
bands are crossed, using the now accepted eroded-corner constraints and
the high/low reset identities. The physical prefix clocks provide the
comparison at the same day parity. The target is (AHT), with at most one
solo-day deficit and with constants measured in units of `d`, not an
O(w) room error. A successful telescoping argument must charge each cheap
phase change to an ensuing corner restriction; the new dual reset supplies
the missing entry charge, while low resets supply the exit charge. The
very first falsification target is whether some coupled offset violates
(HT) although (C) remains true; that would identify information lost by
forgetting the radii at the junction, rather than refute (C).

**2. Keep the cross-boundary lens only when the boundary windows overlap.**
If route 1 loses too much, retain the two radius labels at one junction
instead of replacing the head by independent size maxima. A high reset
certifies an inner hole triangle; after l moves its guaranteed radius
contracts by l. A low reset certifies an outer support ball. Their joint
area is already bounded by the literal ball-intersection capacity used
by M. Thus the head and tail cannot freely select incompatible corners.
Seek a stopped-path inequality: any purported capture by day `P-2`
must either spend enough days in the affine middle or encounter a state
whose size exceeds its mandatory lens capacity. This directly targets
full-start capture and includes short boards, without trying to compare
every partial state. It introduces no new geometric state: the accepted
two radii, occupied corners, and eroded corners are already sufficient
to state the proposed obstruction. What remains is a uniform charge/
stopping argument over arbitrary radius bands and budgets.

The first route is simpler and directly compatible with the new two-sided
transfer. The second addresses a precise possible failure of its maximum-
only junctions. Neither requires proving physical attainment of relaxed
paths, and neither is currently an established uniform small-gap theorem.

## Unbounded-width assessment and a useful weaker target

The available failed invariants do not refute (C). The three-day lead at
width 44 was a BAND9 backward threshold for a partial state, without the
new persistent dual history. The 245-room lead at width 500 likewise
rules out a constant-room pointwise comparison, not a constant number
of full-start capture days. Conversely, the completed dual-nine fixtures
do not prove (C) outside their stated parameters. No counterexample to
(C) has been identified in the existing evidence examined for this note.

There is a fixed finite number of *algebraic branch types* in the
square/pronic inverse formulas. There is not a fixed finite number of
root bins as width varies: their radius index runs up to b. Nor is there
an established bound on the number of relevant crossings in an arbitrary
model path. Therefore merely reducing each local transition to a square
or pronic case does not complete an unbounded-width proof.

In particular, bounding the advantage separately in each bin cannot by
itself give a constant day gap. There can be arbitrarily many bins. Even
a one-room local error can be comparatively expensive where the physical
drift is `k-r`; at minimum budget the reciprocal drifts range like
`1,1/2,...,1/b`. Summing such local estimates can give a harmonic bound
rather than an absolute constant. This is a warning about a proof
strategy, not a construction of a path realizing those independent errors.

The missing combinatorial ingredient is consequently a **global accounting
rule for phase/orientation advantage**: a shortcut earned in one bin must
either be paid back in a later bin or consume a uniformly bounded initial/
terminal credit. The new high and low radius resets, and their shared lens
capacity, are the currently available mechanism that can enforce such a
rule. A scalar independent estimate at each bin throws that mechanism away.

A weaker all-width theorem would already be substantial. For any fixed
nonnegative integer C, the candidate

    tau_M >= P-C

would give `U-T<=2C+1` always, and `U-T<=2C` when U is odd. Its sufficient
head/tail inequality under the same nonoverlap guard is exactly

    max_c {D_c + F^(P-J-H-C-1)(V_H)_c} <= h-1,          (HT_C)

when the exponent is nonnegative; otherwise the guard gives the desired
clock comparison directly. Thus **C=2** is a concrete fallback target:
a uniform five-day bracket, improved to four whenever the prefix upper
is odd. It requires checking the same coupled inequality one ordinary
middle step earlier than (HT). C=3 would give seven/six days, so a uniform
six-day statement at even upper values would additionally need a central
residual improvement. No such constant-C theorem is proved by this note.

The next analytic pass should therefore try to prove (HT_C), first for
C=1 but allowing C=2, through one bin-independent phase-credit invariant.
The invariant must retain the actual radius ages and corner/erosion
features when boundary windows overlap. If an allowed symbolic cycle
can earn repeatable positive credit without violating a reset or lens,
that would instead provide a genuine obstruction to the chosen model
proving a constant gap and identify exactly which extra history is missing.
Either outcome would address arbitrary widths; another fixed-width
certificate would not settle this question.

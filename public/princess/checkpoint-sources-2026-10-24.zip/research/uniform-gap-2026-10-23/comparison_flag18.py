"""Prefix-closed backward relaxation of the accepted closed-hole history model.

Prototype: full lower is inherited only via explicit clock domination by
the accepted flagged necessary model, not physical attainment.
"""
from pathlib import Path
import importlib.util,sys,json,time
from math import isqrt
import comparison_periodic as base
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('flag18_band9',HERE/'lower-band9.py')
er=importlib.util.module_from_spec(spec);spec.loader.exec_module(er)
FEATURES=er.FEATURES
OPTIONS={(c,e):[(i,u,j,v)for i in range(c+1)for u in range(e+1)
               for j in range(u,3)for v in range(i,3)if i>=max(0,c+v-2)]
         for c,e in FEATURES}


def make_step(w,n,k):
    h=w*n//2;r=w//2;prefix={}
    for j,v in FEATURES:
        for i in range(v+1):
            for u in range(j+1):
                no=[0]*(h+1);yes=[0]*(h+1)
                for T in range(1,h-4+j+v+1):
                    Q=er.survivor(w,n,T,i,u,j,v)
                    d=h-T;s=isqrt(d)+int(isqrt(d)**2<d)
                    event=(j,v)==(1,2)and 2<=s<r and s*(s-1)<d<=s*s
                    q=T-(v-i)-s if event else -1
                    flagq=q if 0<q<=Q else 0
                    nonq=Q-int(event and q==Q and Q>0)
                    no[T]=max(no[T-1],nonq);yes[T]=max(yes[T-1],flagq)
                for T in range(max(1,h-3+j+v),h+1):
                    no[T]=no[T-1];yes[T]=yes[T-1]
                prefix[i,u,j,v]=(no,yes)
    def step(B):
        out={}
        for c,e in FEATURES:
            no=max([0]+[prefix[x][0][B[x[2],x[3],0]]for x in OPTIONS[c,e]])
            yes=max([0]+[prefix[x][1][B[x[2],x[3],1]]for x in OPTIONS[c,e]])
            out[c,e,0]=min(h-4+c+e,k+max(no,yes))
            out[c,e,1]=min(h-4+c+e,k+no)
        return out
    return step


def bounds(w,n,k):
    assert w>=6 and k>=4 and w*n%2==0
    start=time.process_time();h=w*n//2
    step=make_step(w,n,k)
    B={(c,e,f):0 for c,e in FEATURES for f in(0,1)}
    C={(c,e,f):min(k//2,h-4+c+e)for c,e in FEATURES for f in(0,1)}
    t=0
    while B[2,2,0]<h:
        Cprev=C;B=step(B);C=step(C);t+=1
    L=2*t-int(Cprev[2,2,0]==h)
    old=base.bounds(w,n,k)
    return dict(w=w,n=n,k=k,solo=t,lower=L,upper=old['upper'],gap=old['upper']-L,
                CPU_seconds=time.process_time()-start)


if __name__=='__main__':
    rows=[]
    for case in sys.argv[1:]or['44,44,24','44,45,24','46,46,24']:
        row=bounds(*map(int,case.split(',')));rows.append(row);print(row,flush=True)
    Path(__file__).with_suffix('.json').write_text(json.dumps(dict(scope=__doc__,rows=rows),indent=2)+'\n')

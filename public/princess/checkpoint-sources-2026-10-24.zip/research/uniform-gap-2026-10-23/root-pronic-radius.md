# Wider pronic radius resets on every even-area rectangle

24 October 2026 UTC. Ordinary proof building on existing localization and
critical equality results. No new Lean claim. Implemented as optional
`pronic_interval` and `critical_pronic` switches in `root_interval.py`.

Let w<=n, wn even, w>=4, b=floor(w/2), h=wn/2. A transition has survivor
U of size q, own-corner count i, target N(U) with own-corner count j,
and original surplus s=|N(U)|-q.

The paired-radius model may impose both additional rules:

1. For 2<=s<b, if i=0,j=1 and (s-1)(s-2)<q<=s(s-1), the target lies
   within radius 2s-2 of its unique corner. Reset relative-color-zero
   radius to at most 2s-2. This includes every partial pronic interval,
   rather than only the equality q=s(s-1).
2. For s=b, if i=0 and q=b(b-1), surplus b forces j=1 and the same
   radius 2b-2. This extends the exact pronic reset to the critical radius.

## Physical interval proof

The existing odd-width argument in `bridge-lower-frontier-terminal-family.md`
extends verbatim below the critical radius to every even-area board.
Here are the premises making that extension legitimate. Since s<b,
h>=2b^2>2s^2. Split U into components connected by sharing a neighbor.
Their neighborhoods are disjoint, their nonnegative surpluses sum to s,
and each has no own corner. Their target sizes are at most q+s<=s^2,
so the large branch of the subcritical corner dichotomy is impossible.
Each component therefore has area at most s_i(s_i-1), with s_i>=2.

Two nonempty components have total area at most (s-2)(s-3)+2,
which is at most (s-1)(s-2); for s=2,3 two components are impossible.
Thus U is connected. The genuine corner-quadrant separation from the
subcritical proof puts it in one quadrant, based at its observed unique
outgoing corner. There is no compression assumption on U.

Its occupied odd diagonals have distances 1,3,...,2L-1 with no gaps.
The disjoint upper shadows contribute at least one extra cell per diagonal,
and the corner itself contributes one more. Thus surplus>=L+1, so L<=s-1.
Every survivor cell has distance<=2s-3 and its neighborhood has
radius<=2s-2. This proves rule1.

Rule2 is the previously proved uniform critical pronic equality theorem
`research/resumed-odd-even-pronic-all-radii.md`. Its full equality analysis
covers even squares, even nonsquares, and odd-width/even-length boards.
The first neighborhood has radius2b-2 in every case. Its second-neighborhood
corner count is allowed to differ at the critical even endpoint; this
radius rule imposes no incorrect zero-corner assertion there.

## Guarded-merger formation, including the critical endpoint

A reset of the synthetic merged transition is an identity merger. Suppose
otherwise that both component original surpluses are positive. They sum
to s<=b and are therefore individually subcritical.

For the interval rule J=1 implies j1+j2=3, so both outgoing counts are
positive. A small component has survivor size at most s_l(s_l-1), hence
at most (s-1)(s-2)<q. A merged survivor cannot exceed either component
survivor, contradiction. For the critical exact rule the same observation
applies, since q=s(s-1) and its forced outgoing count is one.

If both components use their large branches, the sum of their target-hole
sizes is at most s1^2+s2^2<=s^2-2s+2<s^2. But the merged target is at
most s^2, so its holes are at least h-s^2>=s^2. Contradiction, including
h=2b^2 and s=b: the strict inequality is on the component-sum side.

A zero-surplus component consequently exists. The positive merged-survivor
guard excludes an empty survivor there; the accepted zero-surplus profile
forces the component survivor and target full. Since its source has size
at most h, its inspection cost is zero too. The other component is
identical to the merged transition and receives the identical radius reset.

The accepted coordinatewise-minimum radius invariant and paired-capacity
inclusion-exclusion proof now apply unchanged. Intersecting these resets
with the old model preserves its full-game lower-bound interpretation.
This proves new uniformly applicable restrictions, not a uniform constant
gap between lower and upper clocks.

## Initial comparison

On81x82 at k41 the frozen baseline was[1603,1607]. Re-evaluating its old
paired model gives1604; rule2 then gives1605. Rule1 alone gives1604 there.
Thus the final[1605,1607] comparison includes one day from evaluating the
existing model and one from the new critical reset. These are not claimed
to be a theorem about every width or every length. Neither rule changes
28-square or46-square in the corner-only paired model; their improvements
come from the separate erosion-band refinement.

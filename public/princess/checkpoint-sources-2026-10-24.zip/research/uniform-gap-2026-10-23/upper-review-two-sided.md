# Independent review: two-sided bounded histories

24 October 2026 UTC. Accepted ordinary proof and exact evaluator review.
No Lean claim and no unrestricted-width constant-gap claim.

## Clock transfer

The head is evaluated in the accepted dual-radius model. The tail uses
the earlier paired model with unknown radii, a relaxation of that dual
model. If `h>k(J+H)`, every full capture path is long enough to split into
the first J steps, a middle, and the final H steps. The actual first
junction has size at least the recorded minimum for its corner count;
the actual second junction is admitted by the tail seed after radii are
forgotten. Therefore the ordinary middle can only reach the relaxed
meeting test earlier than the full paired path. The offset `J+H` and
the accepted merged-model inequality give the stated full-game lower
bound. There is no new doubling assumption and no inferred physical
attainability of a relaxed head/tail match.

The exact-J head equals the union of states reachable within J: pad any
shorter path with full-state self-loops at the beginning. Thus global
seen-state pruning in the head evaluator is sound. Even the inclusion
alone would suffice for the necessary bound; equality explains the
reported exact head extrema.

The later `finite_board` wrapper replaces `h>k(J+H)` by the weaker
verified condition that the ordinary necessary model cannot capture
within J+H steps. This is sufficient because its clock is no larger
than the dual paired-model clock. It evaluates both head and tail on
the specified board and invokes no length-stabilization assumption.

## Stable head and periodic meeting test

The condition `h-kJ>r(r+1)` excludes all low resets and makes the low
ordinary inverses inactive throughout the head, including survivors.
Every remaining radius is `D-delta` with `0<=delta<=2r-2`. Its complement
is a small antipodal ball of radius delta-1. Under `n>=4r`, small balls
at different long ends are disjoint; all same-end interactions depend
only on width, the bounded radii, and fixed length parity. Hence capacity
deficits and corner capacities stabilize, as do all scalar transitions.
This proves stabilization of the whole relevant head graph, not just
its output minima.

The previous tail theorem supplies a stable seed and horizon-monotone
ordinary backward frontiers. The additional area margin
`h>M0+max(head_defects)` is necessary for the generic insertion proof:
it excludes a meeting before the common middle entry and throughout
the inserted middle blocks. This condition was explicitly added during
review. Afterward both sides of every meeting comparison translate by
the same amount. The ordinary first-hit clock therefore obeys the same
period as the physical prefix upper clock, with the fixed J+H offset.

## Independent implementation attack

`upper-review-two-sided.py` compares42 literal exact-time head frontiers
against the interval evaluator on six boards and horizons zero through
six. The literal version uses neither interval compression nor
earliest-visit pruning. It also checks2,202 literal near-full ball-capacity
transport cases across width and length parities. All passed.

`upper-review-two-sided-certificate.json` independently reproduces the
complete numerical certificate for width24 and budget13: both stable
parity representatives, their exact translated tails, and all76 shorter
lengths24 through99. Together with the reviewed ordinary proof, this
establishes

    T_13(24,n)=24n-369,   every n>=24.

The reusable advance is the bounded-head/ordinary-middle/bounded-tail
transfer theorem. The exact displayed family is a certified application;
it does not by itself establish exactness for other widths or budgets.

"""Small literal audit of antipodal radii and the two exact dual seeds.

This checks constructed physical events, every corner and phase on the
listed small rectangles, plus capacity inequalities. It is not a search
for capture strategies and does not replace the general proof.
"""
from pathlib import Path
import json


def F(i,j,s):
    if s<i+2*j:return -10**9
    if j:return i+2*j-2+(s-i-2*j+2)*(s-i-2*j+1)
    if i:return i-1+(s-i+1)**2
    return max(s*(s-1)//2,s*(s-2))


def G(i,j,s):
    return max(F(2-j,d,s-2+i+d) for d in range(3-i))


def audit():
    complement_checks=pronic_seeds=square_seeds=capacity_checks=0
    for w in range(4,25):
        for n in range(w,w+6):
            if w*n%2:continue
            cells={(x,y) for x in range(w) for y in range(n)}
            color=[{z for z in cells if sum(z)%2==p} for p in (0,1)]
            corners={(0,0),(w-1,0),(0,n-1),(w-1,n-1)}
            h=w*n//2;b=w//2;D=w+n-2
            def N(S):
                return {(x+dx,y+dy) for x,y in S for dx,dy in ((1,0),(-1,0),(0,1),(0,-1)) if (x+dx,y+dy) in cells}
            for C in corners:
                anti=(w-1-C[0],n-1-C[1])
                def dist(z,c):return abs(z[0]-c[0])+abs(z[1]-c[1])
                for p in (0,1):
                    for R in range(-1,D+1):
                        inner={z for z in color[p] if dist(z,C)<=R}
                        outer={z for z in color[p] if dist(z,anti)<=D-R-1}
                        assert color[p]-inner==outer,(w,n,C,p,R)
                        complement_checks+=1
                    for r in range(2,b+1):
                        d=(sum(C)-p)%2
                        if d!=1:continue
                        U={z for z in color[p] if dist(z,C)<=2*r-3}
                        S=color[1-p]-N(U);A=N(S)
                        assert len(U)==r*(r-1) and len(S)==h-r*r
                        assert A==color[p]-U and len(A)-len(S)==r
                        assert len(A&corners)==2 and len(S&corners)==1
                        assert all(dist(z,anti)<=D-2*r+2 for z in A)
                        assert (sum(anti)-p)%2==(1^(D%2))
                        pronic_seeds+=1
                    for r in range(2,b):
                        d=(sum(C)-p)%2
                        if d:continue
                        U={z for z in color[p] if dist(z,C)<=2*r-2}
                        S=color[1-p]-N(U);A=N(S)
                        assert len(U)==r*r and len(S)==h-r*(r+1)
                        assert A==color[p]-U and len(A)-len(S)==r
                        assert len(A&corners)==1 and len(S&corners)==2
                        assert all(dist(z,anti)<=D-2*r+1 for z in A)
                        assert (sum(anti)-p)%2==D%2
                        square_seeds+=1
    for s in range(1,101):
        for i in range(3):
            assert G(i,2,s)<=s*(s-1)
            capacity_checks+=1
        assert G(2,1,s)==s*s
        assert G(2,2,s)==max(s*(s-1)//2,s*(s-2))
        capacity_checks+=2
    for r in range(2,101):
        for s in range(1,r):
            assert s*(s-1)+(r-s)*(r-s-1)<r*(r-1)
            assert s*s+max((r-s)*(r-s-1)//2,(r-s)*(r-s-2))<r*r
            capacity_checks+=2
    return dict(passed=True,boards="4<=w<=24, w<=n<=w+5, even area",complement_checks=complement_checks,
                constructed_high_pronic_events=pronic_seeds,constructed_high_square_events=square_seeds,
                capacity_checks=capacity_checks,scope=__doc__)


if __name__=='__main__':
    result=audit()
    Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

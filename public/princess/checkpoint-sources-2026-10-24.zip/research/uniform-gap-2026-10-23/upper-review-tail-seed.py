"""Independent unpruned literal forward audit of bounded paired-model starts."""
from pathlib import Path
from functools import lru_cache
from math import isqrt
import sys,random,json,time,hashlib
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'src'));sys.path.insert(0,str(Path(__file__).parent))
from bridge_corner_frontier import survivor_bound
from comparison_tail_seed import model,seed

def literal_model(w,n,k,partial,critical,wide):
    h=w*n//2;b=w//2;D=w+n-2
    cells=[(x,y)for x in range(w)for y in range(n)if(x+y)%2==0]
    corners=[(0,0),(w-1,0),(0,n-1),(w-1,n-1)]
    own=[v for v in corners if sum(v)%2==0]
    opposite=[v for v in corners if sum(v)%2]
    @lru_cache(None)
    def capacity(R,S):
        counts=[(sum(x+y<=R and abs(x-ax)+abs(y-ay)<=S for x,y in cells),sum(x+y<=R and abs(x-ax)+abs(y-ay)<=S for x,y in own))for ax,ay in opposite]
        return max(z[0]for z in counts),max(z[1]for z in counts)
    @lru_cache(None)
    def successors(a,c):
        out=set()
        if a<=k:out.add((0,0,-1,-1))
        for q in range(max(1,a-k),a+1):
            for i in range(max(0,c-(a-q)),min(c,q)+1):
                for j in range(3):
                    for T in range(max(1,j),h-2+j+1):
                        if survivor_bound(w,n,i,j,T)<q:continue
                        s=T-q;which=radius=-1
                        if i==1 and j==0 and 2<=s<b and ((s-1)**2 if wide else s*(s-1))<q<=s*s:which,radius=1,2*s-1
                        if i==0 and j==1 and 2<=s<b and(q==s*(s-1)or(partial and(s-1)*(s-2)<q<=s*(s-1))):which,radius=0,2*s-2
                        if critical and i==0 and j==1 and s==b and q==b*(b-1):which,radius=0,2*b-2
                        out.add((T,j,which,radius))
        return out
    def captures(a,c,H):
        current={(a,c,D,D)}
        # Deliberately no size pruning, earliest-visit cache, or interval union.
        for day in range(H+1):
            if any(x[0]==0 for x in current):return True
            if day==H:return False
            following=set()
            for a,c,R,S in current:
                nr,ns=min(D,S+1),min(D,R+1)
                for T,j,which,radius in successors(a,c):
                    x=min(nr,radius)if which==0 else nr
                    y=min(ns,radius)if which==1 else ns
                    cap,cc=capacity(x,y)
                    if T<=cap and j<=cc:following.add((T,j,x,y))
            current=following
        raise AssertionError
    return captures

started=time.process_time();rng=random.Random(202610243);checks=0;boards=[]
for w,n in [(4,4),(4,5),(5,6),(6,6),(6,7),(8,8)]:
    k=w//2+1;h=w*n//2
    for partial,critical,wide in [(False,False,False),(True,False,True),(False,True,False),(True,True,True)]:
        literal=literal_model(w,n,k,partial,critical,wide)
        for H in (1,2,3,4):
            actual=model(w,n,k,H,pronic_interval=partial,critical_pronic=critical,wide_square=wide)
            for _ in range(12):
                c=rng.randrange(3);a=rng.randrange(c,h-2+c+1)
                assert actual(a,c)==literal(a,c,H),(w,n,k,H,partial,critical,wide,a,c)
                checks+=1
    boards.append([w,n])
    print({'board':[w,n],'checks':checks},flush=True)
sources=[Path(__file__),Path(__file__).with_name('comparison_tail_seed.py'),Path(__file__).with_name('root_interval.py'),Path(__file__).with_name('root_capacity.py'),Path(__file__).with_name('comparison-tail-seed-proof.md')]
out=dict(status='PASS',literal_unpruned_horizon_start_checks=checks,boards=boards,CPU_seconds=time.process_time()-started,source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in sources})
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print(out)

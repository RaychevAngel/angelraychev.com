# Independent review: nine-feature to three-corner path projection

Accepted 24 October 2026 UTC as an ordinary algebraic proof, for the current
matching radius-reset switches. No new Lean claim.

The one-sided estimate
`B(i,j,T) >= B(i+1,j,T)-1` is valid for the complete ordinary survivor bound,
including the validity cutoffs and both critical-width exceptions. In the
low inverse, adjacent own-corner counts increase the affine term by one
while the clipped root term decreases by at most one; the special zero
corner term has the required one-unit comparison directly. The high inverse
and critical cap have the same one-unit property. Clipping above at
`h-2+i` preserves it. A positive bound at `i+1` is at least `i+1`, so the
lower cardinality cutoff does not destroy the estimate.

For a reached nine-feature source, `a>=c` follows inductively from the
ordinary closed-survivor constraint on its incoming edge. Consequently
`i*=min(i,q)` satisfies the original deletion charge: both `c-i` and `c-q`
are at most the actual number of inspections. The closed-survivor bound
and the one-sided estimate give `B(i*,j,T)>=q`. The only clamped positive
case is `q=1,i=2,v=2`; positivity of `B(2,j,T)` strengthens it to at least
two, and hence `B(1,j,T)>=1`.

With matching switches, every admitted nine-feature reset is the same as
its three-corner reset; extra feature restrictions can only remove the
edge. The clamped case creates no new low-square reset because its inferred
square radius is one, creates no low-pronic reset because `i*=1`, and lies
below every high-reset size. Capacities and valid state upper bounds only
relax when erosion information is forgotten. Thus the projection retains
the sizes, occupied corner counts, and both radius coordinates.

This proves `tau_M3 <= tau_M9` from the full state. It also allows a head
computed in the current nine-feature model to be connected to the accepted
three-corner ordinary middle and paired-radius tail. This is a consolidation
lemma, not a new numerical capture-time bound by itself.

Independent audit `upper-review-nine-projection.py` checks 333,936 ordinary
one-sided corner inequalities for widths 4 through 40, all nearby lengths
of even area, and every target size. It also checks 2,269,668 admitted
labelled edges across widths 4 through 12 and all four critical-pronic /
wide-square switch settings. Among these, 15,536 use the nontrivial clamped
survivor case. The deletion-charge arithmetic passed 16,877,824 checks.
The source-hashed receipt is `upper-review-nine-projection.json`.

The scope is deliberately tied to the current ordinary survivor bound and
matching reset definitions. Future added three-corner resets need a new
compatibility check. The temporal closed-hole flag is not used here.

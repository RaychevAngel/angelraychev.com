# Proposed bounded-tail transfer of the paired-radius lower bound

24 October 2026 UTC. Research proposal, not an implemented or accepted new
bound. Its purpose is to combine the stronger existing paired-radius tail
with the proved all-length reduction of the simpler corner recurrence.

## Construction and exact obligation

Fix an even-area board, a budget, and a tail horizon `H`. For each corner
count `c`, let `V_j(c)` be the largest support size from which the accepted
paired-radius necessary model, initialized with unknown radii `(D,D)`, can
reach its capture state in at most `j` steps, for `0<=j<=H`. Taking the
largest size is a deliberate relaxation: no unproved downward-closure
property is needed if all starts are evaluated. The prefix-closed seed is
all valid `(a,c)` with `a<=V_j(c)`.

For horizons above `H`, propagate `V_H` by the accepted ordinary
three-corner backward operator. For horizons below `H`, use `V_j` (or an
explicitly weaker necessary seed). Let `tau_tail` be the first resulting
horizon at which the full support `(h,2)` is allowed. Then

    tau_tail <= tau_paired,

where `tau_paired` is the first capture horizon of the existing full
paired-radius necessary model initialized at `(h,2,D,D)`.

Indeed any paired capture path of length at least `H` projects to ordinary
corner transitions until its last `H` steps. At that junction, replacing
its radius certificates by unknown `(D,D)` can only enlarge its possible
continuations: all capacity tests are monotone in both radii, and movement
and reset updates preserve that order. Its junction size is therefore
below `V_H(c)`. A shorter paired path is covered by the corresponding
`V_j`. The ordinary backward operator propagates this inclusion.

The accepted full paired-model lower theorem already gives
`T>=2*tau_paired-1`. Thus the transfer gives the valid full lower

    T>=2*tau_tail-1.

This argument does **not** infer a full two-cohort lower bound from an
arbitrary single-cohort lower bound. It explicitly uses domination by the
existing merger-closed paired model, whose full-game interpretation was
proved in `research/all-budget-2026-10-23/lower-lens.md`.

## Early-horizon trap

It is unsafe to start the new clock at day `H` without checking smaller
horizons. That would falsely lower-bound already capturable small boards
by `H`. Two safe implementations are:

1. Compute all tail seeds `V_j`, `j<=H`, along with `V_H`.
2. Use this transfer only when a separately proved lower bound exceeds
   `H`; for example `h>kH` suffices because the even-area board has a
   perfect matching and a single-cohort support can decrease by at most
   `k` per day. Treat all shorter boards by existing evaluators.

The second route is especially convenient for a uniform all-length theorem:
the below-onset lengths are explicitly finite for each `(w,k,H)`.

## Computing the seed

A fast forward paired evaluator with arbitrary starting `(a,c,D,D)` can
test the predicate. Binary search is justified only after proving that the
predicate is downward closed in `a` for fixed `c`; finite examples are not
a proof. Without that lemma, evaluate all valid starts up to `min(h,kH)`.
The bound `a<=kH` follows from the perfect-matching size inequality, so no
larger start can be captured by day `H`.

Alternatively, a reverse augmented-state dynamic program can compute all
three maxima simultaneously. A prefix-closed *output* is sound regardless
of gaps in the actual winning sets, but imposing prefix closure on internal
radius states requires its own argument.

An analogous family of seeds with terminal size at most `floor(k/2)` can
potentially recover the central-day improvement, but the exact logical
comparison with the accepted paired midpoint test must be checked. The
`2*tau_tail-1` version is the first safe milestone.

## How this could become an all-length improvement

The special resets have bounded low-corner radii and arise only at support
sizes bounded in terms of width. Within a fixed `H`-day tail, every finite
radius is therefore bounded in terms of `(w,H)`. On sufficiently long
boards all interactions involving the far end disappear, while local
same-end capacities stabilize. This should make the seeds independent of
length within each admissible parity once an explicit onset is proved.

Once the seed is length-independent, the periodic-insertion proof applies
to the ordinary recurrence started from it. Its normal form and growth
arguments do not depend on the original zero seed. Below that onset one
keeps the finitely many direct evaluations. A first implementation can
instead verify stable seed formulas without asserting any stronger result.

## Explicit candidate stabilization lemma

The following supplies a concrete route to the local-capacity obligation;
it still needs independent review against the exact reset graph.

Put `Rmax=2r-3+H`. The special subcritical reset radius is at most `2r-3`.
After at most `H` moves every finite radius is therefore at most `Rmax`;
the initially unknown radius remains the symbol infinity until reset.
Any paired-model path captured within `H` days has size at most `kH` at
every time, because each step decreases size by at most `k`. Therefore it
suffices to retain sizes `0..kH` and radii

    infinity, 0,1,...,Rmax.

The `H`-day unknown-radius seeds should be identical for all lengths of a
fixed admissible parity satisfying

    n-1 > 2*Rmax,
    h >= kH+r^2+1,
    n>=w.

Reason: the second inequality removes every high inverse and board-size
cap from the relevant corner transitions. In the paired capacities,
balls of finite radius cannot meet both long ends under the first
inequality. Single finite-ball counts stabilize on the half-infinite
width-w strip. For even width, an opposite-colored anchor on the same
short end remains available and the far-anchor lens is empty. For odd
width and even length, both own-colored corners lie on one short end and
both opposite-colored corners on the other; a two-finite-radius lens is
empty. The finite-radius corner capacities stabilize for the same reason.
The `(infinity,infinity)` area bound is the full half-area `h`, irrelevant
on retained sizes at most `kH`; its corner bound stays two. Radius updates
and reset labels are consequently independent of length after replacing
`D` by the infinity symbol.

This is a finite augmented graph depending on `(w,k,H)` and length parity,
with no claim about optimal physical supports. If verified, its backward
winning sets provide all `V_j` simultaneously and make the seed-transfer
route fully independent of length. It still remains to evaluate the seeds
and check how much improvement survives the three-threshold relaxation.
No universal small constant gap is claimed.

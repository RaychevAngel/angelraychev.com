"""Candidate universal even-area nine-feature lower recurrence.

Only subcritical refined P/F geometry is used at even widths. At critical
reduced surplus use the already accepted three-corner dichotomy on the
corner-closed survivor. Proof review pending; not a published bound yet.
"""
import sys,json,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'src'))
sys.path.insert(0,str(ROOT/'research/all-budget-2026-10-23'))
from bridge_lower_frontier_nine import theta_low,theta_high
from bridge_corner_frontier import survivor_bound
from audit_named_bounds import bounds

FEATURES=[(c,e)for c in range(3)for e in range(3)]
OPTIONS={}
for c,e in FEATURES:
    OPTIONS[c,e]=[(i,u,j,v,c-i+e-u)for i in range(c+1)for u in range(e+1)
                  for j in range(u,3)for v in range(i,3)if i>=max(0,c+v-2)]

def survivor(w,n,T,i,u,j,v):
    if T<=0:return 0
    h=w*n//2;r=w//2;delta=v-i
    # Refined dichotomy below the critical width; relax at/above it.
    threshold=min(theta_low(T,v,u,j),theta_high(h-T,2-j,2-v),r)
    # Accepted critical ordinary dichotomy, applied to closed survivor.
    ordinary=survivor_bound(w,n,v,j,T,critical=True)
    q=min(T-delta-threshold,ordinary-delta,h-4+i+u)
    return max(0,q)

def step(w,n,k,B):
    h=w*n//2
    caps={(i,u,j,v):survivor(w,n,B[j,v],i,u,j,v)
          for j,v in FEATURES for i in range(v+1)for u in range(j+1)}
    return {(c,e):min(h-4+c+e,k+max([0]+[caps[i,u,j,v]
            for i,u,j,v,cost in OPTIONS[c,e]if cost<=k]))for c,e in FEATURES}

def run(w,n,k,compare=True):
    assert w>=4 and w<=n and w*n%2==0 and k>w//2
    h=w*n//2
    if k>=h:
        T=1 if k>=2*h else 2
        return dict(w=w,n=n,k=k,lower=T,upper=T,gap=0)
    B={f:0 for f in FEATURES}
    C={f:min(k//2,h-4+sum(f)) for f in FEATURES}
    tau=0
    while B[2,2]<h:
        Cprev=C
        B=step(w,n,k,B);C=step(w,n,k,C);tau+=1
        assert tau<4*w*n
    L=2*tau-int(Cprev[2,2]==h)
    out=dict(w=w,n=n,k=k,tau=tau,lower=L)
    if compare:
        old=bounds(w,n,k);out.update(basic_lower=old['lower'],upper=old['upper'],gap=old['upper']-L,improvement=L-old['lower'])
        assert L<=old['upper'],out
    return out

if __name__=='__main__':
    start=time.process_time()
    cases=[(16,16,15),(20,20,12),(24,24,13),(24,25,13),(28,28,15),(46,46,24),(108,108,55),(25,26,13),(31,32,16),(81,82,41),(129,130,65)]
    rows=[]
    for case in cases:
        row=run(*case);rows.append(row);print(row,flush=True)
    result=dict(scope=__doc__,rows=rows,cpu_seconds=time.process_time()-start)
    Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')

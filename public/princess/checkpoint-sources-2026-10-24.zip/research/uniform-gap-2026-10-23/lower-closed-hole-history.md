# A closed-hole localization flag on every even-area rectangle

24 October 2026 UTC. New ordinary argument submitted for independent
review. No new Lean theorem. This note does not assert physical attainment
of a relaxed-model path or a uniform numerical bound gap.

## Statement

Let w<=n, wn even, w>=4, b=floor(w/2), h=wn/2. Use the existing
maximal-survivor erosion features (a,c,e). For a transition from A with
survivor S, put q=|S|, (i,u)=(c(S),e(S)), T=|N(S)|, and
(j,v)=(c(N(S)),e(N(S))). Its original surplus is ell=T-q, its
corner-closed surplus is sigma=ell-v+i.

Call a transition a **closed-hole event** if

    (j,v)=(1,2),  2<=sigma<b,
    sigma(sigma-1)<h-T<=sigma^2.

No assumption i=2 is imposed. In particular events with i=1 and positive
corner-closure delta v-i are included.

**Claim.** Two consecutive transitions of a physical cohort cannot both
be closed-hole events. In the weakened maximal/closed erosion relaxation,
this one-bit history rule is preserved by the guarded merger. Both claims
apply to every even-area rectangle; only subcritical localization is used.

This strictly generalizes the trigger in the earlier strict-near-square
history note: its first trigger required i=2, hence delta=0. It is a
mathematical strengthening of that necessary rule, not yet a statement
that a capture-time bound improves.

## Physical proof

Let U be the holes of the first event's target, and write r for that
event's closed surplus. Since its target erosion count is two, the
neighborhood of U contains no own-colored board corner; U itself contains
exactly one corner. The corner-closure identity gives surplus(U)<=r.
The size inequality r(r-1)<|U|<=r^2 and the unconditional profile give
surplus(U)>=r. Thus it equals r. The existing subcritical near-square
localization theorem puts U in the full r^2-cell triangle T_r about its
one corner. The same statement applies to the next event's holes V with
radius parameter s.

Their corner anchors have opposite physical colors. If adjacent along a
side of even length L, their separation is L-1 and L>=2b. Reflect so U's
anchor is (0,0) and V's is (0,L-1). The neighborhood N(V) lies in

    y-x >= L-2s = 2z,  z=L/2-s>=1,

because s<b. In diagonal x+y=2j of T_r, the number of cells outside this
half-plane is min(2j+1,j+z). Summing gives at least its value at z=1,
namely r(r-1)/2+r. At most r-1 cells of T_r are missing from U, hence

    |U minus N(V)| >= r(r-1)/2+1 >= 2.                 (1)

If the opposite-color anchors are diagonally opposite, their distance
exceeds the sum of the two triangle radii, so U and N(V) are disjoint;
then |U|>r(r-1)>=2 gives the same contradiction more strongly.

On the intervening inspection, the source has (c,e)=(1,2), and the next
target again has v=2. Maximal survivor retention forces i=1. Thus its
original surplus ell and closed surplus s obey ell=s+1. Let I be the
useful inspected cells. Complementation gives N(V) subset U union I.
Since I and U are disjoint,

    |U minus N(V)| <= |U|+|I|-|N(V)| = ell-s = 1,

contrary to (1). This proves the physical history restriction. No
inspection strategy is compressed to a prefix and no orientation of U
or V is assumed in advance.

## Merger formation: full TARGET is enough

Use the existing merger of two feature histories:

    size a=a1+a2-h,
    c=(c1+c2-2)_+, e=(e1+e2-2)_+.

For component transitions use closed sizes x_l=q_l+v_l-i_l and reduced
surpluses sigma_l. The merger identities from the established erosion
proof are

    x = x1+x2-h-eta,
    sigma = sigma1+sigma2+eta, eta>=0.

Suppose the merged transition is a closed-hole event with parameter r.
Its target V=2 forces v1=v2=2. Its target J=1 forces j1+j2=3, so both
j_l are positive. Component reduced surpluses are <=r<b, so their refined
subcritical alternatives apply.

Neither component can use its small branch: with positive outgoing
corner count, P(v_l,u_l,j_l;sigma_l)<=sigma_l(sigma_l-1), giving its
TARGET size <=sigma_l^2<=r^2. Its holes would then be >=h-r^2>r^2,
whereas the two nonnegative component hole sizes sum to D<=r^2.
Thus both use their high branches. Since v_l=2, these give

    d_l <= F_(2-j_l,0)(sigma_l) <= sigma_l^2,
    d1+d2=D>r(r-1).

If eta>0, sigma1+sigma2<=r-1, so D<=(r-1)^2<=r(r-1).
If both sigmas are positive, D<= (r-1)^2+1<=r(r-1).
Both contradict the strict lower bound on D. Consequently eta=0 and
one component has reduced surplus r, the other zero.

At reduced surplus zero its high branch forces j=v=2 and d=0. That
component's TARGET is full. Its original source need not be full: closure
may have supplied a missing source corner. The other component's target
and reduced surplus are exactly those of the merged event; it is therefore
itself a closed-hole event. This proves the required state invariant:

    a flagged merged TARGET is the identical target of one flagged
    component, while the other component TARGET is full.

This is where the earlier stricter trigger was unnecessary. The next-step
argument starts from these targets and requires no full-source assertion
about the previous move.

## Merger inheritance at the next step

At a flagged merged source the two component source features are (1,2)
and (2,2). If the next merged transition were another event, V=2 would
force both component target erosion counts to two. Maximality then forces
survivor corner counts i_flagged=1 and i_full=2. Their closure deltas are
one and zero, and eta=0. The same formation argument says one component
has reduced surplus zero and target full.

It cannot be the flagged component: closed-full support would require
q=h-1, but its flagged source has at least three holes (r>=2 and
D>r(r-1)), so q<=a<=h-3. Hence the other component is the zero-surplus
one, and the flagged component would have two consecutive closed-hole
events, which its own model history forbids. This is a contradiction.

Define the merged flag by its own last transition, resetting it on a
non-event. Formation and inheritance prove guarded-merger preservation.
The usual full-board interpretation still requires the separately checked
solo clearing time and preterminal residual; no doubling assertion follows
from a solo clock alone.

## Implementation and dependencies

`lower-history-lens.py` intersects this flag with the proposed universal
nine-feature erosion model and the accepted paired-radius capacities. The
new flag and all endpoint restrictions are necessary-model constraints.
It uses exact bitset BFS, no interval assumption in the flagged state.

Dependencies are the accepted subcritical P/F capacity theorem,
corner closure, maximal survivor normalization, subcritical near-square
localization, the erosion merger identities, and paired-radius merger.
The extension of the unflagged nine-feature merger to the deliberately
relaxed even-width critical interface is recorded separately; it must be
reviewed before the implemented even-width full lower is accepted.

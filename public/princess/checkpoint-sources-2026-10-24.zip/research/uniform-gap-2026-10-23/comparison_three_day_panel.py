"""Assemble complete all-budget/all-length coverage through width64.

Requires the independent envelope review for mathematical acceptance.
--recheck-band9 reproduces the114 intermediate refinements before assembly.
"""
from pathlib import Path
import json,hashlib,sys
HERE=Path(__file__).resolve().parent


def run(recheck=False):
    base=json.loads((HERE/'comparison-complete-widths.json').read_text())
    band=json.loads((HERE/'root-band9-two-day-screen.json').read_text())
    env=json.loads((HERE/'comparison-envelope-certificate.json').read_text())
    key=lambda x:(x['w'],x['k'],x['parity'])
    B={key(x):x for x in base['results']};R={key(x):x for x in band['results']}
    E={key(x):x for x in env['results']}
    assert set(R)=={z for z,x in B.items()if x['maximum_gap']>2}
    assert set(E)=={z for z,x in R.items()if x['maximum_gap']>3}
    assert len(B)==2494 and len(R)==114 and len(E)==5
    if recheck:
        import comparison_band9 as nine
        for z,old in R.items():
            fresh=nine.all_lengths(*z)
            assert fresh==old,z
    output=[]
    for z,x in B.items():
        candidates=[('original',x['maximum_gap'])]
        if z in R:candidates.append(('BAND9',R[z]['maximum_gap']))
        if z in E:candidates.append(('two-sided envelope',E[z]['maximum_gap']))
        name,gap=min(candidates,key=lambda t:t[1]);assert gap<=3
        output.append(dict(w=z[0],k=z[1],parity=z[2],source=name,maximum_gap=gap))
    inputs=['comparison-complete-widths.json','root-band9-two-day-screen.json',
            'comparison-envelope-certificate.json']
    sources=['comparison_three_day_panel.py','comparison_band9.py','lower-band9.py',
             'lower-history-lens.py','comparison-envelope-proof.md','upper-review-envelope.md',
             'upper-review-envelope-certificate.json','upper-review-envelope-premises.json']
    result=dict(status='PASS',scope='All w<=64, all n>=w, all feasible k; odd-by-odd and widths<=5 retain exact evaluators, budgets above accepted gates retain gap<=1',
                mathematical_review='Accepted in upper-review-envelope.md; all five envelope lines independently reproduced',
                even_area_low_budget_lines=len(output),maximum_gap=3,
                counts={str(g):sum(x['maximum_gap']==g for x in output)for g in range(4)},
                BAND9_recomputed=recheck,results=output,
                input_sha256={x:hashlib.sha256((HERE/x).read_bytes()).hexdigest()for x in inputs},
                source_sha256={x:hashlib.sha256((HERE/x).read_bytes()).hexdigest()for x in sources})
    (HERE/'comparison-three-day-panel.json').write_text(json.dumps(result,indent=2)+'\n')
    return result


if __name__=='__main__':
    r=run('--recheck-band9'in sys.argv)
    print({k:v for k,v in r.items()if k not in('results','source_sha256','input_sha256')})

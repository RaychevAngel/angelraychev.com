# Independent review: universal erosion model and dual near-pronic bands

24 October 2026 UTC. Upper/construction lane source and proof review.

**Accepted:** the universal model in `lower-erosion-proof.md`, including its
ordinary critical interface and paired-radius erosion capacity; and the
subcritical even-width extension of the established near-pronic band filters
in `lower-history-lens.py`. This review does not cover the new closed-hole
history flag, which the root is reviewing separately. It does not assert
attainability of model paths or a uniform absolute gap.

## Universal static model and merger

The original `resumed-erosion-corner-profile.md` already proves refined P/F
geometry below `b=floor(w/2)` on every even-area rectangle with both sides
at least4. Its additional refined critical theorem was narrower. The new
model correctly uses only the universal subcritical theorem, then imposes
the previously accepted ordinary corner dichotomy on the corner-closed
support at the critical boundary. This avoids presuming a refined
critical even-width result from computations.

Corner closure adds exactly v-i own-colored corners, preserves the target
neighborhood and survivor erosion count, and has reduced surplus
`sigma=T-q-v+i`. The existing closure-merger identities are algebraic:
merged sigma is the sum of component reduced surpluses plus nonnegative
slack eta. At merged sigma<b all old capacity arguments therefore apply.
At sigma=b there are precisely two cases:

- Both component reduced surpluses are below b. The same capacity
  algebra proves a merged P/F alternative at b, even though no physical
  critical refined theorem was assumed. Its low side implies the ordinary
  F bound since P<=F; its high side is the term with complementary
  outgoing count `2-v` in the ordinary G maximum.
- One reduced surplus equals b. The other and eta equal zero. A positive
  zero-reduced-surplus closed support cannot satisfy the low branch; its
  high branch forces a full closed support and full target, with both
  target features2. The merged closed support, target features and
  reduced surplus are those of the critical component. Thus its ordinary
  critical condition transfers. It is unnecessary and generally false
  to claim the partner's original source was full.

Above b the ordinary profile is automatically admitted; the feature caps
remain valid. The earlier unconditional size profile also follows from
P/F bounds below b and from the width cap at/above b. Existing coupled
inspection-charge and maximal-retention algebra is unchanged. I checked
that the code retains both critical exceptions on a `2b by(2b+1)` board.

## Nine-threshold evaluation

The new survivor maximum is the minimum of the inverse refined threshold,
the ordinary closed-survivor maximum minus delta, and the fixed upper
feature capacity. Each term is nondecreasing in target size, and admitted
positive survivor sizes form an initial interval. The previous nine-frontier
induction therefore applies. The relaxed model deliberately drops the
positive feature lower bounds; it does not reintroduce them silently via
state enumeration. The separate zero state is retained.

## Why the dual bands extend to even widths

The accepted all-radius and observed-hole-corner proofs use only these
facts below critical radius: `h>2r^2`, the genuine-quadrant separator, and
opposite-colored corners beyond distance `2r-1`. For every even-area board
and `r<b`, all three hold; indeed the shortest side has at least2b cells
and `2b-1>2r-1`. The localization and complement identities thus give the
same required triple `(i,u,v)=(1,2,1)` at original surplus at most r.

The ordinary band uses threshold `max(r(r-1)/2,r(r-2))`. When the target
has erosion v=1, the holes already have exactly one outgoing corner, so
the stronger threshold `(r-1)(r-2)` applies. The code chooses precisely
these thresholds. It includes the previously proved critical odd-width
case but excludes the unproved critical even-width band by requiring
`r<=b-1` at even width.

Merger inheritance is unchanged. A merged band target with J=2 forces
both component target corner counts2. Small branches cannot fit the small
combined hole count. If both original surpluses were positive, their
holes would sum to at most `(r-1)(r-2)`, contrary to either band trigger.
The partner is therefore original-full-to-full and the entire feature
triple transfers. No physical interpretation of an abstract merged support
is used. For an odd critical radius, a critical component with a zero
reduced-surplus partner is handled by the closed-full argument above;
if both original surpluses are positive they are strictly subcritical.

The inverse-filter implementation `cap<=T-r-1` for a wrong triple removes
exactly the forbidden original surpluses at most r. Smaller surpluses were
already ruled out; its target-size monotonicity uses the same band-entry
argument as the accepted nine-threshold proof. It is compatible with the
bitset suffix construction.

## Paired erosion capacities

A corner is eroded by the intersection of two sets precisely when it is
eroded by both. Thus the two-element opposite-corner universe satisfies
the same inclusion-exclusion inequality as the own-corner universe. This
justifies the `(e1+e2-2)_+` merger cap even when the minimum two radii come
from different components. The rectangle's color-preserving reflections
make each one-ball count independent of its anchor within the same color.
Maximizing area, occupied-corner count and erosion count separately over
anchors only weakens the relaxation. The literal histogram uses the
maximum distance of BOTH neighbors of each corner, which is the right
erosion condition.

## Critical exact-pronic filters

I also accept the later `Critical exact-pronic identity formation`
section in `lower-erosion-proof.md`. For the direct trigger, if both
original surpluses are positive, both lie strictly below the critical
radius. Two small components cannot have a positive merged survivor;
a mixed pair bounds that survivor by at most `(r-1)^2`, below `r(r-1)`;
and two high components would require at least `r^2` holes while permitting
at most `r^2-2r+2`. For the dual trigger, outgoing count two forces
both component outgoing counts two, strengthening their combined
high-side hole bound to `(r-1)(r-2)`, below the required `r(r-1)`.
The remaining zero-original-surplus component is full-to-full, so these
are identity mergers. This transfers both the direct radius reset and
the dual triple, including the critical even-square value `kappa=2`.
The strict contradictions remain valid when `h=2r^2`; no strict
`h>2r^2` premise is used there. Physical critical rigidity is supplied
by the previously established all-even-area theorem, rather than
inferred from the symbolic model.

## Independent physical attack

`upper-review-bands.py` enumerates corner-free hole sets and constructs
their actual first and second room neighborhoods, without using capacity
inverses. It checks both physical colors on5x6,6x6,6x7 at radius2, and7x8,
8x8 at radius3. For every band trigger, the surplus equals r, exactly one
outgoing corner occurs, and the second neighborhood contains no original
corner. The retained JSON contains the exact counts. This attacks the
geometric extension; it is not a substitute for the ordinary proof above.

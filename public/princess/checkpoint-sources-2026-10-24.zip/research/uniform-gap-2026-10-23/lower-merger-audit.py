"""Independent explicit static edge-merger audit for the universal erosion model."""
import importlib.util,json,time
from pathlib import Path
sp=importlib.util.spec_from_file_location('h',Path(__file__).with_name('lower-history-lens.py'));h=importlib.util.module_from_spec(sp);sp.loader.exec_module(h)
def audit(w,n,k):
 area=w*n//2;states=[(a,c,e)for a in range(area+1)for c,e in h.er.FEATURES if (a>0 or c==e==0)and a<=area-4+c+e];ids={s:i for i,s in enumerate(states)}
 edges=[];row=[{}for _ in states]
 for aa,(a,c,e)in enumerate(states):
  if a<=k:row[aa][ids[0,0,0]]=a
  for dd,(T,j,v)in enumerate(states):
   if T==0:continue
   for i,u,jj,vv,charge in h.er.OPTIONS[c,e]:
    if(jj,vv)!=(j,v)or charge>k:continue
    cap=h.banded_survivor(w,n,T,i,u,j,v)
    q=min(a-charge,cap)
    p=a-q
    if q>0 and p<=k:row[aa][dd]=min(p,row[aa].get(dd,k+1))
  edges.extend((aa,dd,p)for dd,p in row[aa].items())
 checked=0
 for a,b,p in edges:
  x=states[a];y=states[b]
  for aa,bb,pp in edges:
   if p+pp>k:continue
   xx=states[aa];yy=states[bb]
   if x[0]+xx[0]-area<=k:continue
   source=(x[0]+xx[0]-area,max(0,x[1]+xx[1]-2),max(0,x[2]+xx[2]-2))
   target=(y[0]+yy[0]-area,max(0,y[1]+yy[1]-2),max(0,y[2]+yy[2]-2))
   assert source in ids and target in ids,(source,target)
   assert row[ids[source]].get(ids[target],k+1)<=p+pp,(source,target,p,pp)
   checked+=1
 return dict(w=w,n=n,k=k,states=len(states),edges=len(edges),pairs=checked,passed=True)
if __name__=='__main__':
 started=time.process_time();rows=[]
 for case in[(4,4,3),(4,5,3),(4,6,3)]:
  row=audit(*case);rows.append(row);print(row,flush=True)
  Path(__file__).with_suffix('.json').write_text(json.dumps(dict(rows=rows,cpu_seconds=time.process_time()-started),indent=2)+'\n')

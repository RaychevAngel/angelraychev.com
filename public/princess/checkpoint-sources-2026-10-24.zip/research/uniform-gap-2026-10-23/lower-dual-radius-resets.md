# Dual equality seeds already fit the paired outer-radius model

24 October 2026 UTC. New ordinary proof independently accepted by the
upper/construction lane in `upper-review-dual-high.md`. No new Lean claim. The numerical
effects are separate from the geometric and guarded-merger statements.

Let `4 <= w <= n`, `wn` even, `h=wn/2`, `b=floor(w/2)`, and
`D=w+n-2`. A transition has a one-color survivor `S`, size `q`,
survivor own-corner count `i`, target `A=N(S)`, target own-corner count
`j`, and original surplus `s=|A|-|S|`. All balls and neighborhoods are
taken in the entire physical rectangle. A radius certificate `(d,R)`
means the current support lies in a ball about some board corner whose
color differs from the support color by `d`.

The two results below use only `(q,i,j,s)`. They therefore apply to the
existing three-corner paired-radius relaxation, without an erosion state.

## 1. Inner hole balls and outer support balls are the same certificate

Write `C*` for the diagonally opposite corner to `C`. For every cell `x`,

    dist(x,C) + dist(x,C*) = D.

If `H` is the complement of `A` inside its physical color class, then
for every integer `R`,

    H contains every current-color cell at distance <= R from C
    iff A is contained in the ball of radius D-R-1 about C*.

This follows simply by complementing the inequality `dist(x,C)<=R`.
If `C` has relative color `d`, `C*` has relative color `d xor (D mod 2)`.
Thus an inner hole-ball certificate `(d,R)` is precisely the existing
outer certificate `(d xor (D mod 2),D-R-1)`.

Consequently there is no need to introduce an additional inner-radius
coordinate. A full inner ball is useful even when the corresponding
outer ball has a large radius: its exclusion of a corner triangle
persists through the existing propagation `(d,Rout)->(1-d,Rout+1)`.
Equivalently, holes evolve by `H'=E(H union I)`, so the guaranteed inner
radius decreases by one at each unsuccessful day.

## 2. High-pronic equality reset, including the critical radius

Suppose

    2 <= r <= b,   q=h-r^2,   s=r,   j=2.                 (P)

Then the target `A` has the outer certificate

    (1 xor (D mod 2), D-2r+2).                           (RP)

There is intentionally **no premise on `i`**. The physical conclusion
forces `i=1`, but the safe necessary-model reset can also constrain
otherwise permitted synthetic events with another `i`.

**Physical proof.** Put `U=V_target minus A`. Then
`|U|=r(r-1)`, `c(U)=0`, and `N(U)` is contained in the complement of `S`,
which has size `r^2`. Thus the surplus of `U` is at most `r`. The accepted
unconditional profile makes it at least `r`: its square inverse is `r`,
the width cap is at least `r`, and
`h-r(r-1)>=r(r+1)` makes the complementary inverse at least `r`.
The exact-pronic rigidity theorem therefore applies to `U`: it is the
full odd corner triangle on distance layers `1,3,...,2r-3` about an
opposite-colored corner. This includes `r=b` on even squares and on
even-width nonsquares; the accepted critical rigidity proof is essential
here. By Section 1, this inner ball is exactly (RP).

The rigidity theorem and its critical equality cases are recorded in
`../resumed-odd-even-pronic-all-radii.md`. They imply `i=1` because
`N(U)` is the complete complement of `S` and contains exactly one
source-colored corner. The different second-neighborhood corner counts
at the critical endpoint do not alter the present radius certificate.

## 3. High-square equality reset below the critical radius

Suppose

    2 <= r < b,   q=h-r(r+1),   s=r,   i=2,   j=1.       (S)

Then the target has the outer certificate

    (D mod 2, D-2r+1).                                  (RS)

**Physical proof.** Its hole set `U` has size `r^2` and exactly one own
corner. Since `N(U)` is disjoint from `S`, and `S` includes both corners
of its color, `N(U)` includes no corner of that color. Also
`|N(U)|<=h-q=r(r+1)`, so `U` has surplus at most `r`. The square-interval
localization theorem in `lower-wide-square.md` applies. It places `U`
inside its own-corner ball of radius `2r-2`. This ball has exactly `r^2`
rooms of `U`'s color, with no clipping because `r<b`; hence `U` fills the
ball. Section 1 now gives (RS).

The strict bound `r<b` is retained. No critical high-square reset is
asserted by this proof.

## 4. Identity formation under the guarded merger

Recall the accepted guarded merger of two positive component transitions:

    q=q1+q2-h > 0,       T=T1+T2-h,
    s=s1+s2,            i=max(0,i1+i2-2),
    j=max(0,j1+j2-2).

Every component survivor and target has size at most `h`. In particular
the merged target is no larger than either component target. Each
component original surplus is nonnegative. If both surpluses are
positive in either new trigger, then `1<=s_l<=r-1<b`, so the **subcritical**
`F/G` alternative applies to both. The critical exceptional channels
never enter this argument, even when the merged event has `r=b`.

A small component has `q_l<=F_(i_l,j_l)(s_l)<=s_l^2` and consequently

    T_l <= s_l(s_l+1) <= r(r-1).

This is smaller than the merged target in both triggers. For (P),
`T=h-r(r-1)>=r(r+1)>r(r-1)`. For (S), using `b>=r+1`,
`T=h-r^2>=2(r+1)^2-r^2>r(r-1)`. Therefore both components must be high.

For (P), `j=2` forces `j1=j2=2`. The accepted dual capacities satisfy

    G_(i,2)(u) <= u(u-1),       i=0,1,2, u>=1.           (GP)

Indeed `G_(i,2)(u)=max_{0<=d<=2-i}F_(0,d)(u-2+i+d)`.
The candidates are `C2(u-2+i)` for `d=0`,
`(u-1+i)(u-2+i)` for `d=1` when feasible, and
`2+(u-2)(u-3)` for `i=0,d=2` when feasible. Each is at most
`u(u-1)`; impossible candidates are omitted. Thus the two target-hole
sizes sum to at most

    s1(s1-1)+s2(s2-1) <= (r-1)(r-2) < r(r-1),

contradicting the merged hole size `h-T=r(r-1)`.

For (S), `i=2` forces `i1=i2=2`, and `j=1` forces the pair of target
corner counts to be `(1,2)` in one order. The high capacities are then

    G_(2,1)(u)=u^2,        G_(2,2)(u)=C2(u)<=u^2.

Their total is at most `s1^2+s2^2<r^2`, contradicting the merged target
hole size `r^2`.

Therefore a component has original surplus zero. The accepted
unconditional profile makes a zero-surplus component either empty or
full. The positive merged survivor excludes the empty case. That
component is full-to-full, has both corner counts equal to two, and
uses zero inspections. The merged survivor, target, corner counts, and
surplus are exactly those of the other component. The corresponding
reset event and its radius therefore occur in that component as well.
This is **original** full-to-full identity formation; no assertion about
only a closed support or a full target is being substituted for it.

## 5. Persistent-radius inheritance and implementation rules

The existing merger invariant for each relative color is

    rho_merged[d] >= min(rho_1[d],rho_2[d]).

Propagation preserves it. Both new reset formations are identities by
Section 4, so whichever component supplies the identity event makes the
same radius tightening. Taking minima with other resets preserves the
invariant. The established ball-intersection capacity argument then
applies unchanged, even if different components supply the two relative
color coordinates.

Implementation may therefore add precisely these original-surplus events:

* If `j=2`, `h-q=r^2`, and `2<=r<=b`, tighten coordinate
  `1 xor (D mod 2)` to `D-2r+2` **only at target `q+r`**.
* If `i=2,j=1`, `h-q=r(r+1)`, and `2<=r<b`, tighten coordinate
  `D mod 2` to `D-2r+1` **only at target `q+r`**.

A larger target has larger surplus and is not automatically subject to
either reset. The interval evaluator must retain such targets, and must
also retain a no-reset route to a numerical target when another survivor
size in the same interval legitimately supplies one. These are graph
union obligations, separate from the mathematical reset theorem.

The source of the capacities is `../resumed-even-corner-profile.md`, the
critical physical theorem is `../resumed-even-corner-critical.md`, and
the existing radius/lens merger is in
`../bridge-lower-frontier-corner-reach.md` and
`../bridge-lower-frontier-lens.md`. This note adds necessary history
restrictions; it does not identify a relaxed path as a physical strategy.

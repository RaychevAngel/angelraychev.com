# Comparison lane checkpoint

24 October 2026 UTC. Compared against the frozen 23 October baseline.

**Current accepted endpoint.** Every width at most64, every length, and
every feasible budget has a computable bracket of width at most two,
except `(w,k)=(47,25)` with `n>=52,n=4 mod6` and `(w,k)=(61,32)` with
`n>=64,n=4 mod6`, where this complete family certificate permits three.
Stronger individual evaluations exist even inside those two ranges.
The exact24-row and28-row length families are also established below.
`comparison-final-panel.json` is the final assembled coverage record.
No absolute small-gap theorem over unbounded widths has been proved.
The remaining sections preserve the sequence of accepted improvements.

## What changed

An ordinary proof now gives a computable affine period for both named
three-corner lower and fixed-prefix physical upper bounds, for every
feasible `(w,k)` on even-area rectangles. The proof is
`comparison-periodic.md`; independent review accepted it in
`upper-review-periodic.md`. The period is

    length increment = 2(2k-w)/gcd(w,2k-w),
    full-day increment = 4w/gcd(w,2k-w).

This converts comparisons at a fixed width/budget from samples of lengths
into a finite certificate covering **all** admissible lengths. It does not
establish periodicity of the actual capture time or of stronger radius
models, and it does not prove an absolute small gap across all widths.

The complete panel `comparison-complete-widths.json` covers every width
4 through64 and every feasible budget below the existing uniform one-day
gate. All budgets above that gate already have the accepted one-day
theorem. It contains2494 width/budget/parity lines and50,401 finite length
representatives, including exact translated-tail checks. Runtime was221.68
CPU seconds. Across this panel the named gap is at most7; for width at
most30 it is at most4. Hence these are genuine
all-budget/all-length bounded-width guarantees, not
extrapolations from selected boards. Odd-by-odd boards retain their
separate exact evaluator.

The seven-day named maximum occurs only on `(w,k)=(31,16),(46,24),(47,24)`
in this panel. Existing refinements are stronger on specific examples and
some complete families; they must not be overwritten by the weaker named
bound. In particular the frozen fixtures remain `[495,495]` at31x32,k16
and `[505,509]` at46x46,k24. This comparison lane itself has not tightened
either fixture.

The core recurrence implementation independently matched the frozen
`audit_named_bounds.py` on300 reproducibly selected general inputs.
`comparison_audit.py` reproduces the complete bounded-width panel and
records source hashes.

## Additional diagnostic and next mechanism

`comparison-low-budget-lines.json` covers469 lines at the lowest three
budgets, all widths4..100 plus108,128,129,150,151,200,201. Each line covers
all lengths; the width/budget selection itself is deliberately partial.
The basic named gap reaches8 at width108,minimal budget, where the frozen
paired-capacity lower already improves the square-board gap to4. Thus
simply proving a four-day comparison for the basic recurrence is false.

`comparison-tail-seed-proposal.md` describes how to transfer strengthened
paired-radius terminal calculations into the ordinary three-threshold
recurrence without asserting unproved downward closure. Its key bound is
clock domination `tau_tail<=tau_paired`, preserving the accepted full-game
interpretation. It includes the early-horizon issue and a precise proposed
length-stabilization threshold. The latter's capacity formulas passed
33,276 literal checks on180 boards in
`comparison_tail_capacity_verify.json`. The tail-seed evaluator and its
numerical benefit are not yet established in this lane.

No manuscript, website, Lean source, frozen baseline or earlier research
file was changed. This pass supplies ordinary proofs and computational
receipts; it adds no Lean theorem.

## Subsequent BAND9 strengthening

The same period mechanism extends to the newly accepted universal BAND9
lower. In the common interior, the nine coordinates first lose their
erosion-index dependence and then obey exactly the original three-corner
normal forms. The proof is `comparison-band9-periodic.md`; its independent
review accepted it in `upper-review-band9.md`. The lower model itself was accepted
in `upper-review-erosion.md`.

Refining the eight basic lines whose all-length gap exceeded four took
9.49 CPU seconds. The resulting complete width-at-most64 panel has gap at
most **five**, at every feasible budget and every admissible length. All
those lines have gap at most four except width44,budget24, where both
length parities retain the named five-day gap. The complete certificate
is `comparison-band9-refinement.json`; it includes every finite base up
to the new BAND9 onset, not only the older shorter base.

The attempted18-threshold prefix-closed history refinement did not improve
the44x44,44x45 or46x46 tests. Its prototype and receipt are
`comparison_flag18.py/json`. It is parked as a failed attempt, with no new
accepted theorem claimed from that implementation.

Additional complete-line checks in `comparison-band9-extra-lines.json`
establish

    T_15(28,n)=28n-525 for every n>=28,

including both length parities. This tightens the frozen28x28 bracket
`[257,259]` to the exact value259 and covers the entire length family.
The same receipt extends the four-day brackets at `(w,k)=(108,55)`,
`(81,41)` and `(129,65)` to every admissible length, rather than the
individual frozen fixtures. These extra six parity lines took16.70 CPU
seconds. A further100 reproducibly selected BAND9 evaluations matched the
lower lane's clean wrapper exactly.

## Final four-day panel: the remaining44-row line

The generic bounded-tail transfer is now proved and independently accepted
in `comparison-tail-seed-proof.md` and `upper-review-tail-seed.md`.
It replaces the last H steps of the paired-radius necessary model by an
exactly computed three-corner seed, then propagates that seed with the
ordinary recurrence. Clock domination transfers the accepted full-game
lower bound; no downward closure of the paired winning sets is assumed.
An explicit finite-radius argument proves that the seed is independent
of all sufficiently large lengths.

For w44,k24,H28 the seed is `(309,309,309)`. The long-length certificate
and every shorter length44 through139 prove

    22n-635 <= T_24(44,n) <= 22n-631, for every n>=44.

This closes the sole five-day line in the bounded-width panel. Therefore
the final guarantee is **gap at most four days for every width at most64,
every length, and every feasible budget**, combining the new even-area
certificates with the retained exact odd-by-odd and narrow-board results
and the accepted high-budget theorem. The assembled certificate is
`comparison-four-day-panel.json`. It is a proved upper bound on the
remaining uncertainty, not a claim that the true capture time is four
days away from either bound on any particular input.

Independent validation used1,152 unpruned literal finite-horizon starts,
both exact translated long tails, and all96 short lengths. Earlier
seven-day and five-day panel receipts remain intact as the before states.
No absolute constant has yet been proved over unbounded widths.

## Two bounded histories: complete 24-row family

The generic two-sided transfer is now accepted in
`comparison-two-sided-proof.md` and `upper-review-two-sided.md`.
It retains a bounded initial history in the new dual-radius necessary
model, a bounded terminal history in the paired model, and joins them
through the ordinary three-corner recurrence. Initial histories are
summarized by maximum deficits and terminal histories by maximum winning
sizes; both replacements enlarge the relevant sets. Clock domination
preserves the accepted full-game lower bound. Explicit geometry makes
both boundary summaries independent of all sufficiently large lengths,
and the same periodic insertion theorem covers the middle.

For w24,k13,J=H28, this gives head deficits `(110,111,111)` and terminal
seed `(122,123,123)`. Both long parities and every shorter length24..99
now establish

    T_13(24,n)=24n-369 for every n>=24.

The frozen baseline was the one-day bracket24n-370 through24n-369.
This closes an entire previously unresolved length family. The
all-length certificate took11.19 CPU seconds; independent review
reproduced it and checked62 additional finite-board clock dominations.
The result is an ordinary proof with independently checked finite
certificates, not a new Lean theorem. The generic transfer is not
restricted to width24, even though the exact formula is.

## Accepted three-day panel and uniform length envelopes

The strongest complete bounded-width guarantee is now **at most three
days for every width at most64, every length and every feasible budget**.
This supersedes the earlier four-day guarantee above; it does not assert
an absolute constant over unbounded widths. Its assembled certificate is
`comparison-three-day-panel.json`, generated by
`comparison_three_day_panel.py`. It verifies all2494 original lines,
the114 needed BAND9 refinements, and the five final envelope refinements.
The named maxima are0 on499 lines,1 on1714,2 on260 and3 on21.

The new generic step is `comparison-envelope-proof.md`, independently
accepted in `upper-review-envelope.md`. One relaxed boundary graph takes
capacity envelopes over the finite short-length range and the stable
long capacities. The resulting boundary seeds apply simultaneously to
every length, avoiding a separate full paired calculation for each
short board. A self-consistent deficit guard proves the head transfer;
ordinary necessary thresholds prove the tail transfer. All remaining
middle computations use only the three-corner arithmetic recurrence.

This gives the all-length two-day brackets

    22n-633 <= T_24(44,n) <= 22n-631, n>=44;
    46n-1609 <= T_24(46,n) <= 46n-1607, n>=46;
    94n-3683 <= T_24(47,n) <= 94n-3681, n>=48 even.

The complete certificate and independent reproduction each took about
38 CPU seconds. They recomputed all five parity-line envelopes,245 finite
middle comparisons, and exact translated long tails. The baseline,
seven-day, five-day and four-day receipts remain preserved. Mathematical
coverage has improved; this pass has still added no Lean theorem and
made no publication change.

## Final supplemental refinement and remaining scope

A bounded18-line supplemental batch took92.49 CPU seconds. The same
accepted capacity-envelope argument improved16 additional complete
width/budget/parity lines to gap at most two. Its802 finite middle
comparisons, all boundary guards, and common period shifts passed the
independent source/premise/coverage audit in
`upper-review-remaining-panel.json`; that audit did not repeat the graph
searches. Combining these with the accepted24-row exact result and the
frozen25-row exact result gives the current endpoint stated at the top.

The original `comparison-three-day-panel.json` remains unchanged.
`comparison-final-panel.json` separately records the stronger combined
coverage,502 named exact lines,1714 with gap at most one,276 with gap at
most two, and only two lines whose complete certificates permit three.
On those two lines the larger gap occurs only in the length residue4
modulo6. The rejected horizons and subsequent bounded horizon selection
remain in `comparison-panel-candidates.json` and
`comparison-minimized-candidates.json`; no optimality of the selected
horizon is claimed.

The width47,budget25 failure is currently a weakness of this bounded
head/tail summary: the full three-corner dual model gives a two-day
bracket on its first problematic board47x52. The width61,budget32 first
problematic board61x64 needs more than the full three-corner model for
that improvement; the accepted nine-feature model gives a stronger
individual bracket. Neither example proves an entire exceptional
length family. No further fixed-width search was started after the
bounded batch.

For the unbounded-width objective, the new mechanism reduces all-length
comparison to bounded boundary graphs and a common arithmetic middle,
but proving a uniform constant for those boundary summaries remains
open. Natural next refinements are to retain the erosion feature in
both boundary summaries and their middle, and to track the first time
the necessary model reaches size at most floor(k/2), restoring its
central-day distinction. These are directions, not proved additions.
The research goal across all widths, all lengths and all feasible
budgets has not been declared complete.

"""All-length finite-residue certificate for the named corner/prefix bounds.

The proof is comparison-periodic.md. This does not assert a uniform constant
gap, nor exact physical optimality when the two named bounds differ.
"""
from math import gcd
from pathlib import Path
import sys, json, time

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'src'))
from bridge_corner_frontier import step, small_inverse
from bridge_upper_transport_coupling import physical_erosion, square, pronic
from bridge_upper_transport_odd_coupling import physical_step


def model_infinite(w, k, B):
    r = w // 2
    out = []
    for c in range(3):
        survivors = [0]
        for i in range(c + 1):
            for j in range(3):
                t = B[j]
                if t < max(1, j):
                    continue
                exception = (i, j) == ((1, 1) if w % 2 == 0 else (2, 0))
                q = t - min(small_inverse(i, j, t), r + (not exception))
                if q >= max(1, i):
                    survivors.append(q)
        out.append(k + max(survivors))
    return tuple(out)


def physical_infinite(w, k, X):
    r = w // 2
    if w % 2 == 0:
        # Output p takes erosion phase 1-p.
        return tuple(k + X[1-p] - min(r, square(X[1-p]) if 1-p == 0
                                      else pronic(X[1-p])) for p in (0, 1))
    return (k + X[1] - min(r, pronic(X[1])),
            k + X[0] - min(r+1, square(X[0])))


def initial(k):
    m = k // 2
    return ((0, -1, -1), (m, m, m), (0, 0), (m, m))


def advance_infinite(w, k, Z):
    return (model_infinite(w, k, Z[0]), model_infinite(w, k, Z[1]),
            physical_infinite(w, k, Z[2]), physical_infinite(w, k, Z[3]))


def translated(Z, amount):
    return tuple(tuple(x + amount for x in row) for row in Z)


def advance(w, n, k, Z):
    h = w*n//2
    if w % 2:
        physical = lambda X: physical_step(w//2, h, k, X)
    else:
        physical = lambda X: tuple(min(h,k+physical_erosion(w//2,n,1-p,X[1-p]))
                                    for p in (0,1))
    return (step(w,n,k,Z[0]), step(w,n,k,Z[1]), physical(Z[2]), physical(Z[3]))


def entry(w, k):
    assert w >= 4 and k > w//2
    r=w//2
    A = r*(r+1)+1
    Z = initial(k)
    trace = [Z]
    while True:
        normal = (lambda B: B[0] == B[2]-1 and B[1] == B[2]) if not w%2 else (
            lambda B: B[0] == B[1] and B[2]-B[0] in (0,1))
        if min(min(row) for row in Z) >= A and all(normal(B) for B in Z[:2]):
            break
        Z = advance_infinite(w,k,Z)
        trace.append(Z)
        assert len(trace) <= 4*A+20, (w,k,Z)
    first = advance_infinite(w,k,Z)
    assert advance_infinite(w,k,first) == translated(Z,2*k-w)
    M = max(max(row) for state in trace+[first] for row in state)
    safe_h = M+max(r*r+1,k+2)
    g = gcd(w,2*k-w)
    return dict(w=w,k=k,A=A,entry_day=len(trace)-1,entry=Z,next_entry=first,
                safe_h=safe_h,length_period=2*(2*k-w)//g,
                solo_shift=2*w//g,full_shift=4*w//g)


def bounds(w,n,k,keep_trace=False):
    h=w*n//2
    assert n>=w and w*n%2==0 and k>w//2
    if k>=h:
        t=1 if k>=2*h else 2
        return dict(w=w,n=n,k=k,lower=t,upper=t,gap=0)
    Z=initial(k)
    Z=(Z[0],tuple(min(x,h-2+c) for c,x in enumerate(Z[1])),*Z[2:])
    low=up=None; t=0; trace=[]
    while low is None or up is None:
        B,C,X,Y=Z
        if keep_trace: trace.append(Z)
        if low is None and B[2]==h:
            low=2*t-int(Cprev[2]==h)
        if up is None:
            candidates=[]
            if max(X)==h: candidates.append(2*t)
            if max(Y)==h: candidates.append(2*t+1)
            if candidates: up=min(candidates)
        if low is not None and up is not None: break
        Cprev=C; Z=advance(w,n,k,Z); t+=1
        assert t<4*w*n
    out=dict(w=w,n=n,k=k,lower=low,upper=up,gap=up-low)
    if keep_trace: out['trace']=trace
    return out


def threshold(e,parity):
    w=e['w']
    n=max(w,(2*e['safe_h']+w-1)//w)
    return n+(n%2!=parity)


def all_lengths(w,k,parity,check_insertion=True):
    """Exact worst gap of these named bounds over all n>=w of given parity."""
    assert w%2==0 or parity==0
    e=entry(w,k); n0=threshold(e,parity); period=e['length_period']
    nmin=w+(w%2!=parity)
    rows=[bounds(w,n,k) for n in range(nmin,n0+period,2)]
    if check_insertion:
        a=bounds(w,n0,k,True); b=bounds(w,n0+period,k,True)
        t=e['entry_day']; shift=w*period//2; days=e['solo_shift']
        assert a['trace'][t]==e['entry']==b['trace'][t]
        assert b['trace'][:t+1]==a['trace'][:t+1]
        assert b['lower']==a['lower']+e['full_shift']
        assert b['upper']==a['upper']+e['full_shift']
        assert len(b['trace'])==len(a['trace'])+days
        for original,later in zip(a['trace'][t:],b['trace'][t+days:]):
            assert later==translated(original,shift)
    return dict(w=w,k=k,parity=parity,first_stable_length=n0,
                length_period=period,solo_shift=e['solo_shift'],
                full_shift=e['full_shift'],entry=e,
                checked_lengths=len(rows),maximum_gap=max(x['gap'] for x in rows),
                witnesses=[x for x in rows if x['gap']==max(y['gap'] for y in rows)],
                rows=rows)


if __name__=='__main__':
    started=time.process_time(); cases=[]
    limit=int(sys.argv[1]) if len(sys.argv)>1 else 16
    for w in range(4,limit+1):
        for k in range(w//2+1,w+1):
            for parity in ((0,1) if w%2==0 else (0,)):
                row=all_lengths(w,k,parity)
                cases.append(row)
                print(w,k,parity,row['first_stable_length'],row['maximum_gap'],flush=True)
    result=dict(status='PASS',scope=__doc__,cases=len(cases),
                checked_lengths=sum(x['checked_lengths'] for x in cases),
                CPU_seconds=time.process_time()-started,results=cases)
    Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')

"""Recover one shortest model path; never assert physical realizability."""
import importlib.util,json
from pathlib import Path
sp=importlib.util.spec_from_file_location('el',Path(__file__).with_name('lower-erosion-lens.py'));m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)

def witness(w,n,k):
 h=w*n//2;D=w+n-2
 states,ids,rows=m.graph(w,n,k);A,C=m.capacities(w,n);E=m.erosion_capacities(w,n);cache={}
 def allowed(pair):
  if pair not in cache:
   x,y=pair;a,c,e=A[x][y],C[x][y],E[x][y]
   cache[pair]=sum(1<<z for z,(aa,cc,ee)in enumerate(states)if aa<=a and cc<=c and ee<=e)
  return cache[pair]
 front={(D,D):1<<ids[h,2,2]};seen=dict(front);zero=1<<ids[0,0,0];levels=[front]
 while not any(x&zero for x in front.values()):
  following={}
  for(r0,r1),source in front.items():
   pair=(min(D,r1+1),min(D,r0+1));events={}
   for a in m.bits(source):
    for key,mask in rows[a].items():events[key]=events.get(key,0)|mask
   for(d,R),mask in events.items():
    new=list(pair)
    if d>=0:new[d]=min(new[d],R)
    new=tuple(new);mask&=allowed(new)
    if mask:following[new]=following.get(new,0)|mask
  front={pair:mask&~seen.get(pair,0)for pair,mask in following.items()if mask&~seen.get(pair,0)}
  for pair,mask in front.items():seen[pair]=seen.get(pair,0)|mask
  levels.append(front)
 target=ids[0,0,0];pair=next(pair for pair,mask in front.items()if mask&zero);out=[]
 for t in range(len(levels)-1,0,-1):
  bit=1<<target;found=None
  for prev,mask in levels[t-1].items():
   if found:break
   for a in m.bits(mask):
    if found:break
    for(d,R),dest in rows[a].items():
     if not dest&bit:continue
     nxt=[min(D,prev[1]+1),min(D,prev[0]+1)]
     if d>=0:nxt[d]=min(nxt[d],R)
     if tuple(nxt)==pair:found=(prev,a,(d,R));break
  assert found
  prev,a,event=found
  source=states[a];dest=states[target];choices=[]
  if dest[0]:
   aa,c,e=source;T,j,v=dest
   for p in range(min(k,aa-1)+1):
    q=aa-p
    for i,u,jj,vv,charge in m.er.OPTIONS[c,e]:
     if(jj,vv)!=(j,v)or charge>p:continue
     if q<=m.er.survivor(w,n,T,i,u,j,v):choices.append((p,i,u,T-q))
  out.append(dict(day=t,source=source,target=dest,event=event,radii_before=prev,radii_after=pair,choices=choices))
  pair=prev;target=a
 return list(reversed(out))
if __name__=='__main__':
 path=witness(46,46,24);Path(__file__).with_suffix('.json').write_text(json.dumps(dict(w=46,n=46,k=24,path=path),indent=2)+'\n')
 for row in path:
  a=row['source'];b=row['target']
  if a[1:]!=b[1:]or row['event']!=(-1,-1):print(row)

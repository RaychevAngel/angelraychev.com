# Independent review of the all-length named-bound comparison

24 October 2026 UTC. Reviewer: upper/construction lane. This is a source-level
review, separate from the comparison lane's numerical self-checks.

**Verdict: the period theorem is sound**, for the named critical three-corner
lower and fixed-corner physical prefix upper, with the minor clarification
below. It does not establish an absolute constant gap as width and budget vary.

I checked the source recurrences, both physical parity formulas, all nine
corner-count options, the entrance termination argument, the two-step normal
form, clipping at capture, the half-budget test and the finite representative
interval. The argument does not require a daily physical normal form for
arbitrary strategies: it compares already accepted necessary and constructive
recurrences only.

## A short-axis exception that must remain in the finite prefix

The actual `survivor_bound` code has an additional exceptional `(i,j)=(2,0)`
branch on an even-width board when `n=w+1`. Thus the width-only infinite
entrance is not its middle recurrence on that one short length. The proposed
threshold already excludes this case: for `w=2r`,

    M >= A = r(r+1)+1,
    safe_h >= A+H = 2r^2+r+2 > r(2r+1).

Hence every stable even-width length has `n>=w+2`. The finite representative
calculation retains `n=w+1` using the full original recurrence. Adding this
observation to the proof makes the exceptional-axis dependence explicit; it
requires no change to the algorithm or threshold.

## Entrance and branch thresholds

At `A=r(r+1)+1`, every small inverse is at least `r+1`. For the `j>=1`
cases write `c=i+2j-2`. If `c>=r-1`, the built-in minimum root value2 already
proves the claim. Otherwise `c<=r-2` and

    A-2c-(r-c)^2 = r+1+2c(r-1)-c^2 > 0,

so `R(A-2c)>=r-c+1`. The cases `j=0,i=1,2` follow from the pronic
inequality and its one-unit shift; the `i=j=0` option is the minimum of
`rho(2A)` and `rho(A)+1`, both at least `r+1` for `r>=2`.
At `H=r^2+1`, the high inverse cases likewise have value at least `r+1`:
when the opposite-corner count B is positive, the square root plus the
explicit corner shifts suffices; when B is zero and the other count is
positive, `1+rho(H)>=r+1`; for both zero each candidate is at least `r+1`.
All these inverses are nondecreasing, so the inequalities persist.

After one infinite update every model coordinate is at least k. At minimum
budget `k=r+1`, the `(0,0)` option at argument `r+1` has cost at most r because
`2r+2<=r(r+1)` for `r>=2`; the next minimum therefore reaches at least `r+2`.
From then on, every new minimum dominates the previous maximum. The even
exceptional branch increases the middle coordinate, or the odd exceptional
branch increases the largest above the former minimum. Thus the minimum
increases at least once in every two days. This validates termination,
including the minimum feasible odd-width budget where one physical phase
may have a zero one-step increment. Each physical coordinate increases
by at least `2k-w` in two steps. The stated guard is conservative.

## Insertion, translation and first hitting times

The nine-pair substitution yields the displayed middle maps. Their normal
forms give translation by `d=2k-w` in exactly two updates, as do the two
physical maps. Increasing the length by `2d/gcd(w,d)` adds half-area
`wd/gcd(w,d)`, which is exactly `w/gcd(w,d)` such middle pairs.

The entrance margin includes the entire entrance and its next update.
This controls both parities of all inserted pairs. During the translated
tail all low arguments stay above A; high arguments are unchanged deficits,
and all corner/full caps translate exactly. The even-width length parity
is unchanged. No terminal event occurs in the entrance because every
coordinate is below `h-(k+2)`. Therefore the first capture times, rather
than just some later occurrence, shift by the stated even number of days.
The previous-day half-budget test shifts with them. Both full bounds gain
`4w/gcd(w,d)`.

Consequently the finite list really computes the maximum named gap over
all lengths for each fixed width/budget/parity; it is more than a sampling
claim. The scope remains the basic corner model. Additional lens or erosion
history needs its own insertion proof before being given the same period.

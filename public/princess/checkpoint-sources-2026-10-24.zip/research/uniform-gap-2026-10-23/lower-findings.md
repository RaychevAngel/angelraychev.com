# Lower-bound lane: universal erosion and localization

24 October 2026 UTC. Comparison target is the frozen
`research/all-budget-2026-10-23/BASELINE.md`, not only the weaker three-corner
model. No public, manuscript, or Lean source has changed in this lane.

## General theorem added

There is now one nine-feature erosion lower recurrence for **every**
even-area rectangle w<=n,w>=4 and every feasible budget. The refined
geometry is used only below the critical width; at the critical boundary
we use the already accepted ordinary corner theorem on the corner-closed
survivor. The previously missing even-width refined critical theorem is
not assumed. This gives a fixed nine-threshold update with ordinary
proof, guarded-merger interpretation, and independent review in
`upper-review-erosion.md`. It remains an iterated exact lower-model
evaluator, not an O(1) expression for physical capture time.

The old near-pronic dual bands now apply on **all even-area boards at all
subcritical radii**, and at the previously established odd critical radius.
Their static survivor triple is (i,u,v)=(1,2,1). This supplies the useful
new numerical tightening. The universal proof is in `lower-erosion-proof.md`.
The clean inexpensive interface is `lower-band9.py`, exporting `step` and
`bounds`; it has no radius or history state. The comparison lane is
extending its all-length period reduction to this recurrence.

The paired-radius lower can also retain erosion counts using literal
intersection capacities. Erosion commutes with intersection, so the
same two-corner inclusion-exclusion proof preserves the guarded merger.
This combination is implemented in `lower-history-lens.py`; it also
supports the established exact pronic endpoint reset and root's new
subcritical interval-pronic reset. The latter is guarded by observed
outgoing corner count j=1. It is not asserted for j=0 intermediate sizes.

## Numerical tightening currently completed

The band alone, with no new history flag, gives at28x28,k15:
L=259, matching the retained physical U=259. Frozen bracket was257..259.
The paired band model gives at46x46,k24:L=507 versus U=509, improving
frozen505..509. At81x82,k41 the completed combined model gives1605..1607,
improving frozen1603..1607. The completed108-square no-new-history run gives1537..1539, improving
frozen1535..1539 (tau769,residual2;89.6CPU seconds). An earlier90CPU-second
attempt stopped at depth767 and remains explicitly incomplete; it is not
the source of this result.

Additional same-model tests at28x29 and28x56 give lower287 and1043;
at46x47 the lower is553. These are finite evaluations, not yet an
all-length theorem. The comparison lane's independent affine-period
argument is the route to statements over all n.

The older24-row lower remains stronger than this generic model:
24x24 gives205 here, so the preserved combined lower is206. Likewise
24x25 gives229 here, so the preserved lower is230. No old achievement is
discarded merely because a new model is more general.

## New closed-hole history rule

`lower-closed-hole-history.md` removes an unnecessary delta=0 assumption
from the previous strict-near-square hole flag. It flags every target
(j,v)=(1,2) whose closed surplus r is subcritical and whose holes lie in
(r(r-1),r^2]. Two such consecutive events are impossible. The merger
formation needs the partner TARGET full, not its source full; this is
why the weaker trigger is legitimate. Root is independently reviewing
this claim. It has not improved the listed clocks beyond the bands, so
it is not credited with their numerical gains.

A literal corner-triangle audit checked37,464 radius/anchor pairs through
width32, using actual room neighborhoods, and found the required slack
at least2 in every case. This attacks the geometric inequality but does
not replace its proof.

## Audits and failed directions

The universal static inverse bound was checked on4,893,170 literal
supports across4x4/5/6/7/8 and6x6/7, both colors. The banded bound was
checked independently on4,729,334 supports. Explicit static model edges
passed guarded-merger checks on6,479 pairs at4x4,k3;45,819 at4x5,k3; and
191,187 at4x6,k3. These finite tests support the ordinary proofs; none
is a Lean theorem or a universal gap theorem.

The unbanded erosion recurrence improved the basic corner model but did
not beat the frozen paired-radius fixtures. Its combination with paired
radii likewise left20-square,24-square,28-square,46-square and108-square
unchanged, although it improved81x82 by one before the new resets. This
motivated the near-pronic bands rather than further expanding that state.

A stronger even-width critical P/F dichotomy passed small literal-support
attacks, but even assuming it experimentally did not improve the target
clocks. It remains unproved and was not pursued. No result depends on it.

The first implementation of the interval-pronic reset accidentally
filtered j=0 intermediate sizes. This was caught during source review,
the running experiment was stopped, and the code was corrected before
any result from that run was accepted. The reset now requires j=1,
except the independently rigid exact-pronic endpoint. Completed final
receipts are from the corrected version.

## Remaining gap

These are uniform necessary-model refinements with some strict numeric
improvements. They do not establish an absolute gap bound independent
of w,n,k. The remaining challenge is an invariant comparison of the
strengthened lower frontiers with physical upper strategies, or new
physical constructions attaining their faster clocks. The expensive
paired nine-feature implementation also limits broad computation; the
unflagged nine-threshold recurrence and root's exact interval representation
are the natural routes to wider all-length evaluation.

## Whole square-root-bin localization (later in this pass)

The square localization trigger now covers (r-1)^2<q<=r^2 at subcritical
radius when survivor/target corner counts are(i,j)=(1,0), strengthening
the old q>r(r-1) range. Connectedness follows because the one own-corner
component has square capacity while every other component spends at least
two surplus units. The original-support layer argument then localizes to
radius2r-2. `lower-wide-square.md` gives the full proof, merger inheritance,
and root's static dual consequence u=1 for the entire corresponding hole
interval. A C++ literal-support audit checked44,767,180 candidate supports
on6x6/7 and8x8/9;264 met all hypotheses, and every one obeyed the radius
bound. The root's fast interval engine is assessing broad numerical gains.
The new static dual condition and widened history flag did not change
the quick24/28/46/81/108 BAND9 clocks.

## A stronger invariant that fails

A quick full-trace attack rejects two tempting shortcuts. The difference
between the BAND9 full-feature size threshold and the best physical
phase threshold is not bounded by an absolute number of rooms: it reaches
245 rooms on500x500,k251. Nor is the model threshold always within two
physical days: on44x44,k24, at backward day159 its threshold is861 while
the best physical threshold is836, and the physical clock first reaches861
at day162. This does not refute a two-day solo COMPLETION gap; the example
can catch up later. A final full-start comparison may therefore be easier
than an invariant asserting the same sharp bound at every intermediate
threshold. Receipts are lower-band9-size-lead.json and
lower-band9-time-lead.json.
## Dual high-side radius certificates and fast nine-feature evaluation

The new inner-hole idea does not require another state coordinate. Since
distances to opposite rectangle corners add to the diameter, a guaranteed
inner hole ball is exactly an outer support ball at the opposite corner.
`lower-dual-radius-resets.md` proves two new triggers, including exact
high-pronic equality at every radius up to the critical width and exact
high-square equality below it. The upper lane independently accepted
the physical and guarded-merger proof in `upper-review-dual-high.md`.

This lane's small independent audit passed 23,544 literal complement
identities, 2,244 constructed high-pronic events, 1,860 high-square events,
and 10,400 capacity inequalities. These are proof attacks, not a substitute
for the general proof and not a new formalization claim.

`lower-dual-nine-interval.py` now computes the full nine-feature,
paired-radius, static-band model with both new resets. Its interval
compression preserves every allowed size and labeled transition; it
does not impose the dropped feature/cardinality lower bounds. The proof
is `lower-nine-interval-proof.md`. The initial equivalence audit compared
15,762 labeled source-edge unions, 6,440 radius-capacity pairs, and entire
first-arrival layers on 30 small board/budget cases. The independent
upper-lane review accepted it in `upper-review-nine-interval.md`: a
separate direct q/T enumeration passed 17,280 labeled unions and 693,688
admitted base points, and six additional whole-bitset comparisons checked
2,877 source unions, 1,054 capacities, and 105 complete first-arrival layers.

The completed fixture receipt `lower-dual-nine-interval.json` records:

* 28x28, k15: lower 259, retained upper 259.
* 44x44, k24: lower 335, retained upper 337.
* 46x46, k24: lower 507, retained upper 509.
* 81x82, k41: lower 1607, retained upper 1607; frozen lower 1603.
* 108x108, k55: lower 1537, retained upper 1539; frozen lower 1535.
* 129x130, k65: lower 2803, retained upper 2803; frozen lower 2799.

The last three took approximately 3.1, 9.9, and 10.8 CPU seconds rather
than constructing area-sized bitset graphs. These are exact finite
model evaluations with the evaluator review now accepted. They do not
by themselves prove any all-width or all-length constant-gap statement.

## Bounded odd-width minimum-budget diagnostic

The parent requested a small check of whether the new mechanism only
helped near squares. All six requested cases completed within the
30 CPU-second cap, with source hashes in
`lower-odd-min-dual-diagnostic.json`. Its post-cache-limit runs confirm:

* w47, k24: n48 gives 829..831; n94 gives 5153..5155.
* w81, k41: n82 gives exactly 1607; n162 gives exactly 14567.
* w129, k65: n130 gives exactly 2803; n258 gives exactly 35827.

The two matching doubled-length cases show the improvement is not
restricted to the near-square endpoint. The w47 cases disprove the
tentative suggestion that this particular model already matches the
physical prefix upper throughout the odd-width minimum-budget family.
No general exactness theorem is inferred from the other four cases.

The three main memoization caches now retain at most 200,000 entries
each. This limits memory without discarding states or transitions; the
entire small equivalence audit was rerun successfully after the change.
The doubled-length runs took about 1.1, 5.1, and 15.6 CPU seconds.

One concrete later direction is to test analogous dual radius resets
on the **corner-closed** survivor, where reduced surplus can be smaller
than original surplus. Candidate triggers would use target `(j,v)=(1,2)`
with holes `r^2` or `(j,v)=(2,1)` with holes `r(r-1)`, and closed surplus
`r`. The physical triangle inference appears to follow by applying the
same theorem to the closed survivor. A new formation proof must show
that a zero-reduced-surplus partner with full target suffices for radius
inheritance; the existing note proves original-full identity formation.
These broader triggers are **not implemented, tested, or accepted** in
this checkpoint. No numerical claim relies on them.

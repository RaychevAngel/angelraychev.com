# Universal subcritical erosion refinement with an ordinary critical boundary

24 October 2026 UTC. Proposed ordinary theorem for independent review.
`lower-erosion.py` is its nine-threshold implementation. This deliberately
does not assume the unproved refined even-width critical P/F alternative.

Use w<=n, wn even, w>=4, b=floor(w/2), h=wn/2. Retain the established
weakened erosion state: positive (a,c,e) with 0<=c,e<=2 and
1<=a<=h-4+c+e; the zero state is (0,0,0). Drop the positive lower bound
c+2e<=a exactly as in the accepted odd-width merger. Costs and survivor
features obey i<=c,u<=e,(c-i)+(e-u)<=p and q=a-p<=h-4+i+u. Targets obey
u<=j,i<=v. Retain maximal survivor i>=max(0,c+v-2).

Let delta=v-i, closed size x=q+delta, reduced surplus sigma=T-x.
Require both:

1. the established refined P/F alternative whenever sigma<b:
   x<=P(v,u,j;sigma) or h-T<=F_(2-j,2-v)(sigma);
2. the established ordinary critical corner dichotomy applied to the
   CLOSED support x, with own corner count v and outgoing count j.

At sigma>=b the first condition is inactive. The second condition uses
its already proved even-area exceptions: (v,j)=(1,1) if a board side is
2b, and (v,j)=(2,0) if a board side is 2b+1. The unconditional size
profile is retained. This includes the 2b by (2b+1) double exception.

Every physical transition admits this model after maximal survivor
normalization: closure adds just the v-i own corners already in E(B),
keeps B and survivor erosion u unchanged, and both applied profile
theorems have the stated scope.

## Merger

The accepted erosion merger proof applies verbatim to every merged
reduced surplus sigma<b, since each component sigma_l<=sigma and the
same P/F capacity algebra and closure slack eta are available. It also
proves all feature upper bounds, coupled cost, and maximality preservation.

If sigma>b no profile filter requires checking. The only new case is
sigma=b. If both component reduced surpluses are below b, the same P/F
algebra yields the refined merged P/F alternative at sigma=b: the proof
uses only the component alternatives and polynomial capacities. That
alternative implies the ordinary merged critical dichotomy because
P<=F and the observed high-side F is one admissible term in G.

If one component has reduced surplus b, then the other has reduced
surplus zero and eta=0. The zero-surplus refined high branch forces its
closed support and target full, with j=v=2. The merged closed size,
target corner counts, and reduced surplus are then exactly the first
component's. The accepted ordinary critical condition transfers unchanged.
The first component's original source need not be full; neither does the
zero-reduced-surplus partner's. Only the closed support and target enter
this critical argument. This covers every case of sigma=b.

Thus the guarded merger extends to this universal model. The usual full
capture lower 2*tau minus the permitted central saving follows with its
preterminal residual. This is model necessity, not physical attainment.

## Nine-threshold evaluation

For fixed positive target (T,j,v) and survivor features i,u, delta=v-i,
let L(T;v,u,j) and K(h-T;2-j,2-v) be the already derived inverse P and F
functions from `bridge-lower-frontier-nine-proof.md`. Put

    theta=min(L,K,b).

Let Qordinary(T;v,j) be `bridge_corner_frontier.survivor_bound`, the
largest closed survivor allowed by the ordinary critical corner model.
Then the largest allowed original survivor is

    Q=max(0,min(T-delta-theta,
                Qordinary(T;v,j)-delta,
                h-4+i+u)).

Both terms derived from T are nondecreasing in T: the first by the
accepted P/F inverse argument, the second by ordinary critical frontier
monotonicity. Thus Q is nondecreasing. Positive admissible q form an
initial interval for the same monotonicity-in-surplus reason. The accepted
nine-frontier induction applies unchanged:

    B'[c,e]=min(h-4+c+e,k+max Q(B[j,v];i,u,j,v)),

with fixed feature indices satisfying the coupled deletion charge <=k
and maximality. Initial B=0. The same recurrence can start at all states
of size at most floor(k/2), for the central-saving test. No variable-sized
optimization is hidden in a single update, but iterating the recurrence
is not an O(1) numerical formula for the final research objective.

## Paired localization intersection

`lower-erosion-lens.py` adds the accepted paired-radius history. Its
capacity filters retain area, occupied own corners, and eroded opposite
corners of the ball intersection. The last capacity is necessary because
an eroded corner requires BOTH its neighbor cells in that intersection.

For merger, eroded-corner sets of intersections satisfy
E(K1 intersect K2)=E(K1) intersect E(K2). The two-element corner universe
therefore supplies exactly the same inclusion-exclusion lower bound
(e1+e2-2)_+ used for occupied corners. If the two minimum radii come from
different components, apply that inclusion-exclusion to the individual
one-ball erosion sets, just as for the accepted paired area/corner proof.
The maximum over corner anchors is safe by the board's color-preserving
reflection symmetry; anchors achieving area, corner, and erosion maxima
need not coincide, which only weakens the relaxation.

Reset formation remains an identity merger by the accepted subcritical
square/pronic localization proof. The optional all-radius exact pronic
and dual-pronic filters use the established identity-formation argument,
with critical even-width kappa 1 for nonsquares and 2 for squares.
Neither the new static model nor radius intersection is claimed to
improve every earlier specialized lower bound. Take their maximum with
all retained bounds.

## Subcritical near-pronic bands on even widths

The existing all-radius band proofs were stated for odd-width/even-length
boards. For even width 2b retain ONLY 2<=r<b. Their arguments then apply
unchanged: h>=2b^2>2r^2 gives the strict high-branch exclusion, the ordinary
subcritical separator gives genuine quadrants, and the second-neighborhood
radius 2r-1 is strictly smaller than the distance 2b-1 to the nearest
opposite-color board corner. There is no critical even-width inference.

Consequently a target with j=2 and holes d has the following necessary
rule. Put C_r=r(r-1), and let

    D_r=(r-1)(r-2) when v=1;
    D_r=max(r(r-1)/2,r(r-2)) otherwise.

If D_r<d<=C_r and original surplus<=r, then original surplus is r and
(i,u,v)=(1,2,1). Apply all r<b on even width, all r<=b on odd width where
the critical theorem already exists. The proof with observed v=1 omits
the otherwise unnecessary outgoing-corner inference exactly as in the
accepted strengthened band theorem.

The merger is inherited because J=2 forces both outgoing counts to two.
If both original surpluses were positive and totaled at most r, the high
branches give total holes <=(r-1)(r-2), contradicting the trigger. The
small branches have holes >=h-r^2>C_r and are unavailable. Hence one
partner is an original zero-surplus full-to-full action and the merged
transition is identical to the other. This transfers the complete triple
and surplus rule. At the odd critical endpoint one may use the existing
accepted critical band merger; no new even-critical argument is needed.

For fixed target d, at most one radius r=ceil((1+sqrt(1+4d))/2) is active.
For a wrong triple the extra survivor cap is q<=T-r-1. The fixed-target
monotonicity proof from `bridge-lower-frontier-nine-proof.md` applies to
these subcritical bands as well. `lower-history-lens.py` applies them in
`banded_survivor`; the closed-hole flag is independently selectable.

## Critical exact-pronic identity formation, including even squares

The all-even-area physical rigidity theorem is already established in
`resumed-odd-even-pronic-all-radii.md`; here is the merger argument at
r=b without relying on any unproved critical erosion profile.

For a direct trigger Q=r(r-1), I=0, total ORIGINAL surplus r, suppose
both component original surpluses are positive. They are then <r, as
are their reduced surpluses, so the refined subcritical alternatives
apply. Both components cannot be small because their closed sizes would
sum to at most r^2<h, contrary to Q>0. In a mixed pair, the existing
mixed P/F merger inequality bounds Q by the small component's capacity,
which is at most (r-1)^2<r(r-1). If both components are high, their
nonnegative target holes sum to h-r^2>=r^2, whereas their separate high
bounds are at most s1^2+s2^2<=r^2-2r+2<r^2. This is impossible. Thus one
original surplus is zero, its support/target are full, and the merger is
an identity on the exact-pronic component. Its reset and forced target
(j,v)=(1,0) transfer, including the even-square endpoint.

For the dual trigger Q=h-r^2, total original surplus r, J=2, one has
j1=j2=2. If both original surpluses are positive, each is subcritical.
A small component would bound the merged survivor Q by (r-1)^2, while
Q=h-r^2>=r^2. Therefore both are high. Their holes sum to r(r-1), but
with j_l=2 their high bounds are at most s_l(s_l-1), totaling at most
(r-1)(r-2)<r(r-1). Again one component is original-full-to-full and the
merger is the identity on the triggering component. It transfers the
physical dual triple (i,u,v)=(1,2-kappa,1), where kappa is zero below the
width threshold (or at odd width), one at critical nonsquare even width,
and two at the critical even square.

The strict high-side inequalities use h>=2r^2, which includes equality
at the even square. They do not assume h>2r^2 at that endpoint.

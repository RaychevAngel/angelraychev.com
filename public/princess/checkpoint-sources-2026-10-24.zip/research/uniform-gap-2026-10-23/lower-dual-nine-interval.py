"""Exact interval evaluator of the universal nine-feature paired-radius model.

Keeps all positive relaxed sizes, without reinstating dropped feature-size
lower bounds. Includes static bands and dual radius resets, no hole-history
flag. Must agree with root-dual-nine.py at closed_holes=False.
"""
from pathlib import Path
from functools import lru_cache
import importlib.util,json,math,sys,time
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
sp=importlib.util.spec_from_file_location('dual_nine_reference',HERE/'root-dual-nine.py')
ref=importlib.util.module_from_spec(sp);sp.loader.exec_module(ref)
from root_capacity import capacities as affine_capacities
from root_dual_interval import merge,minus


def P(v,u,j,s):
    if s<v+2*j:return -10**12
    z=s-v-2*j
    if u:return v+j+u+z*z+3*z
    if v:return v+j+z*z+2*z
    if j:return j-1+max((z+2)*(z+1)//2,(z+2)*(z-1)+1)
    return max(s*(s-1)//2,s*(s-2))


def engine(w,n,k,critical_pronic=True,wide_square=True):
    assert 4<=w<=n and w*n%2==0
    h=w*n//2;D=w+n-2;b=w//2
    corners=[(0,0),(w-1,0),(0,n-1),(w-1,n-1)]
    other=[z for z in corners if sum(z)%2]
    neighbors={c:[z for z in ((c[0]-1,c[1]),(c[0]+1,c[1]),(c[0],c[1]-1),(c[0],c[1]+1))
                  if 0<=z[0]<w and 0<=z[1]<n] for c in other}

    @lru_cache(None)
    def capacity(R,S):
        a,c=affine_capacities(w,n,R,S);e=0
        for x,y in other:
            e=max(e,sum(all(xx+yy<=R and abs(xx-x)+abs(yy-y)<=S for xx,yy in neighbors[z])for z in other))
        return a,c,e

    @lru_cache(200000)
    def cap(T,i,u,j,v):return ref.banded_survivor(w,n,T,i,u,j,v)

    @lru_cache(200000)
    def first(i,u,j,v,q):
        lo=1;hi=h-4+j+v
        if cap(hi,i,u,j,v)<q:return hi+1
        while lo<hi:
            mid=(lo+hi)//2
            if cap(mid,i,u,j,v)>=q:hi=mid
            else:lo=mid+1
        return lo

    def event(i,u,j,v,q):
        r=math.isqrt(q);r+=r*r<q
        if i==1 and j==0 and 2<=r<b and q>((r-1)**2 if wide_square else r*(r-1)):
            return 1,2*r-1,q+r
        r=(1+math.isqrt(1+4*q))//2;r+=r*(r-1)<q
        local=(r<b and (r-1)*(r-2)<q<=r*(r-1))or(critical_pronic and r==b and q==r*(r-1))
        if i==0 and local and 2<=r<=b and (j==1 or q==r*(r-1)):
            return (0,2*r-2,q+r)if(j,v)==(1,0)else(-2,-2,q+r)
        if j==2:
            r=math.isqrt(h-q)
            if 2<=r<=b and r*r==h-q:
                kappa=(1+int(w==n))if w%2==0 and r==b else 0
                if critical_pronic and(i,u,v)!=(1,2-kappa,1):return -2,-2,q+r
                return 1^(D%2),D-2*r+2,q+r
        if i==2 and j==1:
            r=(math.isqrt(1+4*(h-q))-1)//2
            if 2<=r<b and r*(r+1)==h-q:return D%2,D-2*r+1,q+r
        return None

    @lru_cache(None)
    def records(i,u,j,v):
        """(qlo,qhi,increment,label-color,label-radius), admitted resets only."""
        out=[]
        if i==1 and j==0:
            for r in range(2,b):
                lo=((r-1)**2 if wide_square else r*(r-1))+1
                hi=min(r*r,P(v,u,j,r-(v-i))-(v-i),h-4+i+u,h-4+j+v-r)
                if lo<=hi:
                    assert cap(lo+r,i,u,j,v)>=lo and cap(hi+r,i,u,j,v)>=hi
                    out.append((lo,hi,r,1,2*r-1))
        if(i,j,v)==(0,1,0):
            for r in range(2,b):
                lo=(r-1)*(r-2)+1
                hi=min(r*(r-1),P(v,u,j,r),h-4+i+u,h-4+j+v-r)
                if lo<=hi:
                    assert cap(lo+r,i,u,j,v)>=lo and cap(hi+r,i,u,j,v)>=hi
                    out.append((lo,hi,r,0,2*r-2))
            if critical_pronic:
                q=b*(b-1)
                if cap(q+b,i,u,j,v)>=q:out.append((q,q,b,0,2*b-2))
        if j==2:
            for r in range(2,b+1):
                q=h-r*r;ev=event(i,u,j,v,q)
                if ev and ev[0]>=0 and cap(q+r,i,u,j,v)>=q:
                    out.append((q,q,r,ev[0],ev[1]))
        if i==2 and j==1:
            for r in range(2,b):
                q=h-r*(r+1)
                if cap(q+r,i,u,j,v)>=q:out.append((q,q,r,D%2,D-2*r+1))
        return tuple(out)

    @lru_cache(200000)
    def relation(i,u,j,v,qa,qb):
        """Exact union for qa<=q<=qb, grouped by reset label."""
        top=h-4+j+v;low=first(i,u,j,v,qa)
        if low>top:return ()
        out=[];ev=event(i,u,j,v,qa)
        if ev and low<=ev[2]<=top and not(qa<qb and cap(ev[2],i,u,j,v)>=qa+1):
            if low<ev[2]:out.append((-1,-1,low,ev[2]-1))
            if ev[2]<top:out.append((-1,-1,ev[2]+1,top))
        else:out.append((-1,-1,low,top))
        for a,z,inc,d,R in records(i,u,j,v):
            a=max(a,qa);z=min(z,qb)
            if a<=z:out.append((d,R,a+inc,z+inc))
        return tuple(out)
    return h,D,capacity,relation,cap,event


def run(w,n,k,seconds=120,critical_pronic=True,wide_square=True,trace=False):
    start=time.process_time()
    h,D,capacity,relation,cap,event=engine(w,n,k,critical_pronic,wide_square)
    seed=(D,D,2,2);front={seed:[(h,h)]};seen=dict(front);layers=[];peak=0
    for day in range(4*w*n):
        if not front:raise AssertionError(('empty',day))
        low=min(z[0][0]for z in front.values());layers.append(low)
        if low==0:break
        if time.process_time()-start>seconds:
            return dict(w=w,n=n,k=k,complete=False,day=day,CPU_seconds=time.process_time()-start)
        following={}
        def add(R,S,c,e,a,z):
            size,cc,ee=capacity(R,S);z=min(z,size,h-4+c+e)
            if c<=cc and e<=ee and a<=z:following.setdefault((R,S,c,e),[]).append((a,z))
        for(R,S,c,e),xs in front.items():
            newR,newS=min(D,S+1),min(D,R+1)
            for a,z in xs:
                if a<=k:add(newR,newS,0,0,0,0)
                for i,u,j,v,charge in ref.er.OPTIONS[c,e]:
                    if charge>k:continue
                    qa=max(1,a-k);qb=min(z-charge,h-4+i+u)
                    if qa>qb:continue
                    for d,r,lo,hi in relation(i,u,j,v,qa,qb):
                        nr,ns=newR,newS
                        if d==0:nr=min(nr,r)
                        if d==1:ns=min(ns,r)
                        add(nr,ns,j,v,lo,hi)
        front={}
        for key,parts in following.items():
            allnext=merge(parts);new=minus(allnext,seen.get(key,[]))
            if new:
                front[key]=new;seen[key]=merge(seen.get(key,[])+new)
        peak=max(peak,sum(map(len,front.values())))
    else:raise AssertionError('day bound')
    residual=min(layers[:-1]);out=dict(w=w,n=n,k=k,complete=True,tau=day,residual=residual,
        lower=2*day-int(2*residual<=k),states=sum(z-a+1 for xs in seen.values()for a,z in xs),
        radius_pairs=len({q[:2]for q in seen}),intervals=sum(map(len,seen.values())),peak_front_intervals=peak,
        relation_queries=relation.cache_info().misses,relation_cached=relation.cache_info().currsize,
        capacity_queries=capacity.cache_info().currsize,
        CPU_seconds=time.process_time()-start)
    if trace:out['layers']=layers
    return out


if __name__=='__main__':
    rows=[]
    for case in sys.argv[1:]or['24,24,13','28,28,15','46,46,24']:
        z=run(*map(int,case.split(',')),trace=True);rows.append(z)
        print({k:v for k,v in z.items()if k!='layers'},flush=True)
        Path(__file__).with_suffix('.json').write_text(json.dumps(rows,indent=2)+'\n')

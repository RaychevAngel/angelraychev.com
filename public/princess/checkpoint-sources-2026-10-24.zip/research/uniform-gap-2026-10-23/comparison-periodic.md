# All-length comparison of the corner lower and physical prefix upper bounds

24 October 2026 UTC. Ordinary recurrence argument; numerical implementation
checks are recorded separately. This generalizes the insertion mechanism in
`research/bridge-upper-transport-odd-exceptions.md` from seven fixed budget
lines to every feasible width and budget on even-area rectangles. It does
not prove that the named gap is bounded by an absolute constant.

## Statement

Fix integers `w>=4`, `k>floor(w/2)`. Write `d=2k-w>0` and `g=gcd(w,d)`.
Let `L(w,n,k)` be the accepted critical three-corner necessary lower bound,
including its half-budget central test. Let `U(w,n,k)` be the best of the
two fixed-corner physical prefix constructions and their shared middle
shot. These are exactly the bounds in
`research/all-budget-2026-10-23/audit_named_bounds.py`.

For each admissible length parity there is an explicitly computable `n0`
such that, for every `n>=n0` in that parity,

    L(w,n+2d/g,k) = L(w,n,k)+4w/g,
    U(w,n+2d/g,k) = U(w,n,k)+4w/g.

Consequently the exact maximum of `U-L` over *all* lengths `n>=w` in that
parity is obtained by evaluating the finite list

    n = first admissible length, first+2, ..., n0+2d/g-2.

This is a theorem about the named structural bounds, not about the true
capture time being periodic, and does not assert that no stronger bounds
are known. The full established bound must still combine all available
lower bounds by a maximum and all upper bounds by a minimum. In particular,
a proved bound on this named gap is automatically valid for that stronger
combined bracket.

## The joint recurrence and a computable entry

Put `r=floor(w/2)` and `h=wn/2`. Evolve the ten coordinates

    Z=(B0,B1,B2,C0,C1,C2,X0,X1,Y0,Y1).

`B` is the necessary backward frontier from `(0,-1,-1)`, `C` is the same
frontier from the constant seed `floor(k/2)` (clipped to its corner caps),
`X` is the physical backward prefix frontier from zero and `Y` is its
half-budget seeded version. The exact updates are the cited source
recurrences. `comparison_periodic.py` implements the same updates without
changing their interpretation.

Define an infinite entrance update by deleting all upper-capacity clamps
and the high-root terms, leaving every low-root term and critical corner
cap intact. This avoids selecting an arbitrary huge virtual board. Set

    A=r(r+1)+1, H=r^2+1.

Direct substitution in the nine fixed pairs `(i,j)` of corner counts shows
that every low inverse is at least `r+1` for arguments at least `A`, and
every high inverse is at least `r+1` for deficits at least `H`. The square
and pronic physical costs satisfy the same inequalities at these stronger
common thresholds. Thus the low terms are inactive once every coordinate
is at least `A`; the high terms are inactive when all deficits are at least
`H`.

The entrance algorithm iterates the infinite update until every coordinate
is at least `A` and both model vectors have the following normal form:

* even `w`: `(a-1,a,a)`;
* odd `w`: `(a,a,a+epsilon)`, where `epsilon` is zero or one.

This terminates for every feasible budget. For the model update, once its
coordinates are ordered, the next smallest coordinate is at least the
old largest coordinate, since `k>=r+1` and all costs are at most `r+1`.
After the first update every model coordinate is at least `k`. If `k=r+1`, one
further update gives at least `r+2`: the `(i,j)=(0,0)` option at `t=r+1`
has cost at most `rho(2r+2)<=r`. Thereafter the even-width exceptional
`(1,1)` branch increases the middle coordinate by at least one each day;
the odd-width exceptional `(2,0)` branch increases the largest coordinate
above the previous smallest by at least one. Hence in either case the
minimum grows by at least one every two steps: for even width the next
minimum dominates the old middle coordinate, and for odd width it
dominates the old largest coordinate. Thus for either model vector its
minimum at time `t+2` is at least its minimum at time `t` plus one, for
every `t>=2`. For the physical vectors,
two steps increase each coordinate by at least `d`, since the two maximal
costs sum to `w`. Once above `A`, the model formulas below enter their
normal forms in at most two further steps. In particular all four vectors
meet their entry conditions by time `2A+6`; the implementation's guard
`4A+20` is conservative. The physical coordinates need not individually
increase on every one-step update; their minimum stays above `A`, which is
all the tail-translation argument uses. No infinite search is hidden in
the entry computation.

Record the entry `E`, its time `e`, and its next infinite update `E1`.
Let `M` be the largest coordinate anywhere in the entrance through `E1`.
Choose the first admissible length `n0>=w` satisfying

    wn0/2 >= M+max(H,k+2).

The high terms and all next-step model caps are then inactive throughout
this entrance and its first middle pair. The actual finite-board entrance
therefore equals the infinite one for every `n>=n0`.

There is one extra short-board exception to check: at even width `w=2r`
and length `n=2r+1`, the existing corner recurrence also gives the
`(i,j)=(2,0)` pair the critical cost `r`. The width-only infinite entrance
omits that additional exception. It cannot affect the stable-length
argument: `M>=A` gives `safe_h>=A+H=2r^2+r+2`, strictly greater than
`r(2r+1)`. Hence `n0>=w+2`; the exceptional shorter board is covered by
the direct finite list using the exact original recurrence.

## Common two-step translation

While low and high terms are inactive, put `delta=k-r-1`.
The even-width model update is

    (B0,B1,B2) ->
    (B2+k-r-1, max(B2-1,B1)+k-r, max(B2-1,B1)+k-r).

It preserves `(a-1,a,a)` and adds `k-r` to every coordinate each day.
The odd-width model update is

    (B0,B1,B2) ->
    (B2+delta, B2+delta, max(B2,B0+1)+delta).

It alternates the two normal forms and adds `2delta+1=d` after two days.
The physical updates interchange the phase coordinates; their two costs
sum to `w`, so two days also add `d`. Therefore two middle updates of the
whole vector add `d` to all ten coordinates, for either width parity.

## Insertion and tail translation

Increase length by `P=2d/g`. Its parity is unchanged, and half-area increases
by `Delta=wd/g`. Insert `w/g` middle pairs at the common entrance, adding
`q=2w/g` days and `Delta` to every coordinate. The inserted pairs stay in
the middle: relative to the enlarged board their deficits are at least
those of the original entrance and its next update, covered by the chosen
margin. The last inserted state is exactly `E+Delta`.

Follow the remaining original trajectory with `Delta` added. The low terms
remain inactive: the minimum of each model/physical vector never decreases
below its entrance threshold. All high-root arguments are differences
`h-coordinate`, hence unchanged by simultaneous translation. Full-board
and corner caps translate by `Delta`, too. Every later update, including
capture and saturation, therefore agrees exactly with the translated
original update. The even-width high-root phase depends on length parity,
which is unchanged because `P` is even.

All four first-capture clocks are shifted by the same `q`. Their comparisons
in the full lower and upper definitions are unchanged. The full-day bounds
therefore both gain `2q=4w/g`. This proves the displayed period identities.
Repeated subtraction of `P` reduces every large admissible length to the
finite representative interval; smaller lengths are explicitly included.

## Evidence and limitations

The implementation checks exact translated tails, not just matching final
clock differences. It also permits direct comparison against the frozen
`audit_named_bounds.py` on every finite representative. Independent review
accepted the argument in `upper-review-periodic.md`, including termination,
the nine root cases, clipped tail translation and first-hitting/half-shot
semantics. That review identified the short-board critical exception
clarified above; it requires no threshold or code change.

The theorem removes the length sampling issue for a *fixed* width and
budget. It does not remove the remaining infinitely many `(w,k)` pairs.
Nor does it upgrade the paired-radius or nine-feature lower models: those
have additional state and need their own insertion argument. Any numerical
maximum over finitely many widths must be labelled accordingly.

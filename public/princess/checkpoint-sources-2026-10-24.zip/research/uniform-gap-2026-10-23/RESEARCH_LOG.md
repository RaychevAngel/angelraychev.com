# Uniform low-budget gap research — 23 October 2026 PT

## Fixed comparison contract

The frozen baseline is `../all-budget-2026-10-23/BASELINE.md` and its JSON
companion. Preserve it. Current objective: tighten computable structural
bounds across every even-area rectangle w<=n, k>=floor(w/2)+1, particularly
below the accepted linear-budget one-day gates. The existing exact
finite-interface characterization is not a new result. No public release
or new Lean theorem is assumed in this research pass.

## Parallel attacks

- Lower: extend erosion/closure information to even width with a deliberately
  relaxed critical condition; combine it with persistent radius information.
- Upper: jointly schedule both parity cohorts and investigate physical
  pyramid transport beyond the previously exhausted fixed-corner family.
- Comparison: prove an all-length insertion/reduction theorem for the named
  lower and upper clocks, so a fixed-(w,k) audit covers every length.
- Root: derive a compact interval representation of the persistent-radius
  lower evaluator, independently review proposed results, and seek a
  uniform structural comparison.

## Initial observations and failures

The basic three-corner versus physical-prefix gaps at minimum budget on
square widths 300 and 500 are both six days. These are weak-model gaps,
not counterexamples to a small gap for the strongest combined bounds.
The frozen paired-radius and odd-width erosion refinements must be retained.

The new nine-feature subcritical erosion model initially improves basic
bounds but does not yet exceed frozen paired-radius bounds at 28,46,108
square. Joint budget splitting within anchored prefixes initially does
not improve the five tested gap fixtures. These negative comparisons
prevent attributing gains to changes of representation alone.

## Accepted progress after independent attack

The initial negative lower comparison was superseded by extending the
near-pronic bands to every subcritical even-width radius. The clean
nine-threshold model then closes every length in the 28-row minimum-budget
family: `T_15(28,n)=28n-525`, n>=28. Ordinary proof and all-length
finite-period certificates are recorded in `CHECKPOINT.md`.

The first all-length comparison used three ordinary corner thresholds.
A general insertion theorem gives length period `2(2k-w)/gcd(w,2k-w)`
and full-day shift `4w/gcd(w,2k-w)` for the named lower and physical upper
clocks. Its extension to the nine-feature model uses the fact that erosion
coordinates disappear in the middle region, leaving the same three-corner
normal forms. This does not establish the period of the true optimum.

The complete width-at-most64 comparison progressed from a seven-day named
gap, to five after the new bands, to four after a bounded-tail transfer
resolved the remaining 44-row exception. Each version is retained; the
four-day certificate covers all lengths and all feasible budgets. The
unbounded-width small-constant problem remains open.

Whole square-root-bin localization and partial-pronic localization were
proved without a compression assumption. The exact-pronic reset extends
to the critical endpoint using the existing critical equality theorem.
A static dual square condition follows. Several additional one-step hole
flags did not improve the completed clocks and are not credited for the
other gains.

The most useful later idea was to retain a completely cleared corner
triangle. At first this looked like a new inner-radius state. The identity
`dist(x,C)+dist(x,C_opposite)=D` shows it is already an outer-radius
certificate at the opposite corner. Two high-side equality resets follow,
with original full-to-full identity merger proofs. This avoids adding a
new coordinate. The independent reviewer found that the first interval
prototype appended some labeled edges excluded by the ordinary relation;
those extra edges were a weakening, but were removed before accepting an
exact transcription. The post-gate run and independent q/T-union audit
match. See `lower-dual-radius-resets.md` and `upper-review-dual-high.md`.

Both opening and closing geometric histories can now be transferred to
the ordinary middle recurrence. For opening deficits d and a closing
necessary seed V, a capture path must have a middle frontier reaching
`h-d`. This comparison inherits the lower bound from the accepted full
model; it does not introduce an unproved physical doubling principle.
Length stabilization of both boundary calculations and the common affine
middle give a generic two-sided transfer theorem. The independently
reproduced application proves `T_13(24,n)=24n-369` for every n>=24,
closing the entire frozen one-day family, including both parities.

Combining the new high-side resets with all nine erosion features closes
the frozen 81x82,k41 and129x130,k65 examples, respectively at1607 and2803.
The same model matches the uppers at doubled lengths162 and258. It still
has a two-day gap at47x48 and47x94 with budget24. These computations do
not constitute an all-width or all-length odd-width classification.

## Exact computation improvements and source control

Reachable sizes at a fixed feature/radius tuple can be stored as exact
unions of integer intervals. Monotonic target tails and injective reset
targets permit exact union updates. This drops no reachable state and
uses no cross-radius dominance. The nine-feature implementation retains
the deliberately weakened positive feature/cardinality conditions; adding
the apparently natural q>=i or q>=u would require a new merger argument.
Its independent direct relation, capacity, and full-arrival-layer audits
are in `upper-review-nine-interval.md`.

The paired-ball area is evaluated by a bounded piecewise-affine lattice
count rather than scanning rows. Memoization is capped in the combined
nine-feature implementation to avoid retaining millions of obsolete
queries. These are representation improvements, not new capture theorems.

`baseline-comparison.json` preserves every frozen fixture and retains older
special lower bounds when they beat a newer general evaluator. All27
frozen source hashes remain unchanged. Proof review, finite computational
evidence, and Lean coverage remain distinct; no new Lean source or public
release is claimed.

## Failed shortcuts and remaining problem

Jointly allocating arbitrary daily quotas between two fixed anchored
prefixes did not improve the retained uppers. A direct pyramid solver
timed out, including on a small calibration, and proves nothing. Neither
result excludes geometric constructions outside the searched family.

A constant room-count lead for the lower threshold is false. A stronger
pointwise two-solo-day lead comparison is also false at an intermediate
44-square state. The full-board completion comparison may still hold.
Do not replace it with those disproved stronger invariants.

An attempted shortcut for a uniform capacity envelope was rejected before
use: the lens of two finite balls at opposite long ends need not be
largest at the shortest board or at the infinite-strip limit. Top/bottom
clipping can make it increase before decreasing. The finite envelope must
retain the intermediate lengths or rigorously handle its breakpoints.

The central remaining task is a uniform inequality comparing the total
opening/closing loss with the constructive prefix clock, including short
boards where boundary stages overlap. The new boundary-transfer machinery
makes this obligation explicit, but finite width certificates alone do
not prove it for arbitrary width. All strict numerical gains in this pass
come from lower bounds; the upper-bound attempts have not yet improved a
retained construction.

## Accepted all-length three-day panel and common envelopes

The common-envelope proof was independently accepted after reproducing all
five parity families and245 finite middle representatives plus their
translated tails. It gives two-day brackets throughout width44/budget24,
width46/budget24, and width47/budget24 with even length. Combining these
with the full BAND9 refinement proves a three-day gap for every width at
most64, every length, and every feasible budget. Root separately checked
all2494 expected width/budget/parity keys, every combined minimum, and
input hashes; no line is omitted or duplicated. The earlier four-day
certificate remains a historical intermediate. This is still a bounded-
width result and does not establish a constant for all widths.

The nine-feature-to-three-corner projection is also accepted after an
independent inequality and labelled-edge audit. Its survivor corner count
is clamped to min(i,q); the only nontrivial case has q=1 and i=2. This
repairs the positive-cardinality mismatch without strengthening the
nine-feature graph, whose weakened cardinality constraints are needed for
its merger proof. Stronger nine-feature heads can now feed the accepted
three-corner comparison. No numerical gain is attributed to projection
alone.

The root validation confirmed all27 frozen source hashes and parsed47
new Python sources. The review manifest fingerprints29 accepted sources
and39 review artifacts. Public pages, manuscript PDFs, and Lean files
remain unchanged.

## Precise remaining all-width target

Let P be the physical solo-prefix clock and tau9 the necessary dual-nine
clock. Proving tau9>=P-1 would imply a three-day full-game gap, and a
two-day gap when the physical upper is odd. Even tau9>=P-2 would establish
an absolute five-day guarantee across the entire domain. Neither is
proved. A sufficient opening/closing inequality and the extra central-day
condition for a universal two-day gap are stated in NEXT_UNIFORM_LEMMA.md.

There are finitely many local formula types but arbitrarily many radius
bins as width grows. Bounded error per bin is insufficient: those errors
can accumulate, and the smallest odd-width budget has middle drift one.
The missing argument must bound total phase/orientation advantage, for
example by proving that radius constraints force repayment of successive
shortcuts. Complement symmetry by itself does not cancel independent
opening and closing maxima. A stopped full-start argument may avoid the
stronger partial-state claims already disproved. No new uniform constant
was claimed from this conceptual assessment.

## Final bounded panel refinement

The last supplemental batch completed18/18 parity families in92.49 CPU
seconds. Independent review checked all802 finite representatives,
periodic inherited lookups, matching uppers, head/tail premises, and
pointwise lower-bound maxima, without rerunning the boundary graph
searches. Sixteen additional entire length families improve to gap at
most two. The final complete width64 panel has gap at most two except
w47/k25/n>=52 and w61/k32/n>=64, in both cases n=4 mod6; their family
certificates permit three. Better isolated computations remain valid.
The original three-day fallback is preserved unchanged. Root separately
checked final assembly and precise residue coverage. No all-width
constant-gap claim follows. Fixed-width search stops here.

"""Literal finite-board check of proposed bounded-tail capacity stabilization.

This checks the geometry lemma only, not the complete tail-seed algorithm.
"""
from pathlib import Path
import sys,json,time
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'research/all-budget-2026-10-23'))
from lower_lens import capacities


def stable(w,R,S):
    """None denotes an unknown/infinite radius. Area None is unbounded."""
    if R is None and S is None:return None,2
    if R is not None and S is not None and w%2:return 0,0
    radius=max(x for x in (R,S) if x is not None)
    if R is None:
        # Color0 rooms around a color1 corner have odd distance.
        area=sum(1 for x in range(w) for y in range(radius+1)
                 if (x+y)%2==1 and x+y<=S)
        corners=int(not w%2 and S>=w-1)
        return area,corners
    if S is None:
        area=sum(1 for x in range(w) for y in range(radius+1)
                 if (x+y)%2==0 and x+y<=R)
        return area,1+int(w%2 and R>=w-1)
    points=[(x,y)for x in range(w)for y in range(radius+1)
            if (x+y)%2==0 and x+y<=R and w-1-x+y<=S]
    return len(points),int(S>=w-1)


def run():
    started=time.process_time();checks=boards=0
    for w in range(4,17):
        for H in (1,3,8):
            r=w//2;M=2*r-3+H
            for parity in ((0,1) if not w%2 else (0,)):
                n=max(w,2*M+2);n+=n%2!=parity
                for length in (n,n+2,n+8):
                    A,C=capacities(w,length);D=w+length-2;boards+=1
                    for R in [None,*range(M+1)]:
                        for S in [None,*range(M+1)]:
                            area,corners=stable(w,R,S)
                            actual=A[D if R is None else R][D if S is None else S]
                            corner=C[D if R is None else R][D if S is None else S]
                            assert area is None or area==actual,(w,length,H,R,S,area,actual)
                            assert corners==corner,(w,length,H,R,S,corners,corner)
                            checks+=1
    return dict(status='PASS',boards=boards,radius_pair_checks=checks,
                scope=__doc__,CPU_seconds=time.process_time()-started)


if __name__=='__main__':
    result=run();Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result))

"""Candidate closed-hole history refinement with erosion and paired localization.
Proof and independent finite audit pending. No physical attainment assertion.
"""
import sys,json,time,importlib.util
from pathlib import Path
from bisect import bisect_left
from math import isqrt
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'src'));sys.path.insert(0,str(ROOT/'research/all-budget-2026-10-23'))
spec=importlib.util.spec_from_file_location('newlower',Path(__file__).with_name('lower-erosion.py'));er=importlib.util.module_from_spec(spec);spec.loader.exec_module(er)
from bridge_corner_reach import bits
from lower_lens import capacities
BASE_SURVIVOR=er.survivor
def banded_survivor(w,n,T,i,u,j,v):
    cap=BASE_SURVIVOR(w,n,T,i,u,j,v)
    if T<=0:return cap
    h=w*n//2;d=h-T
    if(j,v)==(1,2) and u!=1:
        r=isqrt(d);r+=int(r*r<d)
        if 2<=r<w//2:
            cap=min(cap,max(0,T-(v-i)-r-1))
    if j!=2:return cap
    r=(1+isqrt(1+4*d))//2
    r+=int(r*(r-1)<d)
    threshold=(r-1)*(r-2) if v==1 else max(r*(r-1)//2,r*(r-2))
    if 2<=r<=w//2-int(w%2==0) and threshold<d and(i,u,v)!=(1,2,1):
        cap=min(cap,max(0,T-r-1))
    return cap
er.survivor=banded_survivor

def graph(w,n,k,critical_pronic=True,closed_holes=True,wide_square=True):
    h=w*n//2
    states=[(a,c,e)for a in range(h+1)for c,e in er.FEATURES if(a>0 or c==e==0)and a<=h-4+c+e]
    ids={s:z for z,s in enumerate(states)};rels={}
    for j,v in er.FEATURES:
        top=h-4+j+v;tails=[0]*(top+2)
        for T in range(top,0,-1):tails[T]=tails[T+1]|(1<<ids[T,j,v])
        for i in range(v+1):
            for u in range(j+1):
                cap=[er.survivor(w,n,T,i,u,j,v)for T in range(1,top+1)]
                assert all(x<=y for x,y in zip(cap,cap[1:])),(w,n,i,u,j,v)
                for q in range(1,h-4+i+u+1):
                    mask=tails[bisect_left(cap,q)+1];special={}
                    r=isqrt(q)+int(isqrt(q)**2<q)
                    if i==1 and j==0 and q>((r-1)**2 if wide_square else r*(r-1)) and 2<=r<w//2:
                        target=q+r
                        if (target,j,v)in ids:
                            bit=1<<ids[target,j,v]
                            if mask&bit:special[1,2*r-1]=bit;mask^=bit
                    r=(1+isqrt(1+4*q))//2
                    r+=int(r*(r-1)<q)
                    local_pronic=(r<w//2 and (r-1)*(r-2)<q<=r*(r-1)) or (critical_pronic and r==w//2 and q==r*(r-1))
                    if i==0 and local_pronic and 2<=r<=w//2 and (j==1 or q==r*(r-1)):
                        target=q+r
                        if(target,j,v)in ids:
                            bit=1<<ids[target,j,v]
                            if mask&bit:
                                if(j,v)==(1,0):special[0,2*r-2]=bit
                                mask^=bit
                    if critical_pronic and j==2:
                        r=isqrt(h-q)
                        if r*r==h-q and 2<=r<=w//2:
                            kappa=(1+int(w==n)) if w%2==0 and r==w//2 else 0
                            if(i,u,v)!=(1,2-kappa,1):
                                target=q+r
                                if(target,j,v)in ids:mask&=~(1<<ids[target,j,v])
                    # Flag every closed near-square hole event, including delta>0.
                    if(j,v)==(1,2) and closed_holes:
                        flag=0
                        delta=v-i
                        for r in range(2,w//2):
                            target=q+r+delta;d=h-target
                            if max((r-1)**2,2)<d<=r*r and(target,j,v)in ids:
                                bit=1<<ids[target,j,v]
                                if mask&bit:flag|=bit;mask^=bit
                        if flag:special[2,0]=flag
                    special[-1,-1]=mask;rels[q,i,u,j,v]=special
    rows=[]
    for a,c,e in states:
        row={}
        if a<=k:row[-1,-1]=1<<ids[0,0,0]
        for p in range(min(k,a-1)+1):
            q=a-p
            for i,u,j,v,charge in er.OPTIONS[c,e]:
                if charge>p:continue
                for key,mask in rels.get((q,i,u,j,v),{}).items():row[key]=row.get(key,0)|mask
        rows.append(row)
    return states,ids,rows

def erosion_capacities(w,n):
    D=w+n-2;corners=[(0,0),(w-1,0),(0,n-1),(w-1,n-1)]
    own=(0,0);anchors=[p for p in corners if sum(p)%2]
    E=[[0]*(D+1)for _ in range(D+1)]
    for other in anchors:
        e=[[0]*(D+1)for _ in range(D+1)]
        for x,y in anchors:
            near=[(xx,yy)for xx,yy in[(x-1,y),(x+1,y),(x,y-1),(x,y+1)]if 0<=xx<w and 0<=yy<n]
            d=max(xx+yy for xx,yy in near);f=max(abs(xx-other[0])+abs(yy-other[1])for xx,yy in near)
            e[d][f]+=1
        for i in range(D+1):
            for j in range(D+1):
                if i:e[i][j]+=e[i-1][j]
                if j:e[i][j]+=e[i][j-1]
                if i and j:e[i][j]-=e[i-1][j-1]
                E[i][j]=max(E[i][j],e[i][j])
    return E

def run(w,n,k,seconds=40,critical_pronic=True,closed_holes=True,wide_square=True):
    begun=time.process_time();h=w*n//2;D=w+n-2
    states,ids,rows=graph(w,n,k,critical_pronic,closed_holes,wide_square);A,C=capacities(w,n);E=erosion_capacities(w,n);maskcache={}
    build=time.process_time()-begun
    def allowed(pair):
        if pair not in maskcache:
            x,y=pair[:2];a,c,e=A[x][y],C[x][y],E[x][y]
            maskcache[pair]=sum(1<<z for z,(aa,cc,ee)in enumerate(states)if aa<=a and cc<=c and ee<=e)
        return maskcache[pair]
    front={(D,D,0):1<<ids[h,2,2]};seen=dict(front);zero=1<<ids[0,0,0];layers=[]
    for t in range(4*w*n):
        if not front:raise AssertionError('empty frontier')
        layers.append(min(states[z][0]for mask in front.values()for z in bits(mask)))
        if any(mask&zero for mask in front.values()):break
        if time.process_time()-begun>seconds:return dict(w=w,n=n,k=k,complete=False,depth=t,build_seconds=build,cpu_seconds=time.process_time()-begun)
        following={}
        for(r0,r1,flag),source in front.items():
            pair=(min(D,r1+1),min(D,r0+1));events={}
            for a in bits(source):
                for key,mask in rows[a].items():events[key]=events.get(key,0)|mask
            for(d,R),mask in events.items():
                if flag and d==2:continue
                new=list(pair)
                if 0<=d<2:new[d]=min(new[d],R)
                new=tuple(new)+(int(d==2),);mask&=allowed(new)
                if mask:following[new]=following.get(new,0)|mask
        front={pair:mask&~seen.get(pair,0)for pair,mask in following.items()if mask&~seen.get(pair,0)}
        for pair,mask in front.items():seen[pair]=seen.get(pair,0)|mask
    f=min(layers[:-1]);return dict(w=w,n=n,k=k,complete=True,tau=t,residual=f,lower=2*t-int(2*f<=k),critical_pronic=critical_pronic,closed_holes=closed_holes,wide_square=wide_square,states=sum(m.bit_count()for m in seen.values()),pairs=len(seen),layers=layers,build_seconds=build,cpu_seconds=time.process_time()-begun)
if __name__=='__main__':
    rows=[]
    for case in sys.argv[1:]or['20,20,12','24,24,13','28,28,15','46,46,24']:
        row=run(*map(int,case.split(',')),seconds=90);rows.append(row);print({k:v for k,v in row.items()if k!='layers'},flush=True)
        Path(__file__).with_suffix('.json').write_text(json.dumps(dict(scope=__doc__,rows=rows),indent=2)+'\n')

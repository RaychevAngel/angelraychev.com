"""Exact full capture clock inside one fixed anchored prefix per current color.
Physical upper only; no unrestricted normal form asserted.
"""
import sys,time,json
from pathlib import Path
from collections import deque
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'src'))
from resumed_even_construction_prefix_arithmetic import erosion_count
from bridge_upper_transport_odd_coupling import physical_step

def erosions(w,n):
 h=w*n//2
 if w%2==0:return [[erosion_count(w,n,p,x) for x in range(h+1)] for p in (0,1)]
 # physical_step output p uses erosion of target color 1-p.
 out=[[],[]]
 for x in range(h+1):
  a,b=physical_step(w//2,h,0,(x,x))
  out[1].append(a);out[0].append(b)
 return out

def update(F,E,k,h):
 # Previous color0 survivor cap P=E1(target color1); color1 cap Q=E0(target color0).
 pairs=[(E[1][y],E[0][x]) for x,y in enumerate(F) if y>=0]
 # P nonincreasing, Q nondecreasing: process a from h down to0;
 # admissible P>=a-k appears sequentially, and candidate P>=a gives Q+k.
 G=[-1]*(h+1);lo=hi=0;window=deque();bestQ=-1
 # Easier ascending P: reverse pairs, Q nonincreasing.
 pairs.reverse();i=j=0;count=len(pairs)
 # For increasing a, Q max in P>=a is first such pair; window a-k<=P<a.
 for a in range(h+1):
  while j<count and pairs[j][0]<a:
   val=sum(pairs[j])
   while window and window[-1][1]<=val:window.pop()
   window.append((j,val));j+=1
  while i<count and pairs[i][0]<a-k:i+=1
  while window and window[0][0]<i:window.popleft()
  b=pairs[j][1]+k if j<count else -1
  if window:b=max(b,window[0][1]+k-a)
  G[a]=min(h,b)
 return G

def run(w,n,k,trace=False):
 start=time.process_time();h=w*n//2;E=erosions(w,n)
 F=[-1]*(h+1);F[0]=0;d=0;hist=[]
 while F[h]<h:
  G=update(F,E,k,h);d+=1
  assert all(G[x]>=F[x] for x in range(h+1))
  assert all(G[x]>=G[x+1] for x in range(h))
  assert G!=F,(w,n,k,d)
  F=G
  if trace:hist.append(F)
 return dict(w=w,n=n,k=k,upper=d,CPU_seconds=time.process_time()-start),hist

if __name__=='__main__':
 rows=[]
 for spec in sys.argv[1:] or ['16,16,15','20,20,12','24,24,13','28,28,15','46,46,24','81,82,41','108,108,55','129,130,65']:
  row,_=run(*map(int,spec.split(',')));print(row,flush=True);rows.append(row)
 Path(__file__).with_suffix('.json').write_text(json.dumps(dict(rows=rows,scope=__doc__),indent=2)+'\n')

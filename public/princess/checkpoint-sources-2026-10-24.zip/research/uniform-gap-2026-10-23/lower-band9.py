"""Universal unflagged nine-threshold lower with proven-range pronic bands.

Ordinary proof under independent review in lower-erosion-proof.md.
No radius state, no history flag, no geometric attainment assertion.
"""
from pathlib import Path
import importlib.util
sp=importlib.util.spec_from_file_location('banded_geometry',Path(__file__).with_name('lower-history-lens.py'))
_geometry=importlib.util.module_from_spec(sp);sp.loader.exec_module(_geometry)
FEATURES=_geometry.er.FEATURES
survivor=_geometry.banded_survivor
step=_geometry.er.step
bounds=_geometry.er.run

if __name__=='__main__':
    for case in[(24,24,13),(28,28,15),(46,46,24),(81,82,41),(108,108,55)]:print(bounds(*case))

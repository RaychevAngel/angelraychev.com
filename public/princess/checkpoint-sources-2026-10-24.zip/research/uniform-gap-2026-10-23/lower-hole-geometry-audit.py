"""Independent literal whole-triangle attack on closed-hole history separation."""
import json,time
from pathlib import Path
start=time.process_time();checks=0;minimum=10**9;worst=None
for w in range(4,33):
 for n in sorted({w,w+1,2*w}):
  if w*n%2:continue
  cells=[(x,y)for x in range(w)for y in range(n)];corners=[(0,0),(w-1,0),(0,n-1),(w-1,n-1)]
  tri={(o,r):{p for p in cells if (sum(p)-sum(o))%2==0 and abs(p[0]-o[0])+abs(p[1]-o[1])<=2*r-2}for o in corners for r in range(2,w//2)}
  N={key:{q for x,y in value for q in[(x-1,y),(x+1,y),(x,y-1),(x,y+1)]if 0<=q[0]<w and 0<=q[1]<n}for key,value in tri.items()}
  for(o,r),T in tri.items():
   assert len(T)==r*r
   for(o2,s),U in tri.items():
    if(sum(o)-sum(o2))%2==0:continue
    separation=len(T-N[o2,s])-(r-1)
    assert separation>=r*(r-1)//2+1,(w,n,o,o2,r,s,separation)
    checks+=1
    if separation<minimum:minimum=separation;worst=(w,n,o,o2,r,s)
row=dict(triangle_pairs=checks,minimum_forced_slack=minimum,minimum_case=worst,all_passed=True,cpu_seconds=time.process_time()-start)
Path(__file__).with_suffix('.json').write_text(json.dumps(row,indent=2)+'\n');print(row)

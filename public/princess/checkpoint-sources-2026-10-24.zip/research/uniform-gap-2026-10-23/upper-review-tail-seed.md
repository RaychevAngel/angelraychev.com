# Independent review: bounded-tail seed transfer

24 October 2026 UTC. Accepted ordinary theorem and implementation review.
No Lean claim; no unrestricted-width absolute-gap claim.

## The lower-bound transfer

The maximum successful unknown-radius start for each corner count is a
valid necessary seed even if its paired-model winning set has holes.
The descending tests do not infer downward closure: they exclude every
larger start individually, using the ordinary frontier only as an
already proved upper limit for the search. Closing the resulting seed
downward enlarges the winning set and therefore weakens, rather than
invalidates, a necessary bound.

For a shortest paired-model capture path longer than H, its final H
steps begin at a state whose size is at most this seed's corresponding
coordinate. Forgetting radii is a relaxation: capacities increase and
the reset/movement maps preserve componentwise radius order. The prefix
projects to ordinary corner transitions. Thus the seeded ordinary clock
plus H cannot exceed the paired-model clock. Applying the already
accepted merged-model full-game theorem yields `T>=2*tau_tail-1`.
This argument does not require the artificially closed seed to satisfy
the guarded-merger property. The sufficient hypothesis `h>kH` follows
from the maximum k decrease per day and excludes short initial capture.

The ordinary seed is also contained in its own ordinary predecessor.
Each coordinate maximum is attained by a paired winning start; its first
step, with radii forgotten, enters a paired winning set for at most H-1
days and hence the H-day seed. Direct capture is handled by the zero
state. This supplies horizon monotonicity for the seeded ordinary
recurrence. Its first update orders the three coordinates, after which
the previous middle-entry argument applies. This clarification was
added during review; no monotonicity of the paired winning sizes is used.

## Bounded-horizon evaluator

Every positive target size is at least its survivor size, which is at
least the old size minus k. Pruning states above k times the remaining
horizon is therefore exact. The graph is time-homogeneous, so discarding
later copies of an identical state does not discard a shorter successful
continuation. These two reductions are independent of interval
compression and of each other.

`upper-review-tail-seed.py` checks 1,152 arbitrary valid starts against
literal forward sets on six boards, horizons one through four, and four
reset-switch configurations. The comparison implementation uses neither
the size pruning nor earliest-visit removal nor interval unions. It
enumerates q, T, and reset conditions directly and counts ball capacities
from literal board cells. All checks passed.

## Length-independent seed

The largest reset radius is `2r-2`; because the first reset occurs after
a move, every finite radius in H steps is at most `2r-3+H`. Under the
stated separation bound on n, balls at different long ends cannot meet.
At one short end their literal geometry is a fixed-width half-infinite
strip. Even width has one eligible opposite-color anchor at that end;
odd width has the two corner colors at different ends. These are exactly
the cases handled by the stable capacity formulas. Single finite radii
and unknown radii satisfy the same count argument.

The area condition makes all high inverses and board caps inactive on
states of size at most kH. The short-board double critical exception is
also excluded by the separation inequality. Reset predicates depend
only on width and state sizes. Consequently the full bounded-horizon
decision graph relevant to success stabilizes, including its labels and
capacities, rather than just the computed seed values.

## The 44-row certificate

For width44, budget24, H28, the checked seed is `(309,309,309)` for both
length parities. The stable lengths begin at140 and141 respectively.
The ordinary seeded recurrence and physical upper recurrence have common
length period two and full-day increment44. The exact translated-tail
checks in the supplied certificate cover both parities; the96 shorter
lengths44 through139 are separately evaluated in the accepted paired
model. Together these establish

    22n-635 <= T_24(44,n) <= 22n-631,   every n>=44.

Combining this with the already checked BAND9 panel can replace its
remaining five-day line by a four-day bound. The finite-width panel
still does not prove a four-day gap for arbitrary width.

"""Bounded horizon selection for the remaining three-day panel lines."""
from pathlib import Path
import json,time
import comparison_two_sided as bridge
import comparison_two_sided_certificate as clock
import comparison_periodic as base
HERE=Path(__file__).resolve().parent


def horizons(w,k,p):
    r=w//2;n=w+(w%2!=p);limit=w*n//2-r*(r+1)-2
    B=(0,-1,-1);H=0
    while max(base.model_infinite(w,k,B))<=limit:
        B=base.model_infinite(w,k,B);H+=1
        assert H<4*w*w
    return sorted({min(w+4,H),H})


def run():
    st=time.process_time();rows=[]
    panel=json.loads((HERE/'comparison-three-day-panel.json').read_text())
    todo=[(x['w'],x['k'],x['parity'])for x in panel['results']if x['maximum_gap']==3]
    for w,k,p in todo:
        if w in(24,25):continue
        for H in horizons(w,k,p):
            a=bridge.run(w,k,H,H,p)
            b=clock.meet_bounds(w,a['n'],k,H,H,a['tail']['paired_seed'],a['head']['defects'])
            row={z:b[z]for z in('w','n','k','J','H','lower','upper','gap')}
            row.update(parity=p,head=a['head']['defects'],tail=a['tail']['paired_seed'])
            rows.append(row);print(row,flush=True)
            (HERE/'comparison-panel-candidates.json').write_text(json.dumps(dict(
                scope=__doc__,CPU_seconds=time.process_time()-st,results=rows),indent=2)+'\n')
            if b['gap']<=2:break
    return rows


if __name__=='__main__':run()

"""Literal paired ball capacities via exact piecewise affine lattice counts."""
from itertools import combinations

def strip_count(U,lower,upper):
    if U<0:return 0
    cuts={0,U+1}
    differences=[]
    for lines in (lower,upper):
        differences += [(a-c,b-d)for (a,b),(c,d)in combinations(lines,2)]
    differences += [(a-c,b-d+1)for a,b in upper for c,d in lower]
    for a,b in differences:
        if a:
            z=(-b)//a
            for t in (z,z+1,z+2):
                if 0<t<U+1:cuts.add(t)
    cuts=sorted(cuts);total=0
    for x,y in zip(cuts,cuts[1:]):
        a,b=min(upper,key=lambda z:z[0]*x+z[1]);c,d=max(lower,key=lambda z:z[0]*x+z[1])
        slope=a-c;intercept=b-d+1
        first=slope*x+intercept;last=slope*(y-1)+intercept
        assert first*last>=0 or y-x==1,(U,lower,upper,x,y,first,last)
        if first+last>0:total+=(first+last)*(y-x)//2
    return total

def capacities(w,n,R,S):
    D=w+n-2;cs=((0,0),(w-1,0),(0,n-1),(w-1,n-1));best=bestc=0
    for ax,ay in cs:
        if (ax+ay)%2!=1:continue
        area=0
        for p in (0,1):
            U=(w-1-p)//2;V=(n-1-p)//2
            lo=[(0,0)];hi=[(0,V),(-1,R//2-p)]
            if ay==0:hi.append((1,(S-w+1)//2))
            elif ax==0:lo.append((1,-((S-n+1)//2)))
            else:lo.append((-1,-((S-D+2*p)//2)))
            area+=strip_count(U,lo,hi)
        c=sum((x+y)%2==0 and x+y<=R and abs(x-ax)+abs(y-ay)<=S for x,y in cs)
        best=max(best,area);bestc=max(bestc,c)
    return best,bestc

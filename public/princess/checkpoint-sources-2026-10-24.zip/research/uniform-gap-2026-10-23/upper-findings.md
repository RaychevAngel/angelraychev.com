# Upper construction lane: joint prefix scheduling and bounded pyramid search

24 October 2026 UTC. New private exploration; no public artifact changed.

## Exact restricted evaluator

`upper-joint-prefix.py` permits arbitrary per-day allocation of the budget
between two parity cohorts, each constrained to a fixed anchored prefix.
This is broader than concatenating a solo strategy and its reflection.
It is a physical upper evaluator only. No unrestricted normal form is claimed.

Let F(x) be the largest second-cohort prefix jointly capturable with a
first-cohort prefix of size x in a given remaining horizon. It is
nonincreasing. For target capacities (x,F(x)), exact prefix erosion gives
pre-inspection survivor capacities `P=E1(F(x)), Q=E0(x)`. Thus the next
backward frontier is

    G(a) = min(h, max_x [Q+k-max(0,a-P)]),

where x ranges over valid F entries with `a<=P+k`. This expression is
necessary and sufficient inside this fixed physical family: inspections
remove suffixes of the two current prefixes, and their costs add. It also
covers unused daily capacity and empty cohorts.

P decreases and Q increases as x increases. Splitting the maximum into
`P>=a` and `a-k<=P<a` gives one monotone endpoint query and one sliding-window
maximum of P+Q. Consequently an entire update costs O(h), h=wn/2, and a D-day
calculation costs O(hD). The companion `upper-joint-prefix-opposite.py`
retains both alternating phase assignments when the two anchors have
opposite color. These two corner-color possibilities cover the corresponding
fixed-anchor phase patterns; arbitrary orientation changes are not asserted.

The independent audit compares 1,390 full frontier updates with literal
candidate maximization, and 240 erosion values with room-set neighborhoods.
All pass. Strategy reconstruction is implicit in the maximizing predecessor;
this diagnostic implementation currently reports only the exact restricted
clock, and does not write a reconstructed complete schedule.

## Outcome against the frozen fixtures

Taking the better anchor pattern did not improve any of the tested large
frozen uppers: 28x28/k15 remains259; 46x46/k24 remains509;
81x82/k41 remains1607; 108x108/k55 remains1539; and129x130/k65 remains2803.
The opposite-anchor variant recovers the known207 at24x24/k13; using the
same corner alone gives208 and would miss that established strategy.
This is a restriction-family negative result on those instances, not a
proof of optimality or a universal no-improvement theorem.

## A bounded non-prefix probe

`upper-pyramid-sat.py` encodes actual downward-pyramid height evolution,
including empty bottom fibers and top clipping, and searches for a fixed
solo horizon. It would independently replay any successful solution on
literal rooms. One worker was used. Searches targeting254 solo days on
46x46/k24 and129 on28x28/k15 returned UNKNOWN after30seconds each; a small
known-solvable12x12/k7,36-day calibration also returned UNKNOWN after10seconds.
These timeouts prove nothing and supply no improved upper. No solver output
is used as a lower certificate. This broad feasibility encoding is not a
promising immediate substitute for geometric structure.

Existing work already explores alternative legal flip orders and physical
boundary clipping during transport. Repeating those priority rules would not
be a new approach. The upper lane switched to independent proof review of
the useful uniform length reduction and the interval lower implementation;
those reviews are separate files. No uniform small-gap theorem or strict
upper improvement was obtained in this lane.

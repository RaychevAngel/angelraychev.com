"""Experimental common tail relaxation across every length in one parity."""
import json,time
from functools import lru_cache
from pathlib import Path
import comparison_tail_seed as tail
import comparison_periodic as base
from root_capacity import capacities
from bridge_corner_frontier import small_inverse,large_inverse
import comparison_two_sided as bridge
FLAGS=dict(pronic_interval=True,critical_pronic=True,wide_square=True)
HERE=Path(__file__).resolve().parent


def run(w,k,H,parity):
    r=w//2;nmin=w+(w%2!=parity)
    ref=tail.seed(w,k,H,parity,**FLAGS);nref=ref['n'];href=w*nref//2;Dref=w+nref-2
    B=(0,-1,-1)
    for _ in range(H):B=base.model_infinite(w,k,B)
    assert w*nmin//2>=max(B)+r*r+1,('low-zone not guaranteed',w,H,B)
    if w%2==0 and nmin==w+1:
        assert small_inverse(2,0,max(B))<=r,('additional critical exception',w,H)
    original=tail.lens.engine
    h,D,_,relation=original(w,nref,k,**FLAGS)
    @lru_cache(None)
    def envelope(R,S):
        best=bestc=0
        for n in range(nmin,nref+1,2):
            cap,c=capacities(w,n,w+n-2 if R==Dref else R,w+n-2 if S==Dref else S)
            best=max(best,cap);bestc=max(bestc,c)
        return best,bestc
    tail.lens.engine=lambda *args,**kw:(h,D,envelope,relation)
    try:
        captures=tail.model(w,nref,k,H,**FLAGS);V=[];tests=0
        for c in range(3):
            for a in range(B[c],c-1,-1):
                tests+=1
                if captures(a,c):V.append(a);break
            else:V.append(-1)
    finally:tail.lens.engine=original
    return dict(w=w,k=k,H=H,parity=parity,nmin=nmin,nref=nref,
                ordinary=B,stable_seed=ref['paired_seed'],envelope_seed=V,
                tests=tests,capacity_pairs=envelope.cache_info().currsize)


def head_envelope(w,k,J,parity,nref):
    r=w//2;nmin=w+(w%2!=parity);href=w*nref//2;Dref=w+nref-2
    original=bridge.dual.engine
    h,D,_,relation=original(w,nref,k,**FLAGS)
    @lru_cache(None)
    def envelope(R,S):
        dr,ds=Dref-R,Dref-S;loss=href;bestc=0
        lengths=list(range(nmin,4*r+2,2))+[nref]
        for n in lengths:
            cap,c=capacities(w,n,w+n-2-dr,w+n-2-ds)
            loss=min(loss,w*n//2-cap);bestc=max(bestc,c)
        return href-loss,bestc
    bridge.dual.engine=lambda *args,**kw:(h,D,envelope,relation)
    try:result=bridge.head(w,nref,k,J)
    finally:bridge.dual.engine=original
    defects=result['defects'];dm=max(d for d in defects if d is not None)
    assert w*nmin//2-dm-k>r*(r+1),('head leaves high-zone',w,J,defects)
    if w%2==0 and nmin==w+1:
        assert large_inverse(2,0,max(0,dm+k-r))<=r,('additional critical exception',w,J)
    return dict(w=w,k=k,J=J,parity=parity,nmin=nmin,nref=nref,
                defects=defects,capacity_pairs=envelope.cache_info().currsize)


if __name__=='__main__':
    st=time.process_time();rows=[]
    for w,k,H in[(44,24,48),(46,24,80),(47,24,80)]:
        for p in((0,1)if w%2==0 else(0,)):
            x=run(w,k,H,p);rows.append(x);print(x,flush=True)
            (HERE/'comparison-tail-envelope.json').write_text(json.dumps(dict(scope=__doc__,CPU_seconds=time.process_time()-st,results=rows),indent=2)+'\n')

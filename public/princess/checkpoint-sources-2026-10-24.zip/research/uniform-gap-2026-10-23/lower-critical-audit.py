"""Literal support audit of proposed critical refined capacities."""
import sys,json,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'src'))
def low(i,j,u,s):
    if not 0<=u<=j<=2 or not 0<=i<=2 or s<i+2*j:return -10**12
    z=s-i-2*j;base=i+j+u
    if u:return base+z*z+3*z
    if i:return base+z*z+2*z
    if j:
        t=z+2
        return base-1+max(t*(t-1)//2,t*(t-3)+1)
    return max(s*(s-1)//2,s*(s-2))
from resumed_even_construction_formula_profile import F

def audit(w,n):
    cells=[(x,y)for x in range(w)for y in range(n)];C=[[p for p in cells if sum(p)%2==z]for z in(0,1)]
    ids=[{p:i for i,p in enumerate(X)}for X in C]
    corner={(0,0),(w-1,0),(0,n-1),(w-1,n-1)}
    ng=[[sum(1<<ids[1-z][q] for q in[(x-1,y),(x+1,y),(x,y-1),(x,y+1)]if q in ids[1-z])for x,y in C[z]]for z in(0,1)]
    cm=[sum(1<<ids[z][p]for p in corner if p in ids[z])for z in(0,1)]
    h=w*n//2;r=w//2;full=(1<<h)-1
    violations=[];tested=0;critical=0
    for z in(0,1):
        N=[0]*(1<<h)
        for mask in range(1,1<<h):
            bit=mask&-mask;N[mask]=N[mask^bit]|ng[z][bit.bit_length()-1]
            a=mask.bit_count();b=N[mask];s=b.bit_count()-a
            if s!=r:continue
            critical+=1
            i=(mask&cm[z]).bit_count();j=(b&cm[1-z]).bit_count()
            u=sum((mask&ng[1-z][t])==ng[1-z][t]for t in range(h)if(cm[1-z]>>t)&1)
            v=sum((b&ng[z][t])==ng[z][t]for t in range(h)if(cm[z]>>t)&1)
            exception=(i,j)==(1,1)or(n==2*r+1 and(i,j)==(2,0))
            if exception:continue
            tested+=1
            if not(a<=low(i,j,u,s)or h-a-s<=F(2-j,2-v,s+i-v)):
                violations.append(dict(color=z,size=a,i=i,u=u,j=j,v=v,s=s,cells=[C[z][t]for t in range(h)if(mask>>t)&1]))
                if len(violations)>=8:break
        if violations:break
    return dict(w=w,n=n,tested=tested,critical=critical,violations=violations)
if __name__=='__main__':
    start=time.process_time();out=[]
    for w,n in[(4,4),(4,5),(4,6),(4,7),(4,8),(6,6),(6,7)]:
        row=audit(w,n);out.append(row);print(row,flush=True)
        Path(__file__).with_suffix('.json').write_text(json.dumps(dict(rows=out,cpu_seconds=time.process_time()-start),indent=2)+'\n')

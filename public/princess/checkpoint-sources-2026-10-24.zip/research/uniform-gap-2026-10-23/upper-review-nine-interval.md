# Independent review: exact nine-feature interval evaluator

24 October 2026 UTC. Accepted exact transcription of the unflagged
nine-feature paired-radius model. This is an evaluation improvement,
not a new physical inequality or a Lean verification claim.

The source interval calculation is exact: with deletion charge ell,
the attainable positive survivors from `[a,z]` are
`[max(1,a-k), min(z-ell,h-4+i+u)]` when ell is at most k.
The implementation correctly omits lower size bounds involving i or u.
Likewise the target insertion does not reintroduce `size>=corner_count`
or `size>=2*erosion_count`. These lower bounds were deliberately removed
in the accepted merger relaxation.

For each fixed feature tuple, static admissibility gives a monotone
target tail. An exceptional numerical target is unique for each survivor
size. The low target functions are increasing; each high target also
increases as survivor size increases. Where low and high pronic
exceptions share a tuple, their target ranges are separated by at least
the gap between b squared and b squared plus b. This remains true for
forbidden exact-pronic points. Therefore only the smallest survivor's
exception can remove a point from the unlabeled union, and the next
survivor repairs it exactly when the static cap admits that next size.
No later exceptional target can collide with it.

The admitted low reset records use the correct closed surplus and
closed size: sigma is `r-(v-i)` and q is capped by
`P(v,u,j;sigma)-(v-i)`. The upper source and target feature capacities
are also included. At these subcritical low events the high profile
cannot apply, P implies the ordinary corner bound, and the extra static
bands do not remove an interior part of the record. Thus the record is
an exact integer interval. Critical and high reset points are gated by
the static cap. Forbidden points are removed without creating a label.

Radius capacities separately maximize area, occupied corners and eroded
corners over the allowed opposite-color anchors, just as in the accepted
bitset model. The erosion condition checks both neighbors of each corner.
Reachable intervals merge only within an identical radius/feature key;
earliest-visit subtraction uses that same complete key. The engine adds
no radius dominance and no unsupported geometric state compression.

`upper-review-nine-interval.py` independently tests the relation against
literal q and T rules, without calling the evaluator's event or record
functions. Across ten boards and all four critical-pronic/wide-square
switch combinations, 17,280 labeled interval unions and693,688 admitted
base point cases passed. This supplements the lower lane's whole-source
edge, literal capacity, and complete first-arrival-layer comparison with
the bitset evaluator. The receipts identify their exact sources.

The evaluator includes the accepted static bands and both dual high
radius resets. The temporal closed-hole flag is excluded from this
review and from this interval engine. Exactness of this necessary model
does not identify every relaxed path as a physical strategy.

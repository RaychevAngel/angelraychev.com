# Projection of reachable nine-feature paths to the three-corner model

24 October 2026 UTC. New short algebraic lemma, submitted for independent
review. No computation was used and no accepted source was modified.

This addresses the deliberately omitted positive feature/cardinality
lower bounds in the nine-feature graph. It is not legitimate simply to
identify its retained corner count i with the three-corner survivor's
count when q<i.

Write `B(i,j,T)=bridge_corner_frontier.survivor_bound(w,n,i,j,T,True)`.
The first lemma is

    B(i,j,T) >= B(i+1,j,T)-1,       i=0,1.               (L)

All B are nonnegative; iterating gives `B(i,j,T)>=B(v,j,T)-(v-i)` for
`i<=v`. The proof includes both width-dependent critical exceptions.

## 1. Verification of (L) from the inverse formulas

The ordinary inverse cost is the minimum of its low inverse, high inverse,
and critical cap. Each individual cost at i is at most its value at i+1
plus one. Thus the same holds for their minimum.

For the low inverse with j>=1, set `c=i+2j-2`; it is
`c+max(2,ceil(sqrt(max(0,T-2c))))`. Increasing c by one decreases the
max-root term by at most one, so the entire cost does not decrease.
For j=0, the i=1 to i=2 costs are `max(1,rho(T))` and
`1+max(1,rho(T-2))`, where `rho(x)=min{z>=0:z(z+1)>=x}` and negative
arguments are clipped to zero. Because successive pronic numbers differ
by at least two, `rho(T)-rho(T-2)<=1`, so again the cost does not decrease.
For i=0 to i=1, the i=0 low inverse is
`min(rho(2T),rho(T)+1)`, at most the i=1 cost plus one.

For the high inverse, put d=h-T, A=2-i, and C=2-j. If C>0, the inverse
is `A+C+max(0,ceil(sqrt(max(0,d-C+1)))-1)`, so removing one own corner
raises it by exactly one. For C=0, the i=0 and i=1 inverses are respectively
`2+rho(d)` and `1+rho(d)`. The i=2 inverse, for d>0, is
`min(rho(2d)+1,1+ceil(sqrt(d+1)))`. Both entries are at least
`1+rho(d)`, because `rho(d)<=rho(2d)` and
`rho(d)<=ceil(sqrt(d+1))`. At d=0 the three costs are 2,1,0, so the
one-unit property also holds.

Each critical cap is b or b+1, hence its increase under any adjacent
change of i is at most one, including the near-square double exception.

The raw survivor bound is T minus the minimum cost, clipped above at
`h-2+i`. Both raw terms at i are at least their i+1 counterparts minus
one. If B(i+1,j,T)>0, its value is at least i+1; therefore the lower
validity cutoff at i cannot violate (L). For i=0 and B(1,j,T)=1, the
claimed lower bound is only zero. If B(i+1,j,T)=0, (L) is immediate.
The target cutoff `T>=max(1,j)` and target upper clipping are independent
of i. This proves (L) for the complete implemented function.

## 2. Projecting one reachable nine-feature edge

A positive nine-feature edge has source `(a,c,e)`, cost p, survivor q=a-p
with features `(i,u)`, and target `(T,j,v)`. Its accepted bound includes

    B(v,j,T) >= q+(v-i),       i<=v.

In particular `B(v,j,T)>0`, so every reached positive target has `T>=j`.
Starting from the full support, induction therefore gives `a>=c` at every
reachable source, even though the ambient nine-feature state list also
contains some states violating this inequality.

Project the retained survivor count to

    i*=min(i,q).

Then `i*<=c`, `i*<=q`, and

    c-i*=max(c-i,c-q)<=p,

using the nine-edge deletion charge and `c<=a=q+p`. If q>=i, (L) gives
`B(i*,j,T)>=q`. If q<i, the only positive case is q=1,i=2,v=2.
Positivity of B(2,j,T) makes it at least two, so (L) gives
`B(1,j,T)>=1=q`. Thus the three-corner model admits the same sizes,
cost, and target corner count, using i* rather than i when necessary.

Direct capture projects too, since the state size and budget are unchanged.
This proves projection to the ordinary three-corner graph on all paths
reachable from the full state, without restoring a dropped nine-feature
lower constraint or altering its merger theorem.

## 3. Projection with the current radius resets

Retain the same two radius values and the same source/target corner counts.
The nine-feature area and occupied-corner capacity bounds include the
three-corner bounds; dropping erosion restrictions only enlarges them.

When i*=i, every reset of the three-corner dual graph is also imposed by
the nine-feature graph at that same survivor and target: low square,
subcritical pronic interval, critical exact pronic, high exact pronic,
and high exact square. Extra nine-feature pronic restrictions can delete
edges, which causes no problem for this direction of projection.

When i* differs from i, q=1,i=2 becomes i*=1. This creates no new
three-corner reset: all low resets require radius at least two, while
the relevant high events have q>=b^2>=4. A nine high-square reset also
cannot occur at q=1, since its radius is strictly below b.

Therefore, for the current mutually matching reset switches, a reachable
nine-feature path projects with identical sizes and radius coordinates
to the three-corner dual-radius graph. In particular

    tau_M3 <= tau_M9.

The same argument applies after a head junction, because reached states
already satisfy a>=c. Forgetting both radii only relaxes continuations.
Thus the accepted three-corner tail model can be used in the head/tail
transfer with a head computed in M9, and ordinary F can propagate its
middle. This last conclusion is conditional only on independent acceptance
of the short projection proof above; it was not implicit in the earlier
three-corner transfer theorem.

Any future extra three-corner reset or change to the underlying ordinary
bound must be checked again against this argument. This note covers the
current accepted model definitions, not arbitrary future refinements.

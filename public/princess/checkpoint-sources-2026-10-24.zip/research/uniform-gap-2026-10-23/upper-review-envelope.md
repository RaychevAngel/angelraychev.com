# Independent review: common-length boundary envelopes

24 October 2026 UTC. Accepted ordinary proof, implementation, and numerical
certificate review. No Lean claim or unrestricted-width constant-gap claim.

## Tail containment and the seed

The infinite ordinary H-step frontier is a necessary bound for all tail
sizes once the stated low-region margin holds. On the exceptional
`n=w+1` board, the additional small-inverse test makes the extra critical
channel inactive. This justifies using the sharper bound b instead of kH.

Every actual paired-tail history can be lifted to unclipped finite radii
and a separate unknown-radius symbol. A finite radius exceeding a short
board's diameter represents the same full ball as its clipped value.
Subsequent growth and resets preserve this interpretation. Taking separate
maxima of area and corner capacities over all shorter boards enlarges
the model. Beyond the stable onset, finite-radius capacities stabilize.
For unknown/unknown radii the reference area does not dominate arbitrary
long-board area, but it admits every relevant size at most b; this
exception was clarified during review. Thus actual winning tails are
contained in the common envelope graph on every length.

The descending search still excludes larger starts individually and
does not assume that the envelope winning set is an interval. Forgetting
radii is a relaxation because the capacity envelope is monotone. Each
maximal H-day winner therefore has an ordinary first transition into
the H-day prefix seed (or immediate capture), proving `V<=F(V)`. The
low-region and short-board critical checks make that first transition
valid for every finite board under consideration. This supplies the
horizon monotonicity needed by periodic insertion.

## Self-consistent head containment

The large-ball capacity envelope is expressed in deficits relative to h.
Its separate extrema dominate every board, using the already reviewed
stabilization of small antipodal complement balls. The maximum d is
computed over all envelope states reached within J steps.

The guard `h_min-d-k>r(r+1)` is applied to each mapped predecessor in
the induction. It proves that the next actual survivor is still in the
high region before translation invariance is invoked. It is therefore
not a circular assumption that unknown actual trajectories stay high.
When `n=w+1`, an otherwise new surplus-r transition would have target
deficit at most `d+k-r`; the large-inverse test makes that transition
already available in the reference graph. No exceptional short-board
channel is omitted.

The resulting head extrema and tail seed are necessary relaxations,
not asserted realizable boundaries. Their use in the existing two-sided
clock transfer is valid. Short representatives explicitly exclude capture
within J+H by the ordinary necessary clock; long lengths use the strict
area condition. The insertion onset also contains the meeting margin,
so no early clock is skipped.

## Reproduced all-length applications

I independently reran both envelope computations and all245 finite
representatives, including exact translated tails, for the five parity
lines. All required reference-board and self-consistency premises were
also checked. The accepted conclusions are:

    22n-633 <= T_24(44,n) <= 22n-631, every n>=44;
    46n-1609 <= T_24(46,n) <= 46n-1607, every n>=46;
    94n-3683 <= T_24(47,n) <= 94n-3681, every even n>=48.

The source-hashed reproduction is `upper-review-envelope-certificate.json`;
the explicit premise margins are in `upper-review-envelope-premises.json`.
Combined with the previously certified remaining lines, these may reduce
the finite-width panel's maximum gap to three. That panel-level assembly
is distinct from a theorem giving three days for unbounded width.

"""Find smaller successful horizons; no monotonicity or minimality asserted."""
from pathlib import Path
import json,time
import comparison_two_sided as bridge
import comparison_two_sided_certificate as clock
HERE=Path(__file__).resolve().parent


def run():
    st=time.process_time();old=json.loads((HERE/'comparison-panel-candidates.json').read_text())['results']
    groups={}
    for x in old:groups.setdefault((x['w'],x['k'],x['parity']),[]).append(x)
    out=[]
    for(w,k,p),xs in groups.items():
        best=min((x for x in xs if x['gap']<=2),key=lambda x:x['H'])
        failures=[x['H']for x in xs if x['gap']>2 and x['H']<best['H']]
        lo=max(failures,default=best['H']-1);hi=best['H']
        for _ in range(4):
            if hi-lo<=1:break
            H=(hi+lo)//2;a=bridge.run(w,k,H,H,p)
            b=clock.meet_bounds(w,a['n'],k,H,H,a['tail']['paired_seed'],a['head']['defects'])
            if b['gap']<=2:
                hi=H;best={z:b[z]for z in('w','n','k','J','H','lower','upper','gap')}
                best.update(parity=p,head=a['head']['defects'],tail=a['tail']['paired_seed'])
            else:lo=H
        out.append(best);print(w,k,p,best['H'],best['gap'],flush=True)
        (HERE/'comparison-minimized-candidates.json').write_text(json.dumps(dict(
            scope=__doc__,CPU_seconds=time.process_time()-st,results=out),indent=2)+'\n')


if __name__=='__main__':run()

"""Compare every source edge union against the independent bitset evaluator."""
from pathlib import Path
import importlib.util,json,time,random
HERE=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('interval_nine',HERE/'lower-dual-nine-interval.py')
m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)


def audit(w,n,k,rng):
    states,ids,rows=m.ref.graph(w,n,k,critical_pronic=True,closed_holes=False,wide_square=True)
    h,D,capacity,relation,cap,event=m.engine(w,n,k)
    def row(a,z,c,e):
        out={}
        if a<=k:out[-1,-1]=1<<ids[0,0,0]
        for i,u,j,v,charge in m.ref.er.OPTIONS[c,e]:
            if charge>k:continue
            qa=max(1,a-k);qb=min(z-charge,h-4+i+u)
            if qa>qb:continue
            for d,r,lo,hi in relation(i,u,j,v,qa,qb):
                mask=sum(1<<ids[T,j,v]for T in range(lo,hi+1))
                out[d,r]=out.get((d,r),0)|mask
        return {key:mask for key,mask in out.items()if mask}
    checks=0
    for a,c,e in states:
        wanted={key:mask for key,mask in rows[ids[a,c,e]].items()if mask}
        got=row(a,a,c,e)
        assert got==wanted,(w,n,k,(a,c,e),[(key,[states[z]for z in range(len(states))if ((got.get(key,0)^wanted.get(key,0))>>z)&1])for key in got.keys()|wanted.keys()if got.get(key,0)!=wanted.get(key,0)])
        checks+=1
    for c,e in m.ref.er.FEATURES:
        top=h-4+c+e
        for _ in range(30):
            a=rng.randint(1,top);z=rng.randint(a,top);wanted={}
            for aa in range(a,z+1):
                for key,mask in rows[ids[aa,c,e]].items():wanted[key]=wanted.get(key,0)|mask
            wanted={key:mask for key,mask in wanted.items()if mask}
            assert row(a,z,c,e)==wanted,(w,n,k,'interval',a,z,c,e)
            checks+=1
    A,C=m.ref.capacities(w,n);E=m.ref.erosion_capacities(w,n)
    for R in range(D+1):
        for S in range(D+1):
            assert capacity(R,S)==(A[R][S],C[R][S],E[R][S]),(w,n,R,S)
    old=m.ref.run(w,n,k,seconds=60,closed_holes=False)
    new=m.run(w,n,k,seconds=60,trace=True)
    assert old['complete']and new['complete']
    for key in ['tau','residual','lower','states','layers']:
        assert old[key]==new[key],(w,n,k,key,old[key],new[key])
    return dict(w=w,n=n,k=k,source_edge_unions_checked=checks,capacity_pairs=(D+1)**2,
                identical_full_first_arrival_layers=len(new['layers']),lower=new['lower'])


if __name__=='__main__':
    start=time.process_time();rows=[];rng=random.Random(722)
    for w in range(4,11):
        for n in range(w,w+3):
            if w*n%2:continue
            for k in range(w//2+1,w//2+3):
                r=audit(w,n,k,rng);rows.append(r)
    out=dict(passed=True,rows=rows,cases=len(rows),source_edge_unions_checked=sum(r['source_edge_unions_checked']for r in rows),
             capacity_pairs=sum(r['capacity_pairs']for r in rows),CPU_seconds=time.process_time()-start)
    Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
    print({key:val for key,val in out.items()if key!='rows'})

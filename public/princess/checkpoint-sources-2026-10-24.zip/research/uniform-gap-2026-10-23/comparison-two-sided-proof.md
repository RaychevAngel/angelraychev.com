# Two bounded boundary histories with an ordinary middle

24 October 2026 UTC. Ordinary proof submitted for independent review.
Implementation: `comparison_two_sided.py`; certificates:
`comparison_two_sided_certificate.py` and its JSON output.
This is a generic lower-bound transfer, not a claim that every paired-model
path is physically realizable. The underlying dual-radius necessary model
and its guarded merger were independently accepted in
`upper-review-dual-high.md`.

## The transfer theorem

Fix an even-area rectangle, `4<=w<=n`, feasible budget k, and positive
integers J,H. Put `h=wn/2`, `D=w+n-2`, and `r=floor(w/2)`.
Let M be the accepted dual-radius model, with all the accepted low-side
resets enabled. Its initial state is `(h,2,D,D)`. Let `d_c` be the maximum
deficit `h-a` among its states `(a,c,R,S)` reachable within J steps. An
unattainable corner type is omitted. This head computation is an exact
finite graph computation, though keeping only the maxima relaxes it.

Let `V_c` be the accepted bounded-tail seed: the largest size from which
the ordinary paired model, started with unknown radii, can capture within
H steps. This tail model may omit the new high-side resets; omitting
constraints only enlarges its winning set. No downward closure of that
winning set is assumed. Each maximum is found by excluding every larger
size up to the known ordinary threshold.

Let F be the ordinary three-corner backward operator, and set

    t_* = min{t>=0 : exists c with F^t(V)_c >= h-d_c},
    tau_bridge = J+H+t_*.

If `h>k(J+H)`, then

    tau_bridge <= tau_M,
    T_k(w,n) >= 2*tau_bridge-1.

Here `tau_M` is the earliest full-state capture in M. Indeed each step
reduces the size by at most k, so a shortest capture path has more than
J+H steps. Split off its first J and last H steps. At the first junction
its size is at least `h-d_c`. At the second junction forget both radii;
its remaining path is admitted by the tail relaxation, so its size is
at most V for its corner type. Every middle transition projects to an
ordinary corner transition. Consequently F iterated for the actual
middle length includes the first junction, proving the clock inequality.
The second inequality is the already accepted guarded-merger theorem
for M followed by this clock domination. It does not assume a new
physical doubling principle or physical attainment of the relaxed seed.

The interval head evaluator retains the union of states reached at all
times up to J, using global seen-state pruning only to avoid exploring
the same state twice. This union certainly contains every J-step state.
It is also exactly the J-step set: the full initial state has a valid
self-loop (inspect nothing, retain both corners and full support), so
any shorter path can be padded at its beginning. Thus the reported d
values are exact for this model and horizon.

## Explicit length stabilization of the head

Fix length parity and require

    n>=4r,
    h-kJ>r(r+1).

Every state or survivor occurring in the first J steps has size at least
`h-kJ`. Thus low-side radius resets cannot occur, and the low inverse
terms in the ordinary transition inequalities are inactive. Use deficit
coordinates `h-a`, `h-q`, and `delta_i=D-R_i`. The initial coordinates
are zero. Each high-side reset gives `0<=delta_i<=2r-2`; movement swaps
the two coordinates and replaces each positive delta by delta-1.
Therefore throughout the head, `0<=delta_i<=2r-2`. All remaining scalar
transition inequalities, corner caps and high-side reset tests depend
only on these deficits and w,k, not n. The additional even-width
exception at n=w+1 is excluded by n>=4r.

For completeness, ball capacities also stabilize in these coordinates.
Within the board, the complement of a ball of radius `D-delta` about
a corner is the ball of radius `delta-1` about its diagonal antipode;
delta=0 has empty complement. The intersection of two large balls is
therefore the complement of the union of two such small balls. Their
radii are at most `2r-3`. Balls based at opposite long ends are disjoint
because n-1 exceeds twice this bound. Balls at the same long end have
intersection counts determined entirely by w and their bounded radii.
The admissible pairs of corner colors depend only on the fixed parity.
Consequently both the area deficit `h-capacity` and the allowed corner
counts are independent of n. Maximizing over the finitely many anchor
choices preserves this independence. This proves that the whole
J-step head graph in deficit coordinates, and hence d, stabilizes.

## Tail and middle stabilization

The tail theorem in `comparison-tail-seed-proof.md` applies once

    n-1>2*(2r-3+H),
    h>=kH+r^2+1.

Its seed V is then fixed within length parity. It satisfies V<=F(V),
and all subsequent ordinary frontiers are horizon-monotone. No prefix
closure of the exact paired winning set is inferred.

The previously accepted periodic insertion proof applies to the ordinary
frontier initialized at V together with the physical prefix upper
clocks. The stopping target is now the union of three thresholds
`h-d_c`, rather than the full threshold h. Choose the low-end entry as
in `comparison_tail_seed_certificate.seeded_entry`; let M0 be the
maximum coordinate seen through that entry and its following update.
In addition to its existing safe-area condition, require

    h > M0 + max_c d_c.

Then the meeting test is false throughout the low entrance and the
inserted middle segment. Translating h and all frontier coordinates by
the same amount preserves every meeting comparison. Its first hitting
time therefore obeys the same insertion identity as the original full
threshold. The common length period and full-day shift remain

    P=2(2k-w)/gcd(w,2k-w),
    full_shift=4w/gcd(w,2k-w).

The fixed offset J+H does not affect the period. One representative for
each length residue beyond this computable onset, and a finite check
of preceding lengths, gives an all-length bound. This is an effective
family theorem for arbitrary w,k,J,H; a small or zero gap still requires
proving or certifying the corresponding finite comparison.

## Width 24 application

For w=24,k=13,J=H=28, both parities give

    d=(110,111,111), V=(122,123,123).

The shared stabilized onset is n=100 (even) and n=101 (odd). Here P=2
and the full-day shift is 48. The bridge lower matches the already
accepted physical-prefix upper:

    T_13(24,n)=24n-369.

The long-length certificate checks the computed entry, both stable
representatives, and the exact translated tails. The shorter lengths
24<=n<100 require the direct accepted dual-model lower, recorded
separately in that certificate. The application is not accepted until
those checks and independent review are complete.

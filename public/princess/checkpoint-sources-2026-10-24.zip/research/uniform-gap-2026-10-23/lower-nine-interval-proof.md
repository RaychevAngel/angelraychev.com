# Exact interval evaluation of the nine-feature radius model

24 October 2026 UTC. Algorithmic consolidation independently accepted in
`upper-review-nine-interval.md`, not an additional physical inequality.
`lower-dual-nine-interval.py` evaluates the same graph as
`root-dual-nine.py` with `closed_holes=False`, both pronic and wide-square
switches enabled. It retains all radius states and all admitted targets.

## Fixed-feature monotonicity

For fixed survivor and target features `(i,u,j,v)`, write `Q(T)` for
`banded_survivor(w,n,T,i,u,j,v)`. The base bound is nondecreasing in `T`
by the inverse-profile and critical ordinary-profile proofs in
`lower-erosion-proof.md`. The two extra filters preserve this property.

The dual-square filter has `r=ceil(sqrt(h-T))`, applies for
`(j,v)=(1,2),u!=1,2<=r<b`, and caps at `T-(v-i)-r-1`. Inside a root bin
this rises by one per unit of `T`. At a downward change of `r` it rises
by two. On first entry from the critical bin, the preceding target
requires closed surplus at least `b` from the accepted hole profile;
the new cap is therefore no smaller than the previous base cap. On
leaving at `r=1`, removing the extra cap cannot decrease `Q`.

The dual-pronic filter caps at `T-r-1` on
`D_r<h-T<=r(r-1)` for a wrong feature triple. Its only possible new
entry as `T` rises is at `h-T=r(r-1)`. At the immediately preceding
target, any original surplus at most `r` has an impossible high branch
because `G_(i,2)(s)<=s(s-1)<=r(r-1)`. Its small branch is also impossible:
when `r<b`, `h>=2b^2` makes the required survivor larger than `r^2`;
when `r=b` is permitted, the width is odd and
`h>=2r^2+3r+1` gives the same strict inequality. Thus the prior target
already required original surplus at least `r+1`. The new cap cannot
drop below its predecessor. Inside the band the cap rises by one; on
leaving the lower end it is removed. This handles every possible band
boundary, including the different `v=1` threshold.

Consequently positive admissible survivors at a fixed target form
`1<=q<=Q(T)`, and for each fixed `q`, admissible target sizes form the
tail `[first(q),h-4+j+v]`. Binary search computes `first(q)` exactly.

## Union over a source interval

Fix source features `(c,e)` and an interval of source sizes `[a,z]`.
For fixed `(i,u,j,v)` satisfying the retained feature/maximality rules,
put `charge=(c-i)+(e-u)`. If `charge<=k`, its exact attainable survivor
size interval before the geometric relation is

    qa=max(1,a-k),
    qb=min(z-charge,h-4+i+u).

For every integer `q` in that interval there is a source size between
`a` and `z` with deletion cost between `charge` and `k`; conversely
every such deletion produces a size in the interval. Do **not** insert
`i` or `u` into the lower bound. The accepted guarded-merger relaxation
deliberately drops positive feature/cardinality lower bounds. Restoring
them would change the graph and would need a new merger proof.

Without resets the union of target tails is exactly the tail beginning
at `first(qa)`. For a fixed feature tuple, any survivor size has at most
one exceptional numerical target, either labeled by a radius reset or
forbidden by an exact-pronic feature rule. These exceptional targets
are strictly increasing as a function of the survivor sizes on which
they occur: the low branches are `q+r(q)`, and the high branches are
`h-r(r-1)` or `h-r^2` with `q` increasing as `r` decreases. Where both
low and high pronic branches occur for one tuple, the low targets are
at most `b^2` and high targets at least `b^2+b`, so they cannot collide.

Therefore the ordinary tail can lose only the exceptional target of
`qa`. It loses that target precisely when it is admissible for `qa`
and is not repaired by `qa+1`: repair is equivalent to
`qa<qb` and `Q(T)>=qa+1`. If repaired, the second survivor has a different
exceptional target and supplies an ordinary route to this one.

All labeled reset intervals are then added separately. Subcritical low
events at fixed surplus `r` have an impossible high profile branch,
so their admitted survivor sizes are exactly their trigger interval
intersected with

    q <= P(v,u,j;r-(v-i))-(v-i),
    q <= h-4+i+u,       q+r <= h-4+j+v.

The ordinary corner bound follows from `P<=F`; the extra high-side static
bands are inactive on these low events. Thus these reset ranges are
computed as intervals without enumerating their cells. Critical pronic
and high-side reset events are isolated points and are gated directly
by `Q(q+r)>=q` before insertion. This gating prevents the spurious
labeled edges caught during review of the earlier three-feature prototype.

## Radius capacities and reachability

For each radius pair the evaluator uses the maximum possible area,
occupied own corners, and eroded opposite corners of the corresponding
two-ball intersection. Erosion is computed literally on the two adjacent
cells at each opposite-colored corner. The maximizers of the three
quantities need not be the same anchor pair; this is the same safe
relaxation as the bitset model.

The queue key is `(R0,R1,c,e)`. Each value is a union of exact integer
intervals of reachable sizes. Intervals merge only when they overlap or
are adjacent. Previously visited sizes are subtracted only within the
identical key. There is no cross-radius dominance or unproved path
compression. The resulting first-arrival layers, solo time, preterminal
minimum size, and shared-budget lower bound equal those of the bitset
graph. This is a substantial evaluation speed improvement, not a new
claim of physical attainability.

`lower-dual-nine-interval-audit.py` independently constructs all bitset
source rows and compares their labeled unions, randomized multi-size
source intervals, radius capacities, and complete first-arrival layers
on small rectangles. Its JSON receipt records the exact finite scope.

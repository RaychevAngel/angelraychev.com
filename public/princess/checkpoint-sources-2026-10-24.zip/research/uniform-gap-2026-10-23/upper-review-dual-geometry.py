"""Literal physical high-radius event audit via exhaustive target-hole sets."""
from itertools import combinations
from pathlib import Path
import hashlib,json,time

def audit(w,n,r,kind):
    h=w*n//2;D=w+n-2
    corners={(0,0),(w-1,0),(0,n-1),(w-1,n-1)}
    cells=[[(x,y)for x in range(w)for y in range(n)if(x+y)%2==p]for p in(0,1)]
    ids=[{v:i for i,v in enumerate(row)}for row in cells]
    cm=[sum(1<<i for i,v in enumerate(row)if v in corners)for row in cells]
    full=(1<<h)-1
    ng=[[sum(1<<ids[1-p][z]for z in((x-1,y),(x+1,y),(x,y-1),(x,y+1))if z in ids[1-p])for x,y in cells[p]]for p in(0,1)]
    d=r*(r-1)if kind=='pronic'else r*r
    q=h-d-r;j=2 if kind=='pronic'else 1
    checked=triggered=0
    for p in(0,1):
        if kind=='pronic':
            candidates=[combinations([i for i,v in enumerate(cells[p])if v not in corners],d)]
        else:
            # i=2 forces N(holes) to avoid both source-colored corners.
            available=[i for i,v in enumerate(cells[p])if v not in corners and not ng[p][i]&cm[1-p]]
            candidates=[((anchor,)+z for anchor,v in enumerate(cells[p])if v in corners for z in combinations(available,d-1))]
        for iterator in candidates:
            for indices in iterator:
                checked+=1;U=sum(1<<i for i in indices);NU=0
                for i in indices:NU|=ng[p][i]
                if NU.bit_count()>d+r:continue
                available_source=full^NU
                available_ids=[i for i in range(h)if available_source>>i&1]
                # Enumerate every source consistent with these target holes,
                # including hypothetical slack in complement-neighborhood size.
                for deleted in combinations(available_ids,len(available_ids)-q):
                    S=available_source^sum(1<<i for i in deleted)
                    if kind=='square'and(S&cm[1-p]).bit_count()!=2:continue
                    NS=0;m=S
                    while m:
                        bit=m&-m;m-=bit;NS|=ng[1-p][bit.bit_length()-1]
                    if NS!=full^U:continue
                    assert NS.bit_count()==q+r and(NS&cm[p]).bit_count()==j
                    if kind=='pronic':
                        assert(S&cm[1-p]).bit_count()==1
                        anchors=[v for i,v in enumerate(cells[1-p])if v in corners and NU>>i&1]
                        assert len(anchors)==1
                        inner=2*r-3;outer=D-2*r+2
                    else:
                        anchors=[v for i,v in enumerate(cells[p])if v in corners and U>>i&1]
                        assert len(anchors)==1
                        inner=2*r-2;outer=D-2*r+1
                    ax,ay=anchors[0]
                    expected=sum(1<<i for i,(x,y)in enumerate(cells[p])if abs(x-ax)+abs(y-ay)<=inner)
                    assert U==expected,(w,n,r,kind,p,indices)
                    zx,zy=w-1-ax,n-1-ay
                    assert all(abs(x-zx)+abs(y-zy)<=outer for i,(x,y)in enumerate(cells[p])if NS>>i&1)
                    triggered+=1
    return dict(w=w,n=n,r=r,kind=kind,candidate_hole_sets=checked,physical_events=triggered)

start=time.process_time();rows=[]
for args in [(4,4,2,'pronic'),(4,5,2,'pronic'),(5,6,2,'pronic'),(6,6,3,'pronic'),(6,7,3,'pronic'),(7,8,3,'pronic'),(8,8,3,'pronic'),(6,6,2,'square'),(6,7,2,'square'),(7,8,2,'square'),(8,8,3,'square')]:
    row=audit(*args);rows.append(row);print(row,flush=True)
sources=[Path(__file__),Path(__file__).with_name('lower-dual-radius-resets.md')]
out=dict(status='PASS',rows=rows,CPU_seconds=time.process_time()-start,source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in sources if p.exists()})
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print({k:v for k,v in out.items()if k!='rows'})

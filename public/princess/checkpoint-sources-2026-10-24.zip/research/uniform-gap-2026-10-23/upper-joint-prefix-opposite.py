import importlib.util,sys,json,time
from pathlib import Path
p=Path(__file__).with_name('upper-joint-prefix.py');s=importlib.util.spec_from_file_location('joint',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
def run(w,n,k):
 start=time.process_time();h=w*n//2;E=m.erosions(w,n)
 F=[[-1]*(h+1)for p in(0,1)];F[0][0]=F[1][0]=0;d=0
 while max(F[0][h],F[1][h])<h:
  F=[m.update(F[1-p],[E[1-p],E[1-p]],k,h)for p in(0,1)];d+=1
 return dict(w=w,n=n,k=k,upper=d,CPU_seconds=time.process_time()-start)
if __name__=='__main__':
 rows=[]
 for spec in sys.argv[1:]or['24,24,13','28,28,15','46,46,24','81,82,41','108,108,55','129,130,65']:
  row=run(*map(int,spec.split(',')));print(row,flush=True);rows.append(row)
 Path(__file__).with_suffix('.json').write_text(json.dumps(dict(rows=rows,scope='Fixed opposite-anchor parity phases; physical upper only'),indent=2)+'\n')

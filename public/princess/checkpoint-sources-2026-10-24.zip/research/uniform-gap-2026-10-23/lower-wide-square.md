# Localization over an entire square-root interval

24 October 2026 UTC. New ordinary theorem, submitted for independent review.
It strengthens the square localization reset from q>r(r-1) to
q>(r-1)^2 when the observed corner counts are (i,j)=(1,0).

Let w<=n, wn even, w>=4, b=floor(w/2), h=wn/2. Let S occupy one physical
color. Suppose exactly one own-colored board corner belongs to S, no
opposite-colored board corner belongs to N(S), and for an integer2<=r<b,

    (r-1)^2 < |S| <= r^2,
    |N(S)|-|S| <= r.

**Theorem.** The surplus equals r, S is connected under sharing a neighbor,
and every room of S lies within Manhattan distance2r-2 of its one corner.
In particular its next belief N(S) lies in the radius2r-1 ball about that
same corner. This is a subcritical all-even-area theorem; no critical
square-radius extension is claimed.

## 1. Component capacities and the strict interval

Partition S into sharing-neighbor components S_l. Their neighborhoods
are disjoint, so sizes and surpluses add. Every nonempty component has
positive surplus. Since the total surplus is at most r<b, the accepted
subcritical corner theorem applies to each component.

The large branch is impossible: |S_l|<=r^2 and s_l<=r give

    h-|S_l|-s_l >= 2b^2-r^2-r > r^2,

while every large-side corner capacity is at most s_l^2<=r^2. Thus each
component uses its small F capacity. Exactly one component contains the
observed own corner and has capacity at most u^2 at surplus u. Every
other component has both current and outgoing corner counts zero and
capacity C_2(v)<=v(v-1). In particular its positive surplus is at least2.

If there are any other components, aggregate their surplus as v>=2 and
the own-corner component's as u>=1. Their combined area is at most

    u^2 + sum_l v_l(v_l-1) <= u^2+v(v-1), u+v<=r.

Both terms increase with their nonnegative arguments, so bound u by r-v.
The function (r-v)^2+v(v-1) is convex in v. On2<=v<=r-1 its endpoint
values are (r-2)^2+2 and 1+(r-1)(r-2), both at most (r-1)^2 for r>=3.
For r=2 the interval2<=v<=r-1 is empty. This contradicts |S|>(r-1)^2.
Therefore S has just the component containing its own corner.

If its total surplus were at most r-1, its now established small F10
bound would give |S|<=(r-1)^2. Hence the surplus is exactly r.

## 2. Radius of the original support

The accepted subcritical separator argument splits a small-side support
into genuine corner quadrants. Connectedness and the included corner
place this entire support in the quadrant at that corner; the relevant
neighborhood remains unchanged there. This is a geometric separator,
not compression of the original support.

Sharing-neighbor adjacency changes the distance from the corner by at
most2. Since the origin is occupied, the occupied even distance layers
are0,2,...,2L-2 without a gap. For each such nonempty layer, its upward
shadow in the next odd layer has at least one more cell. Those shadow
layers are disjoint. Consequently

    |N(S)| >= |S|+L,

so L<=r. Every original room is therefore within distance2r-2 of the
corner. Adding one neighborhood gives the target radius2r-1.

## 3. Merger inheritance of the stronger reset

Consider a synthetic merged transition with survivor size Q in the stated
interval, survivor own-corner count I=1, outgoing corner count J=0, and
total original surplus r. Suppose both component original surpluses are
positive. Each is then less than r<b, so their subcritical alternatives
apply (either ordinary F/G or the stronger erosion refinement).

Two small components cannot have positive merged survivor: their sizes
sum to at most s1^2+s2^2<r^2<h. In a mixed small/large pair, the merged
survivor Q=q1+q2-h is at most the small component's size, hence at most
(r-1)^2, a contradiction. If both are large, their nonnegative target
holes sum to

    h-(Q+r) >= h-r^2-r > r^2,

whereas the separate high capacities bound their sum by
s1^2+s2^2<r^2. Again a contradiction. Thus one component has original
surplus zero. The unconditional size profile forces that positive
component to be full-to-full, and the merger is the identity on the
other transition, including its corner counts and selected corner anchor.

The existing radius-minimum and ball-intersection merger argument now
applies to this enlarged trigger interval unchanged. In the paired-radius
model the reset is relative color1, radius2r-1, because the corner changes
relative color after the move. No radius is guessed for a model state
without a trigger.

## Implementation boundary

In a fixed-q relation for (i,j)=(1,0), r=ceil(sqrt(q)). The old reset test
q>r(r-1) can be replaced by q>(r-1)^2, automatically true for this r.
Keep2<=r<b. The reset target is q+r. Root's interval implementation can
therefore generate all q in[(r-1)^2+1,r^2] symbolically, with no change to
the geometric base relation. The enlarged event is still exactly one
reset target per q, so the old interval-union repair argument remains
valid.

This theorem supplies a stronger necessary history constraint. Numerical
capture-time gains and any uniform absolute gap theorem are separate
obligations, not consequences asserted by this note alone.

## Static dual consequence: exactly one survivor-eroded corner

Root proposed the following consequence; the lower lane independently
checked the complement identities, corner distances, and merger. For a
transition with target (j,v)=(1,2), closed surplus r, and

    2<=r<b,       (r-1)^2<h-T<=r^2,

one necessarily has survivor erosion **u=1**.

Let U be the target holes. They contain one own corner and N(U) contains
no opposite corner, since (j,v)=(1,2). Corner closure bounds their surplus
by r, and the theorem above makes it exactly r and localizes them at their
corner. Equality of cardinalities gives N(U)=complement(closed S).
The original S and closed S differ only by source-own corners, which are
disjoint from all opposite-corner neighbor pairs when both sides are at
least four; thus e(S)=e(closed S).

Now N^2(U) contains its anchor corner and has radius at most2r. Every
other corner of its own color is farther away: on an odd side it is at
least2b away, and on even-by-even boards the same-color corner is diagonal.
Hence N^2(U) contains exactly one own-colored corner. Complementation then
gives e(closed S)=2-1=1, proving u=1.

For merger formation J=1,V=2 imply v1=v2=2 and (j1,j2) is(1,2) or(2,1).
Small components are excluded by their excessive target holes. High
capacities are respectively sigma1^2 and C_2(sigma2), in one order. If
eta>0, their sum is at most(r-1)^2. If both sigmas are positive with sum r,
convexity reduces to the endpoints: (r-1)^2+C_2(1)=(r-1)^2, or
1+C_2(r-1)<=1+(r-1)(r-2)<=(r-1)^2. Thus the strict hole threshold forces
eta=0 and a zero-reduced-surplus partner, whose closed support/target are
full. Its survivor q=h-2+i and the retained upper bound
q<=h-4+i+u force u=2. The other component is itself the same dual event
with u=1; merged erosion is(1+2-2)_+=1. This proves merger inheritance.

For fixed target, r=ceil(sqrt(h-T)) is determined. If u!=1, the rule
requires closed surplus at least r+1, hence

    q <= T-(v-i)-r-1.

This is the new bound in `banded_survivor`. Original closed surpluses
below r were already excluded by the unconditional hole profile. The cap
is monotone in T: within an r-bin it rises with T, and when r decreases
it jumps upward. At entry from r=b to r=b-1 the old profile already
required closed surplus at least b, so no downward jump occurs. It
therefore preserves the exact nine-threshold frontier theorem.

## A wider two-event hole obstruction

The earlier closed-hole history flag also extends to the new hole interval
when r>=3. Its triangle can miss at most2r-2 rooms, and the whole-triangle
separation from the next opposite-color corner neighborhood is at least
r(r+1)/2. The resulting forced slack is

    (r^2-3r+4)/2 >= 2,   r>=3.

At r=2 retain holes>2, since allowing two holes would leave only a
one-unit separation bound. Merger formation uses the refined square/C2
sum in the preceding paragraph, rather than the weaker sum of two square
capacities. A zero-reduced-surplus partner has full target; next-step
inheritance is unchanged from `lower-closed-hole-history.md`.

The implemented flag condition is therefore d>max((r-1)^2,2), d<=r^2.
The new static u=1 condition uses the entire square-root bin, including
r=2; it does not depend on this stricter temporal threshold.

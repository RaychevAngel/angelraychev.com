# A bounded paired-radius tail as a length-independent necessary seed

24 October 2026 UTC. Ordinary proof submitted for independent review.
The implementation is `comparison_tail_seed.py`. The underlying paired
model, optional pronic resets and wide square reset have their separate
accepted physical-necessity and guarded-merger proofs. This argument
preserves their full-game lower bound by relaxation.

## General transfer

Fix an even-area rectangle `w<=n`, `r=floor(w/2)>=2`, feasible budget k,
and positive tail horizon H. Let the accepted paired model start with no
radius information. Define `V_H(c)` to be the maximum valid size a from
which `(a,c,infinity,infinity)` can reach capture within H model steps.
The actual winning set need not be a size interval; retaining only its
maximum deliberately enlarges it to an interval.

For each c the ordinary three-corner H-step frontier is an upper bound
on `V_H(c)`. Therefore compute the maximum exactly by testing every size
from that upper bound downward until the first successful start. This
does not assume that success is monotone in size: every larger start was
individually excluded, and the ordinary frontier excludes all larger
sizes outside the tested range.

Propagate V by the ordinary corner backward recurrence and define

    tau_tail = H + min{t>=0 : (ordinary_step^t(V))_2 = h}.

Assume no paired-model path from full support captures within H steps.
A sufficient condition is `h>kH`. Then

    tau_tail <= tau_paired,

where `tau_paired` is the full paired model's first capture time. To see
this, take its shortest capture path and isolate its final H steps. At
the junction, replacing both radii by infinity only enlarges the allowed
continuations: all ball capacities are monotone, and movement/reset
updates preserve radius order. Its junction size is therefore at most
V_H(c). Its earlier history projects to ordinary corner transitions, so
the propagated seed contains the full initial state by the same horizon.

The already accepted full-game theorem gives `T>=2*tau_paired-1`. Hence

    T >= 2*tau_tail-1.

No arbitrary single-cohort doubling theorem is assumed, and no merger
closure of the prefix-closed seed is needed. Clock domination supplies
the connection to the accepted merger-closed necessary model. A new
central-day improvement is not claimed.

## Exact finite-horizon start tests

The interval engine is evaluated from the specified single initial size
and corner count, with both radii unknown. Its interval unions are exact,
as checked separately against the explicit bitset model. At every step
of this model the new size is at least the old size minus k: a positive
survivor has size q>=a-k and every admitted target has size T>=q.
Consequently a state with size greater than `k*remaining_days` cannot
finish by the horizon and can be discarded. This pruning does not alter
the answer to any start test. Repeated states can be discarded after
their earliest visit because the graph is time-homogeneous and an earlier
visit has at least as much remaining time.

## Explicit stabilization in length

All reset radii in the implementation are at most `2r-2`, including the
critical exact-pronic reset. A first reset occurs after at least one
move. Therefore every finite radius occurring during an H-step test is
at most

    Rmax = 2r-3+H.

Every state on a successful H-step path has size at most kH. Fix a length
parity and require

    n-1 > 2Rmax,
    h >= kH+r^2+1,
    n>=w.

On these states the ordinary high inverses and board-size caps are
inactive: every target deficit is at least r²+1. The exceptional extra
critical branch at even width and `n=w+1` is also excluded by these
inequalities. Reset tests themselves depend only on width, finite sizes
and their fixed labels, not on length.

It remains to check the paired ball capacities. Replace the diameter D
by an infinity symbol. A finite ball cannot reach both long ends, and
two finite balls based at different long ends cannot intersect because
their total radii are less than n-1. Counts near one short end stabilize
on the width-w half-infinite strip. For even width, the opposite-colored
corner at the same short end supplies the only potentially nonempty
two-finite-ball lens. For odd width and even length, the two own corners
are at one short end and the opposite-colored corners at the other, so
every two-finite-ball lens is empty. The single-finite-ball corner counts
stabilize by the same argument. The infinity/infinity area bound h is
irrelevant on sizes at most kH, and its corner bound is always two.

Thus the entire finite-horizon decision graph, restricted to states that
can possibly finish by H, is independent of length within the chosen
parity. The seed computed on one board satisfying the inequalities is
the seed for every such board. Explicit stable capacity formulas and
33,276 literal finite-board checks are in
`comparison_tail_capacity_verify.py/json`; the argument above supplies
the general justification.

## Long-length clocks after transfer

Once the seed is fixed, the already accepted periodic-insertion proof
applies to the ordinary recurrence initialized at that seed. Its middle
normal form and termination do not require the initial vector to be the
zero-capture seed. Explicitly, `V<=ordinary_step(V)`: each maximal winning
start either captures immediately or has an ordinary first transition to
a state that, after forgetting its radius information, captures within
H-1 steps and is therefore contained in V. Monotonicity of the ordinary
operator makes every later frontier horizon-monotone. The first ordinary
update orders the corner coordinates even if the seed itself was not
ordered. This uses no downward closure of the original paired winning
sets. Any invalid initial corner caps can be clipped; for
the above stabilized boards all seed coordinates are at most kH<h-2,
so clipping is unnecessary. The fixed offset H in tau_tail does not
affect the period. Thus the transferred full lower and the physical
prefix upper again have common length period

    2(2k-w)/gcd(w,2k-w)

and full-day increment `4w/gcd(w,2k-w)` after a computable entry. A finite
base below the greater of the stabilization and insertion onsets completes
an all-length certificate. Earlier lengths can retain direct evaluations
of the accepted full paired model.

## Intended 44-row application

For w44,k24,H28 the ordinary seed is `(309,310,310)` and exact descending
start tests give V=`(309,309,309)`. Stabilization holds for all n>=140
(even) or n>=141 (odd), and h>kH there. Propagation gives the candidate
all-length lower `22n-635`, while the already certified physical upper
is `22n-631`. `comparison-tail-seed-certificate.json` checks both seeds,
the exact shifted tails, the computed entry and the first clocks. The
96 shorter lengths44 through139 all passed direct accepted paired-model
evaluation in `comparison-tail44-short.json`. Thus the receipts cover
every n>=44; independent implementation/proof review remains the final
acceptance step.

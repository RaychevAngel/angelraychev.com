import importlib.util,json,random,time
from pathlib import Path
p=Path(__file__).with_name('upper-joint-prefix.py');s=importlib.util.spec_from_file_location('joint',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
from resumed_even_construction_prefix import PrefixGame

def brute(F,E,k,h):
 return [max([-1]+[min(h,E[0][x]+k-max(0,a-E[1][y]))for x,y in enumerate(F)if y>=0 and a<=E[1][y]+k])for a in range(h+1)]
start=time.process_time();literal=updates=0
for w,n in[(2,2),(4,4),(4,5),(5,6),(6,6),(7,8),(8,8)]:
 g=PrefixGame(w,n);h=w*n//2;E=m.erosions(w,n)
 for q in(0,1):
  for z,mask in enumerate(g.orders[q][0]):
   er=sum(1<<i for i,N in enumerate(g.adj[1-q])if not N&~mask)
   assert er==g.orders[1-q][0][E[q][z]],(w,n,q,z,E[q][z],er.bit_count())
   literal+=1
 for k in range(w//2+1,min(h,w+3)):
  F=[-1]*(h+1);F[0]=0
  while F[h]<h:
   G=m.update(F,E,k,h);assert G==brute(F,E,k,h),(w,n,k,F,G)
   F=G;updates+=1
  Fs=[[-1]*(h+1)for _ in(0,1)];Fs[0][0]=Fs[1][0]=0
  while max(Fs[0][h],Fs[1][h])<h:
   Gs=[m.update(Fs[1-q],[E[1-q],E[1-q]],k,h)for q in(0,1)]
   assert Gs==[brute(Fs[1-q],[E[1-q],E[1-q]],k,h)for q in(0,1)]
   Fs=Gs;updates+=2
out=dict(literal_erosion_checks=literal,full_frontier_update_checks=updates,CPU_seconds=time.process_time()-start,scope='Independent brute candidate maximization and literal grid erosion checks; upper evaluator only.')
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print(out)

"""Prototype dual-head / paired-tail necessary clock; proof review pending."""
from pathlib import Path
import sys,json,time
import root_dual_interval as dual
import comparison_tail_seed as tail
from bridge_corner_frontier import step
HERE=Path(__file__).resolve().parent
FLAGS=dict(pronic_interval=True,critical_pronic=True,wide_square=True)


def head(w,n,k,J):
    h,D,capacity,relation=dual.engine(w,n,k,**FLAGS)
    front={(D,D,2):[(h,h)]};seen=dict(front)
    for day in range(J):
        following={}
        def add(R,S,c,a,b):
            cap,cc=capacity(R,S);a=max(a,c);b=min(b,cap,h-2+c)
            if c<=cc and a<=b:following.setdefault((R,S,c),[]).append((a,b))
        for(R,S,c),intervals in front.items():
            nr0,ns0=min(D,S+1),min(D,R+1)
            for a,b in intervals:
                if a<=k:add(nr0,ns0,0,0,0)
                for i in range(c+1):
                    if c-i>k:continue
                    qa=max(1,i,a-k);qb=min(b-(c-i),h-2+i)
                    if qa>qb:continue
                    for j in range(3):
                        for which,radius,u,v in relation(i,j,qa,qb):
                            nr,ns=nr0,ns0
                            if which==0:nr=min(nr,radius)
                            if which==1:ns=min(ns,radius)
                            add(nr,ns,j,u,v)
        front={}
        for key,parts in following.items():
            merged=dual.merge(parts);new=dual.minus(merged,seen.get(key,[]))
            if new:front[key]=new;seen[key]=dual.merge(seen.get(key,[])+new)
    defects=[]
    for c in range(3):
        sizes=[a for(R,S,z),parts in seen.items()if z==c for a,b in parts]
        defects.append(h-min(sizes)if sizes else None)
    return dict(w=w,n=n,k=k,J=J,defects=defects,
                radius_pairs=len({(R,S)for R,S,c in seen}),
                intervals=sum(len(v)for v in seen.values()))


def run(w,k,J,H,parity=0):
    r=w//2;s=tail.seed(w,k,H,parity,**FLAGS)
    n=max(s['n'],4*r,(2*(k*J+r*(r+1)+1)+w-1)//w,
          (2*(k*(J+H)+1)+w-1)//w)
    n+=n%2!=parity;h=w*n//2
    hd=head(w,n,k,J);V=s['paired_seed'];B=tuple(V);t=0
    target=[h-d if d is not None else h+1 for d in hd['defects']]
    while not any(B[c]>=target[c]for c in range(3)):
        B=step(w,n,k,B);t+=1
        assert t<4*w*n
    tau=J+H+t
    return dict(w=w,n=n,k=k,J=J,H=H,parity=parity,head=hd,tail=s,
                middle=t,solo_lower=tau,full_lower=2*tau-1)


def finite_board(w,n,k,J,H):
    """The same clock transfer on one board, with seeds evaluated there.

    The ordinary necessary clock excludes capture in J+H, replacing the
    convenient but stronger sufficient condition h>k*(J+H).
    """
    h=w*n//2;B=(0,-1,-1)
    for _ in range(J+H):B=step(w,n,k,B)
    assert B[2]<h,('head/tail windows may overlap',w,n,k,J,H)
    B=(0,-1,-1)
    for _ in range(H):B=step(w,n,k,B)
    captures=tail.model(w,n,k,H,**FLAGS);V=[];tests=0
    for c in range(3):
        for a in range(B[c],c-1,-1):
            tests+=1
            if captures(a,c):V.append(a);break
        else:V.append(-1)
    hd=head(w,n,k,J);B=tuple(V);t=0
    target=[h-d if d is not None else h+1 for d in hd['defects']]
    while not any(B[c]>=target[c]for c in range(3)):
        B=step(w,n,k,B);t+=1
        assert t<4*w*n
    tau=J+H+t
    return dict(w=w,n=n,k=k,J=J,H=H,head_defects=hd['defects'],tail_seed=V,
                tests=tests,middle=t,solo_lower=tau,full_lower=2*tau-1)


if __name__=='__main__':
    start=time.process_time();rows=[]
    for J,H in[(20,20),(28,28),(40,28),(40,40),(60,40)]:
        out=run(24,13,J,H);out['target_upper']=24*out['n']-369;out['gap']=out['target_upper']-out['full_lower'];rows.append(out)
        print({k:v for k,v in out.items()if k not in('head','tail')},out['head']['defects'],out['tail']['paired_seed'],flush=True)
        (HERE/'comparison-two-sided.json').write_text(json.dumps(dict(scope=__doc__,CPU_seconds=time.process_time()-start,results=rows),indent=2)+'\n')

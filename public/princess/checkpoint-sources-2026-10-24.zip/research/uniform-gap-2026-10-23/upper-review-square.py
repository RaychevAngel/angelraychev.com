"""Literal room-neighborhood attack on the full square-root-bin theorem."""
from itertools import combinations
from pathlib import Path
import hashlib,json,time

def audit(w,n,r):
    corners={(0,0),(w-1,0),(0,n-1),(w-1,n-1)}
    cells=[[(x,y)for x in range(w)for y in range(n)if(x+y)%2==p]for p in(0,1)]
    ids=[{v:i for i,v in enumerate(row)}for row in cells]
    cm=[sum(1<<i for i,v in enumerate(row)if v in corners)for row in cells]
    ng=[[sum(1<<ids[1-p][z]for z in((x-1,y),(x+1,y),(x,y-1),(x,y+1))if z in ids[1-p])for x,y in cells[p]]for p in(0,1)]
    checked=triggered=0
    for p in(0,1):
        for anchor,coord in enumerate(cells[p]):
            if coord not in corners:continue
            # These exclusions are necessary for i=1,j=0, not radius assumptions.
            available=[i for i,v in enumerate(cells[p])if v not in corners and not ng[p][i]&cm[1-p]]
            for q in range((r-1)**2+1,r*r+1):
                for others in combinations(available,q-1):
                    subset=(anchor,)+others;N=ng[p][anchor]
                    for i in others:N|=ng[p][i]
                    checked+=1
                    surplus=N.bit_count()-q
                    if surplus>r:continue
                    assert surplus==r,(w,n,r,p,q,surplus)
                    assert max(abs(cells[p][i][0]-coord[0])+abs(cells[p][i][1]-coord[1])for i in subset)<=2*r-2,(w,n,r,p,subset)
                    NN=0;m=N
                    while m:
                        bit=m&-m;m-=bit;NN|=ng[1-p][bit.bit_length()-1]
                    assert (NN&cm[p]).bit_count()==1,(w,n,r,p,subset)
                    # Closed survivor complement(N) has precisely one eroded corner.
                    support=((1<<len(cells[1-p]))-1)^N
                    erosion=sum(1 for j,v in enumerate(cells[p])if v in corners and ng[p][j]&support==ng[p][j])
                    assert erosion==1,(w,n,r,p,subset,erosion)
                    triggered+=1
    return dict(w=w,n=n,r=r,checked=checked,triggered=triggered)

start=time.process_time()
rows=[audit(*args)for args in[(6,6,2),(6,7,2),(7,8,2),(8,8,3)]]
sources=[Path(__file__),Path(__file__).with_name('lower-wide-square.md')]
out=dict(status='PASS',rows=rows,CPU_seconds=time.process_time()-start,source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in sources})
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print(out)

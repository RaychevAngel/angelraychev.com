"""Interval-set evaluator of the frozen paired-radius necessary model.

Experimental exact transcription; compare complete layer minima against
lower_lens before accepting. No new geometric assumption or dominance rule.
"""
from pathlib import Path
import sys, math, time, json
from functools import lru_cache
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'src'))
from bridge_corner_frontier import survivor_bound
from root_capacity import capacities as affine_capacities

def merge(xs):
    out=[]
    for a,b in sorted(xs):
        if a>b: continue
        if out and a<=out[-1][1]+1: out[-1]=(out[-1][0],max(b,out[-1][1]))
        else: out.append((a,b))
    return out

def minus(xs,ys):
    out=[];j=0
    for a,b in xs:
        while j<len(ys) and ys[j][1]<a: j+=1
        t=j
        while t<len(ys) and ys[t][0]<=b:
            c,d=ys[t]
            if c>a: out.append((a,min(b,c-1)))
            a=max(a,d+1)
            if a>b: break
            t+=1
        if a<=b: out.append((a,b))
    return out

def engine(w,n,k,fast_capacity=True,pronic_interval=False,critical_pronic=False,wide_square=False):
    assert 4<=w<=n and w*n%2==0
    h=w*n//2;D=w+n-2;r=w//2
    corners=[(0,0),(w-1,0),(0,n-1),(w-1,n-1)]
    opposite=[z for z in corners if sum(z)%2]
    @lru_cache(None)
    def capacities(R,S):
        if fast_capacity:return affine_capacities(w,n,R,S)
        best=bestc=0
        for ax,ay in opposite:
            area=0
            for x in range(w):
                hi=min(n-1,R-x);lo=0
                if ay==0: hi=min(hi,S-abs(x-ax))
                else: lo=max(lo,n-1+abs(x-ax)-S)
                lo+=(lo-x)%2
                if lo<=hi: area+=(hi-lo)//2+1
            c=sum(sum(z)%2==0 and sum(z)<=R and abs(z[0]-ax)+abs(z[1]-ay)<=S for z in corners)
            best=max(best,area);bestc=max(bestc,c)
        return best,bestc
    @lru_cache(None)
    def first(i,j,q):
        lo=max(1,j);hi=h-2+j
        if survivor_bound(w,n,i,j,hi)<q: return hi+1
        while lo<hi:
            mid=(lo+hi)//2
            if survivor_bound(w,n,i,j,mid)>=q: hi=mid
            else: lo=mid+1
        return lo
    def event(i,j,q):
        if i==1 and j==0:
            s=math.isqrt(q);s+=s*s<q
            if 2<=s<r and (wide_square or q>s*(s-1)): return 1,2*s-1,q+s
        if i==0 and j==1:
            s=(1+math.isqrt(1+4*q))//2
            if pronic_interval and q>s*(s-1):s+=1
            valid = q>(s-1)*(s-2) if pronic_interval and s<r else q==s*(s-1)
            if 2<=s<=r-int(not critical_pronic) and valid: return 0,2*s-2,q+s
        return None
    def relation(i,j,qa,qb):
        """Union of graph relations for every q in [qa,qb], by reset label."""
        top=h-2+j;t=first(i,j,qa)
        if t>top: return []
        out=[];ev=event(i,j,qa)
        # The smallest q admits every target >=t except its one reset target.
        # Larger q can repair that missing target only when the cap permits it.
        if ev and ev[2]>=t and not(qa<qb and survivor_bound(w,n,i,j,ev[2])>=qa+1):
            if t<ev[2]:out.append((-1,-1,t,ev[2]-1))
            if ev[2]<top:out.append((-1,-1,ev[2]+1,top))
        else:out.append((-1,-1,t,top))
        if (i,j)==(1,0):
            s0=max(2,math.isqrt(qa));s1=min(r-1,math.isqrt(qb)+1)
            for s in range(s0,s1+1):
                q0=max(qa,(s-1)**2+1 if wide_square else s*(s-1)+1);q1=min(qb,s*s)
                if q0<=q1:out.append((1,2*s-1,q0+s,q1+s))
        if (i,j)==(0,1):
            s0=max(2,math.isqrt(qa));s1=min(r-int(not critical_pronic),math.isqrt(qb)+2)
            for s in range(s0,s1+1):
                q=s*(s-1)
                if pronic_interval and s<r:
                    q0=max(qa,(s-1)*(s-2)+1);q1=min(qb,q)
                    if q0<=q1:out.append((0,2*s-2,q0+s,q1+s))
                elif qa<=q<=qb:out.append((0,2*s-2,s*s,s*s))
        return out
    return h,D,capacities,relation

def run(w,n,k,cap_seconds=120,trace=False,pronic_interval=False,critical_pronic=False,wide_square=False):
    start=time.process_time();h,D,capacity,relation=engine(w,n,k,pronic_interval=pronic_interval,critical_pronic=critical_pronic,wide_square=wide_square)
    seed=(D,D,2);front={seed:[(h,h)]};seen=dict(front);layers=[];interval_count=0
    for day in range(4*w*n):
        if not front: raise AssertionError(('empty',day))
        low=min(v[0][0]for v in front.values());layers.append(low)
        if low==0:break
        if time.process_time()-start>cap_seconds:
            return dict(w=w,n=n,k=k,complete=False,day=day,CPU_seconds=time.process_time()-start)
        following={}
        def add(R,S,c,a,b):
            cap,cc=capacity(R,S)
            a=max(a,c);b=min(b,cap,h-2+c)
            if c<=cc and a<=b:following.setdefault((R,S,c),[]).append((a,b))
        for (R,S,c),intervals in front.items():
            newR,newS=min(D,S+1),min(D,R+1)
            for a,b in intervals:
                if a<=k:add(newR,newS,0,0,0)
                for i in range(c+1):
                    if c-i>k:continue
                    qa=max(1,i,a-k);qb=min(b-(c-i),h-2+i)
                    if qa>qb:continue
                    for j in range(3):
                        for d,r,u,v in relation(i,j,qa,qb):
                            nr,ns=newR,newS
                            if d==0:nr=min(nr,r)
                            if d==1:ns=min(ns,r)
                            add(nr,ns,j,u,v)
        front={}
        for key,parts in following.items():
            merged=merge(parts);new=minus(merged,seen.get(key,[]))
            if new:
                front[key]=new;seen[key]=merge(seen.get(key,[])+new)
        interval_count=max(interval_count,sum(map(len,front.values())))
    else:raise AssertionError('limit')
    f=min(layers[:-1]);out=dict(w=w,n=n,k=k,complete=True,solo=day,residual=f,lower=2*day-int(2*f<=k),radius_pairs=len({z[:2]for z in seen}),intervals=sum(map(len,seen.values())),peak_front_intervals=interval_count,states=sum(b-a+1 for vals in seen.values()for a,b in vals),capacity_queries=capacity.cache_info().currsize,CPU_seconds=time.process_time()-start)
    if trace:out['layers']=layers
    return out

if __name__=='__main__':
    out=[]
    for case in sys.argv[1:]or['16,16,15','28,28,15','46,46,24']:
        z=run(*map(int,case.split(',')),trace=True);out.append(z);print({k:v for k,v in z.items()if k!='layers'},flush=True)
        Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')

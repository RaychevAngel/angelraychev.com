# Independent review of the wider pronic radius resets

24 October 2026 UTC. Upper/construction lane.

**Accepted:** both rules in `root-pronic-radius.md`, including guarded-merger
formation at the critical even-square endpoint, and their optional interval
implementation. This is an ordinary proof review, not a new Lean result.

For the partial interval `(s-1)(s-2)<q<=s(s-1)` with `2<=s<b`, the
subcritical matching/quadrant argument applies on every even-area rectangle:
`h>=2b^2>2s^2` rules out every component's high branch. Each nonempty
sharing-neighbor component has surplus at least2 and area at most
`s_i(s_i-1)`. Two components could supply at most `(s-2)(s-3)+2`, below
the strict interval threshold; for s=2,3 two components are impossible.
Connectedness plus the observed outgoing corner identifies the genuine
quadrant. The uncompressed upper-shadow count gives survivor radius
`2s-3`, hence target radius `2s-2`. Every premise of the old odd-width
proof therefore survives the all-even-area subcritical extension.

The critical equality case uses the separately proved full pronic rigidity
at s=b. Its first neighborhood radius remains `2b-2` on even squares,
even nonsquares and odd-width boards. The new rule does not transfer the
false zero-corner assertion to its second neighborhood.

There is no synthetic-state gap in the merger argument. For the partial
rule the merged outgoing count is one by hypothesis. For critical equality,
the ordinary numerical corner profile already excludes outgoing counts0
and2: their low capacities are strictly below `b(b-1)` and their high
capacities are strictly below `b^2`, whereas the merged target-hole count
is at least `b^2`. Thus its outgoing count is one even for an abstract
merged edge, without invoking physical rigidity for that abstract edge.
Both component outgoing counts are consequently positive. If both original
surpluses are positive, they are subcritical. A low component cannot supply
the merged survivor size; two high components have total target holes at
most `s^2-2s+2<s^2`, contradicting the merged holes at least `h-s^2>=s^2`.
The strictness is retained when `h=2b^2` and s=b, so the even square creates
no exceptional hole. The remaining zero-surplus component is original-full
to-full at zero cost by the ordinary unconditional profile. Formation is
therefore an identity merger, and the existing paired-radius invariant
passes the reset unchanged.

The code uses the unique pronic interval containing q. Reset target `q+s`
is strictly increasing with q, so the existing interval-tail hole-repair
argument continues to apply. The new reset labels are enumerated separately
for every intersected interval. At the critical radius only equality is
included, exactly as stated.

`upper-review-pronic.py` independently enumerates original q and target
sizes, applies reset rules directly using surplus `s=T-q`, and compares
with the compressed optional relations. The final rerun includes all eight
switch settings after adding the independently reviewed wide-square reset. It
also checks complete inspection unions over source intervals. The retained
receipt reports:

- 33,600 optional relation-union comparisons;
- 14,400 source-interval union comparisons;
- 24 critical outgoing-count exclusion checks;
- all passed in31.14 CPU seconds.

The receipt hashes the verifier, interval implementation, capacity source,
and proof source. These implementation checks supplement the general
argument; they do not establish a universal numerical gap.

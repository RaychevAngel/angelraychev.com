"""Independent bounded audit of supplemental envelope certificate metadata and premises.

Does not replay head/tail graph searches. Checks the complete finite length
coverage, old periodic lookup, all numerical theorem premises, and ordinary
short-clock exclusion directly.
"""
from pathlib import Path
import sys, json, math, hashlib, time
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P))
import comparison_periodic as base
from bridge_corner_frontier import step,small_inverse,large_inverse
start=time.process_time()
new=json.loads((P/'comparison-remaining-panel.json').read_text())
old=json.loads((P/'root-band9-two-day-screen.json').read_text())
candidates=json.loads((P/'comparison-minimized-candidates.json').read_text())
key=lambda x:tuple(x[z]for z in('w','k','parity'))
old={key(x):x for x in old['results']}
assert new['status']=='COMPLETE' and new['checked_lines']==new['needed_lines']==18
assert {key(x) for x in new['results']}=={key(x) for x in candidates['results']}
for name,digest in new['source_sha256'].items():assert hashlib.sha256((P/name).read_bytes()).hexdigest()==digest,name
rows=[];points=0
for x in new['results']:
    assert 'failed_premise' not in x
    w,k,p=key(x);r=w//2;J=x['J'];H=x['H'];V=x['tail']['envelope_seed'];d=x['head']['defects']
    assert J==H and all(z is not None for z in d)
    nmin=w+(w%2!=p);nref=x['tail']['nref'];href=w*nref//2;hmin=w*nmin//2
    assert x['tail']['nmin']==x['head']['nmin']==nmin
    assert x['head']['nref']==nref and nref%2==p
    assert nref>=4*r and href-k*J>r*(r+1)
    B=(0,-1,-1)
    for _ in range(H):B=base.model_infinite(w,k,B)
    assert list(B)==x['tail']['ordinary']
    assert hmin>=max(B)+r*r+1
    assert hmin-max(d)-k>r*(r+1)
    if w%2==0 and nmin==w+1:
        assert small_inverse(2,0,max(B))<=r
        assert large_inverse(2,0,max(0,max(d)+k-r))<=r
    assert all(a<=b for a,b in zip(V,base.model_infinite(w,k,V)))
    assert nref-1>2*(2*r-3+H)
    prior=old[key(x)];P0=x['period'];s=x['entry']['full_shift']
    assert P0==prior['length_period']==2*(2*k-w)//math.gcd(w,2*k-w)
    assert s==prior['entry']['full_shift']==2*w*P0//(2*k-w)
    assert x['onset']>=prior['first_stable_length']
    assert x['onset']>=base.threshold(x['entry'],p)
    assert x['entry']['safe_h']>=k*(J+H)+1
    before=x['entry']['entry'];after=x['entry']['next_entry']
    M=max(z for state in(before,after)for seq in state for z in seq)
    assert x['entry']['safe_h']>=M+max(d)+1
    expected=list(range(nmin,x['onset']+P0,2))
    assert [a['n']for a in x['rows']]==expected
    assert x['checked_lengths']==len(expected)
    prior_lookup={a['n']:a for a in prior['rows']};n0=prior['first_stable_length']
    for row in x['rows']:
        n=row['n'];j=max(0,(n-n0)//P0);q=n-j*P0
        if n>=n0:assert n0<=q<n0+P0
        else:assert q==n
        a=prior_lookup[q]
        assert row['inherited_lower']==a['lower']+j*s
        assert row['upper']==a['upper']+j*s
        assert row['lower']==max(row['bridge_lower'],row['inherited_lower'])
        assert row['gap']==row['upper']-row['lower']>=0
        B=(0,-1,-1)
        for _ in range(J+H):B=step(w,n,k,B)
        assert B[2]<w*n//2
        points+=1
    assert x['maximum_gap']==max(a['gap']for a in x['rows'])
    rows.append(dict(w=w,k=k,parity=p,finite_representatives=len(expected),maximum_gap=x['maximum_gap'],reference_head_margin=href-k*J-r*(r+1),short_head_margin=hmin-max(d)-k-r*(r+1),short_tail_margin=hmin-max(x['tail']['ordinary'])-r*r))
sources=['upper-review-remaining-panel.py','comparison_remaining_panel.py','comparison-remaining-panel.json','comparison-minimized-candidates.json','root-band9-two-day-screen.json']
out=dict(status='PASS',scope=__doc__,families=len(rows),finite_representatives=points,results=rows,CPU_seconds=time.process_time()-start,source_sha256={name:hashlib.sha256((P/name).read_bytes()).hexdigest()for name in sources})
(P/'upper-review-remaining-panel.json').write_text(json.dumps(out,indent=2)+'\n')
print({k:v for k,v in out.items()if k not in('results','source_sha256')})

"""Conservative final width64 coverage, preserving every earlier receipt."""
from pathlib import Path
import json,hashlib
HERE=Path(__file__).resolve().parent


def run():
    old=json.loads((HERE/'comparison-three-day-panel.json').read_text())
    new=json.loads((HERE/'comparison-remaining-panel.json').read_text())
    exact24=json.loads((HERE/'comparison-two-sided-certificate.json').read_text())
    baseline=json.loads((HERE.parent/'all-budget-2026-10-23/baseline.json').read_text())
    assert exact24['status']=='PASS' and new['status']=='COMPLETE'
    assert any(x['condition']=='w=25,k=13,n>=26 even'and
               x['lower']==x['upper']=='50*n-925'and x['gap']==0
               for x in baseline['all_length_regressions'])
    key=lambda x:(x['w'],x['k'],x['parity'])
    N={key(x):x for x in new['results']}
    exact={(24,13,0),(24,13,1),(25,13,0)}
    assert set(N)=={key(x)for x in old['results']if x['maximum_gap']==3}-exact
    results=[]
    for prior in old['results']:
        x=dict(prior);z=key(x)
        if z in exact:
            x['maximum_gap']=0
            x['source']='accepted complete24-row family'if z[0]==24 else'frozen complete25-row family'
        elif z in N:
            assert not N[z].get('failed_premise')
            assert all(a['gap']==a['upper']-a['lower']>=0 for a in N[z]['rows'])
            x['maximum_gap']=min(x['maximum_gap'],N[z]['maximum_gap'])
            x['source']='supplemental common-envelope certificate and inherited BAND9 bound'
        results.append(x)
    exceptions=[]
    for x in new['results']:
        if x['maximum_gap']<=2:continue
        bad=[a for a in x['rows']if a['gap']>2]
        assert x['period']==6 and {a['n']%6 for a in bad}=={4}
        start=min(a['n']for a in bad)
        assert (x['w'],x['k'],start)in((47,25,52),(61,32,64))
        exceptions.append(dict(w=x['w'],k=x['k'],n_min=start,n_modulus=6,n_residue=4,
                               allowed_gap=3,meaning='The complete family certificate permits three days here; stronger individual evaluations may improve it.'))
    assert len(exceptions)==2 and max(x['maximum_gap']for x in results)==3
    files=['comparison-three-day-panel.json','comparison-remaining-panel.json',
           'comparison-two-sided-certificate.json','upper-review-two-sided.md',
           'upper-review-envelope.md','upper-review-remaining-panel.json',
           'comparison_final_panel.py']
    result=dict(status='PASS',scope='Every w<=64, every n>=w, every feasible k. Gap<=2 except the two displayed length-residue ranges, where gap<=3. Retained exact odd-by-odd and width<=5 classifications and high-budget gap<=1 cover the rest of the domain.',
                mathematical_review='Generic envelope and two-sided theorems accepted; supplemental18-line source/premise/coverage audit accepted without rerunning its graph searches.',
                maximum_gap=3,even_area_low_budget_lines=len(results),
                counts={str(g):sum(x['maximum_gap']==g for x in results)for g in range(4)},
                larger_gap_ranges=exceptions,results=results,
                source_sha256={f:hashlib.sha256((HERE/f).read_bytes()).hexdigest()for f in files},
                frozen_baseline_sha256=hashlib.sha256((HERE.parent/'all-budget-2026-10-23/baseline.json').read_bytes()).hexdigest())
    (HERE/'comparison-final-panel.json').write_text(json.dumps(result,indent=2)+'\n')
    return result


if __name__=='__main__':
    r=run();print({k:v for k,v in r.items()if k not in('results','source_sha256','frozen_baseline_sha256')})

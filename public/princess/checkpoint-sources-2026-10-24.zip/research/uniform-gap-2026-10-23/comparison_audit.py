"""Reproducible finite-residue coverage and frozen-evaluator checks."""
from pathlib import Path
import argparse, hashlib, importlib.util, json, random, time
from comparison_periodic import all_lengths, bounds

ROOT=Path(__file__).resolve().parents[2]


def hashes():
    files=[Path(__file__),Path(__file__).with_name('comparison_periodic.py'),
           Path(__file__).with_name('comparison-periodic.md'),
           ROOT/'src/bridge_corner_frontier.py',
           ROOT/'src/bridge_upper_transport_coupling.py',
           ROOT/'src/bridge_upper_transport_odd_coupling.py',
           ROOT/'research/all-budget-2026-10-23/audit_named_bounds.py']
    return {str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}


def frozen_comparison():
    p=ROOT/'research/all-budget-2026-10-23/audit_named_bounds.py'
    spec=importlib.util.spec_from_file_location('frozen_bounds',p)
    old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
    rng=random.Random(20261024)
    for _ in range(300):
        w=rng.randrange(4,61);n=rng.randrange(w,4*w+1);n+=w*n%2
        k=rng.randrange(w//2+1,min(w*n//2+1,2*w+1))
        assert bounds(w,n,k)==old.bounds(w,n,k)
    return dict(status='PASS',cases=300,seed=20261024)


def run(max_width=64,output=None):
    started=time.process_time();rows=[]
    old=frozen_comparison()
    for w in range(4,max_width+1):
        gate=((13*w+9)//10 if not w%2 else
              min((4*w+2)//3,(13*(w//2)+4)//5+3))
        for k in range(w//2+1,gate):
            for parity in ((0,1) if not w%2 else (0,)):
                rows.append(all_lengths(w,k,parity))
        result=dict(status='PASS',scope='Every feasible budget below the accepted one-day gate; every admissible length via the periodic-insertion theorem.',
                    max_width=w,lines=len(rows),
                    lengths=sum(x['checked_lengths'] for x in rows),
                    maximum_gap=max(x['maximum_gap'] for x in rows),
                    cpu_seconds=time.process_time()-started,
                    frozen_comparison=old,source_sha256=hashes(),results=rows)
        if output: output.write_text(json.dumps(result,indent=2)+'\n')
        print(w,result['lines'],result['maximum_gap'],round(result['cpu_seconds'],2),flush=True)
    return result


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--max-width',type=int,default=64)
    parser.add_argument('--output',type=Path,default=Path(__file__).with_name('comparison-complete-widths.json'))
    args=parser.parse_args();run(args.max_width,args.output)

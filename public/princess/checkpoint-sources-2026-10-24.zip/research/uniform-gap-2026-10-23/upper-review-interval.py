"""Independent verifier of interval relation/source unions and affine capacity counts."""
import sys,importlib.util,time,json,random
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'src'));sys.path.insert(0,str(Path(__file__).parent))
from root_interval import engine
from bridge_corner_frontier import survivor_bound
from bridge_corner_reach import graph
p=ROOT/'research/all-budget-2026-10-23/lower_lens.py';s=importlib.util.spec_from_file_location('lens',p);lens=importlib.util.module_from_spec(s);s.loader.exec_module(lens)
from math import isqrt

def expand(parts):
 out={}
 for d,R,a,b in parts:out.setdefault((d,R),set()).update(range(a,b+1))
 return {k:v for k,v in out.items()if v}

def literal(i,j,qa,qb,w,n):
 h=w*n//2;out={}
 for q in range(qa,qb+1):
  for t in range(max(1,j),h-2+j+1):
   if q>survivor_bound(w,n,i,j,t):continue
   key=(-1,-1);r=isqrt(q);r+=r*r<q
   if i==1 and j==0 and q>r*(r-1) and 2<=r<w//2 and t==q+r:key=(1,2*r-1)
   r=(1+isqrt(1+4*q))//2
   if i==0 and j==1 and q==r*(r-1) and 2<=r<w//2 and t==r*r:key=(0,2*r-2)
   out.setdefault(key,set()).add(t)
 return out
st=time.process_time();rng=random.Random(20261024);relations=caps=sourceunions=0
for w,n in[(4,4),(4,5),(5,6),(6,6),(6,7),(7,8),(8,8),(8,9),(9,10),(10,10),(12,13)]:
 h,D,cap,relation=engine(w,n,w//2+1);A,C=lens.capacities(w,n)
 for R in range(D+1):
  for S in range(D+1):assert cap(R,S)==(A[R][S],C[R][S]),(w,n,R,S);caps+=1
 for _ in range(500):
  i=rng.randrange(3);j=rng.randrange(3);qa=rng.randrange(max(1,i),h-2+i+1);qb=rng.randrange(qa,h-2+i+1)
  assert expand(relation(i,j,qa,qb))==literal(i,j,qa,qb,w,n),(w,n,i,j,qa,qb)
  relations+=1
 if w<=6:
  for k in range(w//2+1,w+1):
   states,index,rows=graph(w,n,k)
   for c in range(3):
    for a in range(c,h-2+c+1):
     for b in range(a,h-2+c+1):
      expected={}
      for x in range(a,b+1):
       for key,mask in rows[index[x,c]].items():expected[key]=expected.get(key,0)|mask
      actual={}
      if a<=k:actual[-1,-1]=1<<index[0,0]
      for i in range(c+1):
       if c-i>k:continue
       qa=max(1,i,a-k);qb=min(b-(c-i),h-2+i)
       if qa>qb:continue
       for j in range(3):
        for d,R,u,v in relation(i,j,qa,qb):
         mask=sum(1<<index[t,j]for t in range(u,v+1));actual[d,R]=actual.get((d,R),0)|mask
      actual={x:y for x,y in actual.items()if y};expected={x:y for x,y in expected.items()if y}
      assert actual==expected,(w,n,k,c,a,b)
      sourceunions+=1
out=dict(status='PASS',relation_unions=relations,source_interval_unions=sourceunions,capacity_pairs=caps,CPU_seconds=time.process_time()-st)
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print(out)

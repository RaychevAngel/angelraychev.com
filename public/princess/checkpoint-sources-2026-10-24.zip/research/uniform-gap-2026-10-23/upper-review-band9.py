"""Independent algebraic/cross-board checks of BAND9 middle and translated tail."""
import sys,random,time,json,hashlib
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent))
import comparison_band9 as m
from math import gcd
st=time.process_time();rng=random.Random(202610243);middle=tail=0
for w in range(6,43):
 r=w//2;A=(r+4)**2
 for k in sorted({r+1,r+2,w,2*w}):
  for _ in range(12):
   B=tuple(rng.randrange(A,A+3*w+1)for f in m.FEATURES)
   out=m.infinite_step(w,k,B)
   expected=tuple(k+max(B[m.INDEX[j,v]]-max(0,v-c)-(r if(v,j)==((1,1)if w%2==0 else(2,0))else r+1)for j,v in m.FEATURES)for c,e in m.FEATURES)
   assert out==expected,(w,k,B,out,expected)
   assert all(out[m.INDEX[c,e]]==out[m.INDEX[c,0]]for c,e in m.FEATURES)
   for z in range(2):out=m.infinite_step(w,k,out)
   assert m.normal(w,out),(w,k,out)
   assert m.infinite_step(w,k,m.infinite_step(w,k,out))==tuple(x+2*k-w for x in out)
   middle+=1
  n=max(w+2,(4*A+w-1)//w);n+=w*n%2
  h=w*n//2;P=2*(2*k-w)//gcd(w,2*k-w);delta=w*P//2
  for _ in range(12):
   # Includes high-region and saturated coordinates, whose local updates must translate.
   B=tuple(rng.randrange(A,h-4+c+e+1)for c,e in m.FEATURES)
   C=tuple(rng.randrange(A,h-4+c+e+1)for c,e in m.FEATURES)
   X=tuple(rng.randrange(A,h+1)for _ in range(2));Y=tuple(rng.randrange(A,h+1)for _ in range(2));Z=(B,C,X,Y)
   assert m.advance(w,n+P,k,m.base.translated(Z,delta))==m.base.translated(m.advance(w,n,k,Z),delta),(w,n,k,Z)
   tail+=1
files=['comparison-band9-periodic.md','comparison_band9.py','lower-band9.py','lower-erosion.py','lower-history-lens.py','comparison_periodic.py']
out=dict(status='PASS',arbitrary_middle_checks=middle,translated_high_tail_checks=tail,CPU_seconds=time.process_time()-st,source_sha256={f:hashlib.sha256((Path(__file__).parent/f).read_bytes()).hexdigest()for f in files})
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print(out)

#include <algorithm>
#include <bit>
#include <cstdint>
#include <cstdio>
#include <vector>
#include <utility>
using U=uint64_t;
int main(){
 unsigned long long tested=0,qualifying=0;int violations=0;
 for(auto [w,n]:std::vector<std::pair<int,int>>{{4,4},{4,5},{6,6},{6,7},{8,8},{8,9}}){
  auto before=tested;auto qualbefore=qualifying;
  for(int color=0;color<2;color++){
   std::vector<std::pair<int,int>> cs[2];int id[10][10];
   for(int x=0;x<w;x++)for(int y=0;y<n;y++){int z=(x+y)%2;id[x][y]=cs[z].size();cs[z].emplace_back(x,y);}
   U ng[2][64]={};
   for(int z=0;z<2;z++)for(int a=0;a<(int)cs[z].size();a++){
    auto [x,y]=cs[z][a];
    for(auto [dx,dy]:std::vector<std::pair<int,int>>{{1,0},{-1,0},{0,1},{0,-1}}){int xx=x+dx,yy=y+dy;if(0<=xx&&xx<w&&0<=yy&&yy<n)ng[z][a]|=U(1)<<id[xx][yy];}
   }
   U own=0,forbid=0;
   for(auto [x,y]:std::vector<std::pair<int,int>>{{0,0},{w-1,0},{0,n-1},{w-1,n-1}}){if((x+y)%2==color)own|=U(1)<<id[x][y];else forbid|=ng[1-color][id[x][y]];}
   for(int anchor=0;anchor<(int)cs[color].size();anchor++)if((own>>anchor)&1){
    std::vector<int> avail;for(int x=0;x<(int)cs[color].size();x++)if(!((own|forbid)>>x&1))avail.push_back(x);
    for(int r=2;r<w/2;r++){
     U ball=0;auto [ox,oy]=cs[color][anchor];for(int x=0;x<(int)cs[color].size();x++)if(abs(cs[color][x].first-ox)+abs(cs[color][x].second-oy)<=2*r-2)ball|=U(1)<<x;
     for(int q=(r-1)*(r-1)+1;q<=r*r;q++){
      auto rec=[&](auto&&self,int pos,int left,U S,U N)->void{
       if(left==0){tested++;int surplus=std::popcount(N)-q;if(surplus<=r){qualifying++;if(surplus!=r||(S&~ball)){violations++;std::printf("FAIL %d %d c%d r%d q%d\n",w,n,color,r,q);}}return;}
       if((int)avail.size()-pos<left)return;
       for(int z=pos;z<=(int)avail.size()-left;z++){int a=avail[z];self(self,z+1,left-1,S|(U(1)<<a),N|ng[color][a]);}
      };
      rec(rec,0,q-1,U(1)<<anchor,ng[color][anchor]);
     }
    }
   }
  }
  std::printf("{\"w\":%d,\"n\":%d,\"tested\":%llu,\"qualifying\":%llu,\"violations\":%d}\n",w,n,tested-before,qualifying-qualbefore,violations);std::fflush(stdout);
 }
 std::printf("{\"total_tested\":%llu,\"total_qualifying\":%llu,\"violations\":%d}\n",tested,qualifying,violations);
 return violations?1:0;
}

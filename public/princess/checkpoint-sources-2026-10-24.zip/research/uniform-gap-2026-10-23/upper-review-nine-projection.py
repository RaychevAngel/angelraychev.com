"""Independent corner-Lipschitz and admitted nine-to-three edge audit."""
from pathlib import Path
import importlib.util, sys, time, json, hashlib
P=Path(__file__).resolve().parent
sys.path.insert(0,str(P.parents[1]/'src'))
sys.path.insert(0,str(P))
from bridge_corner_frontier import survivor_bound as B
from root_dual_interval import engine as three
spec=importlib.util.spec_from_file_location('projection_nine',P/'lower-dual-nine-interval.py')
nine=importlib.util.module_from_spec(spec);spec.loader.exec_module(nine)
start=time.process_time();lipschitz=edges=clamps=charges=0
for w in range(4,41):
    for n in range(w,w+6):
        if w*n%2:continue
        for j in range(3):
            for T in range(w*n//2+2):
                for i in range(2):
                    assert B(w,n,i,j,T)>=B(w,n,i+1,j,T)-1,(w,n,i,j,T)
                    lipschitz+=1
for w in range(4,13):
    for n in range(w,w+3):
        if w*n%2:continue
        h=w*n//2
        for critical in (False,True):
            for wide in (False,True):
                *_,rel3=three(w,n,w//2+1,pronic_interval=True,critical_pronic=critical,wide_square=wide)
                _,_,_,_,cap,event=nine.engine(w,n,w//2+1,critical,wide)
                for j in range(3):
                    for v in range(3):
                        for i in range(v+1):
                            for u in range(j+1):
                                for T in range(1,h-4+j+v+1):
                                    for q in range(1,cap(T,i,u,j,v)+1):
                                        ev=event(i,u,j,v,q)
                                        label=ev[:2] if ev and ev[2]==T else (-1,-1)
                                        if label==(-2,-2):continue
                                        ip=min(i,q)
                                        assert T>=j and B(w,n,ip,j,T)>=q,(w,n,i,u,j,v,T,q)
                                        assert any(lo<=T<=hi and (d,R)==label for d,R,lo,hi in rel3(ip,j,q,q)),(w,n,critical,wide,i,u,j,v,T,q,label)
                                        edges+=1
                                        if ip!=i:
                                            clamps+=1
                                            assert (q,i,ip)==(1,2,1)
                                        for c in range(i,3):
                                            for p in range(max(c-i,c-q,0),4):
                                                assert c-ip<=p
                                                charges+=1
sources=[Path(__file__),P/'lower-nine-projection.md',P/'lower-dual-nine-interval.py',P/'root_dual_interval.py',P.parents[1]/'src/bridge_corner_frontier.py']
out=dict(status='PASS',corner_lipschitz_checks=lipschitz,admitted_labelled_edge_checks=edges,clamped_survivor_checks=clamps,deletion_charge_checks=charges,CPU_seconds=time.process_time()-start,source_sha256={str(p.relative_to(P.parents[1])):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources})
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print(out)

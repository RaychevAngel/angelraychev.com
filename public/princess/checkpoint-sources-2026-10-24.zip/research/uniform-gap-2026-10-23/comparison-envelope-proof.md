# A single boundary relaxation for every length

24 October 2026 UTC. Submitted for independent review. This supplements
the accepted two-sided transfer, without changing its physical-game
interpretation. It replaces many separate short-board computations by
one deliberately enlarged boundary graph. Implementation:
`comparison_tail_envelope.py`.

## Common tail graph

Fix w,k,H and one admissible length parity. Let n_min be its first length,
and n_ref the stable tail onset from `comparison-tail-seed-proof.md`.
Let B_j be the ordinary infinite-strip backward frontier after j steps.
Write b=max B_H. Assume

    w*n_min/2 >= b+r^2+1.

Then the finite-board ordinary frontiers through H equal the infinite
frontiers: all targets are in the common low region, the high inverses
and full-board caps are inactive, and induction gives the assertion.
If even width has n_min=w+1, additionally require
`small_inverse(2,0,b)<=r`; this makes the extra critical branch on that
single board inactive. Consequently every H-step winning path, when j
steps remain, has size at most B_j for its corner count. In particular
every such size is at most b. This sharper necessary size bound is why
the condition uses b, rather than kH.

Use the stable reference board's scalar low-side relations and represent
unknown radius by its diameter D_ref. Every finite radius reached in H
steps is at most R_max=2r-3+H, strictly below D_ref. For each radius pair,
define an envelope area and envelope corner count by taking the separate
maxima of the literal capacities over all n_min<=n<=n_ref of the chosen
parity. An unknown coordinate is replaced by that board's diameter;
a finite coordinate keeps its numerical radius, even if it exceeds the
shorter board's diameter. This has the same ball as a clipped radius.
For radius pairs with at least one finite coordinate, the stable
reference capacity represents every n>=n_ref by the accepted finite-radius
separation argument. The unknown/unknown area is h_n and therefore need
not be bounded by h_ref on longer boards; its reference capacity h_ref
nevertheless admits every relevant winning size, which is at most b.
Its corner capacity is always two. Thus the envelope admits all capacity
checks needed by a winning tail on every admissible board.

Each actual finite-board tail maps into this envelope graph: scalar
transitions agree in its necessary low region, resets agree, movement
agrees up to the harmless radius clipping, and capacity checks only
weaken. The envelope is permitted to contain extra states outside that
region; this cannot invalidate an upper bound on its winning set.
Compute the largest envelope-winning start V_c by descending from B_H(c)
and excluding every larger size. This does not assert downward closure.
The resulting prefix seed contains every actual paired-tail winning
state on every length. Therefore it can replace the tail seed in the
accepted two-sided clock domination theorem simultaneously for all n.

## Common head graph

Choose a reference board n_ref>=4r with h_ref-kJ>r(r+1), and fix the same
parity. Compute the J-step head in high deficit coordinates. For radius
deficits delta_R,delta_S use the envelope

    area = h_ref - min_n (h_n - capacity_n(D_n-delta_R,D_n-delta_S)),
    corners = max_n corner_capacity_n(D_n-delta_R,D_n-delta_S),

where n runs from n_min through at least4r in that parity, together with
the stable reference board. Large-ball capacities in deficit coordinates
stabilize beyond4r; this is the head argument already proved in
`comparison-two-sided-proof.md`. Thus the envelope dominates every
length after translating areas by h_ref-h_n.

Let d_c be the maximum reachable head deficit in this relaxed graph,
and d=max d_c. Check the self-consistent condition

    h_min-d-k > r(r+1).

This proves, by induction along every actual J-step head path, that it
maps into the envelope graph. The initial full state maps correctly. If
the path has mapped up to the previous step, its deficit is at most d;
therefore its next survivor has size greater than r(r+1). Low-side
inverse terms and low-radius resets are inactive. The high scalar
relations are translation invariant, and the envelope admits all actual
capacity checks, proving the next state maps. This induction is not an
assumption about unseen actual deficits: it uses the already computed
finite graph's bound at each predecessor. If n_min=w+1 at even width,
also check `large_inverse(2,0,max(0,d+k-r))<=r`. If the extra cap r
could admit a transition excluded by cap r+1, its integer survivor
size would be exactly T-r. The predecessor gives survivor deficit at
most d+k, hence target deficit at most d+k-r; the displayed check says
the high inverse already permits surplus r there, a contradiction.
Thus the additional critical branch cannot change any transition from
a mapped predecessor. Every radius deficit stays at
most2r-2, as in the stable head argument.

The envelope d may exceed the true board-specific maximum. That is
intentional: every true head size is still at least h_n-d_c. Exact
boundary realizability or equality of any winning set is unnecessary.

## Numerical bridge and coverage

Use these common d and V in

    tau=J+H+min{t: exists c, F_n^t(V)_c>=h_n-d_c}.

When the ordinary necessary model excludes capture by J+H, the accepted
two-sided argument gives T>=2tau-1. This exclusion is checked on every
short representative. Beyond the onset use the sufficient condition
h_n>k(J+H). Both d and V are now valid on every length, although they
were obtained from finite boundary graphs.

The envelope's capacity maxima are monotone in each radius. Forgetting
radii only weakens them. Each maximal tail winner therefore has an
ordinary first transition into the prefix seed, so V<=F_infinity(V).
In the finite boards of interest, the low-region margin makes this same
first update valid. Horizon monotonicity and the accepted normal-form
insertion proof follow. The numerical certificate checks all lengths
before its safe insertion onset and one representative per residue
afterward. The onset includes the meeting margin M+max d+1 and
h>k(J+H). Thus no untested short-board or early-capture assumption is
hidden in the all-length assertion.

## Five family applications

For w44,k24,J=H48, both parities give
`d=(384,385,385)` and `V=(404,404,404)`.
For w46,k24,J=H80, both parities give
`d=(464,465,465)` and `V=(486,486,486)`.
For w47,k24,J=H80 and even lengths, the same d and V apply.
The envelope seeds equal their long-board seeds, but only the envelope
containment proved above is needed. The intended certified conclusions
are

    22n-633 <= T_24(44,n) <= 22n-631,  n>=44;
    46n-1609 <= T_24(46,n) <= 46n-1607, n>=46;
    94n-3683 <= T_24(47,n) <= 94n-3681, n>=48 even.

The two-sided numerical certificate supplies the finite comparisons;
independent review remains necessary before treating these refinements
as accepted. They would remove every remaining greater-than-three gap
from the complete width-at-most64 panel. They do not establish a constant
gap for arbitrary unbounded widths, and add no Lean theorem.

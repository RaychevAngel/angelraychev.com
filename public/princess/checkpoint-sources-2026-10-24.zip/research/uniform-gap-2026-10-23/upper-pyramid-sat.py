"""Bounded search for physical pyramid schedules. SAT success is replayed literally;
failure/timeout is not an unrestricted lower bound. One worker.
"""
import sys,time,json
from pathlib import Path
from ortools.sat.python import cp_model
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'src'))
from bridge_upper_transport import prefix_height,support,height_neighborhood
from resumed_even_construction_prefix_arithmetic import neighborhood_count
from resumed_even_construction_transport import neighborhood

def solve(w,n,k,T,p0=0,seconds=30):
 st=time.process_time();h=w*n//2;m=cp_model.CpModel();before=[];remain=[]
 cap=lambda p,x: (n+1-((p-x)%2))//2
 for t in range(T):
  p=(p0+t)%2
  A=[m.NewIntVar(0,cap(p,x),f'a{t}_{x}')for x in range(w)]
  R=[m.NewIntVar(0,cap(p,x),f'r{t}_{x}')for x in range(w)]
  before.append(A);remain.append(R)
  for x in range(w):m.Add(R[x]<=A[x])
  for x in range(w-1):
   if(p-x)%2==0:m.Add(R[x]-R[x+1]>=0);m.Add(R[x]-R[x+1]<=1)
   else:m.Add(R[x]-R[x+1]>=-1);m.Add(R[x]-R[x+1]<=0)
  if t==T-1:
   for v in R:m.Add(v==0)
   m.Add(sum(A)<=k)
  else:m.Add(sum(A)-sum(R)==k)
  if t==0:
   for x in range(w):m.Add(A[x]==cap(p,x))
  else:
   pp=1-p;P=remain[t-1]
   for x in range(w):
    values=[P[z]for z in(x-1,x+1)if 0<=z<w]
    if(pp-x)%2==0:values.append(P[x])
    else:
     positive=m.NewBoolVar(f'pos{t}_{x}');m.Add(P[x]>=1).OnlyEnforceIf(positive);m.Add(P[x]==0).OnlyEnforceIf(positive.Not())
     addition=m.NewIntVar(0,cap(p,x),f'long{t}_{x}');m.AddMinEquality(addition,[cap(p,x),P[x]+positive]);values.append(addition)
    m.AddMaxEquality(A[x],values)
 # Prefix hint, potentially one day too long; all hinted days except final valid.
 q=h
 for t in range(T):
  p=(p0+t)%2;a=prefix_height(w,n,p,q);r=prefix_height(w,n,p,max(q-k,0))
  for x in range(w):
   m.AddHint(before[t][x],(a[x]-((p-x)%2)+2)//2)
   m.AddHint(remain[t][x],(r[x]-((p-x)%2)+2)//2)
  q=neighborhood_count(w,n,p,max(q-k,0))
 s=cp_model.CpSolver();s.parameters.max_time_in_seconds=seconds;s.parameters.num_search_workers=1
 status=s.Solve(m);out=dict(w=w,n=n,k=k,T=T,p0=p0,status=s.StatusName(status),wall_seconds=s.WallTime(),CPU_seconds=time.process_time()-st)
 if status in(cp_model.OPTIMAL,cp_model.FEASIBLE):
  A={(x,y)for x in range(w)for y in range(n)if(x+y)%2==p0};shots=[]
  for t in range(T):
   p=(p0+t)%2;R={(x,y)for x in range(w)for y in range((p-x)%2,2*s.Value(remain[t][x])+((p-x)%2),2)}
   S=A-R;assert R<=A and len(S)<=k
   shots.append(S);A=neighborhood(w,n,R)
  assert not A
  if p0:shots=[{(w-1-x,y)for x,y in S}for S in shots]
  full=shots+shots[::-1]
  if 2*len(shots[-1])<=k:
   reflect=lambda S:{(w-1-x,y)for x,y in S}
   full=shots[:-1]+[shots[-1]|reflect(shots[-1])]+[reflect(S)for S in shots[-2::-1]]
  A={(x,y)for x in range(w)for y in range(n)}
  for d,S in enumerate(full,1):
   assert len(S)<=k;A-=S
   if not A:break
   A=neighborhood(w,n,A)
  assert not A
  out.update(solo_shots=[sorted(S)for S in shots],physical_replay=True,full_upper=d,final_solo_shot=len(shots[-1]))
 return out
if __name__=='__main__':
 w,n,k,T,p0=map(int,sys.argv[1:6]);seconds=float(sys.argv[6])if len(sys.argv)>6 else 30
 out=solve(w,n,k,T,p0,seconds)
 Path(__file__).with_name(f'upper-pyramid-sat-{w}x{n}-k{k}-t{T}-p{p0}.json').write_text(json.dumps(out,indent=2)+'\n')
 print({k:v for k,v in out.items()if k!='solo_shots'})

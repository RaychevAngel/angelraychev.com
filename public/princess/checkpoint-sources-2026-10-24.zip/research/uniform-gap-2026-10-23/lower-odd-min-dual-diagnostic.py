"""Bounded diagnostic: odd widths, minimum budget, near-square/double length.

Every case has a 30 CPU-second evaluator cap. This finite panel does not
establish an all-width or all-length gap theorem.
"""
from pathlib import Path
import importlib.util,json,hashlib,time
HERE=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('interval_odd_diagnostic',HERE/'lower-dual-nine-interval.py')
m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
from audit_named_bounds import bounds


if __name__=='__main__':
    files=['lower-dual-nine-interval.py','root-dual-nine.py','root_dual_interval.py','root_capacity.py','lower-erosion.py']
    out=dict(scope=__doc__,source_sha256={f:hashlib.sha256((HERE/f).read_bytes()).hexdigest()for f in files},rows=[])
    for w,n in [(47,48),(47,94),(81,82),(81,162),(129,130),(129,258)]:
        k=w//2+1;baseline=bounds(w,n,k)
        result=m.run(w,n,k,seconds=30,trace=True)
        if result['complete']:
            result.update(basic_corner_lower=baseline['lower'],physical_prefix_upper=baseline['upper'],gap=baseline['upper']-result['lower'])
        out['rows'].append(result)
        Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
        print({key:value for key,value in result.items()if key!='layers'},flush=True)

"""Exact seed and periodic-tail certificate for the remaining44-row line."""
from pathlib import Path
from math import gcd
import json,time,hashlib
import comparison_periodic as base
import comparison_tail_seed as tail
HERE=Path(__file__).resolve().parent


def seeded_initial(k,V):
    m=k//2
    return (tuple(V),(0,-1,-1),(0,0),(m,m))


def seeded_entry(w,k,V):
    r=w//2;A=r*(r+1)+1
    Z=seeded_initial(k,V);trace=[Z]
    def normal(B):
        return (B[0]==B[2]-1 and B[1]==B[2])if not w%2 else(B[0]==B[1]and B[2]-B[0]in(0,1))
    while min(min(row)for row in Z)<A or not all(normal(B)for B in Z[:2]):
        Z=base.advance_infinite(w,k,Z);trace.append(Z)
        assert len(trace)<=4*A+20
    first=base.advance_infinite(w,k,Z)
    assert base.advance_infinite(w,k,first)==base.translated(Z,2*k-w)
    M=max(max(row)for state in trace+[first]for row in state)
    g=gcd(w,2*k-w)
    return dict(w=w,k=k,A=A,entry_day=len(trace)-1,entry=Z,next_entry=first,
                safe_h=M+max(r*r+1,k+2),length_period=2*(2*k-w)//g,
                solo_shift=2*w//g,full_shift=4*w//g)


def seeded_bounds(w,n,k,H,V):
    h=w*n//2;Z=seeded_initial(k,V);low=up=None;t=0;trace=[]
    while low is None or up is None:
        trace.append(Z);B,_,X,Y=Z
        if low is None and B[2]==h:low=2*(H+t)-1
        if up is None:
            candidates=[]
            if max(X)==h:candidates.append(2*t)
            if max(Y)==h:candidates.append(2*t+1)
            if candidates:up=min(candidates)
        if low is not None and up is not None:break
        Z=base.advance(w,n,k,Z);t+=1
        assert t<4*w*n
    return dict(w=w,n=n,k=k,H=H,seed=V,lower=low,upper=up,gap=up-low,trace=trace)


def run():
    start=time.process_time();w,k,H=44,24,28;rows=[]
    flags=dict(pronic_interval=True,critical_pronic=True,wide_square=True)
    for parity in(0,1):
        s=tail.seed(w,k,H,parity,**flags)
        V=s['paired_seed'];assert V==[309,309,309]
        e=seeded_entry(w,k,V)
        onset=max(s['n'],base.threshold(e,parity))
        assert w*onset//2>k*H
        P=e['length_period'];shift=w*P//2;days=e['solo_shift'];t=e['entry_day']
        a=seeded_bounds(w,onset,k,H,V);b=seeded_bounds(w,onset+P,k,H,V)
        assert a['trace'][t]==e['entry']==b['trace'][t]
        assert b['trace'][:t+1]==a['trace'][:t+1]
        assert len(b['trace'])==len(a['trace'])+days
        for old,new in zip(a['trace'][t:],b['trace'][t+days:]):
            assert new==base.translated(old,shift)
        assert b['lower']==a['lower']+e['full_shift']
        assert b['upper']==a['upper']+e['full_shift']
        assert a['lower']==22*onset-635 and a['upper']==22*onset-631
        rows.append(dict(parity=parity,seed=s,entry=e,onset=onset,
                         representative={x:y for x,y in a.items()if x!='trace'},
                         translated_tail_states=len(a['trace'])-t))
    files=['comparison-tail-seed-proof.md','comparison_tail_seed.py',
           'comparison_tail_seed_certificate.py','comparison_periodic.py',
           'root_interval.py','root_capacity.py','lower-wide-square.md']
    return dict(status='PASS',scope=__doc__,formula='22*n-635 <= T_24(44,n) <= 22*n-631',
                long_length_start=140,results=rows,CPU_seconds=time.process_time()-start,
                source_sha256={x:hashlib.sha256((HERE/x).read_bytes()).hexdigest()for x in files})


if __name__=='__main__':
    result=run();(HERE/'comparison-tail-seed-certificate.json').write_text(json.dumps(result,indent=2)+'\n')
    print({k:v for k,v in result.items()if k not in('results','source_sha256')})

# Independent review: dual high-radius equality resets

24 October 2026 UTC. Accepted ordinary physical and guarded-merger proofs,
with exact interval-transcription checks. No Lean claim.

The reviewed sources are `lower-dual-radius-resets.md` and the gated
version of `root_dual_interval.py`. The two accepted events are:

* `q=h-r^2`, original surplus r, target corners j=2, `2<=r<=b`:
  reset relative color `1 xor(D mod2)` to radius `D-2r+2`.
* `q=h-r(r+1)`, original surplus r, survivor corners i=2 and target
  corners j=1, `2<=r<b`: reset relative color `D mod2` to radius
  `D-2r+1`.

## Physical proof and parity

The first event leaves exactly `r(r-1)` target holes and no hole corner.
Their neighborhood has size at most `r^2`. The existing unconditional
profile forces surplus at least r, and the accepted exact-pronic
rigidity theorem therefore identifies the holes with a complete odd
triangle around one opposite-colored corner. This remains valid at
critical even squares; the different second-neighborhood corner count
does not change the hole triangle itself.

The second event leaves exactly `r^2` holes, with one own corner and no
outgoing corner. The already accepted square-bin localization places
them inside their corner ball of radius `2r-2`. That ball has exactly
`r^2` cells of their color, so the holes fill it. This proof retains the
strict subcritical condition.

For either event, every point's distances to a corner and its diagonal
antipode sum to D. Complementing the full hole ball gives exactly the
claimed outer ball, and the antipode changes relative color by D modulo
two. These large outer radii fit the existing two-coordinate model;
their values need not be small for the certificates to be valid.

## Merger proof

If both component original surpluses are positive, both are below r.
A small component would have target size at most `r(r-1)`, smaller than
the merged target in either event. Thus both components are high.

For the pronic event, merged target corner count two forces both target
counts to two. The ordinary high capacities satisfy
`G_(i,2)(s)<=s(s-1)` for every i. Their combined holes are therefore at
most `(r-1)(r-2)`, below the required `r(r-1)`.

For the square event, merged survivor corner count two forces both
survivor counts to two, and the target counts are one and two. The high
capacities are `s^2` and `C2(s)<=s^2`; with two positive surpluses their
sum is strictly below the required r squared holes.

Consequently one component has zero original surplus and is
original-full-to-full at zero inspection cost. The merger is the identity
on the other component, so the same event and reset are inherited.
This works directly in the three-corner model; no erosion coordinate
or unproved critical refined profile is needed.

## Implementation correction and independent tests

The first prototype appended high-pronic reset edges even when their
numerical targets were excluded by the ordinary relation, particularly
at wrong survivor corner counts. I identified this and the root added
ordinary-admissibility gates to both new event append loops. The reviewed
version contains those gates. The earlier extra edges were a relaxation,
but they did not represent an exact transcription of the intended model.

For each fixed pair of corner counts the event target is strictly
increasing with survivor size, including these high events. Thus the
existing union rule remains valid: the smallest survivor gives the
unlabeled target tail, its single reset hole is repaired only if a
larger survivor genuinely admits that same target without a reset,
and labeled event targets are included separately.

`upper-review-dual-interval.py` passed 33,600 exact labeled relation-union
comparisons and 14,400 complete inspection/source-interval comparisons
against literal q and T enumeration, across all eight previous optional
switch settings. The JSON identifies the gated source hash.

`upper-review-dual-geometry.py` exhaustively examined 7,976,492 candidate
target-hole sets across both colors of seven boards, including critical
even squares and even-width nonsquares. For every candidate it allowed
all sources consistent with the hole neighborhood, including possible
slack; it did not assume the complement equality. All44 resulting
physical events had the complete required hole triangle and the claimed
outer-radius certificate. This finite attack supplements the uniform
proof above and does not replace it.

Neither this review nor the new history restrictions prove that an
arbitrary relaxed path is a physical strategy or establish a width-free
constant gap. Numerical improvements must still be compared with the
retained physical upper bounds and all earlier lower bounds.

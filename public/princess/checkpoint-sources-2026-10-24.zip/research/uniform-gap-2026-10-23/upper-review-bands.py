"""Literal near-pronic dual-band check, independent of lower capacities."""
from itertools import combinations
from pathlib import Path
import json,time

def audit(w,n,r):
 h=w*n//2;cs={(0,0),(w-1,0),(0,n-1),(w-1,n-1)}
 cells=[[(x,y)for x in range(w)for y in range(n)if(x+y)%2==p]for p in(0,1)];ids=[{v:i for i,v in enumerate(row)}for row in cells]
 ng=[];corn=[]
 for p in(0,1):
  ng.append([sum(1<<ids[1-p][z]for z in((x-1,y),(x+1,y),(x,y-1),(x,y+1))if z in ids[1-p])for x,y in cells[p]])
  corn.append(sum(1<<i for i,v in enumerate(cells[p])if v in cs))
 checked=triggered=0
 for p in(0,1):
  available=[i for i,v in enumerate(cells[p])if v not in cs]
  for q in range(1,r*(r-1)+1):
   for indices in combinations(available,q):
    N=0
    for i in indices:N|=ng[p][i]
    surplus=N.bit_count()-q;v=2-(N&corn[1-p]).bit_count()
    threshold=(r-1)*(r-2)if v==1 else max(r*(r-1)//2,r*(r-2))
    checked+=1
    if q<=threshold or surplus>r:continue
    NN=0;m=N
    while m:
     bit=m&-m;m-=bit;NN|=ng[1-p][bit.bit_length()-1]
    assert surplus==r and (N&corn[1-p]).bit_count()==1 and not NN&corn[p],(w,n,r,p,q,surplus,indices)
    triggered+=1
 return dict(w=w,n=n,r=r,checked=checked,triggered=triggered)
st=time.process_time();rows=[]
for w,n,r in [(5,6,2),(6,6,2),(6,7,2),(7,8,3),(8,8,3)]:
 row=audit(w,n,r);rows.append(row);print(row,flush=True)
Path(__file__).with_suffix('.json').write_text(json.dumps(dict(rows=rows,CPU_seconds=time.process_time()-st),indent=2)+'\n')

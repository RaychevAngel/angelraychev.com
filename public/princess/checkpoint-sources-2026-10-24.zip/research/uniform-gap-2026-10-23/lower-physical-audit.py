"""Literal support validation, independent of inverse capacity derivation."""
import importlib.util,json,time
from pathlib import Path
sp=importlib.util.spec_from_file_location('er',Path(__file__).with_name('lower-erosion.py'));m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
def audit(w,n):
 cells=[(x,y)for x in range(w)for y in range(n)];C=[[p for p in cells if sum(p)%2==z]for z in(0,1)];ids=[{p:i for i,p in enumerate(X)}for X in C]
 corner={(0,0),(w-1,0),(0,n-1),(w-1,n-1)}
 ng=[[sum(1<<ids[1-z][q]for q in[(x-1,y),(x+1,y),(x,y-1),(x,y+1)]if q in ids[1-z])for x,y in C[z]]for z in(0,1)]
 cm=[sum(1<<ids[z][p]for p in corner if p in ids[z])for z in(0,1)];h=w*n//2;checked=0
 for z in(0,1):
  N=[0]*(1<<h)
  for S in range(1,1<<h):
   bit=S&-S;N[S]=N[S^bit]|ng[z][bit.bit_length()-1];B=N[S]
   q=S.bit_count();T=B.bit_count();i=(S&cm[z]).bit_count();j=(B&cm[1-z]).bit_count()
   u=sum((S&ng[1-z][t])==ng[1-z][t]for t in range(h)if(cm[1-z]>>t)&1)
   v=sum((B&ng[z][t])==ng[z][t]for t in range(h)if(cm[z]>>t)&1)
   cap=m.survivor(w,n,T,i,u,j,v)
   assert q<=cap,(w,n,z,S,q,i,u,T,j,v,cap)
   checked+=1
 return dict(w=w,n=n,checked=checked,passed=True)
if __name__=='__main__':
 start=time.process_time();rows=[]
 for c in[(4,4),(4,5),(4,6),(4,7),(4,8),(6,6),(6,7)]:
  row=audit(*c);rows.append(row);print(row,flush=True)
  Path(__file__).with_suffix('.json').write_text(json.dumps(dict(rows=rows,cpu_seconds=time.process_time()-start),indent=2)+'\n')

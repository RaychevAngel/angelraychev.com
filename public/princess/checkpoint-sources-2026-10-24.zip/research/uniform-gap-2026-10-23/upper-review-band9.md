# Independent review of the BAND9 all-length comparison theorem

24 October 2026 UTC. Upper/construction lane.

**Accepted:** `comparison-band9-periodic.md` and the corresponding recurrence
in `comparison_band9.py`, for w>=6 and all feasible k, with no radius
certificates or history flags. The proof supplies a finite all-length
comparison for each width/budget/parity, not an absolute gap bound over
unbounded widths.

The middle collapse is valid even before assuming reachable frontier
structure. Above the common threshold, fixed target features(j,v) have
survivor maximum `T-(v-i)-cap(v,j)`. Choosing `i=min(c,v),u=0` is admissible:
maximality follows from `max(c,v)<=2`, and the deletion charge is at most4.
Since feasible k>=4 at w>=6, no omitted charge condition is needed in the
infinite update. This choice minimizes the closure loss among all options.
The next frontier is therefore independent of e and nondecreasing in c.

For even width, the exceptional target `(j,v)=(1,1)` costs r precisely
when c>=1; at c=0 its closure loss restores cost r+1. For odd width the
exceptional target `(0,2)` costs r only when c=2, while c<=1 can instead
use a nonexceptional v=0 target at cost r+1. This recovers exactly the
three-corner middle update after e has disappeared, including its stated
normal forms and two-day translation.

The inverse threshold claim can also be justified without a long case list:
`P<=F<=sigma^2` implies that `sigma+P<=r(r-1)` whenever sigma<=r-1,
and `F<=(r-1)^2` in that range. Thus A=(r+4)^2 makes both refined inverse
thresholds at least r. It exceeds the already reviewed ordinary low/high
thresholds, and all band hole counts are smaller than A.

The entrance termination argument is valid at the least feasible budget.
The generic `(i,u,v)=(0,0,0)` choice is available from every source because
its charge c+e<=4. It transfers any `B[j,0]` to every next coordinate with
increment at least k-r-1. The even exceptional choice boosts `B[1,0]` by
at least one above the old global minimum; the odd exceptional choice
boosts `B[2,0]`. One generic update propagates this gain to every coordinate.
After the first two startup updates, the minimum thus increases at least
once every two days. No assumption that all nine coordinates are equal
before middle entry is used. The physical two-step increase is unchanged.
The stated finite guard is conservative.

During the translated tail, low terms remain inactive because the backward
frontiers are monotone in the allowed horizon. Static band conditions,
high inverses and finite feature caps depend on unchanged deficits from h.
The entrance margin keeps all caps inactive before insertion and prevents
capture there. The same first-hitting-time and half-budget arguments from
the original reviewed comparison proof therefore apply. The even-width
n=w+1 double exception is excluded by the larger stable threshold.

I also checked that `lower-band9.py` selects the unflagged nine-threshold
model with the proven-range static bands only; importing the richer module
does not add its optional radius or history constraints to this recurrence.

`upper-review-band9.py` independently checks arbitrary middle frontiers,
the three-update normal-form collapse, and exact finite-tail translation on
random high-region and saturated-coordinate states. The receipt includes
source hashes and exact test counts. These checks attack implementation
errors beyond the comparison lane's reachable-orbit tests; the algebra
above supplies the general argument.

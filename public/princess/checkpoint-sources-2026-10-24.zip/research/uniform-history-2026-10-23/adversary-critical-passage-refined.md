# A uniform critical-passage bound: fifty days for five root bands

24 October 2026 UTC. Proposed refinement for independent review. The
earlier7153-day proof is preserved. This theorem is a critical-region
comparison, not yet a complete capture-time bound.

## Statement and scope

Let C be5 or11, w<=n, wn even, b=floor(w/2)>=C+3,
k=b+d with d>=1, h=wn/2, and

    A=(b-C)^2.

Choose integers A<=z<M<=h-A. Start an ordinary three-corner frontier
from any valid entries B_j<=z, and let tau be its first time with
max B>=M. Start the physical two-phase prefix clocks from equal seeds
(z,z), or from a point on an equal-seed orbit with minimum at least z.
Their minimum reaches M within

    tau+8C+10,

that is tau+50 for C=5 or tau+98 for C=11,

further physical days. More generally the same argument gives8C+10
when the symbolic matrix certificate has been verified for C and b>=C+3.
The C=5 certificate has892 symbolic types; C=11 has1,660. Both have zero
sampled widths. The new C=5 receipt is
`adversary-critical-unshifted-five.json`; it uses the unchanged algorithm.

The comparison is uniform in width, length, feasible budget, and the
position of M in the critical region. It includes overlapping geometric
boundary ranges on the shortest rectangles.

## Three exact ingredients

Write

    psi(q)=min(rho(q),ceil(sqrt(h-q)),b).

Every ordinary transition cost is at least psi(q). Moreover q-psi(q) is
nondecreasing: it is the maximum of the three nondecreasing functions
q-rho(q), q-ceil(sqrt(h-q)), and q-b. Therefore, for any frontier with
maximum m, its next maximum is at most

    S(m)=min(h,m+k-psi(m)).                       (1)

The exact physical erosion identities give the same quantity as the
maximum after one physical update from equal seeds(m,m). One further
physical day makes the minimum at least S(m). Thus the scalar reset
(m,m,m)->(S(m),S(m),S(m)) is a valid relaxation of one model step, and
can be simulated with two physical days, paying one extra day.

The physical maps are nondecreasing and at least the identity. Along
an equal-seed orbit,

    min X(t+1)>=max X(t),
    X(t+2)>=min(h,X(t)+2d-1)                    (2)

coordinatewise. These are global facts, including root crossings.

Finally the ordinary and the relaxed corner frontiers used below have
spread at most two: B0<=B1<=B2<=B0+2. The original proof of this source
feature Lipschitz bound is in `adversary-critical-passage.md`. The new
relaxed matrices have the same property, since their costs decrease by
at most one on increasing c by one. Equal-coordinate resets preserve it.

## A relaxation with unshifted roots only

Use the relaxed three-corner operator proved in
`adversary-critical-unshifted.md`. For target q let

    alpha=R(q), beta=rho(q), gamma=R(h-q), delta=rho(h-q).

Its low and high cost matrices, after minimizing over retained corners,
are

    [ beta+1  alpha  alpha+1 ]       [ delta+3  gamma+2  delta+2 ]
    [ beta    alpha  alpha+1 ]  and  [ delta+2  gamma+1  delta+1 ].
    [ beta    alpha  alpha+1 ]       [ delta+1  gamma    delta+1 ]

Take their entrywise minimum with the usual width cap. These costs are
no greater than the accepted ordinary costs. Their erosion maps are
nondecreasing: low costs increase by at most one per room, high costs
are nonincreasing as q increases, and the cap is constant. The resulting
operator is monotone and overapproximates the ordinary operator.

In the critical region its input q lies between A-2 and h-A. Thus q>=7
and h-q>=9, exactly the range required by the unshifted relaxation.

## Exact maxima in a bulk cell

If all three frontier entries have the same four root values, the relaxed
operator is a fixed max-plus matrix. The exact symbolic certificate gives
a potential p from

    (0,0,0),       (0,0,1/2),       (0,1/2,1/2)

such that cost(c,j)>=mu+p_j-p_c, where mu is the mean of the physical
two phase costs. It also exhibits an exact physical two-cycle in the
three-state graph. From equal frontier seeds(z,z,z), the potential gives

    max B(t)<=z+t(k-mu)+1/2.

If the physical costs agree, mu is an integer and rounding removes the
extra1/2. If they differ, they differ by one; for even t the same rounding
removes it, while for odd t the physical leading phase has precisely
the extra1/2. The physical two-cycle gives the reverse inequality. Hence

    model maximum = physical maximum              (3)

at every time for these affine iterates from equal seeds.

In particular their maxima leave a fixed-root cell on the same day.
Both processes use valid cell inputs in the final step, even when their
outputs overshoot. A final output cap only reduces model entries, and
both physical and model maxima are capped at h. One additional physical
day restores minimum>=model maximum by(2). Thus a whole bulk cell,
however many model days it takes, costs at most one extra physical day.

## The relevant root cuts

Put r0=b-C. In the critical range the only relevant low-root breaks are

    m=r^2+1 and m=r(r+1)+1,       r0<=r<=b.

Below these indices even their two-room windows lie below A. Above them
all low costs are at least b+1 and are inactive after the width cap.
This gives2(C+1) low cuts.

The only relevant high-root breaks, as m increases, are

    m=h-r^2,          r0+1<=r<=b,
    m=h-r(r+1),       r0<=r<=b-1.

The lowest excluded square cut is m=h-A, outside the preterminal range.
For h-m>b^2 all high costs are at least b+1 and are inactive after the
width cap. This gives2C high cuts. The total number of cuts is therefore

    J<=4C+2.

Mark the two integer positions s,s+1 after each cut s. When the frontier
maximum is outside their union, its entire two-room spread lies in one
fixed-root cell. There are at most J+1 bulk components. In particular
the exceptional shortest-board point q=h-q=b^2 is marked by the high
square cut; the geometric exclusions in the matrix certificate are valid.

## A faster model with explicit interval resets

Initialize the faster model at (z,z,z), which dominates the original
initial frontier even if its actual maximum is smaller than A. On each
bulk entry reset all three frontier entries to their maximum,
then run the relaxed corner operator until its maximum leaves that bulk
component. Whenever the maximum is in the marked union, use one scalar
step(1) and reset all coordinates to its result. Repeat until the maximum
reaches M. Each reset only increases the frontier, and each operator is
monotone and dominates the ordinary operator. Its target-hitting time
tau_rel is therefore at most tau.

The maximum is nondecreasing. In a bulk component this follows from(3)
and the physical orbit; at marked positions S(m)-m>=d>=1 before the cap.
Consequently no interval is revisited.

Compare the physical clocks to this faster model. Reestablish physical
minimum>=model maximum after every bulk segment and every scalar marked
step. By(3) a bulk segment pays one extra day. By(1)-(2) a scalar marked
step also pays one extra day. It remains only to count marked steps.

## Only five cut types can require two marked steps

If psi(m)<=b-1, a scalar step increases m by at least d+1>=2. A two-room
marked interval with this property can therefore contain at most one
marked step of the monotone model.

All but five of the listed cut types have this property throughout their
two positions. For low square cuts with r<=b-1,

    m<=r^2+2<=(b-1)^2+2<=b(b-1),

so rho(m)<=b-1. For low pronic cuts with r<=b-2 the same conclusion
follows from m<=r(r+1)+2<=b(b-1). For high square cuts with r<=b-1,
h-m<=r^2<=(b-1)^2, so R(h-m)<=b-1; high pronic cuts with r<=b-2 have
the same property.

The only possible exceptions are:

* low pronic cut r=b-1;
* low square and low pronic cuts r=b;
* high square cut r=b;
* high pronic cut r=b-1.

Each exceptional two-room interval contains at most two marked steps,
since every scalar step advances by at least one. Overlaps only reduce
the union; a union bound on visits to the original intervals is valid.
Therefore the total number of marked steps is at most J+5.

## Total delay and remaining interfaces

There are at most J+1 visited bulk components and J+5 marked scalar steps.
Thus the physical minimum reaches M by

    tau_rel+(J+1)+(J+5) <= tau+2J+6
                         <= tau+8C+10.

Unlike the earlier theorem, this statement compares target-hitting times;
it does not claim to dominate the original frontier's final overshoot.
The parent proof uses an explicit target M, so this is its intended
interface. Joining the low and high physical-history arguments, checking
their parameter ranges, and transferring to the two-cohort capture time
remain separate obligations. No new Lean claim is made.

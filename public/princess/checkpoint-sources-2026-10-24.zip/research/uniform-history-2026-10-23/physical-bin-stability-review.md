# Independent review of quantitative full-layer stability and dual resets

Accepted as ordinary mathematics, 24 October 2026 UTC. This accepts the
geometric and guarded-merger statements in `lower-dual-bin-stability.md`,
and the exact labelled relation in `lower-dual-bin-interval.py`.
It does not prove an all-width constant capture-time gap or add Lean
verification.

## Full-layer statement

The hypotheses imply exactly L=r-p occupied layers: the containing ball
gives the upper limit, and omitting its final layer violates the strict
size lower bound. Each occupied layer contributes at least one new cell
to the next layer; parity one also contributes its initial corner. Since
the allowed total surplus equals this minimum, every layer inequality is
an equality. The raw set's layer counts are preserved by the permitted
diagonal compression, so the compressed layer formula applies to those
same counts without claiming the raw set itself is compressed.

The recurrence `a_(j+1)<=a_j+1+epsilon_(j+1)` has the required implication:
a full next layer has two more cells than the current layer's full size,
forcing the current layer to be full as well. After the first nonfull
layer, every later layer stays nonfull and its deficit increases by at
least one. Hence M trailing nonfull layers cost at least M(M+1)/2 cells.
The claimed full inner layers therefore belong to the original set.

## Physical dual statements

For the square trigger, occupied source corners i=2 ensure that the target
holes' neighborhood contains no opposite corner, while j=1 gives their
unique own corner. For the pronic trigger, j=2 gives no own hole corner,
and target erosion v=1 gives exactly one outgoing hole corner. That last
premise is essential to the stated localization argument and is retained.
The accepted localization lemmas then provide all hypotheses of the
full-layer statement.

Complementation about the diagonal antipode gives the claimed outer
radius. The written radii are one unit loose before parity normalization;
this is safe and agrees with the existing equality-reset convention.
When the guaranteed inner layers are empty, clipping the outer radius at
the board diameter is correctly vacuous.

## Merger

If both original component surpluses are positive, each is smaller than r
and therefore subcritical. A small component would have target size at
most r(r-1), below the merged target; hence both components must be high.
For pronic target corner count two, the two hole capacities sum to at most
(r-1)(r-2). For the square corner pattern, their sum is bounded by
`s_1^2+C_2(s_2)<=(r-1)^2`. These contradict the respective strict bin
endpoints. The original-zero-surplus component is consequently full to
full, so the other component has the identical target, features, defect,
and anchor certificate. This is stronger than merely identifying a
corner-closed full partner, and the proof correctly uses the original
surplus throughout.

## Independent computational attack

`physical-bin-stability-check.py` examines raw coordinate sets directly,
without importing the candidate proof's formulas except the stated
triangular-defect radius. It checks every near-capacity deletion pattern
for radii2..4, and all defects through four plus additional sampled larger
defects for radii5..6. Among127,178 candidate raw sets,219 satisfy the
required surplus. All satisfy the forced-full-layer conclusion. Their438
complemented transitions on even squares and adjacent nonsquares satisfy
the exact physical neighborhood relation, feature triggers, and resulting
outer radius. The source-hashed receipt is
`physical-bin-stability-check.json`.

## Interval implementation

The revised Section5 correctly establishes that there is still only one
exceptional target per fixed survivor size and feature tuple. Consecutive
H-bins have one omitted integer; crossing them changes q by two and r by
minus one, so the exceptional target q+r increases strictly. New events
are disjoint from old low events, and coincide with the old high event
only at the same defect-zero endpoint. Ordinary-tail repair therefore
retains its accepted injectivity justification.

The two admissible feature tuples, q offsets, maximum defects, triangular
cuts, and radius labels in `bin_records` match the theorem. The ordinary
survivor cap is unchanged. Independent `physical-bin-relation-check.py`
uses direct predicates in original surplus T-q and target holes h-T,
rather than the implementation's inverse H-bins. Across all four existing
critical/wide flag settings it matches21,600 labelled interval unions and
2,051,476 admitted fixed-q/target points. This audits the new relation;
the queue, capacities, and full-game interpretation are inherited from
the previously accepted evaluator and merger theorem.

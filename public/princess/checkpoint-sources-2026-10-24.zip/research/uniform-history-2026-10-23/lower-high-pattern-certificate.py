"""Symbolic normalized-pattern closure for the isolated high-only operator.

The certificate is uniform in the square-root bin index. It does NOT prove
the game's time comparison, nor replace the finite-board entry/exit guards.
"""
from pathlib import Path
import importlib.util,json,math,time
HERE=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('high_patterns',HERE/'lower-high-patterns.py')
m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
R0=32


def lin_nonnegative(slope,intercept,strict=False):
    assert slope>=0 and slope*R0+intercept>=int(strict),(slope,intercept,strict)


def quadratic_positive(a,b,c):
    assert a>=0 and 2*a*R0+b>=0 and a*R0*R0+b*R0+c>0,(a,b,c)


def root_offset(kind,shift,lo,hi):
    """Prove root(r²+u+shift)=r+c on every r>=R0, lo<=u<=hi."""
    z=R0*R0+lo[0]*R0+lo[1]+shift
    val=m.root(z) if kind=='square' else m.pronic(z)
    c=val-R0
    if kind=='square':
        lin_nonnegative(lo[0]-2*(c-1),lo[1]+shift-(c-1)**2,True)
        lin_nonnegative(2*c-hi[0],c*c-hi[1]-shift)
    else:
        lin_nonnegative(lo[0]-(2*c-3),lo[1]+shift-(c-1)*(c-2),True)
        lin_nonnegative(2*c-1-hi[0],c*(c-1)-hi[1]-shift)
    return c


def positive(shift,slope,constant,lo,hi):
    """Whether u+shift > slope*r+constant; prove same truth throughout cell."""
    value=lo[0]*R0+lo[1]+shift-slope*R0-constant
    if value>0:
        lin_nonnegative(lo[0]-slope,lo[1]+shift-constant,True)
        return True
    lin_nonnegative(slope-hi[0],constant-hi[1]-shift)
    return False


def symbolic_cost(alpha,i,e,j,v,lo,hi):
    A=2-j;B=2-v;delta=v-i
    if B:
        z=A+2*B-2
        c=z+root_offset('pronic',alpha-z,lo,hi)
    elif A:
        c=A-1+root_offset('square',alpha-A+1,lo,hi)
    else:
        q=root_offset('square',alpha+1,lo,hi)
        # pronic(2(d+alpha)) >= 1+root(d+alpha+1).
        quadratic_positive(1,2*lo[0]-2*q+1,2*lo[1]+2*alpha-q*(q-1))
        c=1+q
    c+=delta
    if (j,v)==(1,2) and e!=1:
        c=max(c,delta+root_offset('square',alpha,lo,hi)+1)
    if j==2:
        r=root_offset('pronic',alpha,lo,hi)
        active=True if v==1 else positive(alpha,2*(r-1),r*(r-2),lo,hi)
        if active and (i,e,v)!=(1,2,1):c=max(c,r+1)
    return c


def arrangement():
    cuts={(0,0),(2,1)}
    for a in range(3):
        for b in range(-10,11):
            # Keep only lines strictly internal for all r>=R0.
            if a>=0 and a*R0+b>0 and 2-a>=0 and (2-a)*R0+1-b>0:
                cuts.add((a,b))
    cuts=sorted(cuts,key=lambda p:(p[0]*R0+p[1],p[0],p[1]))
    for x,y in zip(cuts,cuts[1:]):lin_nonnegative(y[0]-x[0],y[1]-x[1],True)
    return [(x,(y[0],y[1]-1))for x,y in zip(cuts,cuts[1:])]


def certify():
    # Candidate set discovery is finite; every claimed closure transition
    # below is then checked independently over all root indices.
    patterns,_,_=m.discover(2000);known=set(patterns);small_checks=0;rows=[]
    for p in patterns:
        for d in range(4,R0*R0):
            assert m.normalized(m.image(d,p)) in known,(p,d)
            small_checks+=1
        for lo,hi in arrangement():
            constants=[]
            for c,e in m.FEATURES:
                constants.append(min(p[3*j+v]+symbolic_cost(p[3*j+v],min(c,v),min(e,j),j,v,lo,hi)
                                     for j,v in m.FEATURES))
            gamma=min(constants);following=tuple(z-gamma for z in constants)
            assert following in known,(p,lo,hi,following)
            # Independent arithmetic calibration against the unsimplified
            # root formulas, outside the asymptotic base index.
            for r in (R0,R0+17,1003):
                for u in {lo[0]*r+lo[1],hi[0]*r+hi[1]}:
                    d=r*r+u;wanted=tuple(d+r+z for z in constants)
                    assert m.image(d,p)==wanted,(r,u,p)
            rows.append(dict(pattern=p,u_lower=lo,u_upper=hi,gamma=gamma,next_pattern=following))
    return dict(passed=True,scope='isolated high-only operator; no capture-time theorem',
                root_index_from=R0,patterns=patterns,small_deficit_checks=small_checks,
                symbolic_cells=len(rows),transition_table=rows)


if __name__=='__main__':
    start=time.process_time();out=certify();out['CPU_seconds']=time.process_time()-start
    Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
    print({k:v for k,v in out.items()if k!='transition_table'})

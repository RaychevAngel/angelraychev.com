"""Exact small-budget base for the three-day physical early passage."""
from math import isqrt
from pathlib import Path
import hashlib
import json


def root(x):
    r = isqrt(x)
    return r + (r * r < x)


def rho(x):
    r = (isqrt(4 * x + 1) - 1) // 2
    return r + (r * (r + 1) < x)


def hits(k, top, phase=None):
    ans = [0] * (top + 1)
    x = t = 0
    while x < top:
        y = x + k
        y -= rho(y) if phase is None or (phase + t) % 2 == 0 else root(y)
        assert y > x
        t += 1
        for z in range(x + 1, min(y, top) + 1):
            ans[z] = t
        x = y
    return ans


def main():
    rows = []
    checks = 0
    for k in range(33, 75):
        R = 4 * k // 5
        L = R * R
        Z = L + k - rho(L + k)
        top = max(Z, L + 1)
        scalar = hits(k, top)
        phases = [hits(k, top, p) for p in (0, 1)]
        entry = max(a[Z] for a in phases) - scalar[L + 1]
        fast = max(a[z] - scalar[z] for a in phases for z in range(1, L + 1))
        assert entry <= 3 and fast <= 2
        checks += 2 * L + 2
        rows.append(dict(k=k, R=R, true_entry_envelope=Z,
                         scalar_crossing=scalar[L + 1],
                         phase_entry_hits=[a[Z] for a in phases],
                         entry_allowance=entry, fast_allowance=fast))
    files = [Path(__file__), Path(__file__).with_name('lower-three-day-early.md')]
    out = dict(status='PASS', budget_count=42, width_or_length_samples=0,
               target_phase_checks=checks,
               maximum_entry_allowance=max(r['entry_allowance'] for r in rows),
               maximum_fast_allowance=max(r['fast_allowance'] for r in rows),
               source_sha256={p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in files},
               rows=rows)
    Path(__file__).with_suffix('.json').write_text(json.dumps(out, indent=2) + '\n')
    print({k: v for k, v in out.items() if k != 'rows'})


if __name__ == '__main__':
    main()

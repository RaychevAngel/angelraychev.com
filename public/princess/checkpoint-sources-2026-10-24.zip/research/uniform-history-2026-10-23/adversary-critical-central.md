# The central critical passage costs at most two extra days

24 October 2026 UTC. Proposed exact comparison for independent review.
This replaces repeated root-cell resets only in the central interval.
It uses the unshifted ordinary-three-corner relaxation justified in
`adversary-critical-unshifted.md`.

Write b=floor(w/2), k=b+d with d>=1, and h=wn/2. Assume b>=8,
w<=n and wn even. A physical pair has labeled update

    H(X,Y)=(G(Y),F(X)),

where G has the pronic low branch and F has the square low branch.
For odd width the finite-board maps always satisfy

    G(u)>=min(h,u+d),    F(u)>=min(h,u+d-1).

Their common clipping at h is understood in every formula below.

## Odd width

Let b^2<=z<M<=h-b(b-1). Start the necessary frontier at any B_j<=z
and the physical pair with both coordinates at least z. Then the physical
minimum reaches M no later than two days after the necessary maximum.
The comparison also dominates the faster model's actual exit maximum.

For the proof speed the model up by starting all three coordinates at z,
discarding its source-corner caps h-2+c, and using the unshifted branch
relaxation. Stop at its first maximum >=M. Before the last update all
targets q satisfy q<M and hence h-q>b(b-1). Once all coordinates exceed
b^2, write

    L=b(b+1),    E=h-b^2,    x=B2=max B,    y=B0.

The exact relaxed updates in this region are

    B0' = x+d-1,
    B1' = max(x+d-1, B0+d if B0<=L),
    B2' = max(x+d-1, B0+d, B1+d if B1>=E).             (1)

Indeed, every cost is b+1 except the permanent (source,target)=(2,0)
edge of cost b, the low edges (1,0),(2,0) when rho(q)=b, and the high
edge (2,1) when R(h-q)=b. Higher roots are inactive after the cap.
For odd width, n>=2b+2, and therefore

    E-L=h-2b^2-b >= 2b+1.                            (2)

The normalized invariant is

    B2=x, B0=y, x-y in {0,1}, B1 in {y,x}.             (3)

It follows directly from (1). Ignoring the last high edge, the labeled
pair update is exactly

    (x,y) -> (y+d, x+d-1),                            (4)

because y+d>=x+d-1. This is the constant-cost physical update, and the
actual finite-board physical maps dominate it everywhere.

The high edge can improve (4) only if B1=x=y+1 and B1>=E. Such an
improvement occurs at most once. In fact B1 can differ from B0 only on
an output of a preceding step whose B0<=L; once the input B0>L, (1)
sets B1'=B0' forever because B0 is nondecreasing. At an improving high
edge, (2) gives B0=B1-1>=E-1>L, so the very same update destroys that
difference permanently. This argument permits a large step that skips
the whole gap between L and E.

At that one exceptional step the model outputs (v+1,v), whereas (4)
outputs (v,v). One additional physical step repairs the discrepancy:

    H(v,v)>=(v+d,v+d-1)>=(v+1,v).

Thus the physical labeled pair dominates (B2,B0) after at most one
extra day, with phase labels preserved. One further day makes both
physical coordinates at least the preceding B2: G(B0)>=B0+1>=B2 and
F(B2)>=B2. This proves the claimed two-day comparison, including the
model's exit overshoot. If any value clips at h, monotonicity preserves
the same inequalities.

There is one entry endpoint. If z=b^2, the exact unshifted relaxed
update from equal seeds is the equal vector min(h,b^2+d), because both
low physical costs are b there and no high or width branch is cheaper.
The actual physical pair has exactly this update as well. If this
already reaches M the passage is complete; otherwise all coordinates
are now strictly greater than b^2, as required above. For z>b^2 no
endpoint adjustment is needed. In particular this does not charge an
extra day at entry.

## Even width

Let b^2<=z<M<=h-(b-1)^2. The same setup has zero extra passage cost.
For every pre-exit target q>=b^2 and h-q>(b-1)^2, the two physical
costs are both b. Every ordinary relaxed cost is at least b, while
the width-cap edge (1,1) of cost b is present. Equal frontiers therefore
stay equal and advance by d, exactly as both physical phases do.
Discarding source-corner caps only speeds the necessary model up and
does not disturb domination of the original model. The final common
update may overshoot the central interval; its inputs remain inside,
so the comparison includes that exit overshoot.

## Scope

This is a central passage lemma, not yet a complete low/high join.
The next high module should start when the deficit is at most b(b-1)
for odd width, or (b-1)^2 for even width. Its phase convention and any
frontier reset must be accounted for separately. No width sampling is
used in the proof.

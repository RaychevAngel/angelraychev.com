# One day suffices for the odd central passage

24 October 2026 UTC. Refinement of `adversary-critical-central.md`.
All hypotheses, notation, and exact recurrences are inherited from that
note. Its two-day bound remains a fallback independent of this refinement.

The odd-width passage actually costs at most one extra physical day,
including domination by the physical minimum of the faster model's actual
exit maximum.

If no exceptional late-edge improvement occurs, model and constant-cost
physical pairs follow exactly the same map. One final physical day makes
both coordinates dominate the model maximum, as already proved.

Suppose an exceptional improvement does occur. Then d>=2. To prove this,
consider the immediately preceding step, which created B1>B0. Its input
satisfies B0<=L, and the span-one invariant gives B2<=L+1. If d=1,
formula (1) of the central note gives the new B1<=L+1. The next step
cannot use its late edge because E>=L+2b+1>L+1. More generally an earlier
B1>B0 cannot survive a step with input B0>L, so this immediate-predecessor
argument covers every possibility. Equal initialization cannot itself
supply B1>B0.

At the exceptional step the model outputs (v+1,v), while the constant
physical map outputs (v,v). The repair day then supplies

    (v+d,v+d-1) = (v+1,v)+(d-1,d-1).

Thus it supplies at least one room of surplus in *both labeled
coordinates*. No further exceptional improvement can occur. Every later
model update is the same constant affine physical map, so this uniform
surplus is preserved (until clipping at h, which only completes the
comparison). In particular, at the final step the physical minimum is
at least the model minimum plus one, hence at least its maximum because
the model span is at most one.

Therefore the single repair day also pays the final phase alignment;
it must not be counted a second time. The finite-board physical maps
dominate the constant maps globally, so their larger values preserve
all the same inequalities. The entry endpoint z=b^2 is still handled
by the common exact first update from the central note.

Even width retains the zero-day central comparison already proved.

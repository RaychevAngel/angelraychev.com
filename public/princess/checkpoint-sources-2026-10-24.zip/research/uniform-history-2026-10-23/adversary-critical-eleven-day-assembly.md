# An eleven-day critical passage, uniformly in width and length

24 October 2026 UTC. Complete component assembly for final independent
review. This note does not assert the final full-game additive constant.

## Statement and guards

Let w<=n, wn even, b=floor(w/2)>=32 and b+1<=k<3b. Put h=wn/2,
H=(b-5)^2. For every

    H<=z<M<=h-H,

let tau be the first layer at which the ordinary three-corner necessary
backward frontier, initialized at (z,z,z), has maximum at least M.
Then the finite-board physical prefix pair initialized at (z,z) has
MINIMUM at least M within tau+11 days. The same holds if the incoming
physical pair is coordinatewise larger. Thus either starting physical
phase is available, not merely the better one.

The guards give H>k. Every pre-exit model target is below M<=h-H,
and any one-step increase is at most k. Therefore every module's actual
exit maximum stays strictly below h. Equivalently, its positive deficit
stays above H-k>0. No clipping-at-zero or zero-deficit root convention is
used in this proof. The stronger source-corner caps may be discarded:
this only speeds the necessary model up.

We use the monotone unshifted three-corner relaxation proved in
`adversary-critical-unshifted.md`. At a module exit, replace all three
necessary capacities by their maximum. This also speeds the necessary
model up. Inductively the sum of elapsed model steps in the three
modules is at most tau. Each physical module below dominates this
actual exit maximum in BOTH coordinates, so the reset is paid for and
no free change of physical phase is being assumed.

## Low module: five days, including its equalized exit

If z<b^2, run the low relaxation until its maximum reaches min(M,b^2).
If M is reached, stop. Otherwise let z1 be its actual exit maximum and
reset the necessary frontier to (z1,z1,z1).

The exact low reduction, with x=B2=B1 and y=B0, is

    (x,y) -> (max(G(y),F(x)),F(x)),
    F(u)=u+k-ceil(sqrt(u)), G(u)=u+k-rho(u), x-y in{0,1}.

Its physical counterpart is (G(y),F(x)). There is at most one tie-closure
event in each of the five upper-half root bins b-4,...,b. One genuine
extra physical day repairs each event, preserving coordinate labels.
These assertions and their finite-board minimum-budget checks are in
`adversary-critical-one-sided.md` and `lower-local-critical-repairs.md`.

The same five-day allowance makes the physical MINIMUM dominate the
model's actual exit MAXIMUM. If fewer than five events occurred, pay one
final alignment day using an unused allowance. If all five occurred,
the last was in root b and tied the model. Thereafter the model remains
tied in that upper-half affine interval through exit, so coordinatewise
domination already gives minimum domination. This includes an exit
overshoot and also covers an earlier target M. If the low module is
skipped because the initial z>=b^2, its allowance is zero.

## Central module: at most one day

For odd width put Q=h-b(b-1); for even width put Q=h-(b-1)^2.
If the current equal seed is below min(M,Q), run the central relaxation
until its maximum reaches that threshold. Then reset to its actual exit
maximum if the final target has not yet been reached.

The exact proofs are `adversary-critical-central.md` and
`adversary-critical-central-refinement.md`. Odd width costs at most ONE
extra physical day; even width costs ZERO. These statements already
dominate the actual exit maximum in both physical coordinates.

In odd width, the only possible advantage over the physical alternating
cap map comes from one late high edge retaining an earlier leading
middle coordinate. The early and late edge ranges are separated by at
least2b+1 rooms. At most one such advantage can occur. Its repair day
supplies a uniform one-room surplus, which also pays the terminal phase
alignment. Without the advantage, one final alignment day suffices.
Even width has constant cost b in both physical phases throughout this
central interval and requires no additional day.

The endpoint b^2 is handled by the common exact first physical/model
update, not by a hidden extra step. Large updates may skip a module or
the entire remaining passage; the actual-exit domination handles this
without any new assumption.

## High reduction, caps, and phase labels

At high entry the necessary frontier has been reset equal, and BOTH
physical deficits are at most that equal deficit. Write D_c=h-B_c,
x=D2, y=D1. The relevant entry ranges are

    odd width:  x=y<=b(b-1),
    even width: x=y<=(b-1)^2.

Define A(u)=u+ceil(sqrt(u)) and B(u)=u+1+rho(u). The exact ordered
high relaxation is

    x'=min(A(y),B(x))-k,       y'=B(x)-k,             (1)

and preserves x<=y<=x+1. After its first step D0=y+1. From an equal
entry the same pair formula already holds; no startup day is needed.

Here is the cap check. In odd width x<=b(b-1), y<=x+1 imply
rho(x)+1<=b and ceil(sqrt(y))+1<=b+1. Thus the relevant high branches
are no larger than their width caps. The special source2,target0 cap b
cannot improve on column2: D0>=x and D0+b>=B(x). Low branches are
inactive since h>=2b^2+3b+1 and every involved deficit is at most x+2.
For example q>=h-x-2>=b^2+4b-1, so its low roots are already above
the relevant high costs.

In even width, after entry y<=(b-1)^2 makes ceil(sqrt(y))+1<=b and
rho(x)+1<=b. Both the ordinary (1,1) cap b and the possible n=w+1
(2,0) cap b are therefore harmless, the latter by the same column2
domination. Low branches are inactive because the involved targets
are at least b^2+2b-2. At the possible equal endpoint
x=y=D=(b-1)^2, (1) gives

    x'=D-(k-b)-1,       y'=D-(k-b),

so the same formula is valid on the first step and immediately enters
the strictly smaller range. The problematic unequal pair
x=D,y=D+1 is never used at entry or reached later.

For completeness, the high cost rows give the pair formula directly.
The target0 contribution is dominated by target2 because D0>=x.
Row2 consequently takes min(A(y),B(x)); row1 takes
min(A(y)+1,B(x))=B(x), using B(x)<=A(y)+1. Row0 takes B(x)+1,
which proves D0'=y'+1 and closes the invariant.

The physical deficit map in the matching ordered labels is

    (x,y) -> (A(y)-k,B(x)-k).                       (2)

For odd width, and for even width with odd n, these are the same order
as the low physical pair (pronic-output coordinate first). For even
width with even n the two coordinate names are interchanged at high
entry. This is legitimate relabeling of the two existing physical
starting phases: entry bounds BOTH deficits by the same number. The
two labels then remain fixed through the entire high simulation.
No intermediate free phase exchange is made.

## High module: at most five days, including its equalized exit

Run (1) until x<=h-M, where h-M>=H. A clamp differs from (2) only
when y=x+1 in a lower-half root bin. Its output ties, and one additional
genuine physical day repairs the discrepancy in both fixed coordinates.
This is `lower-local-critical-repairs.md`.

There is at most one clamp per decreasing lower-half root bin. Odd
width permits only r=b-4,...,b, hence at most five events. Even width
permits only r=b-4,...,b-1, hence at most four. At the possible even
entry endpoint x=y=(b-1)^2 there is no clamp, and the first step strictly
decreases; it does not add a root bin.

The final phase alignment is paid within the same allowance. If fewer
than five (respectively four) events occur, use the unused allowance for
one final physical day. If all occur, the last is in root b-4; its
output ties and stays tied down to the terminal threshold or its
overshoot, because A=B on the remaining interior of that lower-half
bin. Thus BOTH physical deficits are at most the model's actual minimum
exit deficit. The assertion holds also if the terminal threshold is
larger than H: either fewer events occur, or the same tie argument applies.

## Sum and limitations

The total extra physical cost is at most

    odd width: 5+1+5=11;
    even width: 5+0+4=9.

Skipping any module only decreases this cost. Since resets and branch
relaxations speed the necessary model up, its total elapsed time is
at most tau. The resulting physical minimum reaches M in at most
tau+11 days, uniformly over all stated widths, lengths and budgets.

This is an ordinary mathematical comparison of a necessary evaluator
and actual prefix strategies. It is not a complete Lean formalization,
not a proof of exact prefix optimality, and not by itself the final
capture-time gap theorem. Its role is the critical component of the
parent's three-passage join.

# Inverting a safe two-phase relaxation of the high patterns

24 October 2026 UTC. Algebraic exploration after the accepted nine-pattern
high reduction. No uniform clock-gap theorem is claimed.

Away from terminal floors, the accepted high-pattern table uses exactly
the following two scalar maps:

    A(d)=d+ceil(sqrt(d))-k,
    B(d)=d+1+rho(d)-k,

where rho(d) is the least integer r with r(r+1)>=d. Patterns0 through4
use A; patterns5 through8 use B, in the order of
`lower-high-pattern-certificate.json`. B always transitions to an A
pattern. Whenever A transitions to another A pattern, A(d)=B(d).
Allowing A->A at every such equality, rather than only at the allowed
pattern transitions, therefore gives a safe relaxation.

Let a_t,b_t denote the largest initial deficits captured in t updates
when starting in phase A,B respectively. Terminal deficit0 is allowed.
Write

    f(N)=N-ceil(sqrt(N)),
    g(N)=N-rho(N).

The exact inverse identities for positive arguments are

    max{d: d+ceil(sqrt(d))<=N}=g(N),
    max{d: d+1+rho(d)<=N}=f(N).

Thus the relaxed inverse recurrence is

    b'=f(a+k),
    a'=max(g(b+k),E(a)),

where E(a) is the largest positive d for which

    d+ceil(sqrt(d))<=a+k,  ceil(sqrt(d))=1+rho(d),

and includes0 when no positive value qualifies. If x=g(a+k)>0 and
R=ceil(sqrt(x)), then

    E(a)=min(x,R(R-1)).                              (1)

Indeed equality of the two high profiles holds exactly on the integer
intervals ((R-1)^2,R(R-1)], and the preceding such interval ends at
(R-1)(R-2). Formula(1) uses the highest interval containing or preceding x.
At a perfect square x=R^2 it returns R(R-1), not x.

From a=b=0, the recurrence remains in a>=b and a-b<=1. To see this,
write F(x)=f(x+k), G(x)=g(x+k). They are nondecreasing,1-Lipschitz and
G(x-1)<=F(x)<=G(x). If a=b, the update is (G(a),F(a)). If a=b+1, then
G(b)<=F(a)<=G(b)+1. When the inequality is strict, d=F(a)=G(a)
satisfies A(d)=B(d); otherwise a plateau of g at the pronic endpoint
would give G(b)=G(a). Hence E(a)=F(a) in exactly the case where it is
needed to raise the first coordinate. Both coordinates then become F(a).
The exact controlled recurrence therefore reduces to

    M(a,b)=(max(G(b),F(a)),F(a)).                     (2)

This is a one-sided equalizing closure, NOT sorting: if the raw second
coordinate is larger, both new coordinates equal that larger value.
Conjugating by z=x+k turns F,G into the ordinary low square/pronic maps
z+k-ceil(sqrt(z)) and z+k-rho(z), now starting from the equal seed(k,k).

## Diagnostic that rules out an overly strong shortcut

A targeted root-map calculation at k=2001 gives, at step14514,

    M_t=(3924383,3924382),
    H^(t+1)(k,k)=(3924381,3924382),

where H(p,q)=(G(q),F(p)) in the conjugated coordinates. Thus even
maximum-coordinate one-day domination fails for this high relaxation.
This is below the target(k-2)^2 and does not involve a width cutoff.
It is not a counterexample to the actual nine-pattern high recurrence,
which allows fewer phase resets.

A second targeted calculation at k=10001 again fails one-day domination
but satisfies two-day domination through152956 steps, ending at
(k-2)^2. Its maximum room discrepancy is623, although the final discrepancy
is4. These observations support a clock-based or root-flat repayment
argument; they refute small room-error bounds such as one or two rooms
for this relaxation. A finite witness does not exclude every possible
universal room-error constant. They do not prove a bounded clock error.
No wider parameter sweep was run.

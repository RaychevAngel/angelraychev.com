# The early passage also dominates its actual crossing overshoot

24 October 2026 UTC. Strengthening for the uniform joining argument.
Use the geometry and conventions of `lower-three-day-early.md`.
In addition impose the global low-budget guards used by the parent:
b>=32 and b+1<=k<3b. Put H=(b-5)^2.

If the actual two-cohort total hole count first reaches H at time tau,
then some zero-seed physical forward-hole prefix trajectory has at least
Q_tau holes by reference time tau+3. This is stronger than merely
reaching H. Its complementary residual is therefore at most the actual
merged residual at that crossing, with the same three-day allowance.

The crossing satisfies Q_tau<=H+k<b(b-1), so the ordinary scalar
surplus inequality holds at every actual state through time tau. The
scalar G_k orbit therefore reaches Q_tau no later than tau. Moreover

    Q_tau<=G_k(H-1).

Choose R as in the three-day theorem and put L=R^2, u=k-R-1.

If H>L, the existing slow-history proof already maintains pointwise
reference domination all the way through its final target Q_tau. It
never discards the overshoot. Thus its existing conclusion supplies the
claimed reference prefix directly.

Suppose H<=L and k>=75. The target obeys Q_tau<=G_k(L). Let t_G be the
scalar first hit of L+1. The two-stage argument proves t_G<=4u. One
further scalar step reaches G_k(L), so the scalar first hit t of Q_tau
is at most4u+1 (and at most tau). At that time either alternating
quadrant prefix has at least

    Q_tau-ceil(t/2)>=Q_tau-(2u+1).

Until reaching Q_tau<=G_k(L), each reference step gains at least u,
by the same input estimate used in the three-day theorem. Three steps
suffice because2u+1<=3u. Only the actual target prefix and its
neighborhood are needed physically; they lie below b(b-1). The larger
abstract cutoff R can exceed the board's quadrant range without being
used as a physical prefix.

For33<=k<75, the accepted parameter certificate covers every target
at most L with loss at most two. For L<Q_tau<=G_k(L), its exact entry
check shows both physical phases reach G_k(L) within three days of
the scalar first hit of L+1, which is no later than the scalar first
hit of Q_tau. Thus the same three-day conclusion holds.

No additional computation or new geometric label is needed. The new
joining argument may use the actual crossing residual as its middle
target instead of adding a physical day to catch a fixed overshoot
envelope. Its resulting full-game constant remains a separate theorem.

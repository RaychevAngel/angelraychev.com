# Exact credit from a surplus penalty

24 October 2026 UTC. New local comparison lemma, not yet an all-width
capture-time theorem. The result is about physical cardinality transitions
and a specified prefix comparator; no realizability of abstract states is
assumed.

Let x be the number of holes of one parity cohort before a day's inspection,
and let x' be the number afterwards. Put

    sigma = |N(H')| - |H'|.

Since N(H') is contained in H union the day's inspected rooms, a budget k
implies

    x' + sigma <= x + k.                              (1)

This remains true when x'<x. Fix a physical prefix family of the target
color, whose neighborhood size at cardinality y is y+eta(y). Given current
prefix capacity X, its next capacity is

    X' = max {y : y+eta(y) <= X+k}.                    (2)

The chosen prefix family must be closed under this update; this is the
existing anchored-prefix construction, not a claim about arbitrary sets.

## Local credit lemma

Suppose D=X-x>=0, and let m,C,d0 be integers with C>=d0. Assume

    sigma >= m+C,
    eta(y) <= m+d0 for every x'<=y<=x'+k.              (3)

Also assume the candidate values in that interval are within the board's
cardinality domain. Then

    X'-x' >= min(k,D+C-d0).                           (4)

Proof: set a=min(k,D+C-d0), y=x'+a. By (3),

    y+eta(y) <= x'+a+m+d0
              <= x'+D+C+m
              <= x'+D+sigma
              <= x+k+D = X+k.

Thus y is admissible in (2). All variables are integers, so there is no
additional floor or inverse-rounding loss. This proves (4).

For a consecutive block in which the hypotheses hold with common C,d0,
induction gives

    X_t-x_t >= min(k,D_start+t(C-d0)).                 (5)

Retreats of the actual hole count do not invalidate this induction. What
does need verification at every step is the profile bound (3) on the
interval beginning at that step's target cardinality.

## A simple square-root window

For a genuine quadrant prefix, the two target-color neighborhood profiles
are

    eta0(y)=ceil(sqrt(y)),
    eta1(y)=1+rho(y),

where rho(y) is the least nonnegative integer r with r(r+1)>=y.
For y>0, rho(y)<=ceil(sqrt(y)), so both profiles are at most
ceil(sqrt(y))+1.

Write r=ceil(sqrt(x')), with x'>0. If k<=2r+1, then for 0<=a<=k,

    x'+a <= r^2+2r+1 = (r+1)^2.

Both quadrant profiles on [x',x'+k] are therefore at most r+2. If the
actual surplus is at least r+C with C>=2, (4) applies with m=r,d0=2:

    X'-x' >= min(k,D+C-2).                            (6)

In particular, C>2 gives a positive, explicitly quantified credit per bad
step. The square-root condition is r>=(k-1)/2; the stronger r>2k/3 window
also suffices. A finite rectangle application must either keep this whole
target interval inside the genuine-quadrant prefix range or establish the
same upper profile bound for its clipped prefix family. That interface is
not suppressed here.

## What remains before using this in a uniform gap proof

A k-room lead can dominate the next prefix capacity from the smaller
state, since each physical update gains at most k rooms. Nevertheless,
turning it into a paid phase change still requires an explicit comparison
of the phase at the two ends of the block. The lemma alone does not prove
that all anchor changes have enough intervening bad steps, nor that a
sequence of changes can be paid independently without reusing credit.

The necessary additional ingredients are an actual history label, a
lower bound on the number or total surplus penalty of the intervening
steps, and a terminal/entrance comparison that preserves the daily budget.
In particular it is not a repair of the already falsified pointwise
minimum of the two phase clocks.

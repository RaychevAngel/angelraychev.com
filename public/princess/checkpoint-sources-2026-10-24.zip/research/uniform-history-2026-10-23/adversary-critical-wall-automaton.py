"""Exploratory all-residue root-wall comparison, not a width scan/proof yet."""
from itertools import product
from pathlib import Path
import json


def normalize(v):
    a=v[0]
    return tuple(x-a for x in v)


def advance(state, F, G):
    x,y,p,q=state
    return max(G(y),F(x)),F(x),G(q),F(p)


def common_variants(state,v,upper):
    F=lambda x:x+v
    G=(lambda x:x+v) if upper else (lambda x:x+v+1)
    variants={state}
    s=normalize(advance(state,F,G));variants.add(s)
    assert normalize(advance(s,F,G)) in variants
    return variants


def wall(states,v,pronic):
    # q=0 is the first point on the new side of a root flat.
    if pronic:
        F=lambda x:x+v
        G=lambda x:x+v+(x<0)
        old_upper=False
    else:
        F=lambda x:x+v-(x>=0)
        G=lambda x:x+v
        old_upper=True
    out=set(); max_exit=0; max_steps=0; count=0
    for state in states:
        for s in common_variants(state,v,old_upper):
            for entry in range(-v-1,0):
                q=tuple(x+entry for x in s)
                if advance(q,F,G)[0]<0:continue
                steps=0
                while min(q)<0:
                    q=advance(q,F,G);steps+=1
                    assert steps<100
                # One common-region update clears a pending upper-half clamp.
                q=advance(q,F,G);steps+=1
                assert q[0]>=q[1] and q[0]-q[1]<=1
                assert q[0]>=q[2] and q[1]>=q[3]
                out.add(normalize(q));count+=1
                max_exit=max(max_exit,q[0]);max_steps=max(max_steps,steps)
    return out,dict(states=len(out),branches=count,max_exit=max_exit,max_steps=max_steps)


def finish(states,d):
    # Model hits target q=0 (the square endpoint b^2). The square flat is
    # one room later. Actual finite-board maps dominate these local maps.
    F=lambda x:x+d-(x>0)
    G=lambda x:x+d
    failures=[];maxdelay=0;branches=0
    for state in states:
        for s in common_variants(state,d,True):
            for entry in range(-d,1):
                q=tuple(x+entry for x in s)
                if q[0]<0:
                    q=advance(q,F,G)
                    if q[0]<0:continue
                target=q[0];p,r=q[2:];delay=0
                while min(p,r)<target:
                    p,r=G(r),F(p);delay+=1
                    assert delay<100
                branches+=1;maxdelay=max(maxdelay,delay)
                if delay>2:failures.append(dict(state=state,entry=entry,at_hit=q,delay=delay))
    return dict(branches=branches,maxdelay=maxdelay,failures=failures[:10])


def run(C=5):
    rows=[]
    for d in range(1,C):
        states={(0,0,0,0)};trace=[]
        for j in range(C-1,-1,-1):
            v=d+j
            states,meta=wall(states,v,True);trace.append(dict(j=j,kind='pronic',**meta))
            if j:
                states,meta=wall(states,v,False);trace.append(dict(j=j,kind='square',**meta))
        rows.append(dict(d=d,trace=trace,final_states=sorted(states),finish=finish(states,d)))
    return dict(status='EXPLORATORY_OVERAPPROXIMATION',root_bands=C,width_samples=0,rows=rows)


if __name__=='__main__':
    result=run()
    Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({**result,'rows':[dict(d=r['d'],states=len(r['final_states']),finish=r['finish'],max_wall_exit=max(x['max_exit']for x in r['trace']))for r in result['rows']]}))

"""Independent coordinate counts for the exact physical hole-anchor switch charge."""
from pathlib import Path
import json,time,hashlib
P=Path(__file__).resolve().parent;start=time.process_time();checks=neighborhoods=0
for w in range(4,25):
 for n in range(w,w+4):
  if w*n%2:continue
  corners=[(w-1,0),(0,n-1),(w-1,n-1)]
  for p in(0,1):
   cells={(x,y)for x in range(w)for y in range(n)if(x+y)%2==p}
   for C in corners:
    d=(p-sum(C))%2
    for Q in range(1,w):
     ball={z for z in cells if abs(z[0]-C[0])+abs(z[1]-C[1])<=Q}
     core={(x,y)for x in range(w)for y in range(n)if(x+y)%2!=p and abs(x-C[0])+abs(y-C[1])<=Q-1}
     if not core:continue
     N={(a,b)for x,y in core for a,b in((x-1,y),(x+1,y),(x,y-1),(x,y+1)) if 0<=a<w and 0<=b<n}
     assert N==ball
     neighborhoods+=1;m=(Q-d)//2
     assert len(ball)==(m+1)*(m+d+1)
     for R in range(w-1):
      old={z for z in cells if sum(z)<=R};overlap=len(old&ball)
      if C==(w-1,n-1):assert overlap==0
      else:
       delta=sum(C)-R;Qe=Q-(Q-d)%2;de=delta+(delta-d)%2
       ell=max(0,(Qe-de)//2+1)
       assert overlap==ell*(ell+1)//2,(w,n,p,C,Q,R,overlap,ell)
      assert overlap<=len(ball)//2
      checks+=1
sources=[Path(__file__),P/'root-anchor-switch.md']
out=dict(status='PASS',exact_intersection_checks=checks,full_core_neighborhood_checks=neighborhoods,CPU_seconds=time.process_time()-start,source_sha256={z.name:hashlib.sha256(z.read_bytes()).hexdigest()for z in sources})
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print(out)

# A two-day high critical comparison for every terminal threshold

24 October 2026 UTC. Submitted for independent mathematical and
certificate review. Uses the accepted high ordered reduction and cap
checks in `adversary-critical-eleven-day-assembly.md`.

Assume b>=32, k=b+d<3b, d>=1, H=(b-5)^2. Start the high necessary
model at equal deficit x=y=s, where s<=b(b-1) at odd width or
s<=(b-1)^2 at even width. Start the physical pair at deficits at most
(s,s), using the fixed high phase labels of the assembly note. For any
terminal threshold Z>=H below s, the physical MAXIMUM deficit is at
most Z within two days of the model MINIMUM first reaching Z.
In fact it is at most the model's actual exit minimum, including its
overshoot. This holds for arbitrary Z, not only Z=H.

The model and physical maps are

    M(x,y)=(min(A(y),B(x))-k, B(x)-k), x<=y<=x+1,
    H_phys(p,q)=(A(q)-k,B(p)-k),
    A(u)=u+ceil(sqrt(u)), B(u)=u+1+rho(u).

There are at most five clamps. The model is restarted equal only at
entry; physical labels stay fixed thereafter.

## Budgets d>=3: spend two physical days at entry

Both physical coordinates decrease by at least d on every high update:
the deficit inputs remain <=s, where both root costs are <=b. Two
genuine physical days before beginning the model simulation therefore
give a uniform deficit advantage of at least 2d>=6 rooms.

The scalar maps A and B are expansive in the needed order: for u<=v,

    A(v)-A(u)>=v-u,    B(v)-B(u)>=v-u.

Thus a uniform physical advantage of t rooms is preserved by every
ordinary model step. A clamp subtracts at most one from the model's
first coordinate and consumes at most one room of this advantage.
After all five possible clamps, at least one room remains. Since the
model coordinates differ by at most one, the physical maximum is then
at most the model minimum, at every model time. This proves the
two-day comparison for every stopping threshold simultaneously.

Clipping a physical deficit at zero only strengthens the capture claim.
Equivalently one may use the clipped advantage bound
P_i<=max(0,D_i-t); monotonicity and expansiveness preserve it. In the
present application the target H and k<3b are far above the zero
boundary, so no zero convention is needed for the model.

## Budgets d=1,2: finite local root-wall certificate

The source is `adversary-critical-high-wall-automaton.py`, with receipt
of the same name and suffix `.json`. It enumerates phase/error patterns
and every possible entry residue at each of the five root bins. It
does not enumerate widths or lengths. Its additional d=3,4 rows are
redundant consistency checks; the preceding proof covers those budgets.

In root r let v=k-r. On the lower half both deficit maps subtract v;
on the upper half the A-map subtracts v and the B-map subtracts v-1.
At a descending square wall, use offset q=deficit-(r-1)^2:

    A_local(q)=q-v-1_{q<=0},   B_local(q)=q-v.

At a descending pronic wall in root r, use q=deficit-r(r-1):

    A_local(q)=q-v,           B_local(q)=q-v+1_{q>0}.

These are exact local maps on both sides of the indicated wall. Apply
them to both the ordered model and its simultaneous physical pair.
Normalize the four entries by subtracting the model minimum. The model
pair is then (0,0) or (0,1); the physical entries record its actual
nonnegative deficits relative to the model. No phase is discarded.

Between root walls, two common-region steps translate every coordinate
by the same amount. Thus there are only two normalized waiting-phase
variants. The source asserts this exact two-cycle for every state used.
Immediately before the first crossing of a wall by the model minimum,
its positive offset lies among 1,...,v+1. The source includes all of
these offsets and discards only those for which the next minimum does
not cross. The physical coordinates have not crossed first: the
ordered model is coordinatewise at most the physical pair.

The source follows every such branch until ALL FOUR entries have
crossed the wall, and then takes one more common-region step. This
last step removes any transient lower-half clamp, so subsequent
waiting again has exactly two normalized variants. Every generated
intermediate state is tested, as are both common waiting variants:
freeze the current model MINIMUM and check that at most two genuine
physical updates make BOTH physical coordinates at most that minimum.
These are the `delay` checks. Consequently the result applies to a
target met during a wall transition, as well as a target met in a long
common segment. No assumption about the residue or location of Z is made.

An equal zero-error seed is added independently in every common
interval. This includes an arbitrary equal starting deficit s and
the possibility that a central exit skips some initial root bins.
It adds trajectories rather than removing any. The two-coordinate
high entry is equal by construction; an arbitrary unequal entry is
not being silently used here.

The final bin is the lower half of root b-4. Its lower square endpoint
is exactly H. The source need not cross that last wall: every target
Z>=H is met in or before this last common interval. Continuing its
constant maps for the two comparison days is conservative if the
physical deficits pass below H, since all later root costs decrease.
The same observation justifies a `delay` check that crosses the next
root wall: freezing the current local maps can only slow the physical
decrease, not accelerate it.

## Separation and initial/final coverage

For d=1,2 the source's largest exit offsets past a wall are respectively
16 and18 rooms. The minimum distance between consecutive relevant
square/pronic walls is b-5>=27. Hence every enumerated branch finishes
strictly before the next wall. The local two-map formulas used during
the branch are therefore exact. Allowing all two waiting parities and
all crossing offsets may introduce impossible combinations; that only
enlarges the comparison problem.

The model is equal at entry. If entry is exactly a square or pronic
endpoint, it belongs to the new-side common interval, whose independent
zero-error seed is included. If it lies just before a wall, its first
crossing is one of the listed offsets. Thus no additional initial
transient is omitted.

The d=1 and d=2 rows end with45 and42 normalized states, respectively.
Every intermediate and common-segment check has maximum delay two.
The exact integer arithmetic is small and independently replayable;
the all-width conclusion comes from the preceding symbolic coverage,
not from extrapolating the number of checked boards.

## Scope

Together with the cap/phase interface of the eleven-day assembly, this
replaces its five-day high allowance by TWO days. The low and central
modules, the full-game join, and complete Lean formalization remain
separate assertions. No publication claim is made by this private note.

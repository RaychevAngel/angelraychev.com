"""A symbolic relaxation eliminating shifted square/pronic root walls."""
from itertools import product, permutations
from pathlib import Path
import json


def certificate(C=11):
    result=[]
    for even,parity,extra,a,x,c,y in product(
            (False,True),(0,1),(False,True),
            range(-C,3),(0,1),range(-C,3),(0,1)):
        if a<=0 and c<=0:continue
        if not even and (a,x,c,y)==(1,1,0,0):continue
        alpha,beta,gamma,delta=a,a-x,c,c-y
        low=[[beta+1,alpha,alpha+1],
             [beta,alpha,alpha+1],
             [beta,alpha,alpha+1]]
        high=[[gamma+3-y,gamma+2,delta+2],
              [gamma+2-y,gamma+1,delta+1],
              [gamma+1-y,gamma,delta+1]]
        cap=[[1]*3 for _ in range(3)]
        if even:cap[1][1]=cap[2][1]=0
        else:cap[2][0]=0
        if even and extra:cap[2][0]=0
        cost=[[min(low[i][j],high[i][j],cap[i][j])
               for j in range(3)]for i in range(3)]
        physical=([min(alpha,0,gamma if parity==0 else delta+1),
                   min(beta,0,gamma if parity==1 else delta+1)] if even else
                  [min(alpha,1,delta+1),min(beta,0,gamma)])
        total=sum(physical)
        assert 2*min(sum(cost,[]))>=total-1
        for length in (1,2,3):
            for p in permutations(range(3),length):
                value=sum(cost[p[(j+1)%length]][p[j]]for j in range(length))
                assert 2*value>=length*total
        witnesses=[(i,j)for i in range(3)for j in range(3)
                   if (cost[i][j],cost[j][i])in
                   (tuple(physical),tuple(physical[::-1]))]
        assert witnesses
        potentials=[p for p in ((0,0,0),(0,0,1),(0,1,1))
                    if all(2*cost[i][j]>=total+p[j]-p[i]
                           for i in range(3)for j in range(3))]
        assert potentials
        result.append(dict(even=even,length_parity=parity,extra=extra,
                           root_offsets=[a,x,c,y],cost=cost,physical=physical,
                           two_cycle=witnesses[0],half_potential=potentials[0]))
    return dict(status='PASS',root_band_count=C,types=len(result),
                width_samples=0,rows=result)


if __name__=='__main__':
    result=certificate()
    Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
    print({k:v for k,v in result.items()if k!='rows'})

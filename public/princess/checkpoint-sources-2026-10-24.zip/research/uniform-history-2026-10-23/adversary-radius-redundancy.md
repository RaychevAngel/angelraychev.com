# A redundant local-radius inequality

24 October 2026 UTC. Adversarial comparison lane. Ordinary algebraic proof;
not Lean formalization. This explains why one proposed history refinement
does not improve the accepted necessary model.

Let `w<=n`, `wn` be even, `b=floor(w/2)`, and `h=wn/2`. A positive survivor
has size `q`, corner count `i`, target size `T=q+s`, and target corner
count `j`. Suppose its source support has a certified corner-ball radius
`R<=w-2`. The proposed extra condition is

* own-color anchor: `s>=ceil(sqrt(q))`;
* opposite-color anchor: `s>=1+rho(q)`, where `rho(q)` is the least
  nonnegative integer `z` with `q<=z(z+1)`.

Both conditions already follow from the accepted ordinary three-corner
survivor bound, intersected with this one-ball capacity. Consequently
they are also redundant in the stronger paired nine-feature model.

## Algebra supplied by the existing ordinary bound

The bound permits a target only through at least one of its small,
middle, or high branches. Direct inversion of `small_inverse` gives:

* if `i<=1`, the small branch implies `q<=s^2`;
* if `i=0`, the small branch implies `q<=s(s-1)`.

Direct inversion of `large_inverse` gives:

* if `i<=1`, the high branch implies `h-T<=s(s-1)`;
* if `i=0`, the high branch implies `h-T<=(s-2)(s-1)`.

For completeness these inequalities include all target corner counts.
For the first high inequality write `A=2-i>=1`, `B=2-j`. If `B=0`,
`A+rho(h-T)<=s` gives `h-T<=(s-A)(s-A+1)<=s(s-1)`.
If `B>0`, inversion gives
`h-T<=(s-A-B+1)^2+B-1`, also no larger than `s(s-1)` on its admissible
range `s>=A+B`. Setting `A=2` gives the stronger second inequality.
The small inequalities follow by the same inversion of its square/pronic
branches. Branches whose stated baseline exceeds `s` are simply absent.

## Own-color anchor

The source ball contains at most one own-color board corner, so `i<=1`.
Its own-color area is at most `b^2`, in either width parity.
Suppose `s<ceil(sqrt(q))`. Then `s<=b-1` and `q>s^2`.
The small branch is impossible by the preceding algebra. The middle
branch requires `s>=b`, so is impossible as well. The high branch would give

    h=q+s+(h-T)<=q+s^2<=b^2+(b-1)^2<2b^2<=h,

a contradiction.

## Opposite-color anchor

Every own-color corner is at distance at least `w-1` from the anchor.
Thus `i=0`. Its own-color area is at most `b(b-1)` for even `w=2b`, and
at most `b(b+1)` for odd `w=2b+1`.
Suppose `s<1+rho(q)`. Then `q>s(s-1)`, ruling out the small branch.
The middle cap is `b+1` when `i=0`; its exceptional pairs require positive
`i`. Since the proposed lower bound is at most `b` for even width and
at most `b+1` for odd width, the middle branch cannot witness a violation.
The high branch gives

    h<=q+(s-1)^2+1.

In even width a violation has `s<=b-1`, so the right side is at most
`b(b-1)+(b-2)^2+1<2b^2<=h` (for `b>=2`). In odd width a violation has
`s<=b`, so it is at most `b(b+1)+(b-1)^2+1<(2b+1)(b+1)<=h`.
Again this is impossible. The tiny widths can be checked directly and
are outside the present low-budget research range.

## Consequence for the research direction

The physical local-radius inequality is valid, but adding it at radii
`R<=w-2` cannot strengthen the accepted model. A useful new radius argument
must retain additional information once a ball reaches another boundary,
or relate successive certificates more strongly than the existing local
area/corner constraints. This is a rejected strengthening, not a failure
of the desired all-width constant-gap conjecture.

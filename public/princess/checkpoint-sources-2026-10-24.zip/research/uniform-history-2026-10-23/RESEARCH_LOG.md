# Uniform history inequality: research log

Started 23 October 2026 PT / 24 October UTC. This pass attacks the all-width
history comparison; it does not extend a finite panel of certified widths.

## Fixed target and baseline

For every even-area rectangle 4<=w<=n and feasible k>floor(w/2), compare
the accepted computable lower bound to the physical prefix upper bound.
The concrete sufficient conjecture remains tau_model>=P-1, where P is
the smaller zero-seed solo prefix clock. Guarded merger then gives full
gap at most three, and at most two for odd upper clocks. The even-upper
central residual condition is an additional obligation for gap two.

The preceding checkpoint is `../uniform-gap-2026-10-23/CHECKPOINT.md`.
It covers all lengths and budgets for widths through 64 with gap two,
apart from two residue families allowing three. That cutoff is not removed
by any of the lemmas recorded below. The original comparison fixtures in
`../all-budget-2026-10-23/` remain unchanged.

## Attempts and findings

1. **Rejected as redundant: zero-leakage radius-conditioned expansion.**
   A support inside a sufficiently small corner ball obeys the quadrant
   square/pronic expansion profile. The existing corner profile plus the
   ball's capacity already imply that inequality. Extending it by an exact
   far-boundary leakage count also produced no stricter transition in the
   diagnostic audit. See `adversary-radius-redundancy.md` and
   `physical-radius-leakage.md`. This route was not added to the model.

2. **Accepted new all-width information: near-extremal sets contain a
   full inner triangle.** The quantitative full-layer lemma and its
   bin-wide dual resets are in `lower-dual-bin-stability.md`. A deficit d
   from a square/pronic capacity permits at most m terminal nonfull layers,
   where m(m+1)/2<=d. This concerns the original set, not only a compressed
   replacement. Its guarded merger and exact interval implementation were
   independently checked in `physical-bin-stability-review.md`. The
   critical whole-bin extension is not claimed, and the pronic rule needs
   its stated erosion-corner premise. This is stronger necessary history
   information, not a uniform gap theorem.

3. **Accepted physical history: changing the corner of a large hole core
   requires inspections.** See `root-anchor-switch.md` and its independent
   review `physical-anchor-switch-review.md`. Exact lens counts improve
   the simple half-neighborhood charge. Existing nine features already
   force alternating types for adjacent qualifying events, so that weaker
   consequence would add nothing. Actual corner coherence is the new
   geometric information.

4. **Accepted physical history over arbitrary intervening steps.**
   `physical-matching-block.md` transports holes using a fixed perfect
   matching and charges a final neighborhood against all inspections in
   the block; old localization expands by at most one matching edge.
   `root-expanding-cone.md` instead propagates a corner-localized mass
   requirement backwards with an expansion profile at each step. These
   address the loss of information between qualifying events, but neither
   yet measures excess cost relative to the physical prefix. Their charges
   must not be added without preventing double counting.

5. **Live analytic candidate: four-pattern low-boundary dynamics.**
   The nine-feature low-only recurrence appears to reduce to symmetric
   balancing of two alternating square/pronic maps. The proposed one-day
   comparison would bound an entire boundary regime independently of width.
   Symbolic branch verification, strip clipping, and small-root cases are
   still needed. A dual high-boundary reduction is also under investigation.
   Finite diagnostic runs are evidence for this candidate only.

6. **Correction to a failed abstract approach.** The root generic-map
   counterexamples refute monotone interlacing alone. Their f map has
   jumps of two, so they do NOT refute a theorem requiring both maps to
   be 1-Lipschitz. This was caught independently by the comparison lane.
   The symmetric-balancing conjecture with both maps 1-Lipschitz remains
   open. The stronger claim that every balanced tie lies below the smaller
   next physical coordinate is false even for the actual root maps.

## Evidence boundaries and unfinished work

No new theorem here has been formalized in Lean. Ordinary proofs and
independent finite audits are identified separately in the linked notes.
No public website or manuscript claim has been changed in this pass.
The entries above record the earlier state of this pass. The developments
below supersede their statements of what remained open; the failed
approaches and evidence boundaries are retained.

## Accepted consolidation: the width cutoff is removed

The primary combined result is `root-uniform-additive-bound.md`, reviewed
independently in `physical-uniform-bound-review.md` and by the lower lane.
It proves an absolute119-day structural bracket throughout the full
feasible rectangular domain. This is not advertised as a small gap.
Previously, no absolute gap bound was accepted beyond the width cutoff.
All earlier tighter results remain in the combined bounds.

The proof has three stages, rather than a growing list of separate
fixed-width theorems:

1. **Early physical passage, at most three days.** Good near-extremal
   states have one dominant actual corner and cohort. A change of that
   identity requires a long intervening block; inefficient inspections
   in that block pay for a reference rewind. Rewinds preserve phase and
   do not accumulate an extra day per switch. The last-crossing argument
   handles retreats. See `lower-three-day-early.md` and its dependencies.

2. **Critical passage, initially fifty days.** The three-corner necessary
   model is relaxed to fixed-size cost matrices with symbolic root offsets.
   Every constant-root cell has exactly the physical maximum growth from
   equal seeds. A finite number of root interfaces is charged, giving50
   days for five excluded root bands. This is a proof for unbounded board
   parameters, not a panel of sampled widths. See
   `adversary-critical-passage-refined.md` and the C5 symbolic certificate.

3. **Late physical passage, at most four days.** The signed merged
   residual is controlled through a dominant small survivor cohort and a
   nearly full other cohort. Matching transport charges corner changes.
   The fast exit uses backward nonexpansive thresholds, avoiding the
   false assumption that forward residual maps are nonexpansive. Last
   crossing reset steps are paid by ignored actual excursion durations.
   See `physical-four-day-late.md` and its dependencies.

The original8-day early and8-day late proofs are preserved as audit
history; they are not additional results to count beside their stronger
three- and four-day replacements. The intermediate7153-day and98-day
critical estimates are similarly superseded by the C5 fifty-day module.

The42 budgets33..74 are handled by exhaustive scalar parameter arithmetic,
independent of either board dimension. Smaller feasible budgets imply
width at most63 and are already covered by the previous all-length result.
The complementary high-budget range uses the previously proved one-day
theorem. This is an exhaustive parameter split.

## Strictness on the preserved baseline

The full-inner-layer necessary condition was independently replayed on
the existing46x46,k24 fixture. It gives lower509, matching the retained
physical upper509; the previous checkpoint had507..509 and the original
baseline505..509. The replay took5.25 CPU seconds. No new width scan was
run. Other frozen fixtures were preserved rather than relabeled by the
coarser uniform theorem.

## Current quantitative attack

The119 constant spends100 days on the middle comparison after doubling.
Its proof resets phase at every root interface. New analysis instead
carries two ordered coordinates through each boundary half. Both halves
reduce to the same one-sided tie correction, with at most five corrections
in the relevant interval. Each correction can be repaired in one physical
day. The central cap region is being analyzed with its actual phase state;
its extra favorable edges cannot persist simultaneously on an odd-width
rectangle. These sharper components are still being assembled and reviewed.

The central research goal remains a genuinely small uniform gap, ideally
the two- or three-day behavior of the strongest previous bounds. An
absolute119-day theorem is a real qualitative advance, not completion of
that quantitative goal. No new Lean theorem, public page, manuscript, or
PDF has been claimed or changed in this pass.

## Accepted sharpening:25 days over the full domain

The final accepted result is `root-uniform-twenty-five.md`, with independent
assembly review `physical-twenty-five-review.md/.json`. It gives25 days for
every feasible rectangle, sharpened to23 at even width. Previously retained
exact and smaller-gap theorems are combined rather than weakened.

The critical allowance was reduced from50 to11 by carrying ordered phase
coordinates, then to5 (four at even width) by the two finite root-wall
certificates. Their states are relative errors and phase labels, and every
entry residue is included. Spacing guards prove that each local transition
applies at every larger root index. The certificates check no board widths.
Their original generator receipts still say exploratory; the subsequent
source-hashed independent reviews are the acceptance layer.

The late fast-exit estimate improved from three extra days to two by a
three-stage scalar bound, leaving a total late allowance of three. The early
three-day argument was strengthened to dominate the actual first-crossing
overshoot. This saved a physical reset at the full-game join and two days
in the final bracket. Exact arithmetic is23/25, not an inferred fit.

Two distinct error directions matter. Low backward maps are nonexpansive,
so at most five injections give a five-room discrepancy. High deficit maps
are expansive; a similar discrepancy argument would fail. Advancing the
physical trajectory first gives favorable credit that expansiveness
preserves, and at most five clamps spend that credit. The smallest budgets
are handled by the full residue certificates. Both proofs compare the
physical phase MINIMUM with the model exit MAXIMUM, including overshoot.

The new numerical component is implemented in `root-prefix-clock.py`.
Its generic prefix-neighborhood count was checked on252 literal prefix
sets, and its clocks were replayed on all eleven existing frozen fixtures.
These are implementation checks, not the basis of the uniform theorem.
The separate full-inner-layer replay makes46x46,k24 exact at509 days.
All27 frozen baseline source hashes were rechecked and remain intact.

Read `CHECKPOINT.md` for the resulting coverage, remaining gap, proof entry
points, and restart rules. No new Lean proof or public artifact is asserted.

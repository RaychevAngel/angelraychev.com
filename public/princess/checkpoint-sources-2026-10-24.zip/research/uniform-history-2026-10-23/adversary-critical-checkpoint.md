# Critical comparison checkpoint

24 October 2026 UTC. Private research log for the comparison lane.

The current direction replaces repeated scalar resets at every root
wall by two labeled model/physical phases. This is genuine uniform
comparison work, not a new fixed-width panel.

## Secured ordinary proofs

- `adversary-critical-passage-refined.md` proved50 critical days at C=5
  through symbolic root matrices and a bounded number of root cuts.
  Independent review accepted it. This remains a fallback.
- `adversary-critical-eleven-day-assembly.md` improved the same module
  to11 days at odd width and9 at even width for b>=32,k<3b. Independent
  final review accepted its low/high cap interfaces, fixed phase labels,
  skipped modules, arbitrary target and entry, and exit overshoots.
- The low two-state model has at most one unit tie closure per upper
  half root bin. Each costs one genuine physical day, and an unused
  event allowance also pays the final phase alignment. This gives5
  low days without pretending phase exchanges are free.
- Odd central passage costs at most1 extra day; even central passage
  costs0. The only odd extra edge can improve the leading coordinate
  once, after a sufficiently large step skips a middle interval. Its
  repair also pays the final phase alignment.

## Accepted five-day assembly

`adversary-critical-five-day-assembly.md` specializes the low entry to
H=(b-5)^2 and target to b^2<M<=h-H, precisely the full-game join's
range. It gives critical5 at odd width and4 at even width, with final
independent acceptance in `physical-twenty-five-review.md/.json`.
It does not claim the stronger arbitrary
low-seed/target statement of the11-day fallback.

The low2 proof is independently accepted. Its local root-wall
automaton includes every entry residue and both physical phase/error
states; it checks zero widths. Five roots, d=k-b in1..4, require only
6/11/16/19 final normalized states. The physical minimum catches the
actual model exit maximum within2 days. For d>=5 a five-room error
bound and global drift prove the same result analytically.

The high2 proof has been independently accepted by both the lower and
upper lanes (`lower-review-high-two-day.md/.json` and the final
twenty-five review). For d>=3,
two physical days supply6 rooms of deficit advantage. Expansive high
root maps preserve that advantage, except for at most5 one-room
clamps. For d=1,2 a mirrored local wall automaton checks every
intermediate and waiting state against the frozen model minimum.
This covers arbitrary high terminal thresholds, not just H. The
largest generated wall offsets16/18 are strictly below the guaranteed
27-room separation. Equal seeds added at every common interval cover
arbitrary central overshoots and skipped initial bins.

## Lessons and limitations

The first critical proof paid worst-case transient and wall costs
independently. Keeping the exact ordered phase pair exposed that most
steps are already physical. Only upper-half low and lower-half high
tie closures need repair. The further local certificates retain timing
through each wall rather than summing independent event costs.

The high map is expansive, so a late room-error bound is a poor tool.
The useful direction is to spend physical time first and propagate its
deficit advantage; expansion then helps rather than hurts. The low
map is1-Lipschitz, so an accumulated room-error bound is natural there.
Their superficially similar recurrences require opposite comparisons.

The finite-state certificates are parameter-independent local proofs.
They must not be described as numerical confirmation across boards.
Their original generated JSON status says exploratory; independent
review documents supply the later proof-acceptance layer while leaving
source/receipt hashes intact.

The parent has now assembled and independently checked the full-game
uniform25-day bound (23 at even width), preserving all earlier stronger
bounds; see `root-uniform-twenty-five.md`. This conclusion depends also
on the parent's early actual-history bound, late actual-history bound
and joining lemma, not on the critical comparison alone.
No new complete Lean proof,
manuscript/PDF, public website release or fixed-size capture formula
was produced in this lane.

The next mathematical tightening should retain phase and surplus
through the low/central/high interfaces, or improve the actual-history
boundary inequalities. It should not return to width-by-width samples.

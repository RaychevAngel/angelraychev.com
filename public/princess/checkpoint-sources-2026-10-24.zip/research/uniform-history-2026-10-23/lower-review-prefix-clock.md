# Independent review of the physical prefix clock

Status: accepted as an evaluator of the stated physical construction, not
as an exact optimizer. Review date:24 October2026 UTC.

The prefix consists of all cells of one color in smaller diagonals,
followed by the rightmost cells of its last diagonal. Binary search finds
the unique last occupied diagonal using the parity-generic inclusion and
exclusion count. The count is valid at odd width as well as even width;
shifting by a side length also shifts the counted color by its parity.

If the source last diagonal is D and its leftmost occupied column is C,
all opposite-color diagonals through D-1 occur in its neighborhood. On
diagonal D+1 the neighborhood is the interval of columns

    max(0,D+2-n,C) <= x <= min(w-1,D+1).

This interval is again the rightmost occupied interval, so the entire
neighborhood is the opposite-color prefix of the size returned by the
helper. This set identity, not merely equality of cardinalities, makes
repeated evaluation a physical inspection strategy. Inspecting the last
k cells leaves the shorter prefix. If its size is at most k, the next
inspection clears it; hence the final +1 in the solo clock is correct.

The independent audit constructs literal cell sets and literal
neighborhoods. It checks318 prefixes and complete neighborhood-prefix
identities, and284 complete solo histories over both initial phases,
including odd-width/even-length, even-width/odd-length, even/even and
width-one boards. All pass. The receipt records source hashes. These
small literal checks audit the implementation; they are not a width
survey supporting the new uniform mathematical theorem.

`sequential_prefix_upper=2P` remains a valid possibly nonoptimal upper.
The stronger retained shared-inspection upper is intentionally combined
elsewhere. In particular this helper must not replace a better existing
bound. The new history lower is only attached in its stated new-range
guard, and the helper makes no claim to implement all retained bounds.

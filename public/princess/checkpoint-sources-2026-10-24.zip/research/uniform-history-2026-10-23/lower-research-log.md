# Lower lane: uniform-history pass

24 October 2026 UTC. The target is a fixed absolute gap over all even-area
rectangles and feasible budgets. Selected instances below are diagnostic
witnesses of a uniform theorem's effect, not a replacement for that target.

## Accepted new result

`lower-dual-bin-stability.md` proves that a localized quadrant set near its
square or pronic maximum contains a full initial triangle. If its cardinality
defect is d, at most m(d)=floor((sqrt(8d+1)-1)/2) terminal layers can be
incomplete. This bound follows from a triangular cost for each incomplete
tail, using original diagonal counts preserved by compression.

Applied to target holes, it extends both high equality resets to entire
subcritical bins. The original-surplus merger forces a full-to-full identity
partner throughout those bins, so the new restrictions apply to the accepted
paired-radius lower-bound construction for every width and length. The
pronic rule needs target erosion v=1; omitting it would be unsound in the
lower part of the bin. The old critical equality rule is retained separately.

The exact interval engine is `lower-dual-bin-interval.py`. It leaves all old
sources unchanged. The new bin records are split only at triangular defects.
Although the conditions are wider, a fixed survivor q still has at most one
exceptional target; its target is injective as q varies. Thus the established
ordinary-tail repair argument applies.

Independent acceptance is recorded in `physical-bin-stability-review.md`.
The review's separate audit matched 21,600 labeled interval unions and
2,051,476 admitted q/T points across all four old switch settings. Its
literal physical audit tested 219 near-extremal sets and 438 complemented
transitions among 127,178 candidates. Our separate union audit checked
11,076 unions and 444,065 admitted points. The receipts identify source hashes.
No new Lean verification is claimed.

Three bounded diagnostic evaluations, using the same physical upper clocks:

* 24 by 24, budget13: lower207, upper207, unchanged.
* 44 by 44, budget24: lower335, upper337, unchanged numerical lower;
  the preterminal minimum increases from4 to7.
* 46 by 46, budget24: lower509, upper509. The accepted old dual-nine
  lower was507; the new restriction raises its solo clock from254 to255.

The last case establishes that the strengthened geometry has a real effect.
It does not establish a uniform two-day gap or generic optimality.

## Discarded route: radius-conditioned scalar quadrant drift

A support inside a same-color corner ball of effective radius<=w-2 has
surplus at least ceil(sqrt(q)); an opposite-color ball gives the pronic
root. These physical statements and their min-radius merger are sound.
However the ordinary corner profiles plus existing ball area capacities
already imply them. The comparison lane proved the redundancy symbolically.
The physical lane's boundary-leakage generalization likewise showed no
strict improvement in its diagnostic comparison. No evaluator was built for
this redundant filter.

The lesson is specific: retaining a ball's independent capacity and its
independent isoperimetric profile does not retain the correlation between
which layers are occupied. The new stability theorem retains full layers,
which survive as hole exclusions through later moves.

## History bridge and remaining obstruction

Parent's `root-anchor-switch.md` charges actual inspections for moving a
large guaranteed hole core to a different corner. Together with the new
stability theorem it rules out changes of actual anchor between sufficiently
large consecutive near-extremal events. This is geometric information about
physical histories. It is not automatically a valid transition rule for
synthetic radius states with separately maximized anchors.

A simple phase corollary is already present in the nine features: a square
event ends at(c,e)=(1,2), but another square event requires retained i=2;
a pronic event ends at(2,1), but another requires retained u=2. Thus neither
event type can repeat on consecutive days. The new anchor theorem's possible
benefit is finer than forbidding those adjacent repeated types.

The missing uniform argument must handle the intervening nonqualifying
steps. Merely saying they cost an extra unit of surplus does not yet prove
they repay the advantage of changing phase. Different root bins may value
that unit differently, especially near the minimum budget. Independently
maximizing entrance and exit profiles also loses correlations across the
short boards where their regions overlap.

A focused next target is a phase-dependent clock credit, defined through
square/pronic bin coordinates and the retained radius/core deficit, whose
change on every allowed transition is at most one day's physical progress.
Its total entrance-to-exit oscillation must be bounded independently of
w,n,k. The current accepted geometry supplies concrete constraints for
that inequality; no such bounded-oscillation credit has yet been proved.

The low-only nine-frontier comparison lane is reducing the scalar frontier
to four patterns with entries b or b-1. This may settle the low boundary
uniformly, but the full-board statement still needs a rigorous transfer
through the high boundary and through overlapping boundary regimes.

## Further uniform reductions and a physical history comparison

`lower-high-patterns.md` is now independently accepted in
`physical-high-pattern-review.md`. The isolated high-boundary nine-feature
operator closes on nine normalized patterns. Its unbounded root indices
are covered by387 exact symbolic cells, with9,180 direct checks below the
symbolic range. The independent physical-interface audit checked612
arbitrary deficit vectors. This gives a fixed-pattern scalar system; it
does not yet supply entry, terminal-floor, or capture-time comparison.

Inspection of its table gives only two scalar maps, the alternating
square and pronic high maps, with repeated square phases allowed only
where their numerical outputs coincide. `lower-high-inverse-control.md`
inverts a safe relaxation of these transitions. The resulting one-sided
equalizing process is stronger than the previously studied balanced
process. A targeted root-map witness refutes one-day domination for this
relaxation, although it is not a counterexample to the actual nine-pattern
system. The same diagnostic exhibits a large transient room lead that
shrinks near the slow endpoint; a small room-error ansatz is unsuitable.
It does not by itself refute every possible universal room-error constant.

`lower-bad-step-credit.md` proves an exact physical comparison lemma:
if an actual target pays C additional surplus units, while the reference
profile differs from the common lower profile by at most d0 on a k-room
window, its lead grows by C-d0 rooms, capped at k. There is no rounding
loss, and actual cardinality retreats are allowed.

The physical lane combined that lemma with its dominant actual component
and matching-block charge in `physical-slow-block.md`. My independent
review accepts the local argument: for k>=108 and root indices
2k/3<r<=b-10, near-minimal-surplus events have a canonical cohort/corner;
changing this identity forces enough intervening bad steps to earn k
rooms of lead. Rewinding the prefix reference by one day flips its phase
while preserving domination, so these changes do not accumulate time
loss. The apparent O(100)-room remainder does not alter the anchored
square/pronic profile: component capacity aggregation gives the exact
phase profile for the total hole count. All candidate prefix sizes in
this interior fit genuine quadrants.

This is progress on the actual history-dependent obstruction, not only
another scalar bound. The parent subsequently joined a bounded fast-entry
allowance to this interior in `root-interior-passage.md`: reaching
H=(b-11)^2 total physical holes takes at least the corresponding best
prefix passage clock J minus8 days, under its displayed guards.

`lower-physical-passage-join.md`, independently accepted by the physical
lane, now supplies the full-game joining inequality without new anchor
merger assumptions. Put Z=G_k(H-1), a*=h-Z, and let s* be the first
ordinary nine-feature backward capture threshold whose maximum reaches
a*. Then

    T_k>=2(max(0,J-8)+s*)-1.

The proof uses the new physical passage only before the first H-crossing,
then the old guarded merger until total holes reach h-k, followed by the
ordinary reversed-walk cut with explicit day indices. The sharp overshoot
Z is essential: the coarse H+k-1 envelope loses k rooms near a slow
boundary. Here Z-H<=k-b+10, and interlacing gives F_k(H)>=Z, so one extra
physical prefix day catches the entire crossing envelope.

There is still no all-width fixed numerical gap. What remains is the
uniform comparison of J+s* to the physical solo clock, including the
near-critical root bands and coverage outside the passage theorem's
budget range. This is now an explicit clock inequality rather than an
unproved transfer of new geometric labels through the merger.


## Uniform physical boundary passages and first absolute gap

The smaller rewind allowance D=k-R-1 permits good slack three rather
than nine, with at most four nondominant surplus units. This moves the
physical cut from (b-11)^2 to (b-5)^2. The generic-R proof covers all
k>=33: use R=floor(4k/5) for the42 budgets33..74 and floor(2k/3)
thereafter. The finite base is exact scalar arithmetic independent of
board width or length. Crossing targets are clipped explicitly when
large budgets can skip a whole boundary region.

`lower-three-day-early.md` now proves a uniform THREE-day early physical
passage. The decisive improvements are the true entry envelope G(R^2),
the fact that only every second alternating update differs from scalarG,
and a two-stage root-drift estimate t_G<=4(k-R-1). All three budget
residue classes have elementary polynomial proofs. The small-budget
certificate checks159,022 target/phase comparisons, with maximum entry
loss three and fast-only loss two. The physical lane independently
accepted the proof.

I independently accepted the physical lane's four-day late passage,
including the signed survivor decomposition and exact phase bound.
Two crossing resets can be paid from the ignored actual excursion
durations, leaving only one phase adjustment plus three fast-exit days.
For budgets33..74 the stronger late allowance is three; the independent
reproduction uses explicit neighborhood arrays and binary-search inverses
for all163,432 target/phase comparisons. These are physical-history
inequalities, not assumed mergers of new corner labels.

Together with the separately reviewed critical50 comparison, the parent
assembled a first absolute all-parameter bound U-L<=119 in
`root-uniform-additive-bound.md`. I reviewed the parameter coverage,
critical cut guards, joining indices and arithmetic in
`lower-review-uniform-assembly.md`. The new theorem applies beyond every
fixed width cutoff; the previously sharper exact and small-gap results
remain combined by maximum/minimum. The constant119 is not called small
or sharp. Its main excess is the fifty-day critical-interface allowance;
removing repeated phase resets there is the next quantitative target.


## Further boundary and critical improvements

A three-stage scalar backward estimate sharpened the fast late exit to
two days for all budgets at least75, matching the finite33..74 base.
Thus `physical-three-day-late.md` gives a uniform three-day late passage.
The parent also noticed that the early theorem can retain the actual
crossing overshoot; `lower-early-overshoot-domination.md` proves this
with the same three-day allowance under the full low-budget guards.
These remove separate bookkeeping losses in the global join.

`lower-local-critical-repairs.md` gives one extra physical paired day
per low injection or high clamp. The minimum-budget cases remain in
precisely the cheap-root region required by the seemingly slow phase;
no free phase exchange occurs. Unused event allowances pay the final
phase alignment, while a last possible event ties the model through
its endpoint. Thus low costs at most5, and high costs at most4 at the
even gate or5 at the odd gate. These replace repeated root-cut resets
with actual local simulations.

The comparison lane then reduced the low critical five-bin module to
a finite root-wall automaton. I reviewed the all-width completeness in
`lower-review-wall-automaton.md`: normalized common-region waiting has
exactly two phase variants; independent first-crossing residues cover
all widths; b>=22 separates the bounded wall windows; and the terminal
check compares the physical minimum with the actual model overshoot.
The finite audit gives a TWO-day low allowance for d=k-b in1..4. For
d>=5, the five-room model error plus its one-room spread is repaired
within two days by global physical drift at least d-1. Thus low2 holds
for every budget in the global b>=32 range without any width scan.
The phase-preserving middle and high modules remain coordinated with
the comparison lane before any smaller full capture constant is claimed.

## High two-day comparison and the all-width25-day theorem

The high mirror also admits a two-day comparison with every terminal
threshold at least H and every equal starting seed below the central
exit. The finite certificate for d=1,2 checks all normalized wall-entry
residues, both common-region waiting phases, every intermediate stopping
state and arbitrary equal starts within a bin. For d>=3, two physical
steps paid in advance supply at least six rooms of favorable deficit
lead; expansive high maps preserve it, and at most five clamp events
spend one room each. The remaining room pays the model's coordinate
spread. I independently accepted this in
`lower-review-high-two-day.md/.json`.

The parent assembled low2, central0/1, high2 with physical early3 and
late3 in `root-uniform-twenty-five.md`. It gives a structural computable
bracket of width at most25 for all feasible rectangles, and at most23
for even width, preserving sharper old bounds by maximum/minimum.
This is an ordinary proof plus reviewed finite arithmetic/state
certificates, not Lean verification. No public artifact is updated here.

I also independently audited the parity-generic physical prefix-clock
implementation. Literal prefix sets and their full neighborhoods agree
on318 states, and284 complete physical solo histories agree with the
returned clock. The evaluator computes a concrete strategy's clock; it
does not optimize over every physical strategy.

The next quantitative target is a single global virtual-prefix-clock
comparison, rather than summing independently maximal losses at early,
critical, and late cuts. For example P<=g+5 for every actual first merged
gate time g would imply the uniform nine-day capture bracket. The current
proof gives P<=g+12 at even width and P<=g+13 at odd width. Its interior
corner switches are already paid from the actual history; the unresolved
loss is the interaction of the fast-boundary phase deficits, critical
root-wall events, and the phase/overshoot passed to the late boundary.
It is not yet proved that their separate worst cases can coexist, nor
that retained physical lead cancels enough of them. A useful stronger
invariant must retain actual phase and unused room credit through all
three regions; merely sharpening one more fixed-width evaluator does
not address this remaining all-width obligation.

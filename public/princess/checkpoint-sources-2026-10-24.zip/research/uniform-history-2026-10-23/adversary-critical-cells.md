# A finite critical-band comparison through cycle costs

24 October 2026 UTC. Proposed algebraic lemma, with an exact finite
certificate. This is a local comparison tool, not a complete all-width
capture-time theorem. No individual widths were sampled.

## Scope and exact interface

Write b=floor(w/2), d=k-b>=1, h=wn/2, and fix C=10. Assume b>=C+3.
The critical region is

    (b-C)^2 <= q <= h-(b-C)^2.

Outside the small neighborhoods of square and pronic breakpoints, all
roots used by the ordinary three-corner inverse recurrence are constant.
For a bulk cell, require these constants to hold for every q argument
occurring in the cell, including q-8 through q and h-q-1 through h-q+1.
Thus all offsets in the exact formulas `small_inverse` and `large_inverse`
are covered. Put

    alpha=ceil(sqrt(q)), beta=rho(q),
    gamma=ceil(sqrt(h-q)), delta=rho(h-q).

Then beta is alpha or alpha-1, and delta is gamma or gamma-1.
All roots are at least b-C. Any alpha or gamma >=b+2 is inactive after
the width cap, so its offset may be replaced by2 in the finite analysis.
This replacement does not alter a capped matrix entry or a physical cost.

Both q and h-q are at least9. Consequently the doubled-argument branches
in the two exceptional inverses simplify: the low cornerless cost is
beta+1, and the high two-corner cost is gamma+1. The root-wall exclusion
also gives R(h-q+1)=gamma.

## Exact costs in a bulk cell

Rows are retained source corner counts i=0,1,2; columns are target
corner counts j=0,1,2. Before the width cap the low and high cost matrices
are, respectively,

    [ beta+1   alpha     alpha+2 ]
    [ beta     alpha+1   alpha+3 ]
    [ beta+1   alpha+2   alpha+4 ]

and

    [ gamma+3  gamma+2   delta+2 ]
    [ gamma+2  gamma+1   delta+1 ]
    [ gamma+1  gamma     gamma+1 ].

The cap is b+1 except at (i,j)=(1,1) for even width or (2,0) for odd
width, where it is b. For even width and n=w+1 the additional (2,0)
exception is included. The certificate permits this extra exception
independently of all other parameters, a safe relaxation.

Let S(c,j) be the minimum capped cost over 0<=i<=c. The ordinary
three-corner backward update is the max-plus matrix

    B'_c = max_j [B_j+k-S(c,j)].

The finite-board size caps are inactive in the displayed critical region.
The physical two-phase costs are

    even width:
      p0=min(alpha,b, gamma if n even else delta+1),
      p1=min(beta,b, gamma if n odd else delta+1);
    odd width:
      p0=min(alpha,b+1,delta+1),
      p1=min(beta,b,gamma).

Put mu=(p0+p1)/2. The physical phase costs differ by at most one.

## Two geometric exclusions

If alpha<=b and gamma<=b, then q+(h-q)<=2b^2. Since every relevant board
has h>=2b^2, equality would force q=h-q=b^2, which lies on an excluded
square wall. Thus this combination does not occur in a bulk cell.

One further cell is excluded for odd width:

    alpha=b+1, beta=b, gamma=delta=b.

It would imply q<=b(b+1), h-q<=b^2, and hence h<=2b^2+b. But odd width
and even area imply n>=2b+2 and h>=(2b+1)(b+1)=2b^2+3b+1. This cell is
impossible. Without that geometric exclusion the ordinary model has
a spurious three-cycle of total cost3b+1, faster than the physical mean
b+1/2. This is why merely checking unconstrained root combinations fails.

## Finite algebraic certificate

The file `adversary-critical-cells.py` enumerates offsets alpha-b and
gamma-b from -10 through2, and the two binary differences alpha-beta
and gamma-delta. Width parity, length parity, and the extra cap are also
retained. This is a finite enumeration of symbolic matrix types, not a
test of finitely many boards. Each type represents every integer b for
which its root inequalities and geometric constraints hold.

After the two exclusions, all1,532 matrix types satisfy:

1. Every directed simple cycle of length l has total cost at least l*mu.
2. Every edge has cost at least mu-1/2.
3. The two physical costs differ by at most one.

All checks are exact integer inequalities after subtracting b; no
floating-point or sampled large-width substitution is used.

## Consequence: at most one room of transient bulk advantage

For any directed path of length t in the three-state graph, successively
erase simple cycles. The remaining simple path has at most two edges.
The erased cycles cost at least their length times mu. The remaining
edges cost at least mu-1/2 each. Therefore total path cost is at least
t*mu-1.

It follows that, from any initial frontier with B_j<=z,

    max B^(t) <= z+t*(k-mu)+1.

From equal physical seeds(z,z), the better of the alternating physical
phases has value at least z+t*(k-mu), as long as the same bulk matrix
applies. Thus the model's advantage inside one constant-root cell is at
most one room, regardless of how many days the cell takes to traverse.
In particular an O(b/(k-b))-day critical cell does not accumulate that
many independent phase-switch errors.

This is a statement about the affine matrix iterates. Joining actual
root cells still requires a stopping/overshoot argument; the matrix must
not be continued past its defining root inequalities without justification.

## What remains to join a full critical module

Only a bounded number of root walls occur, since the un-clipped root
indices range from b-10 through b+1. A wall has bounded room width
(the offsets above are bounded constants). The unrestricted long middle
has the already accepted exact two-step translation.

A valid global join must track (i) the two-room spread of the ordinary
corner frontier, (ii) overshoot when a step crosses a wall, (iii) the
physical phase at re-entry, and (iv) the entrance time credit provided by
the preceding slow-region argument. Critical increments are at most
d+C+O(1), while physical two-step progress is at least2d-1. This suggests
a fixed number of days per wall even when d=1, but the full stopping-time
and overshoot lemma is not asserted as proved here.

For shortest rectangles, both boundary roots can appear in the same
critical module. They are already present simultaneously in the matrices
above. The geometric exclusions use only h>=2b^2 (or its sharper odd-width
version), so the bulk comparison does not require n to be large.

# The same ordered two-state map at both critical boundaries

24 October 2026 UTC. Exact reduction of the unshifted low relaxation.
The high inverse map was derived independently in
`lower-high-inverse-control.md`.

Let A=(b-C)^2, k>=b+1, h>=2b^2, and consider target values q<=b^2.
Then h-q>=b^2, so the high branches of the unshifted relaxation cannot
beat its low branches. The width caps also cannot improve them. Its cost
matrix is consequently

    [ rho(q)+1   R(q)   R(q)+1 ]
    [ rho(q)     R(q)   R(q)+1 ]
    [ rho(q)     R(q)   R(q)+1 ].

From equal seeds, B1=B2=z and B0=a are preserved, with a in{z-1,z}.
The last target column is dominated by the middle one. Define

    F(u)=u+k-R(u),       G(u)=u+k-rho(u).

The exact recurrence is

    a'=max(G(a)-1,F(z)),       z'=max(G(a),F(z)).

Since G(u-1)<=F(u)<=G(u), the first maximum is always F(z) on the
invariant a in{z-1,z}. With the leading coordinate first, (x,y)=(z,a),
the update becomes

    M(x,y)=(max(G(y),F(x)),F(x)),       x-y in{0,1}.       (1)

This is exactly the ordered high inverse-control map, after the latter's
accepted shift by k. The unmodified physical map in this phase convention
is

    H(x,y)=(G(y),F(x)).

It need not preserve the order x>=y. Equation(1) adds at most one room
to the first coordinate of H, and only when x=y+1 and

    F(x)=G(x-1)+1.

Writing r=R(x), that condition is exactly

    r(r-1)+2 <= x <= r^2.

Thus an injection can occur only inside the upper-half root interval
where F=G=u+k-r. It ties the two output coordinates. As long as later
inputs remain in that interval, a tie stays tied and no further injection
occurs. Monotonicity prevents revisiting an interval, so there is at most
one injection per root index r.

From the equal seed A=(b-C)^2, the initial root index b-C produces no
injection: the first step leaves that square endpoint. Until the maximum
reaches b^2, only the C root indices b-C+1,...,b can inject. Both physical
maps are nondecreasing and1-Lipschitz. Therefore, comparing M and H from
the same equal seed,

    0 <= M^t-H^t <= (I_t,I_t),       I_t<=C,

coordinatewise, up to and including the first exit step. This is an exact
room bound, not a sampled observation.

The physical finite-board maps agree with these uncapped low maps while
their inputs remain below b^2. Since the relaxed pair dominates the
physical pair, that agreement holds through the model's first exit.
Afterwards global physical progress is at least one room every two days,
and one further day makes its minimum dominate the previous maximum.
Consequently this low-half module has a crude delay at most2C+1 days,
including domination of the model's exit maximum.

For C=5 this gives11 days. The intended next improvement is to retain
the timing and phase of the at most five injections, rather than pay for
all five at the final minimum velocity. The high boundary uses the same
map, but its initial/terminal shift and inverse target must be retained;
the low statement alone does not silently prove the full high comparison.

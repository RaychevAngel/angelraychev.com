"""Exact finite algebra for the ten-root critical bulk; no width sampling.

All entries are costs minus b. The roots themselves range over b+s,
where -C<=s<=1; s>=2 is identically inactive after the strip cap.
The accompanying note proves the two discarded geometric cells impossible.
"""
from itertools import product, permutations
from pathlib import Path
import hashlib
import json


def certificate(C=10):
    rows = []
    cycles = [p for length in (1, 2, 3)
              for p in permutations(range(3), length)]
    for even, parity, extra, a, x, c, y in product(
            (False, True), (0, 1), (False, True),
            range(-C, 3), (0, 1), range(-C, 3), (0, 1)):
        # alpha=b+a, beta=alpha-x; gamma=b+c, delta=gamma-y.
        if a <= 0 and c <= 0:
            continue  # q+d<=2b^2; equality is a removed square wall.
        if not even and (a, x, c, y) == (1, 1, 0, 0):
            continue  # q+d<=2b^2+b < (2b+1)(b+1).
        alpha, beta, gamma, delta = a, a-x, c, c-y
        low = [[beta+1, alpha, alpha+2],
               [beta, alpha+1, alpha+3],
               [beta+1, alpha+2, alpha+4]]
        high = [[gamma+3, gamma+2, delta+2],
                [gamma+2, gamma+1, delta+1],
                [gamma+1, gamma, gamma+1]]
        cap = [[1]*3 for _ in range(3)]
        cap[1 if even else 2][1 if even else 0] = 0
        if even and extra:
            cap[2][0] = 0  # additional n=w+1 critical exception
        cost = [[min(min(low[i][j], high[i][j], cap[i][j])
                     for i in range(z+1)) for j in range(3)]
                for z in range(3)]
        if even:
            physical = [min(alpha, 0, gamma if parity == 0 else delta+1),
                        min(beta, 0, gamma if parity == 1 else delta+1)]
        else:
            physical = [min(alpha, 1, delta+1), min(beta, 0, gamma)]
        total = sum(physical)
        assert 2*min(sum(cost, [])) >= total-1
        assert abs(physical[0]-physical[1]) <= 1
        margins = []
        for p in cycles:
            value = sum(cost[p[(j+1) % len(p)]][p[j]]
                        for j in range(len(p)))
            margin = 2*value-len(p)*total
            assert margin >= 0, (even, parity, extra, a, x, c, y, p)
            margins.append(margin)
        rows.append(dict(even_width=even, length_parity=parity,
                         extra_critical_exception=extra,
                         root_offsets=[a, x, c, y], cost=cost,
                         physical_costs=physical,
                         minimum_cycle_margin=min(margins)))
    return dict(status="PASS", root_band_count=C,
                parameter_cells=len(rows),
                simple_cycles_per_cell=len(cycles),
                mathematical_claim="Every critical bulk matrix cycle costs at least the physical mean; every edge costs at least that mean minus one half.",
                width_samples=0, rows=rows)


if __name__ == '__main__':
    result = certificate()
    source = Path(__file__)
    result['source_sha256'] = hashlib.sha256(source.read_bytes()).hexdigest()
    source.with_suffix('.json').write_text(json.dumps(result, indent=2)+'\n')
    print({k: v for k, v in result.items() if k != 'rows'})

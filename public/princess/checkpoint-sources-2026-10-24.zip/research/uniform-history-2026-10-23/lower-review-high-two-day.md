# Independent review of the two-day high critical passage

Accepted `adversary-critical-high-two-day.md` under its stated equal-entry
and cap/phase hypotheses. The source-hashed replay is
`lower-review-high-two-day.json`. It checked no board dimensions.

The large-budget proof correctly uses expansiveness in the advantageous
direction: starting the physical deficit trajectory two days earlier
creates a uniform advantage, preserved by A and B. Every model clamp
spends only one room. The allowance of five clamps leaves a room to
cover the ordered model's final one-room span for d>=3. A naive upper
bound on accumulated positive physical error would be invalid because
these decreasing-deficit maps are expansive; the upfront advantage
argument avoids that issue.

For d=1,2 the wall state retains all four labeled coordinates. Two
homogeneous updates translate them equally, so both normalized waiting
variants exactly cover arbitrary waiting times. Every first-crossing
residue is included. The local descending pronic and square maps have
their jumps on the correct inclusive sides of the endpoints.

An independent zero-error equal seed is included in every common region
and at either wall's new-side endpoint. This covers an arbitrary equal
central overshoot, including skipped bins. The homogeneous lower-half
state is cleared after the wall simulation; its possible transient clamp
is not omitted. An arbitrary unequal initial seed is not required by
the theorem and is not claimed to be covered.

Every intermediate state during a wall crossing and both waiting
variants are checked against the frozen MODEL MINIMUM. Thus the test
asks for BOTH physical deficits to be below the actual model exit value,
not merely for one phase or for a target at the bottom of the region.
This is enough for every terminal threshold Z>=H, including one crossed
inside a wall window. Extending a local map past a later descending wall
is conservative during the comparison: the real root costs decrease,
so the real physical deficit cannot be larger than that extrapolation.

The exact replay returned maximum exit offsets16 and18 for d=1,2,
strictly below the minimum spacing27 at b>=32. Consequently all states
propagated to the next wall use the exact local maps; no branch traverses
an unmodeled wall. The final homogeneous interval ends at H, and the
same conservative extrapolation handles any terminal overshoot.

Final state counts are45 and42 for d=1,2; every intermediate and common
check has delay at most two. The redundant d=3,4 rows have delay one.
The resulting all-width conclusion follows from the symbolic coverage
and finite state proof together, not from extrapolating chosen widths.

This review does not itself verify the assembled low/central/high phase
interface or the final full-game numerical constant.

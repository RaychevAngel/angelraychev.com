# Independent review of critical bulk cells and physical passage join

24 October 2026 UTC. Accepted ordinary mathematical components. Source
hashes and exact replay counts are in `physical-critical-and-join-review.json`.

## Critical constant-root cells

The displayed low and high matrices follow entry by entry from
`src/bridge_corner_frontier.py`, using the stated root constancy at q-8
through q and deficit-1 through deficit+1. For q>=9, rho(2q)>=rho(q)+1;
for deficit>=9, rho(2*deficit)>=ceil(sqrt(deficit+1)) away from the excluded
square wall. Thus the two exceptional minimum branches simplify as stated.
The roots above b+1 are inactive after the width caps, including beta=alpha-1
and delta=gamma-1. Physical phase costs agree with the accepted exact
prefix erosion formulas in the even and odd coupling sources.

Both geometric exclusions are valid. The symbolic certificate was
reexecuted on all 1,532 cells. An independent min-plus iteration from all
three equal seeds additionally checked the path bound through length 12
for every cell (18,384 exact checks). The universal argument is cycle
erasure: every deleted simple cycle costs at least its length times mu;
the remaining path has at most two edges, each costing at least mu-1/2.
It therefore loses at most one room, independent of the residence time.

One scope qualification: the outer finite-board cap after adding k is
not necessarily inactive merely from the input critical-region condition
when k is unrestricted. The affine matrix is always an upper envelope;
it is exact while the update stays in the guarded bulk. This does not
weaken the proposed local upper comparison. No stopping/overshoot gluing
or complete capture-time gap is asserted by this review.

## Physical passage joined to the accepted necessary model

The sharp version with H<=Q_cross<=Z<h-k and a*=h-Z is accepted. The
continuation starts above k, so the existing guarded merger remains valid
through the first gate Q>=h-k. Its merged target at that gate is positive
and at most k. One final inspection therefore completes the model path,
giving gate time at least j0+s*-1. The reversed-walk cut has matching day
indices: g forward moves meet g-1 reverse moves plus a final reverse
inspection on original day g+1. Both sets have more than h positions,
contradicting a 2g-day winning schedule.

The exact overshoot G_k(H-1)=H-1+k-rho(H-1+k) follows by inverting
y+ceil(sqrt(y))<=H-1+k. The passage guards keep the crossing target below
b^2, where the scalar physical inequality is proved. It yields the stated
k-b+10 overshoot, rather than an unnecessary k-room loss. Forward-hole
passage clocks and backward capture thresholds remain distinct.

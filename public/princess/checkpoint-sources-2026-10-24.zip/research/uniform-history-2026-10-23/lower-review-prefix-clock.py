"""Independent literal-grid check of the parity-generic prefix helper.
Not a new board-family certificate or a width search.
"""
from pathlib import Path
import hashlib, importlib.util, json
HERE=Path(__file__).resolve().parent
SOURCE=HERE/'root-prefix-clock.py'
spec=importlib.util.spec_from_file_location('reviewed_prefix_clock',SOURCE)
mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
boards=[(1,2),(1,10),(2,7),(3,4),(3,8),(4,4),(4,7),(5,6),(5,10),(6,9),(7,8)]
counts={'prefixes':0,'whole_neighborhood_prefixes':0,'literal_solo_clocks':0}
for w,n in boards:
    orders=[sorted(((x,y)for x in range(w)for y in range(n)if(x+y)%2==p),key=lambda xy:(sum(xy),-xy[0]))for p in(0,1)]
    h=w*n//2
    def hood(S):
        return {(x+dx,y+dy)for x,y in S for dx,dy in ((1,0),(-1,0),(0,1),(0,-1))if 0<=x+dx<w and 0<=y+dy<n}
    for p in (0,1):
        for q in range(h+1):
            S=set(orders[p][:q]);N=hood(S)
            expected=mod.neighborhood_size(w,n,p,q)
            assert expected==len(N),(w,n,p,q,'cardinality',expected,len(N))
            assert N==set(orders[1-p][:expected]),(w,n,p,q,'prefix closure')
            if q:
                D,C=mod.parameters(w,n,p,q)
                assert S=={(x,y)for x,y in orders[p]if x+y<D or(x+y==D and x>=C)}
            counts['prefixes']+=1;counts['whole_neighborhood_prefixes']+=1
        for k in range(w//2+1,h+2):
            S=set(orders[p]);phase=p;day=0
            while True:
                day+=1
                # Delete the last k occupied prefix cells, leaving the prefix.
                S-=set([v for v in orders[phase]if v in S][-k:])
                if not S:break
                S=hood(S);phase^=1
                assert day<=2*h+2,(w,n,k,p,'nontermination')
            assert mod.clock(w,n,k,p)==day,(w,n,k,p,mod.clock(w,n,k,p),day)
            counts['literal_solo_clocks']+=1
out={'status':'PASS','counts':counts,'boards':boards,'source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),'audit_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'scope':'Literal prefix sets, neighborhood prefix closure, and full physical solo histories; no width sweep or new mathematical family claim.'}
(HERE/'lower-review-prefix-clock.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))

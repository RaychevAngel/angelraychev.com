# A uniform critical-passage bound

24 October 2026 UTC. Proposed ordinary comparison theorem for independent
review. It joins the accepted constant-root graph comparison. The constant
is deliberately crude; no complete all-width capture-time theorem is
claimed here, because the low/high physical-history interfaces are separate.

## Statement

Let w<=n, wn even, b=floor(w/2), k=b+d with d>=1, and h=wn/2. Set

    C=11, b>=14, A=(b-C)^2, V=d+C, v=2d-1.

Let B(t) be the ordinary three-corner backward frontier, following the
accepted finite-board update in `src/bridge_corner_frontier.py`. Assume
the horizon-monotone orbit is at time t0 with

    A <= m0=max B(t0) < h-A.

Let X(s) be the physical two-phase prefix orbit from equal seeds, using
the exact finite-board maps in the accepted physical erosion identities.
Assume at some time s0 that min X(s0)>=m0. Let t1 be the first subsequent
model time with max B(t1)>=h-A. Then

    min X(s0+(t1-t0)+7153) >= max B(t1).

Truncation at h is understood. The same statement holds for an ordinary
frontier restarted at time t0 from the equal upper envelope (m0,m0,m0),
which overapproximates any finer frontier whose entries are at most m0.

This supplies a constant-delay passage through the entire central region
on every rectangle, including the shortest ones. It does not assume a
long affine middle, exact phase matching at entry, or a fixed width.

## Structural input: frontier spread and maximum increment

After its first update, the ordinary frontier satisfies

    B0<=B1<=B2,        Bc<=B0+c.

Indeed the source choices for c are nested, including the source size cap.
For fixed target j and every retained i, each of the three candidate costs
(small inverse, large inverse, width cap) obeys cost(0,j)<=cost(i,j)+i.
This follows directly from the displayed square/pronic inverse formulas:
the low shifts are by2i with an added i, the high inverse loses at most i,
and a special cap saves at most one and has i>=1. The source size caps
h-2+i have exactly the same Lipschitz property. Therefore each survivor
bound for retained i is at most its retained-zero bound plus i. Maximizing
over i<=c and targets j gives Bc'<=B0'+c. The initial zero-horizon frontier
has the asserted spread after one step; the equal restarted frontier has
it initially. We use only the consequence B_j>=max B-2.

Every ordinary cost is at least

    min(rho(T),ceil(sqrt(h-T)),b).

This is the scalar profile already implied by the small, high, and strip
branches. Since rho(A-2)>=b-C for b-C>=3, while max B<h-A, every input
T=B_j lies in [A-2,h-A), and every transition cost is at least b-C.
The maximum frontier increment is therefore at most

    max B(t+1)-max B(t) <= k-(b-C)=V.              (1)

An output size cap can only reduce this increment.

## Structural input: physical advancement

Both physical maps are nondecreasing and are at least the identity before
the final cap. The even-width phase costs are each at most b; the odd-width
costs are at most b and b+1. Hence for every input pair

    X(s+2) >= min(h,X(s)+v)                        (2)

coordinatewise. An orbit started from equal seeds is coordinatewise
nondecreasing. Its crossed update and the identity lower bounds then give

    min X(s+1) >= max X(s).                       (3)

These statements hold globally, across root walls and with output caps.

## A fixed finite partition

Take the relevant scalar root jump locations

    z=r^2+1,       z=r(r+1)+1,

for max(0,b-C-4)<=r<=b+2, and their reflected locations h-z. Around each
location remove the integer interval of radius12. Intersect with the
critical range [A,h-A-1], and merge overlapping or adjacent intervals.
Call these merged intervals walls; the remaining intervals are bulk cells.

There are at most J=4(C+7)=72 original intervals, since the index range
has at most C+7 elements. Their combined number of integer positions is
at most W=25J=1800. There are at most J walls and J+1 bulk cells.

The radius12 covers the two-room frontier spread and every inverse shift
q-8 through q and h-q-1 through h-q+1. In a bulk cell the exact capped
matrix costs are consequently fixed. Root jumps above the stated index
range are inactive after the width cap; below it none of the shifted
arguments can reach the critical range. At a low endpoint b-C=3, the
index range is truncated at zero and is smaller than the displayed bound.

The C=11 matrix certificate is `adversary-critical-eleven.json`, obtained
from the same exact symbolic algorithm as the independently reviewed
C=10 certificate. It has1,660 parameter cells. In each, every cycle costs
at least the physical phase mean mu, and every edge costs at least mu-1/2.
Thus an affine model segment from entries bounded by z has

    max B(t) <= z+t*(k-mu)+1,                     (4)

whereas the affine physical orbit from (z,z) has maximum at least
z+t*(k-mu). Output caps on the model preserve the upper inequality.

## Passage through one wall

Suppose the model maximum enters a wall [l,u] at m>=l, and the physical
minimum is at least m. Run the model until it first exits the wall, or
until the final critical exit. Its exit maximum is at most u+V by(1).
For a wall containing W_i integer positions, its exit maximum exceeds
the entry maximum by at most W_i+V. By(2), the physical minimum catches
that exit maximum within

    2*ceil((W_i+V)/v) <= 2*(W_i+C+1)

additional physical days. Allowing also the elapsed model days only
weakens this bound. Skipped walls require no payment.

## Passage through one bulk cell

Suppose the model maximum enters [l,u] at z, with physical minimum>=z.
Let t be the number of model steps until its first exit, or the critical
exit. All model input roots during these steps have the fixed bulk costs;
the final output may lie beyond the cell. The model exit maximum m is
at most u+V.

Compare with a physical orbit started from (z,z). Until its maximum first
exceeds u it has precisely the same constant physical phase costs. If it
has not exited by time t, (4) implies its maximum is at least m-1>=u.
By(2), it therefore exits within t+2 steps. If it exited earlier, this
claim already holds. Monotonicity transfers the claim to the original
physical orbit, whose starting minimum was at least z.

One additional step makes the physical minimum at least u+1 by(3).
At most 2*ceil((V-1)/v) more steps then make its minimum at least m.
The extra time, beyond the model's t steps, is at most

    3+2*ceil((V-1)/v) <= 2C+3.                    (5)

This explicitly handles overshoot; the affine matrix is not continued
beyond its root cell.

## Joining the finite partition

At every visited interval reestablish the invariant that physical minimum
dominates model maximum, using the preceding two passage lemmas. Model
maxima are nondecreasing, so no interval is revisited. Sum the payments:

    delay <= 2W+2J(C+1)+(J+1)(2C+3)
          <= 4(C+7)(4C+55)+2C+3
          =7153,        for C=11.

This proves the stated passage claim, subject to independent review of
the elementary frontier-spread and root-partition interfaces. The bound
is not advertised as numerically sharp. The substantial point is that
the duration of a critical cell can grow with b, while the additional
time allowed for that cell cannot.

## Scope of the conclusion

The theorem is a comparison of an accepted necessary corner frontier and
explicit physical prefix clocks through a specified region. It is not
yet a proof that T lies within a universal constant of the retained
physical upper bound: the low-region entrance comparison, high-region
exit comparison, merger into the two-cohort game, and any small-budget
base ranges must be joined with their own precise interfaces. No Lean
formalization is asserted for this new argument.

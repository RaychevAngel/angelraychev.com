"""Independent literal target-hole predicates versus symbolic labelled interval unions."""
from pathlib import Path
import importlib.util,math,random,time,json,hashlib
P=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('bin_review',P/'lower-dual-bin-interval.py')
m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)

def label(w,n,i,u,j,v,q,T,critical,wide):
 h=w*n//2;b=w//2;D=w+n-2;s=T-q;holes=h-T
 if 2<=s<b and i==2 and j==1 and(s-1)**2<holes<=s*s:
  M=(math.isqrt(8*(s*s-holes)+1)-1)//2
  return D%2,min(D,D-2*s+1+2*M)
 if 2<=s<b and j==2 and v==1 and(s-1)*(s-2)<holes<=s*(s-1):
  M=(math.isqrt(8*(s*(s-1)-holes)+1)-1)//2
  return 1^(D%2),min(D,D-2*s+2+2*M)
 if i==1 and j==0 and 2<=s<b and((s-1)**2 if wide else s*(s-1))<q<=s*s:return 1,2*s-1
 low=(2<=s<b and(s-1)*(s-2)<q<=s*(s-1))or(critical and s==b and q==b*(b-1))
 if i==0 and low and(j==1 or q==s*(s-1)):return(0,2*s-2)if(j,v)==(1,0)else None
 if j==2 and 2<=s<=b and q==h-s*s:
  kappa=(1+int(w==n))if w%2==0 and s==b else 0
  if critical and(i,u,v)!=(1,2-kappa,1):return None
  return 1^(D%2),D-2*s+2
 if i==2 and j==1 and 2<=s<b and q==h-s*(s+1):return D%2,D-2*s+1
 return -1,-1

start=time.process_time();rng=random.Random(2026102453);checks=points=0
cases=[(6,6),(6,7),(7,8),(8,8),(8,9),(9,10),(10,10),(12,13),(14,14),(14,15)]
for w,n in cases:
 h=w*n//2
 for critical,wide in((True,True),(False,True),(True,False),(False,False)):
  _,_,_,relation,cap,_=m.engine(w,n,w//2+1,critical,wide)
  for j in range(3):
   for v in range(3):
    for i in range(v+1):
     for u in range(j+1):
      qmax=h-4+i+u;top=h-4+j+v;direct={}
      for q in range(1,qmax+1):
       row={}
       for T in range(1,top+1):
        if cap(T,i,u,j,v)<q:continue
        key=label(w,n,i,u,j,v,q,T,critical,wide)
        if key is not None:row[key]=row.get(key,0)|(1<<T)
        points+=1
       direct[q]=row
      intervals=[(1,qmax),(1,1),(qmax,qmax)]
      for _ in range(12):
       a=rng.randint(1,qmax);intervals.append((a,rng.randint(a,qmax)))
      for qa,qb in intervals:
       want={};got={}
       for q in range(qa,qb+1):
        for key,mask in direct[q].items():want[key]=want.get(key,0)|mask
       for d,R,lo,hi in relation(i,u,j,v,qa,qb):got[d,R]=got.get((d,R),0)|sum(1<<T for T in range(lo,hi+1))
       assert want==got,(w,n,critical,wide,i,u,j,v,qa,qb)
       checks+=1
sources=[Path(__file__),P/'lower-dual-bin-interval.py',P/'lower-dual-bin-stability.md']
out=dict(status='PASS',labelled_interval_unions=checks,admitted_fixed_q_target_points=points,flag_combinations=4,CPU_seconds=time.process_time()-start,source_sha256={z.name:hashlib.sha256(z.read_bytes()).hexdigest()for z in sources})
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print(out)

# Full initial triangles from near-extremal quadrant capacity

24 October 2026 UTC. New proposed ordinary theorem; independent review pending.
This strengthens a history certificate. No uniform capture-time gap is claimed.

Write

    m(d)=max{m>=0:m(m+1)/2<=d}.

The integer d below is a cardinality defect, not a relative color.

## 1. A quantitative full-layer lemma

Let S be a finite set of one color in a genuine nonnegative quadrant. Assume
its occupied distance layers from the origin are consecutive and begin at
distance p, where p is zero or one. Suppose its neighborhood surplus is at
most r, and

    p=0: (r-1)^2 < |S| <= r^2;
    p=1: (r-1)(r-2) < |S| <= r(r-1).

For p=0 also suppose the origin belongs to S. Suppose the original support
is contained in the ball of radius 2r-2-p. Then S contains every cell of
its color on the first

    L-m(d) layers, where L=r-p and d=L(L+p)-|S|.

In particular the guaranteed full inner radius is 2(L-m(d)-1)+p. A
nonpositive number of full layers means an empty certificate.

**Proof.** The containing ball has L layers. If the last layer were empty,
the total size could be at most (r-1)^2 for p=0 and (r-1)(r-2) for p=1.
Thus there are exactly L occupied layers. Diagonal compression preserves
all layer counts a_j, their occupied indices, and the containing ball,
and cannot increase the neighborhood. The unconditional quadrant profile
forces compressed surplus r. Every occupied diagonal contributes at least
one to the surplus, while the initial output contributes exactly p (for
p=1 its count a_0-epsilon_0 is one whether a_0=1 or 2). Consequently every
occupied output layer has surplus exactly one. The usual layer formula
therefore gives

    a_{j+1} <= a_j+1+epsilon_{j+1},

where epsilon_j=1 precisely for a full diagonal. If a layer is nonfull,
the next cannot be full: its full size is two greater than the previous
full size, whereas the displayed inequality would permit at most that
size minus one. Once nonfull, the layer deficits therefore increase by
at least one on every succeeding layer. If M terminal layers are nonfull,
their total defect is at least 1+...+M. Thus M<=m(d). All preceding layers
are full, and since compression preserved their counts, they were full
in the original set too. This is a statement about the raw set, not merely
its compressed image.

The localization hypotheses are supplied in rectangles by the accepted
wide-square theorem and pronic-interval theorem. The containing ball and
consecutive-layer assumptions are not asserted for an arbitrary set near
capacity without the relevant corner conditions.

## 2. Bin-wide high-square reset

Let w<=n, wn even, w>=4, b=floor(w/2), h=wn/2, D=w+n-2. Let S be a
survivor, A=N(S), q=|S|, T=|A|, original surplus T-q=r, and let (i,j)
be their respective occupied own-corner counts. Suppose

    i=2, j=1, 2<=r<b, (r-1)^2 < h-T <= r^2.

Put d=r^2-(h-T), M=m(d). Then A has an outer radius certificate

    (D mod 2, min(D,D-2r+1+2M)).

Here the first coordinate is the relative color of the anchor. To prove
this, put U=V_A minus A. It has exactly one own corner, and N(U) contains
no opposite corner because S contains both source-colored corners. Its
surplus is at most r, since N(U) is disjoint from S. The wide-square
localization theorem makes U a genuine quadrant set in radius 2r-2 with
surplus exactly r. Section 1 gives a full inner hole ball of radius
2r-2-2M. Distances to diagonal opposite corners sum to D, so this is the
asserted outer support ball. At d=0 this is the accepted equality reset.

## 3. Bin-wide high-pronic reset

In the same setting let v=e(A) count the source-colored corners whose
entire neighbor pair belongs to A. Suppose

    j=2, v=1, 2<=r<b,
    T-q=r, (r-1)(r-2) < h-T <= r(r-1).

Put d=r(r-1)-(h-T), M=m(d). Then A has the outer certificate

    (1 xor (D mod 2), min(D,D-2r+2+2M)).

Indeed the target holes U have no own corner, and N(U) contains exactly
2-v=1 source-colored corner. Also its surplus is at most r. The accepted
pronic-interval localization theorem puts U in a genuine quadrant about
this opposite-colored corner, in radius 2r-3, with consecutive odd layers
and surplus exactly r. Section 1 forces its first r-1-M layers full,
and complementation gives the certificate.

The premise v=1 is intentional: j=2 alone does not select the odd-corner
quadrant throughout this entire bin. The old exact high-pronic theorem
has the stronger critical endpoint r=b and no v premise; it is retained
separately. No critical bin-wide extension is claimed here.

## 4. Original-surplus guarded merger

Both resets are preserved by the existing positive guarded merger. Assume
both component original surpluses are positive. They sum to r and hence
are strictly below b, so both have the subcritical F/G alternatives.

A small component has target size at most r(r-1), whereas the merged
target h-z, with z the hole count, is greater than r(r-1). Thus both
components must use their high alternatives. In the pronic event j=2
forces j_1=j_2=2, whose target-hole capacities are at most
s_ell(s_ell-1). Their sum is at most (r-1)(r-2), contradicting the strict
lower endpoint for z.

In the square event i=2 forces i_1=i_2=2, and j=1 forces the outgoing
corner counts to be (1,2) or (2,1). The respective high capacities are
s_1^2 and C_2(s_2), where C_2(s)<=s(s-1) and C_2(1)=0. For positive
s_1+s_2=r, convexity gives

    s_1^2+C_2(s_2) <= (r-1)^2,

including the other endpoint 1+C_2(r-1)<=(r-1)^2. This contradicts
the square-bin lower endpoint. Thus one component has zero original
surplus. As in the accepted equality-reset proof, it is full-to-full,
so the merged transition equals the other component, including q,T,i,j,v
and the cardinality defect d. Hence the same reset radius is inherited.

This argument uses original surplus throughout; it does not replace a
full-to-full partner with one whose closed support alone is full.

## 5. Computational implementation obligation

These events specify the target T=q+r, with r determined by the target
hole bin. As q varies, the defect d varies linearly and m(d) is constant
between triangular numbers. Therefore a bin can be split into exact
interval records, with labels indexed by both r and m(d). No per-cell
enumeration is needed.

For fixed q put H=h-q. The square trigger requires

    r(r-1)+2 <= H <= r(r+1),

and the pronic trigger requires

    (r-1)^2+2 <= H <= r^2.

The intervals for distinct r are disjoint, with one omitted integer
between successive intervals. Thus there is still at most one exceptional
target for a fixed q and feature tuple. As q rises from the last event
in one r-bin to the first event in the next, q rises by two and r falls
by one, so q+r increases by one. Within a bin it increases with q.
Low and high events remain separated by the old size gap, and the
retained critical pronic equality is disjoint from all subcritical bins.
Hence exceptional target injectivity survives, and the accepted
single-exception ordinary-tail repair proof still applies.

The static nine-feature bands already exclude every wide-square event
except (i,u,j,v)=(2,1,1,2) and every wide-pronic event except (1,2,2,1).
For these tuples the whole indicated q-bin is admitted: the refined high
capacity is respectively r^2 and r(r-1), the ordinary high capacity agrees,
and all feature-size upper bounds hold. Therefore the exact records need
only split these intervals at triangular defects; there is no hidden
optimization or numerical admission search within a record.

The zero-leakage radius-conditioned scalar drift explored before this
lemma is redundant with accepted corner profiles and area capacities.
The new information here is forced occupancy of whole inner layers;
their complements give persistent exclusions across a nontrivial range
of near-equality events.

# Independent coverage review of the five-bin wall automaton

Accepted for the complete low passage from equal seed A=(b-5)^2
through first reaching b^2, for b>=22 and d=k-b in{1,2,3,4}.
The calculation gives physical MINIMUM at least the model's actual
exit MAXIMUM within two additional physical steps. It enumerates no
rectangle widths. Source hash and replay results are in the adjacent
JSON receipt. This review does not silently extend the conclusion to
arbitrary initial root levels or intermediate stopping targets.

## Why the normalized states retain all necessary information

The state contains both ordered model coordinates and both labeled
physical coordinates, normalized by subtracting the model maximum.
In a lower half root bin the maps are F(u)=u+v and G(u)=u+v+1;
in an upper half bin both are u+v. After two common-region updates,
all four coordinates have the same net translation. The model's
tie/one-room pattern and the two physical phase errors therefore have
period at most two after normalization. Enumerating the state and one
common-region successor covers EVERY possible waiting duration.

At the first crossing of a wall the old model maximum is negative and
its next increment is at most v+1. Its integer position must therefore
be one of -v-1,...,-1. The code includes every such translation of
both waiting variants, and filters only those that do not actually
cross next. No congruence class depending on b is omitted. The residues
at different walls are allowed to vary independently, a valid relaxation.

The local wall maps use the exact root flats. At a pronic wall only G
drops by one. At a square wall only F drops by one. The simulation runs
until all four coordinates have crossed, then takes one homogeneous
step to clear a possible outstanding upper-half tie clamp. Thus the
next normalized state is again suitable for the two waiting variants.

## Separation proves the local formulas remain valid

Consecutive pronic/square walls in a root r are distance r apart. The
smallest relevant r is b-4>=18. The independently replayed maximum
exit offset, INCLUDING the clearing step, is16. Therefore a local
crossing simulation never reaches the next wall. Monotonicity also
keeps all earlier states within this window. Before the next crossing,
all intervening updates use precisely the homogeneous maps accounted
for by the two variants.

At the beginning, the first step from the equal square endpoint A
remains tied and advances d+5<=9. It lies before the first pronic wall,
whose distance from A is b-4>=18. Thus the normalized zero state is
the correct initial state in the first lower half bin.

After the final pronic wall the maximum recorded exit offset is at
most12, while the remaining distance to the square endpoint b^2 is
b-1>=21. Consequently the model has not prematurely crossed the
terminal target during the wall calculation.

## The terminal audit checks the required phase minimum

At the first final-target crossing, the old model maximum lies in
-d,...,-1 relative to b^2. The finish routine enumerates these positions
and both homogeneous waiting variants. It freezes the actual model
exit maximum, including its overshoot, then advances the labeled
physical pair until its MINIMUM reaches that exact value. The maximum
number of steps is two, so this is not merely a best-phase or nominal
target statement.

The terminal local F flat is one room after b^2; G is unchanged until
b^2+b+1. Model overshoot is at most d-1, and two further updates reach
offset at most3d-1<=11<b+1. Thus every terminal physical step uses a
valid root formula. Actual finite-board caps and high branches can only
increase these physical capacities, so the local physical comparison
remains conservative.

The replay returned final state counts6,11,16,19 for d=1,2,3,4,
respectively, with terminal delays2,2,2,1 and no failure. These finite
counts accompany the completeness argument above; they are not a
sample-based inference about unexamined widths.

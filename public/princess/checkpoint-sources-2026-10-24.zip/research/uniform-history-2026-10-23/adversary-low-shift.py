"""Mechanism diagnostics for low-only recurrence comparison, not coverage certificates."""
from pathlib import Path
import sys, json, random, time
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'research/uniform-gap-2026-10-23')]
import comparison_band9 as c

def run(w,k):
    B=(0,)*9; X=(0,0); r=w//2
    worst=0; witness=None; day=0; failures=[]
    while min(B+X)<(r+3)**2 or not c.normal(w,B):
        nxt=c.base.physical_infinite(w,k,X)
        lead=max(B)-max(X)
        if lead>worst:worst=lead;witness=(day,B,X)
        if max(B)>max(nxt):failures.append((day,B,X,nxt))
        B=c.infinite_step(w,k,B);X=nxt;day+=1
        assert day<10*(r+3)**2
    return dict(w=w,k=k,days=day,max_room_lead=worst,witness=witness,
                middle_lead=max(B)-max(X),drift=2*k-w,
                one_day_shift_failures=failures)

if __name__=='__main__':
    rng=random.Random(917542)
    cases=[(w,w//2+1)for w in [6,7,22,23,98,99,198,199,498,499,998,999]]
    cases += [(w,rng.randrange(w//2+1,2*w+2))for w in [rng.randrange(6,500)for _ in range(40)]]
    start=time.process_time();out=[]
    for w,k in cases:
        row=run(w,k);out.append(row)
        print(w,k,row['max_room_lead'],row['middle_lead'],len(row['one_day_shift_failures']),flush=True)
    data=dict(status='diagnostic',claim='No universal theorem is inferred from these cases',
              CPU_seconds=time.process_time()-start,rows=out)
    (HERE/'adversary-low-shift.json').write_text(json.dumps(data,indent=2)+'\n')

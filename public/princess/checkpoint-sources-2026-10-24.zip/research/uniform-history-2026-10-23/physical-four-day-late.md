# Four-day uniform physical late passage

24 October 2026 UTC. Refinement of the independently accepted physical
late-passage proofs. All their geometric and clock conventions remain
unchanged. The improvements here are nonexpansive-map counting and
exact last-crossing bookkeeping.

For w<=n, wn even, b=floor(w/2)>=6 and k>=max(33,b+1), put H=(b-5)^2.
Suppose an actual two-cohort history starts at merged residual m_s>=H
and first reaches m_g<=k at time g. Then a physical anchored-prefix
residual trajectory started at H, in EITHER initial phase, reaches
residual<=k within

    g-s+4

transitions. For33<=k<=74, the sharper allowance is3. If k>=H, the
reference is already at the gate and no allowance is needed.

## At most three fast-exit days for k>=75

Use the notation of `physical-five-root-late.md`: scalar backward map
G(x)=k+x-rho(x), alternate physical map F(x)=k+x-ceil(sqrt(x)), and
v=k-floor(2k/3)-2. Both maps are nondecreasing and1-Lipschitz; F<=G
and G-F<=1.

A physical backward phase orbit uses F on at most ceil(t/2) of its first
t updates. At a G update, its deficit from the all-G scalar orbit does
not increase; at an F update, the deficit increases by at most one.
Thus after t updates the deficit is at most ceil(t/2), rather than t.
The accepted fast-exit proof already establishes t<=5v at the first
scalar hit of the required initial residual. Consequently

    ceil(t/2)<=ceil(5v/2)<=3v.

Every additional physical update below that target gains at least v.
Three further updates suffice. The same final-inspection/gate conversion
as in the original proof gives a fast actual interval of ell transitions
a physical gate trajectory of at most ell+3 transitions.

For33<=k<=74 the exhaustive parameter certificate in
`physical-late-small-budget-check.json` already proves fast allowance2.
No new enumeration is needed.

## Crossing resets are paid by the ignored actual durations

Retain the exact last-crossing notation from the accepted proof:

* t0 is the last crossing into m<=H, or s if there is no such later
  crossing and m_s=H;
* t1 is the first subsequent time with m<=F_cut, where F_cut=R^2+k;
* t2 is the last return to m<=F_cut, or t1 if there is no later excursion.

The H reset needs one reference step only when t0>s. In that case the
ignored actual duration t0-s is at least one. If t0=s, the initial
reference H already lies below m_s=H, so this reset is omitted.

Similarly the F_cut reset needs one reference step only when t2>t1.
Its ignored actual excursion duration t2-t1 is then at least one.
If t2=t1, the slow comparison has already placed the reference below
the actual residual, so that reset is omitted.

Write delta_H and delta_F for these zero-or-one reset steps. The exact
reference transition count is at most

    delta_H+(t1-t0)+1+delta_F+(g-t2)+C_fast,

where the one is the possible initial phase adjustment in the slow
segment. Since delta_H<=t0-s and delta_F<=t2-t1, this is at most

    g-s+1+C_fast.

Using C_fast=3 for k>=75 and2 for33<=k<=74 proves the statement.
If the slow interval is empty, there is no phase adjustment and the
bound is stronger. As always, stop the reference if it has already
reached the gate at any earlier stage.

This is an unconditional physical late-passage inequality. It does not
by itself supply the early/critical/full-game joining theorem or a Lean
formalization.

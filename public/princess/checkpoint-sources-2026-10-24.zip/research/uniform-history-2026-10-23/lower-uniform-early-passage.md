# Uniform eight-day early passage for every budget at least33

24 October 2026 UTC. Ordinary theorem submitted for independent review.
This extends `lower-five-root-passage.md`; accepted earlier sources are
unchanged. It is a physical two-cohort passage, not a full capture bound.

Let w<=n, wn even, b=floor(w/2)>=6, h=wn/2 and k>=max(33,b+1).
Set H=(b-5)^2. Start both physical cohorts with no holes. If tau is the
first time their total holes Q reach H, then the smaller hitting time J
of H by the two zero-seed physical forward-hole prefix trajectories obeys

    J<=tau+8.                                       (1)

There is no restriction on whether the slow interval is nonempty.
The finite part of the proof checks42 scalar budgets, with no board
enumeration or width cutoff.

## The scalar and physical maps

Write rho(y) for the least nonnegative integer r with y<=r(r+1), and

    G(x)=x+k-rho(x+k),
    F(x)=x+k-ceil(sqrt(x+k)).

They are nondecreasing,1-Lipschitz, F<=G, and G(x-1)<=F(x).
An alternating F/G orbit is the genuine-quadrant forward-hole prefix
orbit. For targets up to H its prefixes and their neighborhoods fit in
the rectangle. Even if an update's unconstrained target is much larger,
the actual finite-board physical prefix reaches every target y<=H that
the quadrant inverse permits. Thus its hitting time of H is no larger
than the quadrant hitting time used below. This is an inverse-neighborhood
comparison, and does not assert that large finite-board updates still
have the quadrant formula.

The accepted scalar surplus argument gives sigma>=ceil(sqrt(Q'))
whenever a physical target Q'<=b^2. Consequently the scalar G orbit
dominates the physical hole history up to any target A<=H. Here large
crossing overshoots must be clipped, not silently assumed subcritical.
If Q'>=A+ceil(sqrt(A)), then Q'+sigma>=A+ceil(sqrt(A)) follows from
sigma>=0. Otherwise Q'<A+ceil(sqrt(A))<=H+sqrt(H)<b^2, and the scalar
surplus bound gives the same conclusion. Thus an actual first hit of A
cannot precede the scalar first hit of A, even for an arbitrarily large
inspection budget.

## A general cutoff and the slow reset charge

Choose

    R=floor(4k/5) for33<=k<75,
    R=floor(2k/3) for k>=75,
    L=R^2, v=k-R-2, D=k-R-1.

In both cases R>=2k/3, v>0, and k>R. On a slow interval

    R<r=ceil(sqrt(Q))<=b-4,

call a target good if its actual total hole surplus sigma<=r+3.
Exactly the proof in `lower-five-root-passage.md` gives a unique dominant
physical cohort/corner, at most four nondominant surplus units and at
most16 outlier holes. Its phase supplies the exact square/pronic profile
for the entire Q. Every bad transition earns two rooms of reference lead.

For a good-identity change separated by Delta transitions, with r the
new target root, the physical matching charge gives

    Delta*k >= (r^2-9r-66)/2.

This expression increases for r>=R+1>=27. Hence, putting

    Delta0=ceil(((R+1)^2-9(R+1)-66)/(2k)),

it suffices that 2(Delta0-1)>=D. The smaller rewind proof is valid for
this general R: if q>R^2 and X_j-q>=D, monotonicity and
rho(q-1+k)>=R+1 imply X_(j-1)>=q. A paid rewind flips phase without
losing domination. No reset losses accumulate with the number of events.

For k>=75 the polynomial proof from the previous note establishes the
charge. For33<=k<75 the exact integer audit establishes it with at least
six spare rooms. The audit is `lower-parameter-passage-audit.py`, with
its complete42-row receipt in the adjacent JSON file.

All reference candidates remain genuine quadrant prefixes: R>=2k/3
and r<=b-4 give Q+k<=b^2-6.5b+10<b(b-1). The dominance and reset
arguments therefore do not assume an unevaluated finite-board profile.

## Fast entry and the fast-only branch

Let t_G be the scalar first hit of L+1, and J_entry the larger of the
two alternating quadrant-prefix hitting times of L+k. For k>=75,
the earlier nonexpansive/drift proof gives J_entry<=t_G+8, because

    8v^2-kv-R^2 >= (k^2-78k+288)/9 >0.

For33<=k<75, direct exact arithmetic of the three scalar recurrences
gives the stronger J_entry<=t_G+7. No parameter of a board occurs in
that finite calculation.

If H<=L, the whole passage is fast. For k>=75, let t be the scalar
first hit of H. Before that hit the scalar drift is at least v, so
t<=ceil(H/v). At time t either alternating prefix is at least H-t.
Each further step below H gains at least v. The same displayed
polynomial gives t<=8v, and hence at most eight additional steps suffice.
For33<=k<75, the audit checks every integer target1<=A<=R^2, finding
that BOTH alternating phases hit A at most two steps after the scalar.
The clipped scalar argument proves (1) in this branch. Finite-board
updates only need to attain the target; no large quadrant overshoot is
used as a physical state.

## Last crossing in the nonempty slow branch

Suppose H>L, equivalently b-5>R. Before the first physical hit of H,
choose the last state with Q<=L and let t0 be the following time.
Then Q_(t0)<=L+k and t0>=t_G. Both reference phases reach the entry
envelope by reference time J_entry<=t0+8.

Every state from t0 to the first H hit has root greater than R. The
final overshoot is still in the slow window:

    Q_tau<=H+k<=(b-4)^2,

since k<1.5(b-5)<=2b-9. Select the initial reference phase to agree with
the first good event, if any. Advance once per physical step and use
the paid rewinds at later convention changes. At the final state its
index is at most tau+8 and its size is at least H. This proves (1)
without requiring the physical history to be monotone.

## Boundary of the conclusion

This is a uniform early passage theorem. The full capture-time bound
still requires a critical-region comparison and an early/late joining
argument with explicit clock conventions. The computed finite budgets
are a proof of elementary scalar arithmetic, not selected rectangle
evidence or a substitute for the physical argument.

# Independent review of the low-budget late passage

Accepted the generic-R extension and the42-budget arithmetic base in `physical-late-small-budget.md`. The physical proof is the independently reviewed five-root late passage; its changed root cutoff preserves every structural and rewind guard.

An independent reproduction computed all inverse maps by binary search in explicit neighborhood-size arrays, without using the closed-form root inverses. It checked all163,432 target/phase pairs, recovering maximum fast loss two and minimum twice reset-credit margin573. No rectangle dimensions were enumerated. Source hashes and exact counts are in `lower-review-small-budget-late.json`.

This confirms the eight-day physical late passage uniformly for b>=6 and k>=max(33,b+1). It does not by itself prove the full capture-time gap.

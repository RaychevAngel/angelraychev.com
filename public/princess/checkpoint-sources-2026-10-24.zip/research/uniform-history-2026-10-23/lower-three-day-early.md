# A uniform three-day early passage

24 October 2026 UTC. Strengthening submitted for independent review.
The physical concentration, reset and last-crossing proof is exactly
`lower-uniform-early-passage.md`. Only its fast-entry allowance is
sharpened here. The old accepted eight-day result is left intact.

For every even-area rectangle with b=floor(w/2)>=6 and
k>=max(33,b+1), put H=(b-5)^2. If the physical two-cohort total hole
count first reaches H at time tau, then one of the two zero-seed physical
forward-hole prefix trajectories reaches H by time tau+3.

## The true entry envelope and the half-frequency discrepancy

Retain the cutoff R of the preceding theorem: floor(4k/5) for33<=k<75,
and floor(2k/3) for k>=75. Write L=R^2 and u=k-R-1.

In the nonempty slow branch H>L, a last crossing from Q<=L has target
at most L+k. That target is below b^2, so the actual scalar surplus
inequality applies to it. Its true upper envelope is therefore

    Z=G_k(L)=L+k-rho(L+k)<=L+u,                    (2)

because k>R implies rho(L+k)>=R+1. This replaces the earlier coarse
entry envelope L+k.

Let t_G be the scalar G_k first hitting time of L+1. At that time
either alternating F_k/G_k prefix orbit is at least

    L+1-ceil(t_G/2).                               (3)

Indeed, scalar and physical updates are nonexpansive, and the scalar
G-only orbit can gain at most one additional room on an F step; on a
G step the discrepancy cannot increase. Either phase uses F at most
ceil(t_G/2) times.

For k>=75 every alternating step before reaching Z gains at least u.
Its input x satisfies x<Z<=L+u, so

    x+k<=L+2k-R-2<=(R+1)^2,

where2k<=3R+3. Thus even the smaller F map subtracts at most R+1.
The same lower drift holds for a physical reference below any target
at most L. These updates fit in a genuine quadrant on the slow branch.
On the fast-only branch only the target prefix must fit, as explained
by the clipped inverse-neighborhood argument in the preceding theorem.

## A two-stage bound on the scalar crossing time

For k>=75 put S=floor(R/2) and p=k-S-3. Until the scalar G orbit first
exceeds S^2 it gains at least p per step: rho(S^2+k)<=S+3 follows
from k<=7S+12. From that crossing until it exceeds L, it gains at
least u. Therefore

    t_G <= ceil((S^2+1)/p)+ceil((R^2-S^2)/u)
        <= 4u.                                    (4)

Here is an exact check of the second inequality for the three residue
classes, writing k=3m+j. In each case m>=25.

* j=0: R=2m, S=m, u=m-1, p=2m-3. The first ceiling is at most m-8,
  since m^2+1<=(m-8)(2m-3); the second is exactly3m+4.
  Their sum is at most4m-4=4u.
* j=1: R=2m, S=m, u=m, p=2m-2. The first ceiling is at most m,
  since m^2+1<=m(2m-2); the second is3m. Their sum is at most4u.
* j=2: R=2m+1, S=m, u=m, p=2m-1. The first ceiling is at most m-5,
  since m^2+1<=(m-5)(2m-1); the second is3m+5.
  Their sum is at most4u.

The three displayed polynomial inequalities hold at m=25 and have
positive derivatives thereafter. All denominators are positive.

Combining (2)--(4), at time t_G either prefix lacks at most
u-1+2u=3u-1 rooms to reach Z. Three further steps therefore suffice.
Both initial phases attain the actual last-crossing entry envelope by
time t_G+3.

If H<=L, let t be the scalar first hitting time of H. Then t<=t_G<=4u.
The alternating prefix is at least H-ceil(t/2)>=H-2u, and each step
below H gains at least u. Thus both phases reach H within t+2 steps.
The clipped scalar argument still handles arbitrarily large actual
crossing overshoots. No assumption on the slow range is needed.

## The42 smaller budgets

For33<=k<75 the scalar quantities are finite parameter-only arithmetic.
`lower-three-day-early-check.py` computes t_G and the two alternating
hitting times of the exact envelope Z=G_k(R^2), for every one of these
budgets. Their maximum excess is3. The accepted all-target audit already
shows fast-only excess at most2 for every target through R^2; the new
check reproduces this as well. There is no width or length enumeration.

## Physical conclusion

The accepted general-R slow reset charge is unchanged. At the last
crossing of L, both reference phases attain its now sharper envelope
within three days of the actual crossing. Choose the phase agreeing
with the first good event and use the paid rewinds for later phase
changes. The same last-crossing argument then proves

    J_H <= tau_H+3.

This is a physical passage inequality, independently of the numerical
nine-feature lower evaluator. It does not by itself establish the
global capture-time gap or the remaining critical-region comparison.

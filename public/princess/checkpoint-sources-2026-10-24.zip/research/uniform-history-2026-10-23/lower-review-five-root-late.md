# Independent review of the five-root late passage

Accepted as an ordinary physical-history theorem, with exactly its stated guards.

Source: `physical-five-root-late.md`

SHA-256: `7524ecfd3ae0803c4c9b909c99d8ce11fbe7ad81d40709767431dd2184c9536d`

The signed survivor quantity is used consistently: the small survivor cohort dominates it, and the co-small deficit only strengthens the required square/pronic phase bound. The two possible identity changes use different valid transport witnesses. The smaller rewind allowance is applied at a slow source, where the inverse root profile gives its required strict inequality.

The fast argument uses backward capture capacities, which are nonexpansive. Its additional final clearing inspection cancels when the result is expressed as transitions to residual at most the budget. The three crossing/alignment allowances and the five-day fast exit total eight. Last crossings, rather than any monotonicity assumption on the actual history, dispose of excursions.

This review does not establish the global early/critical/late joining comparison or a full uniform capture-time gap.

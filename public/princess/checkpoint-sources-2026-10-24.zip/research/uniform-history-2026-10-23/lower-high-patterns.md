# A finite pattern system for the isolated high boundary

24 October 2026 UTC. Proposed algebraic reduction, with a symbolic certificate.
It is a tool toward a uniform clock comparison, not such a comparison itself.

## Exact isolated operator

Write D(c,e)=h-B(c,e), where B is the nine-feature backward threshold. Define
H(d;A,B) to be the accepted function `theta_high(d,A,B)`. For retained
features (i,u) and target features (j,v), put

    C(d;i,u,j,v) = (v-i)+H(d;2-j,2-v),

then apply the two existing static-band penalties:

* If (j,v)=(1,2), u!=1, and r=ceil(sqrt(d))>=2, replace C by
  max(C,(v-i)+r+1).
* If j=2, r is the least integer with d<=r(r-1), and
  d>[(r-1)(r-2) if v=1, else max(r(r-1)/2,r(r-2))], replace C by
  max(C,r+1) unless (i,u,v)=(1,2,1).

The isolated high-boundary update is

    G(c,e) = min_{0<=j,v<=2}
      [D(j,v)+C(D(j,v);min(c,v),min(e,j),j,v)],
    D'(c,e)=max(4-c-e,G(c,e)-k).                 (H)

The displayed min chooses among nine fixed alternatives. Its pattern
analysis below does not iterate over width, budget, or rectangle length.

Why maximal retained features suffice: the ordinary high term decreases
when i increases and does not depend on u. Each static penalty either does
the same or disappears when its required i/u is reached. Taking
i=min(c,v),u=min(e,j) is therefore optimal. These choices obey the existing
maximality condition i>=max(0,c+v-2). All deletion charges are at most four,
so the full-budget backward update permits them when k>=4.

## A safe physical interface, deliberately conservative

Let b=floor(w/2)>=10, h>=2b^2, and suppose

    4<=D(c,e)<=(b-8)^2 for every c,e.

Then (H) is exactly the accepted unflagged nine-feature backward update.
Indeed each target T=h-D(j,v) exceeds b(b-1). A subcritical small-side
capacity at reduced surplus s<b would force T<=s(s+1)<=b(b-1), impossible.
Every high root and both static penalties in this range have reduced
surplus strictly below b: theta_high is at most b-3, and the added root
penalties are no larger. Thus neither the width cap nor a critical
exception is active. The source feature-size upper bound is automatic
before subtracting k because D(j,v)>=4. The final source feature bound is
exactly the max(4-c-e,...) in (H).

This interface is sufficient, not optimal. It does not yet establish that
every full-board threshold trajectory enters with one of the patterns
below. The near-critical interface and short-board overlap remain explicit
obligations for a complete time theorem.

## Nine normalized patterns

Let d=min D, and write D=d+P in row-major (c,e) order. The following nine
patterns are closed under G after subtracting min G, for every integer
d>=4:

    000/000/000
    111/000/000
    111/110/000
    111/110/100
    111/110/110
    111/111/000
    222/111/100
    222/211/100
    322/211/100.

Each three-digit group is one row c=0,1,2. The even and odd affine-middle
patterns occur among these nine. This closure concerns G. If terminal
floors in (H) are active, they must be handled separately; they are not
silently discarded.

For a fixed pattern P, write d=r^2+u with 0<=u<=2r. Every branch is then

    min G=d+r+gamma(P,cell),
    normalized G=P'(P,cell),

where gamma is a fixed integer and P' is one of the listed patterns. The
cells have endpoints affine in r. Thus the nonterminal scalar transition is

    d'=d+r+gamma-k.

## Why the finite certificate covers unbounded root indices

For r>=32 the offsets of d entering every square/pronic root are bounded
absolute integers. On a cell u in [a*r+b,c*r+e], a square root equals r+s
if and only if

    (r+s-1)^2 < r^2+u+offset <= (r+s)^2.

After cancellation both inequalities are affine in r and u. Their extrema
over the cell occur at the two endpoints. Nonnegative slope together with
the correct sign at r=32 proves them for every larger r. The pronic root
is handled identically using (r+s-1)(r+s-2) and (r+s)(r+s-1).

For the C2 inverse, the root branch 1+ceil(sqrt(d+offset+1)) is the smaller
one throughout this range. The certificate proves the necessary comparison
with the other pronic root using a quadratic polynomial whose value and
derivative are positive from r=32 onward. Static-band comparisons are also
affine on these cells. Every branch test is therefore uniform in r.

All relevant cuts lie among u=a*r+b for a=0,1,2 and -10<=b<=10. Their order
is stable for r>=32, again checked by affine inequalities. The resulting
43 cells for each of nine patterns give 387 symbolic cells. The remaining
finite deficits 4<=d<1024 are checked directly, for 9,180 pattern/deficit
pairs. The program uses exact integers only. A separate arithmetic check
calibrates every symbolic cell against the original unsimplified root
formulas; the proof of unbounded coverage is the sign checks, not that
calibration sample.

The source `lower-high-pattern-certificate.py` and its JSON table contain
the full transition specification. `lower-high-patterns.py` specifies the
isolated operator independently using the original root functions.

## The remaining mathematical inequality

The reduction does not by itself bound how far this finite-pattern scalar
orbit can lead the two alternating physical prefix clocks. Such a bound
must telescope across the square/pronic cells; a separate error allowance
per cell would still accumulate over unboundedly many cells. The point of
this reduction is to make that final debt comparison a fixed-pattern
problem, while retaining every root-bin change exactly.

# Independent review of late4 and the absolute-bound assembly

Accepted the four-day late refinement and the combined theorem as an
application of the separately reviewed critical50 statement. Exact source
hashes are in `lower-review-uniform-assembly.json`.

The H crossing reset is omitted when t0=s and otherwise costs at most the
ignored positive duration t0-s. The F crossing reset is similarly omitted
when t2=t1 and otherwise costs at most t2-t1. Thus these two resets do not
contribute to the final additive allowance. The one remaining possible
phase adjustment plus the three-day fast exit gives four. The underlying
geometric proof and all42 smaller-budget scalar checks were independently
reviewed earlier.

For w>64, b>=32 and every feasible budget is at least33. The k>=3b range
meets both accepted high-budget one-day thresholds. In the remaining
range the displayed three cut guards hold. In addition, rho(H-1+k)<=b
and k>=b+1 imply Z>=H, so M=h-Z<=h-H, while the gap guard gives M>H.
These are exactly the critical theorem's interval conditions.

The three-passage joining uses the old necessary merger only while its
source residual exceeds H>k. Its late overlap is one transition, giving
the gate lower S-8 where S=J+c_*+P_H. The reversed-walk cut then gives
T>=2S-15. The constructed prefix capture clock satisfies P<=S+52.
Therefore T>=2P-119 and the retained upper U<=2P has gap at most119.
The arithmetic, phase maxima, and first/final inspection conventions
are consistent.

The review does not identify119 as small or sharp, does not prove a
universal two-day gap, and does not assert complete Lean coverage.

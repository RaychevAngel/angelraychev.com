"""Challenge a root-independent symmetric-balancing comparison."""
from pathlib import Path
import random,json
HERE=Path(__file__).resolve().parent

def sample(rng,N,flats):
    positions=sorted(rng.sample(range(2,N-2),flats))
    fflat=[];previous=0
    for end in positions:
        fflat.append(rng.randrange(previous+1,end+1));previous=end
    def seq(points):
        p=set(points);out=[0]
        for x in range(1,N):out.append(out[-1]+int(x not in p))
        return out
    return seq(fflat),seq(positions)

def run(seed=342621,trials=2000):
    rng=random.Random(seed)
    for trial in range(trials):
        N=2000;nf=rng.randrange(2,45);k=nf+rng.randrange(2,12)
        f,g=sample(rng,N,nf)
        assert all(0<=f[i+1]-f[i]<=1 and 0<=g[i+1]-g[i]<=1 for i in range(N-1))
        assert all(g[i-1]<=f[i]<=g[i]for i in range(1,N))
        X=(0,0);B=(0,0);trace=[]
        while max(X+B)<N-k-2:
            Y=(k+g[X[1]],k+f[X[0]])
            trace.append((X,B))
            if max(B)>max(Y):
                return dict(status='counterexample',trial=trial,k=k,f=f,g=g,trace=trace,next_physical=Y)
            a,b=k+g[B[1]],k+f[B[0]];m=max(a,b)
            B=(max(a,m-1),max(b,m-1));X=Y
    return dict(status='no counterexample',seed=seed,trials=trials)

if __name__=='__main__':
    out=run();(HERE/'adversary-interlacing.json').write_text(json.dumps(out,indent=2)+'\n')
    print({k:v for k,v in out.items()if k not in('f','g','trace')})

"""Discover normalized high-only frontier patterns, not width certificates.

This is an algebraic diagnostic of a proposed reduced high-only operator.
It does not assert its unbounded-bin closure or a capture-time comparison.
"""
from pathlib import Path
from functools import lru_cache
import importlib.util,sys,json,time,math
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'src'))
from bridge_lower_frontier_nine import theta_high,root,pronic
FEATURES=[(c,e)for c in range(3)for e in range(3)]


@lru_cache(None)
def cost(d,i,u,j,v):
    delta=v-i;s=delta+theta_high(d,2-j,2-v)
    if (j,v)==(1,2) and u!=1:
        r=root(d)
        if r>=2:s=max(s,delta+r+1)
    if j==2:
        r=pronic(d)
        threshold=(r-1)*(r-2) if v==1 else max(r*(r-1)//2,r*(r-2))
        if r>=2 and d>threshold and (i,u,v)!=(1,2,1):s=max(s,r+1)
    return s


def image(d,pattern):
    return tuple(min(d+pattern[3*j+v]+cost(d+pattern[3*j+v],min(c,v),min(e,j),j,v)
                     for j,v in FEATURES) for c,e in FEATURES)


def normalized(xs):
    low=min(xs)
    return tuple(x-low for x in xs)


def algebra_audit():
    p=ROOT/'research/uniform-gap-2026-10-23/lower-band9.py'
    sp=importlib.util.spec_from_file_location('accepted_band9',p)
    m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
    # A single arbitrary large rectangle is a vehicle for checking the
    # algebraic high-only formula, not a claimed family of game bounds.
    w,n,k=100,1000,51;h=w*n//2
    seeds=[tuple(int(c==0)for c,e in FEATURES),tuple(int(c<2)for c,e in FEATURES),(0,)*9]
    checks=0
    for pattern in seeds:
        for d in range(4,2300,7):
            B={f:h-d-pattern[z]for z,f in enumerate(FEATURES)}
            actual=m.step(w,n,k,B)
            expected=tuple(max(4-c-e,g-k)for (c,e),g in zip(FEATURES,image(d,pattern)))
            got=tuple(h-actual[f]for f in FEATURES)
            assert got==expected,(d,pattern,got,expected)
            checks+=1
    return checks


def discover(maxd=2000):
    initial={tuple(int(c==0)for c,e in FEATURES),tuple(int(c<2)for c,e in FEATURES),(0,)*9}
    known=set(initial);todo=list(initial);edges={};witnesses={p:None for p in initial}
    while todo:
        p=todo.pop()
        for d in range(4,maxd+1):
            q=normalized(image(d,p));edges[p,q]=edges.get((p,q),0)+1
            if q not in known:
                known.add(q);todo.append(q);witnesses[q]=(d,p)
                assert len(known)<100,('pattern explosion',len(known),q)
    return sorted(known),edges,witnesses


if __name__=='__main__':
    start=time.process_time();checks=algebra_audit();patterns,edges,witnesses=discover()
    out=dict(status='finite algebra diagnostic; no universal closure claim',
             algebra_checks=checks,deficit_range=[4,2000],pattern_count=len(patterns),
             patterns=[dict(pattern=p,first_witness=witnesses[p])for p in patterns],
             transitions=[dict(source=p,target=q,count=n)for (p,q),n in sorted(edges.items())],
             CPU_seconds=time.process_time()-start)
    Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
    print({k:v for k,v in out.items()if k!='transitions'})

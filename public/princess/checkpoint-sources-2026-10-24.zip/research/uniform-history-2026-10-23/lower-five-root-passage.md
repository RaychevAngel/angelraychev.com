# A smaller rewind allowance and a five-root passage

24 October 2026 UTC. Strengthened variant submitted for independent review.
The accepted earlier eight-day/eleven-root passage is left unchanged.
This note changes constants in its physical history argument, not its
authority boundary or the separate full-game clock-comparison goal.

## A smaller exact rewind allowance

Put R=floor(2k/3), L=R^2 and

    D*=k-R-1=floor((k-1)/3).

Suppose the current actual total hole count is q>L. Consider a forward
prefix capacity sequence X_j and a step whose source below q would still
be in the genuine-quadrant range. If X_j-q>=D*, then X_(j-1)>=q.

Indeed, otherwise X_(j-1)<=q-1. The larger of the two prefix updates is

    G_k(x)=x+k-rho(x+k),

where rho(N) is the least r with r(r+1)>=N. Since q>=R^2+1 and k>R,

    q-1+k>=R^2+k>R(R+1),

so rho(q-1+k)>=R+1. Monotonicity gives

    X_j<=G_k(q-1)<=q+k-R-2=q+D*-1,

a contradiction. Thus a D*-room lead, rather than a k-room lead, pays
one reference rewind in this slow range. The predecessor is still ahead
of the actual count and has the opposite phase.

## Slow-interior constants

Assume k>=75 and b=floor(w/2). On a physical two-cohort hole-history
interval put r=ceil(sqrt(Q)) and assume

    2k/3<r<=b-4.                                    (I)

Call a target good when its total actual neighborhood surplus sigma is
at most r+3, and bad otherwise. A good state has sigma<b. The same
small-branch exclusions as in `physical-slow-block.md` apply: r>=51,
Q>=(r-1)^2+1>sigma^2/2, and h-Q>sigma(sigma+1).

The sharper dominant-component theorem gives at most four units of
nondominant surplus. To verify this, if m>=5, the decreasing quadratic
capacity on m<sigma/2 would imply

    Q<=(sigma-5)^2+25<=(r-2)^2+25
      <(r-1)^2+1,

where the last inequality holds for r>=14. This is impossible. Thus
the dominant physical cohort/corner is canonical and there are at most
16 holes outside it. The exact aggregated square/pronic phase profile
remains valid, with no remainder correction.

For consecutive good states whose dominant identities differ, let Delta
be their time separation and use the root r of the new good state. The
accepted matching block charge yields

    Delta*k >= (r-1)^2+1-32-(r+3)(r+2)/2
             = (r^2-9r-66)/2.                       (2)

All Delta-1 intervening states are bad. Since r is an integer strictly
larger than2k/3, it is at least2k/3+1/3. The quadratic in (2) is
increasing on this range, so

    Delta-1 >= 2k/9-34/9-310/(9k).

Every bad transition has surplus at least r+4. The exact credit lemma
therefore earns two rooms per step, retaining at least
min(D*,old_lead+2). There are enough bad steps before the new good
transition because

    2(Delta-1)-D*
      >= (k^2-65k-620)/(9k) > 0                     (3)

for k>=75. At75 the numerator is130, and its derivative is positive
thereafter. A phase-convention change requires an identity change, so
the new rewind allowance applies before every required phase reset.
Identity changes preserving phase need no reset.

All candidate capacities used by the bad-credit and rewind arguments
fit the genuine quadrant. From r<=b-4 and k<1.5r,

    Q+k<=(b-4)^2+1.5(b-4)=b^2-6.5b+10<b(b-1),

on the present range b>=55. Both colors' prefixes up to b(b-1) fit
inside the board with their whole quadrant neighborhoods. Thus their
profiles are the exact square/pronic profiles, rather than a conjectured
extension through the finite-board cap.

The rest of the phase-tracking proof is unchanged: advance the reference
once per actual transition; before a mismatched good event rewind once,
using the freshly earned D* lead. No forward reference-day losses
accumulate over arbitrarily many phase changes.

## The eight-day passage now reaches five roots below b

Suppose in addition

    b-5>floor(2k/3).

Put H=(b-5)^2. Let J be the smaller of the two genuine-prefix forward
hole hitting times of H, starting at0. If tau is the first actual
two-cohort total-hole hit of H, then

    J<=tau+8.                                       (4)

The fast entry argument in `root-interior-passage.md` remains valid at
k>=75: with v=k-R-2,

    8v^2-kv-R^2 >= (k^2-78k+288)/9 >0.

The last polynomial has value63 at75 and increases thereafter. Thus
both reference phases reach the entry envelope R^2+k within at most
eight additional days beyond the scalar first crossing.

The new guard implies R+2<=b-4, so that entire entry estimate is still
inside the new slow window. Before the first hit of H, choose the last
state with Q<=R^2. All subsequent states lie above that lower cut, and
the final overshoot satisfies

    Q_tau<=H+k<=(b-4)^2,

because k<1.5(b-5)<=2b-9 on this range. Hence every intervening state
satisfies (I), even if its size retreats. The strengthened slow phase
tracking now proves (4), exactly as in the earlier passage proof.

## Full-game joining consequence and remaining limitation

Apply `lower-physical-passage-join.md` with this new H and

    Z=G_k(H-1),   a*=h-Z,
    j0=max(0,J-8),
    s*=min{s>=1 : max_(c,e) B_s(c,e)>=a*}.

The coarse joining guard holds: k<1.5(b-5), h>=2b^2 imply
h-H-2k>b^2+7b-10>0. Therefore

    T_k(w,n)>=2(max(0,J-8)+s*)-1.                    (5)

The sharper overshoot is only

    Z-H<=k-b+4,

and F_k(H)>=G_k(H-1)=Z, so one additional physical prefix day catches
that entire envelope. This supplies an additional computable lower with
the cut five roots below b instead of eleven, and expands the clean
parameter gate from k>=108 to k>=75. It does not assert that its numerical
value dominates every earlier cut for every instance; retain their maximum.

It does not prove that (5) is within a fixed number of the physical upper
days. The remaining uniform clock comparison, the critical finite root
bands, and the other budget ranges remain explicit obligations.

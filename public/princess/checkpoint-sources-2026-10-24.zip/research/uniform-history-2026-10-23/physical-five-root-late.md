# Uniform physical late passage with five excluded roots

24 October 2026 UTC. Proposed ordinary theorem for independent review.
It strengthens the earlier late-passage candidate and keeps its two
physical cohorts throughout. No new merger or Lean claim is made.

## Statement

Let w<=n, wn even, b=floor(w/2)>=6 and k>=max(75,b+1). Set

    H=(b-5)^2, R=floor(2k/3), F=R^2+k.

For any physical joint history, write m_t=|A_t^0|+|A_t^1|-h after t
complete inspections and moves, where h=wn/2. Suppose m_s>=H, and let
g be the first later time with m_g<=k. Then a physical anchored-prefix
residual trajectory starting at cardinality H, in EITHER initial phase,
reaches residual<=k within g-s+8 transitions.

If k>=H this is immediate, since the reference is already at the gate.
In the rest assume k<H; this also implies b>=14. No hypothesis that
H exceeds R^2 is needed: if H<=F, the late history is handled by the fast
part alone. These are decreasing physical belief prefixes; they are not
the earlier forward-hole prefix capacities.

## Scalar inequality and crossing interlacing

For a physical transition put

    q=m-p=|S^0|+|S^1|-h>0,  0<=p<=k,
    sigma=sum_i (|N(S^i)|-|S^i|),  m_next=q+sigma.

For q<=b^2 one has sigma>=ceil(sqrt(q)). Indeed this is immediate if
sigma>=b. If sigma<b, the accepted subcritical size dichotomy for each
actual survivor is either |S^i|<=sigma_i^2 or
h-|S^i|<=sigma_i(sigma_i+1). Both survivors cannot be small, since
q>0. Both cannot be co-small, since that would give
q>=h-sigma(sigma+1)>b^2. The small survivor has size at least q and at
most sigma^2, proving the claim.

In the genuine quadrant the physical residual prefix maps for x>k are

    phi_0(x)=x-k+ceil(sqrt(x-k)),
    phi_1(x)=x-k+1+rho(x-k),

with both zero for x<=k. Here rho(u) is the least integer r with
u<=r(r+1). They are nondecreasing and strictly increasing for x>k;
phi_0<=phi_1 and

    phi_1(x)<=phi_0(x+1).                            (1)

Consequently a physical step from a reference residual<=x lies below
any actual crossing from >x to <=x, for k<x<=H. Even if that crossing
source exceeds b^2, its survivor q is at most its target m_next<=H,
so the preceding scalar inequality still applies. All prefix survivors
used at residual<=H are genuinely in a quadrant, since H<b(b-1).

## Good slow transitions concentrate in one actual corner

During the slow segment the source residual obeys

    F<m<=H.

Thus q>=m-k>R^2 and q<=H, and r=ceil(sqrt(q)) satisfies

    r>2k/3, r>=51, r<=b-5.

Call the transition good if sigma<=r+3, and bad otherwise. At a good
transition sigma<=b-2, q>sigma^2/2, and exactly one actual survivor
cohort P is small; the other is co-small. Write q=|P|-D, with D its
other-cohort survivor-hole count. Apply the additive component argument
of `physical-dominant-corner.md` to P, reserving the other cohort's
surplus as unused nonnegative surplus. There is a unique dominant
component with surplus a>sigma/2. Put z=sigma-a. Then

    q<=(sigma-z)^2+z^2.

This forces z<=4: for z>=5 the right side is at most
(sigma-5)^2+25<=(r-2)^2+25<(r-1)^2+1<=q. Thus the small cohort has at
most16 cells outside the dominant component, and the other cohort has
at most z(z+1)<=20 holes. The dominant component has a unique actual
corner anchor and lies in its radius2a-2 ball.

Its phase yields an EXACT inequality for the signed q. For own-anchor
color, q<=sigma^2. For opposite-anchor color,

    q<=|P|<=a(a-1)+z^2<=sigma(sigma-1).

Thus sigma is at least the corresponding physical quadrant surplus
beta_phase(q). No correction for the remainder is necessary.

## Actual identity changes pay for a small rewind

The matching survivor transport proved in `physical-late-slow-block.md`
gives, between consecutive good transitions Delta apart,

    Delta*k >= |K minus f^Delta(S_new)|

for every old survivor subset K. If the small cohort is unchanged but
its dominant anchor changes, apply it to the old dominant component.
The distinct-corner half-intersection bound and the two16-cell outlier
budgets give, with the OLD r,

    Delta*k >= (r-1)^2+1-(r+3)^2/2-32
              =r^2/2-5r-34.5
             >=2k^2/9-10k/3-35.

If the small cohort changes, apply transport to the old LARGE cohort,
which has size at least h-20; its new size is at most(b-1)^2. The
resulting charge h-20-(b-1)^2 is stronger. Therefore every convention
change has Delta-1 intervening bad transitions, with

    3(Delta-1)>=2k/3-13-105/k>=k/3                  (k>=75), (2)

where the last inequality follows from k^2-39k-315>0.

Suppose the physical reference X<=m has not yet reached the gate.
Set u=X-k and lead D=m-X. At a bad actual transition, q>=u+D and
sigma>=r+4, whereas either reference phase satisfies beta(u)<=r+1.
Hence

    m_next-X_next>=D+3.                              (3)

At a good transition with aligned phase, the exact signed-q inequality
and monotonicity preserve X_next<=m_next.

The needed rewind credit is smaller than k. Define

    D0=k-R-1<=k/3.

At a slow source m>F, ceil(sqrt(m-k))>=R+1, hence
phi_0(m)>=m-D0. If X_j<=m-D0, then X_j<=phi_0(m). Were X_(j-1)>m,
strict monotonicity and phi_phase>=phi_0 would imply
X_j>=phi_0(m+1)>phi_0(m), a contradiction. Thus X_(j-1)<=m: one
reference rewind preserves domination and flips phase.

By (2) and (3), all intervening bad transitions earn D0 credit before
the next phase-changing good transition. The reset is paid. Every later
reset has its own preceding bad block. An arbitrary initial phase needs
at most one extra reference advance, and all-bad endpoints need no
phase alignment. This proves the slow interval comparison with at most
one extra reference day. It allows arbitrary retreats of m while
F<m<=H.

## Every fast residual exit costs at most five days

Consider an actual interval of length ell, starting at k<m0<=min(F,H),
whose source residuals stay at most min(F,H) and whose final residual is
at most k. The scalar backward capacity

    Y_0=0, Y_(t+1)=k+Y_t-rho(Y_t)

satisfies m0<=Y_(ell+1), by the physical scalar inequality plus one
final clearing inspection. The two alternating physical backward
capacities use this map and x -> k+x-ceil(sqrt(x)). These maps are
nondecreasing,1-Lipschitz and differ by at most one. At the first t
with Y_t>=m0, either physical phase capacity is at least Y_t-t.

Put v=k-R-2>0. While below m0, all inputs are below F=R^2+k<(R+1)^2,
so every scalar/physical backward increment is at least v. Consequently

    t<=ceil(F/v)<=5v,

where the last inequality follows from F<=5v^2, itself implied by

    5*(k/3-2)^2-(4k^2/9+k)
      =(k^2-69k+180)/9>0                            (k>=75).

Five further physical updates erase the at-most-t-room capacity deficit.
Thus either phase of a prefix of size<=m0 reaches the gate within
ell+5 transitions. The maps need their exact quadrant form only while
the input is below m0<=H, which has already been checked. This argument
uses nonexpansive backward capacities, not an invalid nonexpansiveness
assumption on the decreasing forward residual maps.

## Last crossings finish the proof

Take the last actual crossing into residual<=H before the gate, at time
t0. If m_s=H and there is no subsequent excursion above H, use t0=s.
After t0 the actual residual stays at most H. One reference advance
from H puts it below m_(t0), by (1). This extra advance is harmless if
t0=s, when it was unnecessary.

If H<=F, the remaining history is entirely fast and the fast lemma
finishes within a further g-t0+5 transitions, proving the asserted
bound (in fact six rather than eight extra transitions).

If H>F, let t1 be the first time after t0 with m_(t1)<=F. Before it,
all source residuals lie in the slow interval, so reference domination
through t1 costs at most t1-t0+1 additional transitions. If there is
later an excursion above F, let t2 be its last return to <=F; otherwise
take t2=t1. One more reference advance puts it below m_(t2), by (1).
The remaining actual interval stays below F and H, so the fast lemma
finishes within g-t2+5 further transitions.

The total reference time is at most

    (t1-t0)+(g-t2)+1+1+1+5<=g-s+8.

All ignored excursion durations are nonnegative. At every stage stop
if the reference already reached the gate. This proves the statement.

## Scope

The theorem handles every k>=max(75,b+1), with b>=6, including budgets
where the slow range is empty. It is a genuine physical late passage,
independent of a low-boundary numerical-model comparison. Joining the
separate early and critical passages and handling the remaining bounded
width/budget regime are still required for a full uniform capture gap.

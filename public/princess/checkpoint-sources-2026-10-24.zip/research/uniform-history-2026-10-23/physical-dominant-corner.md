# A dominant actual corner for every near-capacity small set

24 October 2026 UTC. Ordinary physical theorem proposed for independent
review. This is a spatial stability result, not a uniform capture-time gap.

## Connected quadrant localization without a corner-count hypothesis

Call a set of one checkerboard color two-step connected if the graph on
its cells, joining two cells that share a grid neighbor, is connected.
Let U be such a nonempty set in a genuine quadrant. Write

    q=|U|, s=|N(U)|-|U|.

If q>s(s-1)/2, then U is contained in the corner ball of radius 2s-2.
Neither occupation of the origin nor a prescribed outgoing corner is
required.

Proof: use the diagonal compression and notation in the accepted
punctured-quadrant theorem, `paper/sections/quadrant-boundary-profiles.tex`.
Let h be the smallest occupied distance from the origin, and L the number
of occupied distance layers. The compressed surplus delta is at most s.
The branch with no full diagonal has cardinality at most
delta(delta-1)/2, so is impossible. In the other branch the existing
layer estimate gives L<=delta-h<=s-h. Two-step connectivity implies that
the occupied distance layers are consecutive: the distance changes by
zero or two along each two-step edge. Consequently the largest distance
is h+2(L-1), which is at most 2s-h-2<=2s-2. Compression preserved all
layer counts, so this bounds the original, uncompressed set. QED.

The strict threshold matters. Proper ramps of size s(s-1)/2 can float
arbitrarily far along a quadrant axis while retaining surplus s.

## General finite-board concentration

Let w<=n, wn even, b=floor(w/2). Let S be a one-color set with surplus
s<b in the **small side** of the accepted separator dichotomy. In other
words its contracted support avoids the common strongly connected
component in `research/resumed-even-corner-profile.md`. Suppose

    q=|S|>s^2/2,
    d=s^2-q.

There is a unique two-step component U of largest surplus s*. Put
m=s-s*. Then

    s*>s/2,       0<=m<=M(s,q)<=floor(d/s),
    |S minus U|<=m^2,
    U lies in a ball of radius 2s*-2 about an actual board corner.

Here M(s,q) is the largest integer m<s/2 satisfying
2m(s-m)<=s^2-q. Equivalently

    M(s,q)=floor((s-sqrt(2q-s^2))/2).

Thus all but at most M(s,q)^2 rooms are localized in one corner ball.
The result applies to cornerless sets as well as to sets containing their
anchor corner.

Proof: the existing empty matched-row and empty paired-column separators
partition S into four genuine corner quadrants, with disjoint whole
quadrant neighborhoods. Every two-step connected component lies in one
piece. Distinct two-step components also have disjoint neighborhoods by
definition. Their intrinsic surpluses s_i are positive integers, sum to
s, and the quadrant profile gives q_i<=s_i^2. If s*=max s_i, then

    q<=sum s_i^2<=s* sum s_i=s*s*.

Therefore s*>s/2 and is unique, and m=s-s*<=d/s. The other components
have total cardinality at most (sum_{i!=*}s_i)^2=m^2. The dominant
component has

    q* >= q-m^2 > s^2/2-m^2 >= (s*)^2/2.

For the last inequality, writing s=s*+m and 0<=m<s*, the difference is
m*s*-m^2/2>=0. In particular q*>s*(s*-1)/2. The connected quadrant
lemma puts U in radius 2s*-2 of its actual board corner. QED.

The sharper remainder bound follows from
q<=s*^2+m^2=(s-m)^2+m^2: hence 2m(s-m)<=d. The quadratic is strictly
increasing on 0<=m<s/2, giving the formula for M. In particular
q>(s-1)^2+1 forces m=0. For s>=3 the lowest integer of the near-square
bin q=(s-1)^2+1 can allow m=1; every larger integer in that bin forces
a single connected component. This is a topological statement even
without knowing either corner count.

Both the component and its corner are canonical. The component is
intrinsic to physical two-step connectivity. For corner uniqueness,
suppose it fitted two different corner balls of radius 2s*-2. This radius
is smaller than w-1. Balls about opposite corners are disjoint; for
adjacent corners their intersection is strictly on one side of the
coordinate-swap symmetry in either corner ball. Thus the intersection
has at most half that ball's cells, hence at most (s*)^2/2. This
contradicts q*>(s*)^2/2. The argument does not assume the same separator
on different days.

## How to guarantee the small branch numerically

The theorem itself assumes the small branch. A sufficient numerical
condition is

    h_board-q>s(s+1),  where h_board=wn/2,

since this excludes the co-small alternative of the ordinary profile.
In particular q<=s^2 and s<b automatically give this condition on every
even-area rectangle: h_board>=2b^2 and
2b^2-s^2>s(s+1) for s<=b-1. This is the range relevant to a near-capacity
small hole set. No localization is asserted for a co-small set under
the same notation.

## A physical two-cohort bridge, without a synthetic support

The same theorem applies to both cohorts jointly in the following sense.
Suppose a joint inspection-and-move step has source survivors S_0,S_1,
target beliefs A_i=N(S_i), and original surpluses

    r_i=|A_i|-|S_i|,    r=r_0+r_1<b.

Let U_i be the target holes in the appropriate color class and let
Q=|U_0|+|U_1|. Assume r^2/2<Q<=r^2. Then among the physical two-step
components of BOTH hole sets there is a unique component with surplus
s*>r/2. It has an actual cohort and an actual corner, lies within radius
2s*-2 of that corner, and all other holes together have size at most
m^2, where

    m=r-s* <= M(r,Q).

Indeed the dual surpluses t_i=|N(U_i)|-|U_i| obey 0<=t_i<=r_i,
because N(U_i) avoids S_i. Each hole set is in the small branch:
h_board-|U_i|>=h_board-r^2>r(r+1)>=t_i(t_i+1).
The canonical component capacities and surpluses therefore add across
the two cohorts, with total surplus at most r. If s* is the largest
component surplus, Q<=s* sum s_i<=s*r, so s*>r/2 is unique.
The remaining component surpluses sum to at most m=r-s*, giving outside
mass at most m^2. The same dominant-size and punctured-layer arguments
prove localization, while Q<=(r-m)^2+m^2 gives m<=M(r,Q).
Unused surplus only enlarges m and does not invalidate any inequality.

This is an ordinary necessary condition on a physical joint history.
It does not assume that the merged scalar feature itself is a physical
support, and it does not yet specify a merger of arbitrary certificate
labels in the relaxed evaluator.

## A blockwise anchor charge without a full inner core

Suppose H_t and H_(t+Delta) are physical hole sets meeting the preceding
small-branch hypotheses, with parameters (q_old,s_old,m_old) and
(q_new,s_new,m_new). Suppose their dominant components are assigned
different actual board corners. For any positive integer Delta,

    sum_(j=0..Delta-1)|I_(t+j)|
      >= q_new-m_new^2-s_new(s_new-1)/2-m_old^2.      (3)

In particular the right side is at most Delta*k under daily budget k.
Intermediate hole sets need not meet any localization hypothesis.

To prove (3), let U be the new dominant component and v its surplus.
The stronger fixed-matching block inclusion from
`physical-matching-block.md` gives

    |N(U) minus f^(Delta-1)(H_t)|<=sum |I_(t+j)|.

The old dominant component after f^(Delta-1) lies within radius
2s_old-2+((Delta-1) mod 2) of its old corner. This is strictly smaller
than w-1. The new component U lies in radius 2v-2 of its corner, so
N(U) lies in radius 2v-1. Both balls fit genuine corner quadrants.
If the corners are adjacent, their intersection occupies strictly one
side of the diagonal symmetry in the new ball; hence it has at most
half that ball's cells. If diagonally opposite, the intersection is
empty. By parity the new neighborhood ball has at most v(v+1) cells:
when U has its anchor's color this is the odd ball of radius 2v-1;
otherwise it is the even ball of effective radius 2v-2 and has v^2 cells.
The old remainder contributes at most m_old^2 further cells. Since
|N(U)|=|U|+v, the inspection charge is at least

    |U|+v-v(v+1)/2-m_old^2
      = |U|-v(v-1)/2-m_old^2.

Use |U|>=q_new-m_new^2 and v<=s_new to obtain (3).

One may replace the half-ball bound by the exact adjacent-corner lens
formula in `physical-anchor-switch-review.md`, using the actual dominant
component surpluses and parity. The displayed weaker expression suffices
to show that substantial dominant-corner relocation takes many days when
q_new is close to s_new^2. It also proves anchor persistence between
consecutive qualifying days whenever its right side exceeds k.

For the two-cohort bridge the same charge holds using the TOTAL daily
inspection budget. If the dominant component stays in the same cohort
but changes corner, apply (3) to that cohort, bounding its nondominant
old holes by the total old remainder. If the dominant COHORT changes,
all old holes in the new dominant cohort lie in the old remainder, so
the stronger bound

    sum |I_(t+j)| >= q_new-m_new^2+v-m_old^2

holds, where v is the new dominant component surplus and q_new denotes
the total new hole count. Thus both types of physical identity change
are charged without interpreting a synthetic merged set geometrically.

## Remaining history obligation

This is stronger spatial information than a corner-count-only profile:
removing the origin from a large triangle no longer erases its effective
location. The block charge (3) controls relocation through arbitrary
intermediate shapes, but it charges total inspections, not excess above
the time already required by the physical prefix construction. Extracting
a uniform capture-time comparison still requires that further accounting.
No merger rule or dynamic evaluator is asserted here.

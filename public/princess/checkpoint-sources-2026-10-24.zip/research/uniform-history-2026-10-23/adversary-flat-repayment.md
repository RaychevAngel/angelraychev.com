# A factor-of-two obstruction to a local flat-crossing estimate

24 October 2026 UTC. Algebraic counterexample for arbitrary partial-state
comparisons. It does not refute the zero-start constant-day conjecture.

The tempting assertion that each square or pronic flat contracts the
maximum two-phase room discrepancy by approximately `E/v` is too strong.
A flat acts on only one coordinate in each day, while the two ancestral
phase coordinates alternate.

Take integers `v>=3`, `r>=6v`, `k=r+v`, and `a=r^2+1`. Use the uncapped
physical root maps

    F(x)=k+x-ceil(sqrt(x)), G(x)=k+x-rho(x),
    H(p,q)=(G(q),F(p)).

Start an ahead comparison pair at `B_0=(a,a)` and a physical pair at
`X_0=(a-4v,a-4v)`. These are valid partial states for comparing the maps;
they are not asserted to occur simultaneously on their two zero-start
orbits. For the entire following crossing, the pronic profile is `r`.
The square profile is `r` below `a` and `r+1` at or above `a`. The next
pronic flat is far away because `r>=6v`.

For `0<=t<=4`, direct substitution gives

    X_t=(a-4v+t*v, a-4v+t*v),
    max B_t=a+t*v-floor(t/2),
    min B_t=a+t*v-ceil(t/2).

The balanced closure does nothing: the ahead pair already has coordinate
difference at most one. At time4 both physical coordinates have reached
the square flat, and

    X_4=(a,a), B_4=(a+4v-2,a+4v-2).

The maximum discrepancy has decreased from `E=4v` to `E-2`. It remains
`E-2` through the ensuing region where both pairs use the same square
and pronic affine pieces. Thus this complete square-flat crossing has
contracted the maximum error by exactly2, whereas
`ceil(E/(v+1))>=3` for `v>=3`. It cannot justify that stronger estimate
for each flat separately.

The correct exact accounting for arbitrary ordered comparison pairs is
obtained with the SUM of the coordinate discrepancies. Write
`D_p=B_p-X_p`, `D_q=B_q-X_q`, and let `eta` be the possible unit increase
of the balanced second coordinate. Then

    D'_p=D_q-[rho(B_q)-rho(X_q)],
    D'_q=D_p-[ceil(sqrt(B_p))-ceil(sqrt(X_p))]+eta,

and hence

    S'=S-[rho(B_q)-rho(X_q)]
         -[ceil(sqrt(B_p))-ceil(sqrt(X_p))]+eta.

The width-clipped version replaces each root by its clipped root, with
the identical identity. This is a genuine history-sensitive accounting
equation. It shows where repayment occurs, but by itself it does not
prove that the repayments dominate all injections with a uniform day
constant. Any stronger result must exploit the zero-start history or
the special timing of `eta`, rather than counting both flat locations
as if each independently contracts both phases on every day.

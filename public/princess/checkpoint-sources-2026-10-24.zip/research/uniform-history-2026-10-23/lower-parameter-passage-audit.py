"""Exact parameter-only arithmetic for the uniform early passage.

This enumerates the 42 budgets 33..74, not rectangles or graph states.
Every integer root is computed by an exact inequality, and each finite
scalar hitting-time array is independently checked against its recurrence.
"""
from math import isqrt
from pathlib import Path
import hashlib
import json


def root(x):
    r = isqrt(x)
    return r + (r * r < x)


def rho(x):
    r = (isqrt(4 * x + 1) - 1) // 2
    return r + (r * (r + 1) < x)


def forward_hits(k, top, phase=None):
    hits = [0] + [None] * top
    x = t = 0
    orbit = [0]
    while x < top:
        y = x + k
        d = rho(y) if phase is None or (phase + t) % 2 == 0 else root(y)
        y -= d
        assert y > x
        t += 1
        for target in range(x + 1, min(y, top) + 1):
            hits[target] = t
        x = y
        orbit.append(x)
    for target in range(1, top + 1):
        t = hits[target]
        assert orbit[t - 1] < target <= orbit[t]
    return hits, orbit


def main():
    rows = []
    target_phase_checks = 0
    for k in range(33, 75):
        R = 4 * k // 5
        v = k - R - 2
        r = R + 1
        D = k - R - 1
        charge = (r * r - 9 * r - 66) // 2
        assert 2 * charge == r * r - 9 * r - 66
        delta = (charge + k - 1) // k
        assert v > 0 and 3 * R >= 2 * k and R < k - 2
        assert 2 * (delta - 1) >= D
        top = R * R + k
        scalar, scalar_orbit = forward_hits(k, top)
        phases = [forward_hits(k, top, p)[0] for p in (0, 1)]
        entry = max(h[top] for h in phases) - scalar[R * R + 1]
        fast = max(h[t] - scalar[t]
                   for h in phases for t in range(1, R * R + 1))
        assert entry <= 7 and fast <= 2
        target_phase_checks += 2 * R * R
        rows.append(dict(k=k, R=R, v=v, rewind=D,
                         switch_charge=charge,
                         minimum_switch_separation=delta,
                         switch_credit_margin=2 * (delta - 1) - D,
                         entry_allowance=entry, fast_allowance=fast,
                         scalar_crossing=scalar[R * R + 1],
                         phase_entry_hits=[h[top] for h in phases]))
    out = dict(status='PASS', scope='Exact scalar parameter arithmetic; no board enumeration',
               budgets=[33, 74], budget_count=len(rows),
               target_phase_checks=target_phase_checks,
               maximum_entry_allowance=max(r['entry_allowance'] for r in rows),
               maximum_fast_allowance=max(r['fast_allowance'] for r in rows),
               minimum_switch_credit_margin=min(r['switch_credit_margin'] for r in rows),
               source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
               rows=rows)
    path = Path(__file__).with_suffix('.json')
    path.write_text(json.dumps(out, indent=2) + '\n')
    print(json.dumps({k: v for k, v in out.items() if k != 'rows'}, indent=2))


if __name__ == '__main__':
    main()

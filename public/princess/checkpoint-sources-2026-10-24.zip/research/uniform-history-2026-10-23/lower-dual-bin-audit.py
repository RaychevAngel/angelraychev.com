"""Direct finite q/T audit of new exact labeled interval unions."""
from pathlib import Path
import importlib.util,json,random,time,hashlib
HERE=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('new_dual_bins',HERE/'lower-dual-bin-interval.py')
m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)


def audit(w,n,rng):
    h,D,capacity,relation,cap,event=m.engine(w,n,w//2+1)
    checked=admitted=resets=0
    features={(i,u,j,v)for c,e in m.ref.er.FEATURES for i,u,j,v,_ in m.ref.er.OPTIONS[c,e]}
    for i,u,j,v in sorted(features):
        top=h-4+i+u
        samples=[(q,q)for q in range(1,top+1)]
        samples += [(a,rng.randint(a,top))for a in [rng.randint(1,top)for _ in range(8)]]
        for qa,qb in samples:
            expected={}
            for q in range(qa,qb+1):
                ev=event(i,u,j,v,q)
                for T in range(1,h-4+j+v+1):
                    if cap(T,i,u,j,v)<q:continue
                    admitted+=1;label=(-1,-1)
                    if ev and ev[2]==T:
                        if ev[0]<0:continue
                        label=ev[:2];resets+=1
                    expected.setdefault(label,set()).add(T)
            actual={}
            for d,R,a,z in relation(i,u,j,v,qa,qb):
                actual.setdefault((d,R),set()).update(range(a,z+1))
            assert actual==expected,(w,n,(i,u,j,v),qa,qb,[(key,sorted(actual.get(key,set())^expected.get(key,set())))for key in actual.keys()|expected.keys()if actual.get(key,set())!=expected.get(key,set())])
            checked+=1
    return dict(w=w,n=n,labeled_unions=checked,admitted_base_points=admitted,reset_points=resets)


if __name__=='__main__':
    start=time.process_time();rng=random.Random(824);rows=[]
    for w,n in [(4,4),(6,6),(6,7),(7,8),(8,8),(8,9),(10,10),(12,12)]:
        row=audit(w,n,rng);rows.append(row);print(row,flush=True)
    out=dict(passed=True,rows=rows,labeled_unions=sum(r['labeled_unions']for r in rows),
             admitted_base_points=sum(r['admitted_base_points']for r in rows),
             reset_points=sum(r['reset_points']for r in rows),CPU_seconds=time.process_time()-start,
             source_sha256=hashlib.sha256((HERE/'lower-dual-bin-interval.py').read_bytes()).hexdigest())
    Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
    print({k:v for k,v in out.items()if k!='rows'})

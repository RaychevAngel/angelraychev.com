# Five days for the critical passage needed by the full-game join

24 October 2026 UTC. Independently accepted refinement of the eleven-day
assembly, after review of the high two-day proof and finite-state coverage.

Let w<=n, wn even, b=floor(w/2)>=32 and b+1<=k<3b. Put

    h=wn/2,    H=(b-5)^2,

and let b^2<M<=h-H. Let tau be the first layer at which the ordinary
three-corner necessary backward frontier initialized at (H,H,H) has
maximum at least M. Then the actual finite-board physical prefix pair
initialized at (H,H) has BOTH coordinates at least M within

    tau+5 days at odd width,
    tau+4 days at even width.                       (1)

The same conclusion holds if the incoming physical pair dominates
(H,H). This statement intentionally fixes the low entry at H and uses
M>b^2. It does not replace the more general eleven-day statement for
every intermediate seed and target.

Use exactly the branch relaxations, equal frontier resets, ranges, cap
checks and phase conventions of
`adversary-critical-eleven-day-assembly.md`. All sources remain preserved.
That proof showed that the total elapsed time of the faster, piecewise
reset necessary model is at most tau, and that equal resets are
justified whenever BOTH physical coordinates dominate its actual exit
maximum. The new estimates maintain precisely that stronger interface.

1. **Low passage H to b^2: two extra physical days.**
   The all-residue root-wall certificate
   `adversary-critical-wall-automaton.py` covers d=k-b=1,2,3,4. It
   retains both physical phases and all possible local entry residues
   through the five root bins. Its terminal test freezes the model's
   ACTUAL exit maximum, including any overshoot; the physical minimum
   catches it in at most two days. It checks no widths. For d>=5,
   at most five unit injections and 1-Lipschitz low maps give a
   componentwise discrepancy at most five; the normalized model span
   is at most one. Therefore the physical minimum is at most six rooms
   behind the model maximum. The global physical per-day minimum
   increment is at least d-1>=4, and two days suffice. Independent
   coverage/terminal reviews are `lower-review-wall-automaton.md` and
   the upper review of this same low certificate.

2. **Central passage: one extra day at odd width, zero at even width.**
   The unchanged proofs are `adversary-critical-central.md` and
   `adversary-critical-central-refinement.md`. They already dominate
   the actual exit maximum in BOTH phases, so no interface day is
   added. The high-entry capacities are the actual central exit values,
   not a rounded or guessed threshold.

3. **High passage to deficit <=h-M: two extra days.**
   The proof is `adversary-critical-high-two-day.md`, with its finite
   local certificate `adversary-critical-high-wall-automaton.py`.
   For d>=3, two physical updates at entry give at least six rooms of
   uniform deficit advantage; the expansive high root maps preserve
   this advantage except for at most five one-room clamps. The final
   model span is at most one, so both physical deficits dominate its
   minimum. For d=1,2, the certificate checks EVERY intermediate wall
   state and both common-region waiting phases against the current
   frozen model minimum. Thus it covers the arbitrary terminal value
   h-M>=H, not only H. It also includes arbitrary equal high entry
   deficits and skipped initial bins. Both physical phases again
   dominate the actual exit extremum.

The sum is2+1+2=5 at odd width and2+0+2=4 at even width.
If a large step reaches M before all three modules are needed, stop
then; no skipped module is charged. In particular, since M>b^2, the
low full-exit certificate is applicable even when its exit overshoots
the ultimate target M.

The equal resets and all input/cap checks are inherited from the
eleven-day proof rather than reinterpreted. The numerical small
certificates prove finite normalized state coverage through symbolic
root windows; they are not finite-width experiments or parameter
preprocessing needed to evaluate the game itself.

This proves only the critical evaluator-to-physical comparison (1).
The parent's early actual-history bound, late actual-history bound,
and three-passage joining lemma are separate dependencies for any
claimed full-game additive gap. No new complete Lean proof or public
artifact is asserted here.

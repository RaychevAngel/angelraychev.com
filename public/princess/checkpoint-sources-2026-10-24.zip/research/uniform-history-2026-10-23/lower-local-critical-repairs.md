# One physical day repairs a critical tie-closure event

24 October 2026 UTC. Ordinary local comparison lemmas submitted for
independent review. They use the exact two-state reductions separately
established by the critical-comparison lane. Their purpose is to keep the
two physical phase coordinates through a whole boundary region instead
of restarting at every square/pronic root cut.

Let b=floor(w/2), k>=b+1 and h=wn/2 on an even-area rectangle. In the
low prefix range u<=b^2, the two physical backward-capacity updates are

    F(u)=u+k-ceil(sqrt(u)),
    G(u)=u+k-rho(u),

where rho(u) is the least r>=0 with u<=r(r+1). The finite-board maps
are globally nondecreasing and at least the identity, and gain at least
one room globally when k>=b+2. All comparisons below retain their phase
coordinate labels. Final capacities are capped at h.

## Low-side local repair

The ordered two-state relaxation is

    M(x,y)=(max(G(y),F(x)), F(x)),  x-y in{0,1}.

The physical map is H(x,y)=(G(y),F(x)). They differ only at an injection
from x=y+1 with F(x)=G(x-1)+1. Put r=ceil(sqrt(x)). At such an event

    r(r-1)+2<=x<=r^2,
    v=F(x)=x+k-r,
    M(x,y)=(v,v),       H(x,y)=(v-1,v).             (1)

One additional PHYSICAL update from (v-1,v) dominates (v,v).
The first coordinate is G_finite(v)>=v. For the second, if k>=b+2
global unit progress gives F_finite(v-1)>=v. At the minimum budget
k=b+1, the injection's actual source yields the stronger location

    v-1=x+b-r<=r^2+b-r<=b^2.

Thus this potentially slow physical phase is still in its low-root
range: its cost is at most b, and it also gains at least one room.
The cap at h preserves the conclusion; if a raw update exceeds h both
coordinates can simply stop at h.

This proves a local simulation: from ANY physical pair that dominates
the current ordered model pair, an ordinary model step costs one
physical step, and an injection step costs two. Monotonicity proves
the induction. The extra physical step is an actual paired update, not
an unproved change of anchor or a free exchange of phase coordinates.

By `adversary-critical-one-sided.md`, from equal seeds z>=A=(b-C)^2
up to first reaching b^2 there is at most one injection in each upper
half root bin. Only r=b-C+1,...,b can occur; the initial square endpoint
cannot inject from an equal pair. Therefore there are at most C events.
The physical pair dominates the model's entire exit pair, including its
overshoot, within model time plus C. In particular for C=5 the low-side
allowance is FIVE physical days, rather than one reset for every root
interface. Starting with a physical pair already above equal seed z
only strengthens this conclusion.

The same allowance also makes the physical MINIMUM dominate the model
MAXIMUM at exit. If fewer than C injections occur, use one final physical
alignment day; it is paid by the unused event allowance. The accepted
equal-seed physical interlacing gives min X(t+1)>=max X(t), and a larger
incoming physical pair only helps. If all C injections occur, their
last root is b. That last injection ties the model output, and every
remaining pre-exit input stays in the upper half of root b, where F=G.
All subsequent model outputs through exit therefore remain tied, so the
coordinatewise domination already supplies the desired minimum without
an additional day. This argument was identified independently by the
critical-comparison lane. It also covers an earlier prescribed target:
if all C events have occurred then the same final-root tie persists;
otherwise its unused allowance pays the final alignment.

## High-side local repair

In the uncapped high-root range define

    A(u)=u+ceil(sqrt(u)),
    B(u)=u+1+rho(u)              (u>0).

The ordered three-corner deficit reduction has x=D2<=y=D1<=x+1,
with

    M_down(x,y)=(min(A(y),B(x))-k, B(x)-k).         (2)

The corresponding physical deficit map is

    H_down(x,y)=(A(y)-k, B(x)-k).

Decreasing deficits means increasing captured capacity, so physical
domination here is coordinatewise <=. A model clamp occurs only if
y=x+1 and A(x+1)=B(x)+1. Put r=ceil(sqrt(x+1)). Then

    (r-1)^2<=x<=r(r-1), rho(x)=r-1,
    v=x+r-k,
    M_down(x,y)=(v,v), H_down(x,y)=(v+1,v).        (3)

One additional physical update takes (v+1,v) below (v,v). For budgets
k>=b+2 this is the global unit decrease of deficits. At k=b+1 and
r<=b, the actual injection source gives

    v+1=x+r-b<=x<=b(b-1).

Therefore rho(v+1)<=b-1=k-2 and

    B(v+1)-k=v+2+rho(v+1)-k<=v.

Also ceil(sqrt(v))<=b<k, so A(v)-k<=v. This proves the repair in both
phase coordinates. If a physical trajectory has already reached zero,
it stops there. In the intended critical application H=(b-5)^2>k and
all model target deficits stay positive, so no zero convention is used
to prove an artificial strict inequality.

## High-side count and terminal phase

Assume the exact high reduction (2) is valid from an initial ordered
pair with

    H<x<=y<=x+1,   y<=(b-1)^2,

until x first reaches H. This is the cap-inactive high range verified
by the critical-comparison lane. A physical pair initially at most
(x,x) is below the model pair.

There is at most one clamp per lower half root bin. At a clamp the
output ties. While its input stays in the interior of the same lower
half bin, A=B and a tie remains tied. At its lower square endpoint,
the next state leaves that bin. The model deficits strictly decrease
in this range, so no bin can be revisited.

Only r=b-4,...,b-1 can occur before the first H hit: x>H implies
ceil(sqrt(x+1))>=b-4, and x+1<=y+1 with y<=(b-1)^2; at the possible
top endpoint x=y=(b-1)^2 there is no clamp and the first move decreases
strictly. Thus there are at most FOUR clamp events. Applying the local
repair after each gives physical deficits at most the ordered model
deficits within four extra days.

At exit the model minimum x is at most H while y<=x+1. One further
physical update puts BOTH phase deficits at most x, because both
physical deficit maps decrease by at least one at inputs<=H+1.
Indeed H+1<=b(b-1) and k>=b+1. Hence the high-side comparison has
allowance at most FIVE days and may dominate the model's minimum exit
deficit, including its overshoot, rather than merely its nominal target.

The same argument applies to any larger terminal threshold in this
range, with no more clamp events. Here the terminal alignment should be
checked with its labels rather than claiming both maps strictly decrease
through the whole odd entry range. If y=x+1, then y<=b^2 implies
A(y)-k<=y-1=x, while x<=b(b-1) implies B(x)-k<=x. Thus one additional
physical update still puts both coordinates at most x. If y=x the
pair is already aligned. In particular the possible zero decrement of
B at the odd upper endpoint does not invalidate this conclusion.

For odd width the cap-inactive reduction has a wider valid entry range:
x<=b(b-1), y<=x+1. Assuming its separately verified cap comparison,
exactly the same argument allows the additional root bin r=b. Thus
there are at most FIVE clamp events and one possible final phase day,
for a SIX-day high-side allowance. The local repair already includes
r=b; no new estimate or change of phase convention is needed.

These conservative five/six-day allowances improve to FOUR days at the
even entry and FIVE at the odd entry, including the terminal phase.
If fewer than the allowed four/five clamps occur, its unused allowance
pays the one final physical phase day. If all occur, the last is in the
lowest possible bin r=b-4. Its output ties, and every subsequent input
before the target remains between H+1 and r(r-1), where A=B. The model
therefore stays tied until it reaches or overshoots its target, and no
final phase day is needed. For a target larger than H, either it is
reached before all the events, leaving an unused allowance, or this
same final-bin argument still applies. This finishing observation was
identified independently by the parent and critical-comparison lanes.

## What is and is not supplied here

These local simulations and event counts require no width or budget
sampling. They substantially reduce the cost of the low and high root
interfaces once their two-state reductions and entry conditions hold.
They do not by themselves supply the middle cap-region comparison,
the exact three-module joining, or a new complete capture-time constant.

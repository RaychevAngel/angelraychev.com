# Removing shifted-root walls from the critical comparison

24 October 2026 UTC. A proposed refinement, kept separate from the first
critical-passage proof while that proof is reviewed.

Let q>=7, d=h-q>=9, and write alpha=R(q), beta=rho(q), gamma=R(d),
delta=rho(d), y=gamma-delta in{0,1}. Minimize the exact ordinary inverse
cost over retained i<=c separately for each of its low, high, and width
branches. This distributes over the minimum, so is exact.

The effective low cost matrix is

    [ beta+1  alpha  2+R(q-4) ]
    [ beta    alpha  2+R(q-4) ]
    [ beta    alpha  2+R(q-4) ].

For j=1, the inequality i+max(2,R(q-2i))>=R(q) makes i=0 optimal.
For j=2 the same comparison with q-4 makes i=0 optimal. For j=0,
1+rho(q-2)>=rho(q), while rho(2q)>=rho(q)+1 for q>=7.
Since R(q-4)>=R(q)-1 in this range, replace the third column by alpha+1
to obtain a valid relaxation without shifted roots.

The effective high matrix is

    [ R(d-1)+3  gamma+2  delta+2 ]
    [ R(d-1)+2  gamma+1  delta+1 ]
    [ R(d-1)+1  gamma    delta+1 ].

In the last column, the i=2 alternative1+R(d+1) never beats delta+1.
The only possible change R(d-1)=gamma-1 occurs at d=(gamma-1)^2+1.
At that point delta=gamma-1, so y=1. It is therefore safe to replace
R(d-1) by gamma-y throughout. This is a relaxation, including away from
the single exceptional point; it introduces no additional root walls.

Apply the same width caps as in the reviewed critical-cell proof. The
resulting relaxed costs depend only on the four unshifted roots. The
finite exact certificate `adversary-critical-unshifted.py/.json` checks
all1,660 symbolic C=11 matrix types, with no width samples. It proves:

* every directed cycle costs at least its length times the physical mean;
* every edge costs at least that mean minus1/2;
* an exact physical two-cycle occurs in the three-state graph;
* a vertex potential can be chosen from
  (0,0,0), (0,0,1/2), (0,1/2,1/2).

Thus all shifted-root walls can be removed in this relaxed comparator.
Only the two-room spread of the frontier can place distinct entries on
opposite sides of an unshifted root break. Around a break at z it suffices
to mark model maxima z and z+1. Reflection of a high-root break is at
q=h-z+1. There are at most4(C+3) relevant breaks, so the total marked
room width is at most8(C+3), instead of100(C+7).

There is also a stronger bulk stopping comparison. Relax the frontier by
replacing its three entries by their maximum on entry to a bulk cell.
This only increases its necessary reachable thresholds. Since the exact
physical two-cycle is present, the affine iterates from equal seeds obey

    physical maximum <= model maximum <= physical maximum+1.

Consequently the physical orbit cannot leave that cell earlier than the
relaxed model. The final model step is valid for both, so no per-cell
overshoot payment is needed: two extra physical steps catch the possible
one-room deficit, and one further step makes the physical minimum dominate
the model maximum. This costs at most3 days per bulk cell.

For a full optimized passage theorem, the remaining obligations are to
formalize the cell-entry resets as a horizon-monotone relaxed evaluator,
join the two-room walls, and account for the original model's terminal
overshoot once. Carrying the small vertex potential globally may reduce
these payments further, but an unqualified room-error telescope is not
valid: the high-boundary physical map can have slope2 at a root break.

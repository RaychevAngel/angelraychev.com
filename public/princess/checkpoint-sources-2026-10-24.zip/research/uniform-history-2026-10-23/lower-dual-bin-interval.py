"""Exact nine-feature radius evaluator with proposed near-extremal high resets.

Adds the two subcritical bin-wide rules proved in lower-dual-bin-stability.md.
All older accepted sources remain unchanged. Ordinary edge caps are unchanged.
"""
from pathlib import Path
from functools import lru_cache
import importlib.util,json,math,sys,time
HERE=Path(__file__).resolve().parent
OLD=HERE.parent/'uniform-gap-2026-10-23'
sp=importlib.util.spec_from_file_location('accepted_dual_nine_interval',OLD/'lower-dual-nine-interval.py')
base=importlib.util.module_from_spec(sp);sp.loader.exec_module(base)
ref=base.ref;merge=base.merge;minus=base.minus


def tri_root(d):return (math.isqrt(1+8*d)-1)//2


def engine(w,n,k,critical_pronic=True,wide_square=True,dual_bins=True):
    h,D,capacity,base_relation,cap,base_event=base.engine(w,n,k,critical_pronic,wide_square)
    if not dual_bins:return h,D,capacity,base_relation,cap,base_event
    b=w//2

    def event(i,u,j,v,q):
        H=h-q
        if (i,u,j,v)==(2,1,1,2):
            r=(math.isqrt(1+4*H)-1)//2;r+=r*(r+1)<H
            if 2<=r<b and r*(r-1)+2<=H<=r*(r+1):
                d=r*(r+1)-H;M=tri_root(d)
                return D%2,min(D,D-2*r+1+2*M),q+r
        if (i,u,j,v)==(1,2,2,1):
            r=math.isqrt(H);r+=r*r<H
            if 2<=r<b and (r-1)**2+2<=H<=r*r:
                d=r*r-H;M=tri_root(d)
                return 1^(D%2),min(D,D-2*r+2+2*M),q+r
        return base_event(i,u,j,v,q)

    @lru_cache(None)
    def bin_records(i,u,j,v):
        if (i,u,j,v) not in ((2,1,1,2),(1,2,2,1)):return ()
        square=(i,u,j,v)==(2,1,1,2);out=[]
        for r in range(2,b):
            offset=h-r*(r+1) if square else h-r*r
            end=2*r-2 if square else 2*r-3
            for M in range(tri_root(end)+1):
                a=offset+M*(M+1)//2
                z=offset+min(end,(M+1)*(M+2)//2-1)
                d=D%2 if square else 1^(D%2)
                R=min(D,D-2*r+(1 if square else 2)+2*M)
                assert cap(a+r,i,u,j,v)>=a and cap(z+r,i,u,j,v)>=z
                out.append((a,z,r,d,R))
        return tuple(out)

    @lru_cache(200000)
    def first(i,u,j,v,q):
        lo=1;hi=h-4+j+v
        if cap(hi,i,u,j,v)<q:return hi+1
        while lo<hi:
            mid=(lo+hi)//2
            if cap(mid,i,u,j,v)>=q:hi=mid
            else:lo=mid+1
        return lo

    @lru_cache(200000)
    def relation(i,u,j,v,qa,qb):
        low=first(i,u,j,v,qa);top=h-4+j+v
        if low>top:return ()
        out=[];ev=event(i,u,j,v,qa)
        if ev and low<=ev[2]<=top and not(qa<qb and cap(ev[2],i,u,j,v)>=qa+1):
            if low<ev[2]:out.append((-1,-1,low,ev[2]-1))
            if ev[2]<top:out.append((-1,-1,ev[2]+1,top))
        else:out.append((-1,-1,low,top))
        # Old labeled events are unchanged or identical to the d=0 new event.
        out.extend(row for row in base_relation(i,u,j,v,qa,qb) if row[0]>=0)
        for a,z,inc,d,R in bin_records(i,u,j,v):
            a=max(a,qa);z=min(z,qb)
            if a<=z:out.append((d,R,a+inc,z+inc))
        return tuple(out)
    return h,D,capacity,relation,cap,event


def run(w,n,k,seconds=120,critical_pronic=True,wide_square=True,trace=False,dual_bins=True):
    start=time.process_time()
    h,D,capacity,relation,cap,event=engine(w,n,k,critical_pronic,wide_square,dual_bins)
    seed=(D,D,2,2);front={seed:[(h,h)]};seen=dict(front);layers=[];peak=0
    for day in range(4*w*n):
        if not front:raise AssertionError(('empty',day))
        low=min(z[0][0]for z in front.values());layers.append(low)
        if low==0:break
        if time.process_time()-start>seconds:
            return dict(w=w,n=n,k=k,complete=False,day=day,CPU_seconds=time.process_time()-start)
        following={}
        def add(R,S,c,e,a,z):
            size,cc,ee=capacity(R,S);z=min(z,size,h-4+c+e)
            if c<=cc and e<=ee and a<=z:following.setdefault((R,S,c,e),[]).append((a,z))
        for(R,S,c,e),xs in front.items():
            newR,newS=min(D,S+1),min(D,R+1)
            for a,z in xs:
                if a<=k:add(newR,newS,0,0,0,0)
                for i,u,j,v,charge in ref.er.OPTIONS[c,e]:
                    if charge>k:continue
                    qa=max(1,a-k);qb=min(z-charge,h-4+i+u)
                    if qa>qb:continue
                    for d,r,lo,hi in relation(i,u,j,v,qa,qb):
                        nr,ns=newR,newS
                        if d==0:nr=min(nr,r)
                        if d==1:ns=min(ns,r)
                        add(nr,ns,j,v,lo,hi)
        front={}
        for key,parts in following.items():
            allnext=merge(parts);new=minus(allnext,seen.get(key,[]))
            if new:
                front[key]=new;seen[key]=merge(seen.get(key,[])+new)
        peak=max(peak,sum(map(len,front.values())))
    else:raise AssertionError('day bound')
    residual=min(layers[:-1]);out=dict(w=w,n=n,k=k,complete=True,tau=day,residual=residual,
        lower=2*day-int(2*residual<=k),states=sum(z-a+1 for xs in seen.values()for a,z in xs),
        radius_pairs=len({q[:2]for q in seen}),intervals=sum(map(len,seen.values())),peak_front_intervals=peak,
        relation_queries=relation.cache_info().misses,relation_cached=relation.cache_info().currsize,
        capacity_queries=capacity.cache_info().currsize,dual_bins=dual_bins,
        CPU_seconds=time.process_time()-start)
    if trace:out['layers']=layers
    return out


if __name__=='__main__':
    rows=[]
    for case in sys.argv[1:]or['24,24,13','44,44,24','46,46,24']:
        z=run(*map(int,case.split(',')),seconds=30,trace=True);rows.append(z)
        print({k:v for k,v in z.items()if k!='layers'},flush=True)
        Path(__file__).with_suffix('.json').write_text(json.dumps(rows,indent=2)+'\n')

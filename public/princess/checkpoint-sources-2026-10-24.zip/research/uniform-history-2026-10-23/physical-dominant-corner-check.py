"""Independent literal-coordinate audit; no imports from candidate proofs."""
from pathlib import Path
import hashlib, json, random, time

HERE = Path(__file__).resolve().parent
RNG = random.Random(233103)
started = time.process_time()
counts = dict(quadrant_sets=0, quadrant_premises=0,
              board_sets=0, board_premises=0, history_steps=0, blocks=0,
              joint_trials=0, joint_premises=0)

def neighbors(S, w=None, n=None):
    return {(x+dx,y+dy) for x,y in S
            for dx,dy in ((1,0),(-1,0),(0,1),(0,-1))
            if x+dx>=0 and y+dy>=0 and
            (w is None or x+dx<w) and (n is None or y+dy<n)}

def components(S, w=None, n=None):
    remaining=set(S); out=[]
    while remaining:
        U={remaining.pop()}; stack=list(U)
        while stack:
            z=stack.pop()
            nxt=neighbors(neighbors({z},w,n),w,n)&remaining
            remaining-=nxt; U|=nxt; stack.extend(nxt)
        out.append(U)
    return out

def quadrant_check(S):
    counts['quadrant_sets']+=1
    if not S or len(components(S))!=1: return
    q=len(S); s=len(neighbors(S))-q
    if 2*q<=s*(s-1): return
    counts['quadrant_premises']+=1
    assert max(x+y for x,y in S)<=2*s-2, (S,q,s)

for p in (0,1):
    cells=[(x,y) for x in range(7) for y in range(7)
           if x+y<=6 and (x+y)%2==p]
    for mask in range(1<<len(cells)):
        quadrant_check({z for i,z in enumerate(cells) if mask>>i&1})
    for _ in range(5000):
        # Random connected growth, including floating starts.
        S={(RNG.randrange(12),RNG.randrange(12))}
        if sum(next(iter(S)))%2!=p:
            x,y=S.pop(); S.add((x+1,y))
        for __ in range(RNG.randrange(1,65)):
            z=RNG.choice(tuple(S)); choices=tuple(neighbors(neighbors({z})))
            S.add(RNG.choice(choices))
        quadrant_check(S)

def board_check(S,w,n):
    counts['board_sets']+=1
    if not S: return
    q=len(S); s=len(neighbors(S,w,n))-q; h=w*n//2; b=w//2
    if not (0<s<b and 2*q>s*s and h-q>s*(s+1)): return
    counts['board_premises']+=1
    comps=components(S,w,n)
    data=[(len(neighbors(U,w,n))-len(U),U) for U in comps]
    data.sort(key=lambda x:x[0],reverse=True)
    ss,U=data[0]; m=s-ss
    assert sum(t for t,_ in data)==s
    assert all(len(V)<=t*t and t>0 for t,V in data)
    assert 2*ss>s and m<=(s*s-q)//s
    assert 2*m*(s-m)<=s*s-q
    assert q-len(U)<=m*m
    corners=((0,0),(w-1,0),(0,n-1),(w-1,n-1))
    assert sum(max(abs(x-a)+abs(y-bb) for x,y in U)<=2*ss-2
               for a,bb in corners)==1, (w,n,S,s,ss)

for w,n in ((4,4),(4,5),(4,6),(6,6)):
    cells=[(x,y) for x in range(w) for y in range(n) if (x+y)%2==0]
    # Exhaust the two smaller boards; sample the larger ones.
    masks=range(1<<len(cells)) if len(cells)<=10 else [
        RNG.randrange(1<<len(cells)) for _ in range(10000)]
    for mask in masks:
        board_check({z for i,z in enumerate(cells) if mask>>i&1},w,n)

for w,n in ((8,8),(8,11),(9,10),(12,14),(16,18)):
    cells=[(x,y) for x in range(w) for y in range(n)]
    corners=((0,0),(w-1,0),(0,n-1),(w-1,n-1))
    for _ in range(5000):
        p=RNG.randrange(2); S=set()
        # Corner mixtures + random omissions exercise split components.
        for a,bb in RNG.sample(corners,RNG.randrange(1,5)):
            R=RNG.randrange(max(1,w-2))
            S.update((x,y) for x,y in cells if (x+y)%2==p and
                     abs(x-a)+abs(y-bb)<=R)
        for z in RNG.sample(tuple(S),min(len(S),RNG.randrange(5))): S.remove(z)
        board_check(S,w,n)

for w,n in ((8,8),(8,11),(9,10),(12,14),(16,18)):
    V=[{(x,y) for x in range(w) for y in range(n) if (x+y)%2==p}
       for p in (0,1)]
    corners=((0,0),(w-1,0),(0,n-1),(w-1,n-1))
    for _ in range(1200):
        holes=[]; original_surplus=0
        for p in (0,1):
            a,bb=RNG.choice(corners); R=RNG.randrange(w-2)
            U={(x,y) for x,y in V[p] if abs(x-a)+abs(y-bb)<=R}
            if RNG.randrange(3)==0: U=set()
            for z in RNG.sample(tuple(U),min(len(U),RNG.randrange(3))): U.remove(z)
            S=V[1-p]-neighbors(U,w,n)
            A=neighbors(S,w,n)
            original_surplus+=len(A)-len(S)
            holes.append(V[p]-A)
        counts['joint_trials']+=1
        r=original_surplus; Q=sum(map(len,holes))
        if not (0<r<w//2 and r*r<2*Q<=2*r*r): continue
        counts['joint_premises']+=1
        data=[]
        for p,U in enumerate(holes):
            for C in components(U,w,n):
                data.append((len(neighbors(C,w,n))-len(C),p,C))
        data.sort(key=lambda x:x[0],reverse=True)
        ss,p,C=data[0]; m=r-ss
        assert sum(t for t,_,_ in data)<=r and 2*ss>r
        assert 2*m*(r-m)<=r*r-Q
        assert Q-len(C)<=m*m
        assert sum(max(abs(x-a)+abs(y-bb) for x,y in C)<=2*ss-2
                   for a,bb in corners)==1

# Audit the exact one-step decomposition and weighted block union bound.
for w,n in ((4,5),(6,6),(8,9)):
    V=[{(x,y) for x in range(w) for y in range(n) if (x+y)%2==p}
       for p in (0,1)]
    for _ in range(200):
        p=RNG.randrange(2); H=set(RNG.sample(tuple(V[p]),RNG.randrange(len(V[p])+1)))
        start=set(H); losses=[]; Delta=RNG.randrange(1,9)
        for j in range(Delta):
            I=set(RNG.sample(tuple(V[p]),RNG.randrange(len(V[p])+1)))
            nextH={z for z in V[1-p] if neighbors({z},w,n)<=H|I}
            N=neighbors(nextH,w,n); E=H-N
            assert len(N-H)==len(nextH)-len(H)+len(N)-len(nextH)+len(E)
            assert len(I)>=len(N-H)
            losses.append(len(E)); H=nextH; p=1-p
            counts['history_steps']+=1
        N=set(H)
        for j in range(Delta): N=neighbors(N,w,n)
        assert sum((j+1)**2*x for j,x in enumerate(losses))>=len(start-N)
        counts['blocks']+=1

names=['physical-dominant-corner.md','physical-excess-slack.md',Path(__file__).name]
receipt=dict(status='PASS',counts=counts,cpu_seconds=time.process_time()-started,
             sha256={name:hashlib.sha256((HERE/name).read_bytes()).hexdigest() for name in names})
(HERE/'physical-dominant-corner-check.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))

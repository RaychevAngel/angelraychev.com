# An exact boundary-tax decomposition and a block charge for discarded holes

24 October 2026 UTC. Ordinary whole-history identities. These isolate an
actual excess cost; they do not establish a uniform capture-time gap.

Let H_t be one cohort's holes just before its day's inspections I_t.
After an unsuccessful inspection and compulsory move,

    H_(t+1)=E(H_t union I_t),
    N(H_(t+1)) subset H_t union I_t.

Define

    s_(t+1)=|N(H_(t+1))|-|H_(t+1)|,
    E_t=H_t minus N(H_(t+1)),       delta_t=|E_t|.

Then the exact set-difference identity yields

    |I_t| >= |N(H_(t+1)) minus H_t|
           = |H_(t+1)|-|H_t| + s_(t+1) + delta_t.       (1)

The size increment telescopes. If g(q) is any valid minimum surplus
profile on the finite board, (1) charges both the ordinary boundary tax
g(|H_(t+1)|) and the nonnegative excess

    delta_t + s_(t+1)-g(|H_(t+1)|).

This is not a new assumption on how efficiently the actual inspections
are chosen; redundant inspections merely increase the left side.

## Discarded-hole slack across a block

By definition H_t subset N(H_(t+1)) union E_t. Iterating gives

    H_t subset N^Delta(H_(t+Delta))
                union union_(j=0..Delta-1) N^j(E_(t+j)).

Each vertex of the square grid has at most (j+1)^2 vertices reachable
by an exactly j-step walk: these are the parity-compatible cells of its
Manhattan ball. Boundary truncation can only decrease this number.
Consequently, for any K subset H_t,

    sum_(j=0..Delta-1) (j+1)^2 delta_(t+j)
      >= |K minus N^Delta(H_(t+Delta))|.                (2)

If K is a known old inner corner core and the final holes have a known
outer ball about a different corner, the right side can be bounded by
the exact intersection of K with that outer ball expanded by Delta.
In particular the unweighted sum of discarded-hole slack is at least
the ceiling of this deficit divided by Delta^2. This charges actual
excess in (1), unlike a bound only on the total number of inspections.

## Why discarded-hole slack alone cannot close the problem

A full corner triangle can erode inward without any inspections. Except
at its final cell, its old support is exactly the neighborhood of its
next erosion, so delta_t can be zero throughout the erosion. The lost
area is paid by the boundary tax in (1), not by discarded-hole slack.
If a second component grows elsewhere while the first erodes, the useful
extra charge is instead the excess of their combined boundary over the
minimum boundary of a single set with the same total area.

Thus a successful uniform comparison must control the sum of BOTH terms
in delta_t+s_(t+1)-g(|H_(t+1)|), or an appropriate weighted version. The
new dominant-component localization in `physical-dominant-corner.md`
offers a way to detect spatial splitting even when a corner was removed.
No assertion that all relocation benefits are repaid has been proved.

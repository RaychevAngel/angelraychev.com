# Review and exact count for the physical hole-anchor charge

Accepted as ordinary mathematics, 24 October 2026 UTC. This reviews
`root-anchor-switch.md` and strengthens its numerical intersection bound.
It does not supply a new merged model or a constant capture-time gap.

The exact hole identity gives `N(K) subset H_t union I_t` for every
K subset H_(t+1), and hence the stated inspection charge. The nonempty
full quarter-ball neighborhood identity is valid with the stated parity
convention and width cutoff. For adjacent distinct corners the old-ball
condition excludes one half of the new full ball, by coordinate swap;
for diagonally opposite corners it excludes the entire ball. This proves
the claimed half-ball charge without an average-budget relaxation.

There is an exact bounded-operation count for adjacent corners. Let L be
their edge distance, delta=L-R>0, and let d in {0,1} be the source color
relative to the new corner. Define

    Qeff=Q-((Q-d) mod 2),
    delta_eff=delta+((delta-d) mod 2),
    ell=max(0,(Qeff-delta_eff)/2+1).

The old-ball condition in coordinates measured from the new corner is
`x-y>=delta`, or its coordinate swap. In a layer of distance u, the
number of included cells is zero until u=delta_eff, then1,2,...,ell.
Consequently

    |B_C'(Q) intersect B_C(R)|=ell(ell+1)/2.

The full new ball has `(m+1)(m+d+1)` cells, where
`m=floor((Q-d)/2)`. Subtracting the exact intersection gives the stronger
inspection charge. For opposite corners the intersection is zero.
The triangle is unclipped because Q<=w-1<=n-1.

The coordinate-only audit `physical-anchor-switch-check.py` passed76,920
exact intersection comparisons and4,800 full-core neighborhood identities
over widths4..24, nearby even-area lengths, both source colors, all
admissible radii, and all distinct corner positions relative to the fixed
old corner. It imports no candidate geometry routine. The ordinary proof
is uniform; this finite audit is an independent challenge, not its basis.

The separate lemma `physical-matching-block.md` extends the spatial charge
through an arbitrary number of intervening steps using a fixed perfect
matching, with only one extra radius unit on one parity of block lengths.

"""Exploratory high critical all-residue wall comparison; no width samples."""
from pathlib import Path
import json


ZERO=(0,0,0,0)


def normalize(q):
    x=q[0]
    return tuple(a-x for a in q)


def advance(q,A,B):
    x,y,p,r=q
    return min(A(y),B(x)),B(x),A(r),B(p)


def variants(state,v,lower):
    A=lambda q:q-v
    B=(lambda q:q-v)if lower else(lambda q:q-v+1)
    states={state}
    z=normalize(advance(state,A,B));states.add(z)
    zz=normalize(advance(z,A,B))
    assert zz in states,(state,v,lower,z,zz)
    return states


def delay(q,A,B):
    x,y,p,r=q;answer=0
    while max(p,r)>x:
        p,r=A(r),B(p);answer+=1
        assert answer<100
    return answer


def wall(states,v,square):
    if square:
        A=lambda q:q-v-(q<=0)
        B=lambda q:q-v
        old_lower=True
    else:
        A=lambda q:q-v
        B=lambda q:q-v+(q>0)
        old_lower=False
    out={ZERO};count=0;maxexit=0;maxdelay=0;maxsteps=0;bad=[]
    for state in states|{ZERO}:
        for s in variants(state,v,old_lower):
            for entry in range(1,v+2):
                q=tuple(a+entry for a in s)
                if advance(q,A,B)[0]>0:continue
                steps=0
                while max(q)>0:
                    q=advance(q,A,B);steps+=1
                    dd=delay(q,A,B);maxdelay=max(maxdelay,dd)
                    if dd>2:bad.append(dict(q=q,delay=dd))
                    assert steps<100
                q=advance(q,A,B);steps+=1
                dd=delay(q,A,B);maxdelay=max(maxdelay,dd)
                if dd>2:bad.append(dict(q=q,delay=dd))
                assert q[1]>=q[0] and q[1]-q[0]<=1
                assert q[2]>=q[0] and q[3]>=q[1]
                out.add(normalize(q));count+=1
                maxexit=max(maxexit,-q[0]);maxsteps=max(maxsteps,steps)
    return out,dict(states=len(out),branches=count,max_exit=maxexit,max_steps=maxsteps,maxdelay=maxdelay,failures=bad[:10])


def common_audit(states,v,lower):
    A=lambda q:q-v
    B=(lambda q:q-v)if lower else(lambda q:q-v+1)
    rows=[]
    for s in states|{ZERO}:
        for q in variants(s,v,lower):
            rows.append(dict(q=q,delay=delay(q,A,B)))
    return dict(branches=len(rows),maxdelay=max(r['delay']for r in rows),failures=[r for r in rows if r['delay']>2][:10])


def run(C=5):
    rows=[]
    for d in range(1,5):
        states={ZERO};trace=[]
        # Descend from lower half root b through root b-C+1.
        for j in range(C):
            v=d+j
            trace.append(dict(j=j,kind='common_lower',**common_audit(states,v,True)))
            if j==C-1:break
            states,meta=wall(states,v,True);trace.append(dict(j=j,kind='square',**meta))
            trace.append(dict(j=j+1,kind='common_upper',**common_audit(states,v+1,False)))
            states,meta=wall(states,v+1,False);trace.append(dict(j=j+1,kind='pronic',**meta))
        rows.append(dict(d=d,trace=trace,states=sorted(states)))
    return dict(status='EXPLORATORY_OVERAPPROXIMATION',root_bands=C,width_samples=0,rows=rows)


if __name__=='__main__':
    result=run()
    Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({**result,'rows':[dict(d=r['d'],states=len(r['states']),maxdelay=max(x['maxdelay']for x in r['trace']),maxexit=max(x.get('max_exit',0)for x in r['trace']),failures=[x for x in r['trace']if x['failures']])for r in result['rows']]}))

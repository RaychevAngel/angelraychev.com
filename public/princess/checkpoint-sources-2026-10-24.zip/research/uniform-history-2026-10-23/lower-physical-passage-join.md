# Joining a physical hole passage to the accepted merger lower bound

24 October 2026 UTC. Ordinary theorem, submitted for independent review.
This joins an actual-history estimate to the already accepted necessary
model. It neither asserts a merger for the new anchor labels nor doubles
an unproved physical solo optimum.

## A general joining theorem

Consider an even-area rectangle with h cells in each color and a daily
budget 1<=k<h. For a physical joint history starting from the full board,
let A_t^0,A_t^1 be its two cohort beliefs after t complete inspections
and moves, and write

    Q_t = 2h-|A_t^0|-|A_t^1|.

Thus Q_0=0. A perfect matching implies that neighborhood formation cannot
decrease the cardinality of either survivor set, so every actual step
satisfies

    Q_(t+1)<=Q_t+k.                                  (1)

Fix integers H,Z with 1<=H<=Z<h-k. Suppose every actual joint
history's first time t_H with Q_(t_H)>=H satisfies

    t_H>=j0,       Q_(t_H)<=Z,                       (2)

where j0 is a nonnegative integer. If a history never reaches H, it
already cannot capture the whole board, and causes no exception below.

Let B_s(c,e) be the accepted ordinary nine-feature backward threshold:
the largest model belief size with corner features(c,e) that can be
captured in at most s inspections, with B_0=0. The ordinary model here
means the already accepted erosion/corner model with its proven static
bands, without the new physical anchor labels. Its backward winning
sets are exactly size thresholds; its guarded joint-to-solo merger is
already proved in `research/resumed-erosion-merger-proof.md` and the
universal extension `research/uniform-gap-2026-10-23/lower-erosion-proof.md`,
with the static-band implementation independently accepted in
`research/uniform-gap-2026-10-23/upper-review-band9.md`. In particular

    max_(c,e) B_1(c,e)=k.

Put

    a* = h-Z,
    s* = min {s>=1 : max_(0<=c,e<=2) B_s(c,e)>=a*}.    (3)

Then, whenever s* is finite,

    T_k(w,n) >= 2(j0+s*)-1.                          (4)

The same proof gives impossibility if no finite s* exists. No geometric
attainment of B_s is needed; these are necessary-model thresholds.

## Proof of the first gate bound

Let t_g be the first time Q_t>=h-k. The overshoot hypothesis ensures
that the first H-crossing occurs strictly before this gate:

    H<=Q_(t_H)<=Z<h-k.                              (5)

At this crossing the merged belief size is

    m_(t_H)=|A_(t_H)^0|+|A_(t_H)^1|-h
           =h-Q_(t_H)>=h-Z=a*>k.                    (6)

Retain the actual merged corner and erosion features supplied by the
accepted nine-feature merger. At every subsequent time before t_g the
merged source size is strictly larger than k. Therefore the old guarded
merger applies to every transition from t_H through t_g, with exactly
the actual total inspection cost and exactly the merged target size.
There is no new anchor certificate in this continuation.

At t_g the merged target size is at most k. It is positive: the preceding
merged size is >k and (1) implies that a step reduces it by at most k.
The merged model can therefore capture with one further inspection.
This constructs a model capture from the crossing state using
t_g-t_H+1 inspections. By the threshold characterization and (6),

    max_(c,e) B_(t_g-t_H+1)(c,e)>=a*.

Consequently

    t_g>=t_H+s*-1>=j0+s*-1.                          (7)

If an actual history never reaches this gate, it cannot capture the full
board and again needs no separate case. Notice that this argument only
uses the new physical information before the H-crossing. The continuation
uses the old model exactly in its proved guarded range.

## The reversed-walk cut, with day indices

Write g=j0+s*-1. Since a*>k, s*>=2, hence g>=1. Equation(7) says that
every physical joint history satisfies Q_t<h-k at all t<g.

Suppose a winning schedule used at most2g days, and pad it with empty
inspection sets to length2g. Process its first g inspection sets
forward, including the move after the g-th inspection. At time g-1 its
deficit is <h-k; by (1), after the g-th move its deficit is <h. Thus its
possible-position set B, on day g+1, has more than h vertices.

Now process the last g inspection sets in reverse order, using the
undirected grid edges. Perform g-1 complete reversed inspections and
moves, followed by the final reversed inspection without a move. The
g-1-step deficit is <h-k by the same universal physical bound. The
final inspection removes at most k additional rooms, so the resulting
set R, also on day g+1, has more than h vertices.

The board has2h vertices, so B and R intersect. A vertex in the
intersection has a walk avoiding the first g inspections and a reversed
walk avoiding the last g inspections. Concatenating them produces a walk
avoiding all2g inspections, a contradiction. Therefore

    T_k>=2g+1=2(j0+s*)-1,

as asserted. This is the usual physical reversed-walk argument applied
to the newly proved gate bound, not to a proposed new merged model.

A universally available overshoot envelope is Z=H+k-1, by (1) and
integrality, whenever H+2k<=h. A sharper physical envelope should be
used when available: losing k rooms in this estimate can be costly in
the low-budget slow region.

## Applying the eight-day physical passage

Under the hypotheses of `root-interior-passage.md`, put

    H=(b-11)^2,
    J=min_p min{t : X_t^p>=H},
    j0=max(0,J-8),

where X_t^p is the actual forward-hole prefix capacity after t complete
inspections and moves, starting at0 in either phase. It is NOT the
backward capturable threshold whose first layer is k. The physical
passage theorem supplies (2).

Its guards k>=108 and b-11>floor(2k/3) imply b>=84 and
2k<3(b-11). Since h>=2b^2,

    h-H-2k > b^2+19b-88 >0.

Thus the coarse overshoot envelope already satisfies the joining guard.

At this particular crossing there is a stronger envelope. Every crossing
target is at most H+k-1<(b-10)^2<b^2, so the physical scalar profile in
the passage proof gives

    Q_(t_H)+ceil(sqrt(Q_(t_H)))<=H-1+k.

Consequently choose

    Z=G_k(H-1)=H-1+k-rho(H-1+k),
    a*=h-Z,                                         (9)

where rho(N) is the least r with r(r+1)>=N. In particular

    Z<=H+k-(b-11)-1=H+(k-b)+10.

This avoids the unnecessary k-room overshoot loss: the true bound is
only k-b+10 rooms past H. Feasibility gives Z>=H, and the preceding
coarse envelope proves Z<h-k. Using (9) in (3), the new lower bound is

    T_k(w,n)>=2(max(0,J-8)+s*)-1,                   (8)

and in particular it implies the slightly weaker expression
2(J-8+s*)-1 without needing to assume J>=8.

## What remains for a uniform small numerical gap

This theorem is an exact joining inequality with computable quantities.
It does not assert that its right side is within a fixed constant of
the existing physical upper. To obtain that conclusion, compare
J+s* with the actual solo prefix capture clock P, keeping the forward
hole / backward threshold distinction explicit.

The physical passage has already paid for most of the high-boundary
interior. The ordinary continuation begins at size at least h-G_k(H-1);
its backward threshold needs the low boundary, any intervening middle,
and only the remaining near-critical part of the high boundary. The
needed uniform comparison is now a concrete relation between those
clocks, rather than an unproved merger of the new physical history label.
Small budgets and budgets outside the passage theorem's range remain
separate coverage obligations.

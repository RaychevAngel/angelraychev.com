"""Independent raw-set attacks on near-extremal full inner layers and dual resets."""
from pathlib import Path
import itertools,random,math,time,json,hashlib
P=Path(__file__).resolve().parent
def adjacent(xy):
 x,y=xy
 return [(a,b)for a,b in((x-1,y),(x+1,y),(x,y-1),(x,y+1))if a>=0 and b>=0]
def shadow(S):return set().union(*(set(adjacent(z))for z in S)) if S else set()
rng=random.Random(20261024);start=time.process_time();candidates=accepted=physical=0;rows=[]
for r in range(2,7):
 for p in (0,1):
  L=r-p;top=2*r-2-p
  pool=[(x,y)for x in range(top+1)for y in range(top+1-x)if(x+y)%2==p]
  full=set(pool);N=shadow(full);neighbors=[sum(1<<i for i,z in enumerate(pool)if y in adjacent(z))for y in N]
  minimum=(r-1)**2 if p==0 else(r-1)*(r-2);maxdef=len(pool)-minimum-1
  subsets=[]
  for d in range(min(maxdef,6 if r<=4 else 4)+1):subsets.extend(itertools.combinations(range(len(pool)),d))
  for _ in range(3000):
   d=rng.randrange(maxdef+1);subsets.append(tuple(sorted(rng.sample(range(len(pool)),d))))
  local=0
  for holes in set(subsets):
   S=full-{pool[z]for z in holes}
   if p==0 and(0,0)not in S:continue
   candidates+=1;q=len(S);mask=sum(1<<i for i,z in enumerate(pool)if z in S)
   ns=sum(bool(mask&a)for a in neighbors)
   if ns-q>r:continue
   assert ns-q==r
   d=len(pool)-q;M=(math.isqrt(8*d+1)-1)//2;inner=2*(L-M-1)+p
   expected={z for z in full if sum(z)<=inner}
   assert expected<=S,(r,p,d,S,expected-S)
   accepted+=1;local+=1
   for w,n in((2*r+2,2*r+2),(2*r+2,2*r+3)):
    h=w*n//2;D=w+n-2
    V={(x,y)for x in range(w)for y in range(n)if(x+y)%2==p}
    W={(x,y)for x in range(w)for y in range(n)if(x+y)%2!=p}
    A=W-shadow(S);B=V-S
    if shadow(A)&V!=B:continue
    corners={(0,0),(w-1,0),(0,n-1),(w-1,n-1)}
    i=len(A&corners);j=len(B&corners)
    v=sum(all(z in B for z in adjacent(c)if z in V)for c in corners&W)
    assert len(B)-len(A)==r
    if p==0:assert(i,j)==(2,1);rad=D-2*r+1+2*M;relative=D%2
    else:assert(j,v)==(2,1);rad=D-2*r+2+2*M;relative=1^(D%2)
    rad=min(D,rad);anchor=(w-1,n-1)
    assert (sum(anchor)-p)%2==relative
    assert all(abs(x-anchor[0])+abs(y-anchor[1])<=rad for x,y in B),(r,p,d,w,n)
    physical+=1
  rows.append(dict(r=r,parity=p,accepted_quadrant_sets=local))
sources=[Path(__file__),P/'lower-dual-bin-stability.md']
out=dict(status='PASS',candidate_raw_sets=candidates,near_extremal_raw_sets=accepted,complemented_physical_transitions=physical,rows=rows,CPU_seconds=time.process_time()-start,source_sha256={z.name:hashlib.sha256(z.read_bytes()).hexdigest()for z in sources})
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print(out)

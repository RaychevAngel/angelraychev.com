# Low-boundary growth: balanced phases and an amortized error bound

24 October 2026 UTC. Research note. The injection-count lemma below is
proved for the explicitly defined balanced comparison process. The final
one-day comparison, and a complete reduction of the nine-feature model
through its critical strip transitions, remain open.

## Two processes

Let `b=floor(w/2)` and let the feasible budget satisfy `k>=b+1`. Define

    F(x)=k+x-min(ceil(sqrt(x)), b+(w mod 2)),
    G(x)=k+x-min(rho(x), b),

where `rho(x)` is the least `r>=0` with `x<=r(r+1)`. Thus the physical
low-only prefix process is

    X_(t+1) = H(X_t),     H(p,q)=(G(q),F(p)),     X_0=(0,0).

Define `C(p,q)=(max(p,max(p,q)-1),max(q,max(p,q)-1))` and the balanced
process `B_(t+1)=C(H(B_t))`, also starting at zero. Both scalar maps are
nondecreasing and 1-Lipschitz, and

    G(x-1)<=F(x)<=G(x)                 (x>=1).

For even width both maps have positive progress. For odd width at the
minimum budget, the final clipped square map has zero progress, while
the pronic map still has positive progress. Arguments requiring strict
progress of both maps must therefore stop before this critical region.

The conjectured useful comparison is

    B_t <= H^(t+1)(0,0)                coordinatewise.

It has not been proved. A weaker fixed-day shift would already suffice
for the intended all-width comparison once the terminal analysis is joined.

## The only artificial increment

The balanced process always has coordinate difference at most one. From
`G(x-1)<=F(x)<=G(x)`, the first coordinate of `H(B_t)` never needs raising.
The exact recurrence is consequently

    p_(t+1)=G(q_t),
    q_(t+1)=max(F(p_t),G(q_t)-1).

An artificial increment is either zero or one. It occurs only from an
opposite-phase-leading state `(z-1,z)` and exactly when

    G(z)-F(z-1)=2.

This is a precise source of model advantage; there is no need to speak
about unrestricted arbitrary phase switching.

## Proved injection-count lemma

On each interval on which `G(x)-F(x)=1` and both affine slopes are one,
the balanced process introduces at most one artificial increment.

Indeed, after such an increment the state is own-phase-leading, `(a,a-1)`.
As long as subsequent relevant inputs remain in that interval, write
`G(x)=x+d` and `F(x)=x+d-1`. An own-phase-leading state goes to a tie,
and a tie goes to an own-phase-leading state. Neither can introduce an
increment. All coordinates are nondecreasing, so an interval cannot be
left and later reentered. If a step leaves the interval, any later
increment belongs to a later interval.

For the actual square/pronic maps the nonterminal intervals are

    j^2 < x <= j(j+1).

They are separated by the intervening pronic-to-square intervals, so
there are at most `b-1` possible injection intervals in even width. In
odd width there are at most `b`, including the final permanently clipped
interval beginning after `b^2`.

If `I_t` is the number of increments through time `t`, monotonicity and
the 1-Lipschitz property give the rigorous comparison

    0 <= B_t-X_t <= (I_t,I_t).

This is a direct induction: an ordinary step cannot increase the
coordinatewise maximum difference, and a balancing step adds at most
one. In particular, the low growth process has an `O(w)` room bound
without any search over widths or lengths.

More locally, before the balanced maximum passes a root scale `r`, at
most `r` injection intervals have been visited. Thus the error is at
most `r` rooms. In a region with `r<=c*k`, `c<1`, the physical progress
is of order `(1-c)k`; this reduces the unresolved constant-day comparison
to the slow region near the strip threshold. A precise numerical day
constant still requires endpoint accounting; none is claimed here.

## Concrete connection to the nine-feature low recurrence

Away from the strip cap, its normalized frontier closes on the following
four patterns, with maximum entry `z`:

* A: every entry is `z`.
* B: only feature `(0,0)` is `z-1`.
* C: entries with erosion feature `e=0` are `z-1`; all others are `z`.
* D: entries with corner feature `c=0` are `z-1`; all others are `z`.

For `z=r^2+u`, `r>=5`, `0<=u<=2r`, direct substitution into the square
and quadratic inverses gives this proposed transition table. The additive
budget `k` is included in `F,G` above.

* A or B: new maximum `G(z)`; new pattern D for `1<=u<=r`, B otherwise.
* C: new maximum `G(z)` and new pattern D.
* D: new maximum `F(z)`; new pattern B for `1<=u<=r+1`, C otherwise.

Patterns B, C, D correspond respectively to a tie, an opposite-phase
lead, and an own-phase lead in the balanced two-coordinate process.
The table has been derived and checked on representative root bins,
but a complete branch certificate, the tiny-root base cases, and the
critical-strip transitions are not yet supplied here. Therefore the
injection lemma is not silently asserted for the full nine-feature
model.

The critical distinction matters: odd width can gain one extra room
over the simple balanced process. For example `w=31,k=16,t=65` gives
nine-feature maximum227 and balanced maximum226. Likewise, at an even
critical cap a nine-feature all-equal vector need not mean a balanced
tie: for `w=144,k=73,t=446`, the former has all entries5115, while the
balanced pair is `(5114,5115)`.

## Failed shortcuts and useful reductions

The ordinary three-corner model is too weak for one-day low domination:
`w=46,k=24,t=79` gives its maximum487, while the physical next-day
maximum is486. Erosion information is essential to the candidate bound.

The stronger claim that the nine-feature minimum is at most the next
physical minimum also fails: `w=144,k=73,t=446` gives5115 versus5114.
This does not refute the balanced-process conjecture, because of the
critical interpretation issue just described.

The parent's first arbitrary-map counterexample used an `f` with jumps
of size two. It refutes monotone sandwich inequalities alone, but not a
claim requiring both maps to be 1-Lipschitz. Independent valid-map
diagnostics have not found a counterexample to the balanced comparison;
these checks do not prove it.

Eliminating the first balanced coordinate gives

    q_(t+1)=max((F composed with G)(q_(t-1)), G(q_t)-1).

Write `J=F composed with G` and `Q=G-1`. Then `Q^2<=J-1`. However the
stronger proposed word reduction `Q J^m Q<=J^(m+1)` is false for valid
abstract maps, as recorded in the parent's counterexample. Pairwise
deletion of all phase switches is therefore not a valid proof.

For a first violation of coordinatewise one-day domination, monotonicity
forces exact contact in the first coordinate: the preceding balanced
state is `(x,x+1)`, the physical one-day-ahead state is `(x,y)` with
`y>=x+1`, and `G(x+1)=F(x)+2`. Only the second coordinate can first
fail, and only by one. This is the sharp contact condition still requiring
a history argument.

## Research status

No all-width constant capture-time gap has been proved in this note.
No counterfamily to the accepted full history model has been found.
The work narrows the issue to a concrete one-cell phase correction and
supplies a rigorously amortized room bound for its balanced comparator.
The outstanding task is to prevent repeated corrections from exhausting
a constant number of physical days as the root scale approaches `k`.

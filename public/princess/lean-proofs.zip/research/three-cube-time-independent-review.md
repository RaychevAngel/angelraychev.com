# Independent review: complete minimum capture times on the 3 × 3 × 3 grid

## Conclusion and scope

The assembled theorem `ThreeCubeTimeClassification.can_capture_iff` gives a
complete statement for every natural inspection budget m and every round index t:
a globally budgeted physical schedule guarantees capture by round t if and only
if m≥5 and the tabulated minimum is at most t+1. Round zero is the first day.

The minimum days are 18 for m=5, 10 for m=6, 6 for m=7 or 8, 4 for m=9,10,11,
3 for m=12, 2 for 13≤m≤26, and 1 for m≥27. Budgets m≤4 are impossible.

This is a result of the present investigation. Literature priority is a separate
question; the formal theorem does not assert novelty. It does not settle other
boxes, arbitrary side lengths, or arbitrary dimension.

## Lower proof and independent checks

The room type is Fin 27, encoded by (x,y,z)=(v/9,(v/3)%3,v%3). The adjacency
predicate requires exactly one coordinate to change by one and the others to
remain equal. A checked finite theorem establishes that adjacent rooms have
opposite colors and that every room has a neighbor.

An arbitrary belief B and inspection set S are partitioned by their current
physical colors. The two inspection cardinalities sum exactly to |S|. After the
inspection and movement, each color slice is exactly the neighborhood of the
opposite surviving slice. The proof does not restrict the inspection schedule,
assume a canonical support shape, or use a strategy compression theorem.

The two neighborhood lower profiles, including their zero entries, are:

- even source: 0,3,5,7,8,9,10,10,11,12,12,13,13,13,13;
- odd source: 0,4,6,7,9,10,11,12,12,13,13,14,14,14.

`FiniteSubsetProfiles.checkAll_sound` proves a generic include/exclude checker
sound for every selected subset of a finite list. The concrete checker branches
over 14 even or 13 odd rooms, carrying only selected cardinality and a union of
neighborhood bitmasks. Each bitmask is independently checked against the physical
coordinate adjacency. The resulting certificate covers all 2^14+2^13 supports.
`ThreeCubeTimeIsoperimetry.profile_lower` connects it to arbitrary Prop-valued
room sets. The selected-count/global-cardinality equality explicitly uses the
same-parity support hypothesis; no mixed-support state is omitted from the final
proof, because arbitrary mixed beliefs are first split by current color.

For each essential lower-budget endpoint 5,6,8,11,12, a finite potential is
specified on the 15×14 possible count pairs. Lean checks that it is nondecreasing
in each count, vanishes at (0,0), has the required initial value at (14,13), and
can decrease by at most one under every relaxed full-budget transition. Profile
monotonicity extends that fact to unused budget and larger physical successor
supports. Summing the one-step inequalities gives the desired lower bound.
The packed numeric potential data are certificates, not trusted solver outputs:
the generating search's optimality is unnecessary for the proof.

The lower bound of two days for 13≤m≤26 is checked separately: at day zero the
full belief has 27 rooms, so fewer than 27 inspections cannot guarantee capture.
The earlier four-probe trapping theorem supplies impossibility at all m≤4.

## Upper proof and semantics

Actual coordinate schedules are encoded as room lists and replayed against the
physical graph. Essential witnesses are provided for budgets 5,6,7,9,12,13; budget
monotonicity covers the gaps, and m≥27 inspects every room. The finite list replay
is connected to the unrestricted set-valued recurrence, then to every actual
avoiding walk. The final schedules satisfy the daily budget on all rounds,
including rounds after the guaranteed capture time.

I independently inspected `next_slice`, `next_profile`, `stateRank_step`, the
finite-counter `physical_step`, the smaller-budget impossibility bridge, and the
final `can_capture_iff` quantifiers. I found no substantive gap or hidden
geometric assumption. As with the path result, deterministic all-failure probe
schedules are formalized directly. The familiar reduction of a deterministic
adaptive strategy to its unique all-failure branch is explanatory rather than a
separate adaptive-strategy datatype.

## Computational trust and resource use

The profile certificate uses `decide +kernel`, not native_decide or an external
solver axiom. Large arrays initially caused high memory use. Neighborhood rows
and profile entries are now packed in natural numbers, and a proved binary-digit
counter replaces repeated finite-room list counting inside the checker. The
semantic theorem still uses the original finite cardinality definition.

The fresh exact-source build receipt is
`research/three-cube-time-lean-verification.json`. Standard logical axioms may
include propositional extensionality, classical choice, and quotient soundness;
no sorryAx, added axiom, or assumed geometric classification is used.

# Independent review of the new uniform budget families

13 September 2026. Parent review of the independently developed arguments.
These are ordinary proofs and finite certificates. No new Lean compilation,
manuscript build, or public artifact release is asserted.

## Odd boards: every budget up to width minus one

Accepted: for odd w=2b+1>=3, n>=w odd, and b+1<=k<=2b, the exact
physical time is 2tau-1 if the sum of the two precentral solo residuals
is at most k, and 2tau otherwise. The canonical solo-prefix central
construction attains the first value; the established solo construction
attains the second. The scalar clocks can still require a recurrence.

The parent separately checked the q-window collar proof, the generalized
orientation onset with J=max(2K+k+1,K+b²+1), all constants in the
unbounded b>=160 proof, and the twenty margins covering b140..159.
The source is bridge-odd-clock-linear-budget.md.

The parent reconstructed all 3,168 original finite interval endpoints
directly from K_old, K8, and the onset, obtaining exactly19,826 triples.
The original1,907 residual input and output keys matched exactly; all
cost decisions and source hashes matched. The retained-frontier C++ code
was checked against the existing exceptional-retention and physical
midpoint theorem: the majority saturation is at inverse input M, the
minority saturation at E, and the calculation stops at the last proper
layer. Every quota split is considered. Descending-x Pareto pruning is
valid because transitions and final capped union are monotone.

The later complete certificate removes the scalar filters from the
proof dependency. It checks19,852 cases, including26 small-width cases,
in5.523 CPU seconds. The optimized implementation was separately read:
both inverse lookups include every input through E+k; every touched
per-x maximum is cleared after use; descending-x filtering is identical
to coordinatewise Pareto pruning; final pairs are exhaustively evaluated.
The equality check compares the exact central decision with the distinct
solo central decision, so it is not tautological. The receipt is
bridge-odd-clock-linear-budget-whole-verified.json. See
bridge-odd-clock-linear-budget-all.md for the combined theorem.

## Odd boards: a superlinear budget range

Accepted in addition: 27k³<=b⁴. If k<=2b the preceding theorem applies.
Otherwise b>216, and q=ceil(sqrt(b)) in the new collar proof gives
K<=449b²/900<b²/2. The checked estimates imply k<b²/100,
J<=3b²/2+1, and W<=2sqrt(k)+2. Consequently the orientation onset is
less than97b²/50, below the smallest admissible board's M=2b(b+1).
The parent checked the ceiling in r, q(b-1)>=k-1, the positive domains,
and all rational constants. This is an ordinary all-length theorem;
no finite extrapolation is involved. Source:
bridge-odd-clock-superlinear-budget.md.

## Even-area boards: a uniform one-day interval at linear budgets

Accepted: for w>=4, n>=w, wn even, and ceil(4w/3)<=k<wn/2, the named
critical-corner lower and physical-prefix upper differ by at most one
day. This does not decide which of those days is optimal in every case.

For even w, the root-buffer proof was checked through the low root bands,
the lossless common middle, and the alternating high-collar losses.
For odd w, the parent checked the positive delta hypothesis, the entrance
at B0>=b(b+1)-1, the aligned invariant X0>=B2+c and X1>=B0+c, and
the single physical trajectory used through the high part. This does
not select a fresh favorable physical phase on every day.

The seven remaining odd-width budget lines have an exact two-update
translation by D=2k-2b-1. The parent checked the low thresholds, stable
entry margin, unchanged high arguments under simultaneous translation
of all five coordinates and the half-area, and translated state caps.
The insertion n->n+2D adds2w physical updates. Every inserted pair has
the checked comparison, and all later comparisons translate unchanged.
The finite lengths w+1 through n0+2D-2 contain all shorter boards and
one representative of every even residue. Source:
bridge-upper-transport-odd-exceptions.md, with the two coupling notes.

## Radius geometry and remaining lower-bound work

The exact aligned-lens formula, negative radius-cut arguments, parity
inclusion-exclusion, radius-sum consequence, and guarded merger were
independently checked. The new radius-aware clock gives a Bellman lower
potential. Its extension outside the terminal size sector must clip its
size argument, as explained in bridge-lower-frontier-radius-clock.md.
Neither that potential's initially weak value nor the finite width23/47
diagnostics proves the general terminal-hull conjecture.

The proposed consecutive sharp-event charge has passed an independent
necessary-model test on b2..20 (19,263 admissible cases). It remains a
conjecture pending an ordinary proof and treatment of critical excursions.
See bridge-sharp-event-charge-check.json. Testing the smallest even
length uses the weakest lens constraint; larger lengths cannot introduce
new admissible events at those fixed widths.

## A rejected simplification

The parent suggested that solo deficits remain tied or differ by one
before the reflected root branches activate, which would erase all early
exceptional histories. This is false. For11x11,k7, the bottom-only
sequence is (0,0),(4,4),(8,7),(10,11),(14,12). One-Lipschitz inverse
maps with a pointwise difference of at most one do not preserve the
proposed interlacing. This failed shortcut is not used in any theorem
accepted above. Whether relevant actual exceptional frontiers always
admit a correctly oriented dominating representative remains open.

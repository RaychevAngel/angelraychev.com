# Independent semantic review of the ladder Lean theorem

11 September 2026 PT, beginning approximately 19:45. Reviewed independently
of the author of `LadderGame.lean`. The coordinating agent performs the
separate fresh compilation; this review concerns whether the definitions
and proved statements express the intended mathematical game.

**Conclusion: no substantive semantic or mathematical gap found.** The
assembly now reaches arbitrary probe sequences on the actual physical
ladder, including finite cardinalities and capture-before-movement. The
new single-edge declarations added during review also correctly cover
`n=1`. Together the declarations classify every positive column count and
positive probe budget. They do not classify wider grids.

## 1. Actual graph, not an assumed projection

`LadderGeometry.Room n = Fin n × Bool` gives exactly two physical rows
and `n` columns. `rowAdj` allows precisely:

- the opposite row in the same column;
- either adjacent column in the same row, when that column exists.

There are no loops, diagonal moves, wraparound moves, or jumps. The
checkerboard-coordinate Boolean is introduced separately through
`recolor`, which is proved involutive. `rowAdj_iff_colorAdj` proves the
edge correspondence in both directions. The apparent “stay” in
`closedPathAdj` is a vertical move to the other physical room, not a
license for the princess to wait in the same room.

`physicalStep_iff_recolored` transports both the arbitrary belief and
arbitrary probe set through the same bijection. Thus the physical-to-color
transfer does not accidentally move the target while leaving the probes
in their former coordinates.

## 2. Cardinalities really count all inspected rooms

`card` counts a predicate over `List.finRange n`, the exhaustive
duplicate-free list of column indices. `roomCard` sums the counts in the
two disjoint Boolean fibers. It therefore counts actual distinct rooms,
including probes outside the current belief.

`budget_split` identifies the two cohort allocations with that physical
count; `recolor_roomCard` preserves it under coordinate transport. Neither
lemma assumes probes are useful, in one color, or in a suffix. Counting
wasted probes in the lower bound can only make the compressed comparison
more generous to the searcher, which is the correct direction.

The use of classical predicates in these finite cardinalities does not
exclude any finite room subset. The formal theorem proves existence; it
does not by itself promise an extracted executable schedule generator.

## 3. Lower comparison covers arbitrary strategies

`column_count_lower B S` proves

```
next(n, |B|, |S|) ≤ |N_closed(B \ S)|
```

for all actual column sets. Its ingredients are separately proved:
removing `|S|` probes removes at most that many candidates, a nonempty
proper path subset gains an exterior neighbor, and the full and empty
cases are handled explicitly. The lower comparison does not assume that
an optimal arbitrary belief is an interval.

`room_run_to_counters` decomposes each arbitrary room state into the two
current colors, updates both exactly using `pair_step`, and invokes the
cardinality lower comparison. `counters_mono` allows the more favorable
compressed state to follow the successful remaining allocations. This
direction is correct: success from a larger actual state implies success
from the smaller compressed one, so counter impossibility rules out
actual success. The initial `full` room state has `n` candidates in each
fiber.

The final lower theorem quantifies over **every** sequence
`Nat → RoomSet n` satisfying the daily budget. Requiring the budget at
all future times loses no finite strategy: after its last relevant day,
it can be padded with empty probe sets. Adaptive deterministic strategies
have only the single all-misses continuation before capture, so this
sequence formulation covers their worst-case guaranteed time as well.
That elementary adaptive-to-sequence observation is not a separate Lean
declaration here.

## 4. Attainment is implemented by legal room probes

The upper direction uses `suffix b`, a terminal interval of exactly `b`
columns when `b≤n`, and `cut b p`, its first at most `p` columns.
`suffix_step` proves equality of the actual next column set with the
suffix of length `next(n,b,p)`; it handles complete elimination,
endpoint saturation, and zero probes.

`counters_to_room_run` combines the two cuts in opposite colors.
`pair_card` and `cut_card_le` prove the physical budget. After the move,
the color flips and the induction continues. The intermediate lengths
remain bounded by `n` through `next_le`. The initial paired suffixes of
length `n` really are the full room set. No numerical solver or unproved
certificate is assumed in this construction.

The counter upper proof permits probes beyond the cohort size. The
physical cut simply clips them to actual rooms, preserving the “at most
`m`” budget and the same elimination effect. This is legitimate.

## 5. Capture semantics and the index shift

In `BeliefSemantics.lean`, `possible ... 0` is the initial belief.
`possible ... (t+1)` applies probe set `probes t` and then one compulsory
edge move. `Reachable` describes an actual finite legal trajectory that
has missed all earlier probes. `possible_iff_reachable` establishes their
equivalence by induction, independently of the ladder.

`GuaranteesAt ... t` means that every trajectory still uncaught at
zero-based round `t` is hit in that round. An empty next belief is
equivalent to this claim only if an uncaught target always has a legal
move. That potential loophole is closed explicitly:
`physical_no_dead_ends` supplies the vertical neighbor of every room,
and `empty_iff_guaranteed_capture` invokes the general theorem with that
proved fact.

Consequently an optimum of **`T` rounds** means `possible ... T` is empty,
or, for positive `T`, `GuaranteesAt ... (T−1)`. It does not mean capture
at zero-based round `T`. The final theorem's convention is consistent
throughout. The `PhysicalClears` intermediate relation and its two
transfers to/from arbitrary sequences preserve exactly this count.

An already empty belief may be padded by more rounds. This is appropriate
for capture *by* the stated deadline and causes no lower-bound weakness:
the theorem minimizes all successful deadlines.

## 6. Parameter and boundary checks

- For `n≥2,m≥2`, `actual_ladder_classification` gives an attaining physical
  probe sequence and a lower bound for all physical probe sequences.
- For `n≥2,m=1`, `actual_one_probe_impossible` rules out every finite
  guaranteed-capture time. The counter invariant is stronger than a weak
  potential estimate: either full cohort remains full under zero or one
  allocated probe.
- The quotient formula automatically gives one round when `m≥2n`.
  At `m=2n−1`, its half-remainder obstruction instead gives two rounds;
  a one-round strategy cannot inspect the entire initial room set.
- At `m=2`, it gives `2n−2`; at `m=n`, it gives two rounds. These agree
  with the ordinary construction and matching threshold.
- `actual_single_edge_classification`, added during this audit, proves
  the `n=1` case: two rounds for `m=1`, one for `m≥2`. Its one-round lower
  obstruction requires both singleton cohorts to receive a probe and
  hence a total budget of at least two. The witness for `m=1` targets the
  same physical room twice, through the flipped cohort encoding.
- Zero columns and zero probes are outside the positive-parameter
  classification; no meaning is silently assigned to them.

The proved one-probe statement is nonexistence of any finite guaranteed
deadline. Constructing a single infinite evading walk for a fixed
sequence would additionally use a finite-branching compactness argument;
that is not needed for the stated capture-time classification and is not
a separate theorem in this artifact.

## 7. Arithmetic and reporting boundary

The executable optimum is the proved quotient expression with
`N=n−1`, `M=m−1`, `q=N/M`, `s=N mod M`:

```
2q       when s=0;
2q+1     when 0<s and 2s<M;
2q+2     otherwise.
```

For the nontrivial budget range this agrees with `ceil(2N/M)` plus one
exactly when `M` is even and `s=M/2`. **Addendum, 11 September 2026 PT:**
the newly added `LadderCounters.optimalTurns_ceiling` was independently
read and its successful fresh build confirmed in the updated receipt;
the ceiling expression and its exact half-remainder condition are now
also kernel-checked. The previous arithmetic-display limitation is closed.

The older boundary document was stale when first read. Its owner was
notified and is updating it. The reviewed assembly contains the formerly
missing cardinality and room-game steps. Final fresh build evidence,
source hashes, and axiom dependencies belong in
`research/ladder-lean-verification.json`; this independent review does not
substitute for that compilation receipt or claim publication novelty.

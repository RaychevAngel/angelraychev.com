# Independent semantic review: MiddleIntervalTransfer.lean

12 September 2026. Verdict: **PASS**.

The module's `Reach` relation records a genuine integer allocation p in
[0,m] at every step and gives the other counter exactly m−p. The initial
band condition is supplied by `hAB`; every subsequent step explicitly
retains both counters in the band. Cohort identities stay fixed in this
algebraic relation, as required for the accumulated-rate formula.

`exact_interval_iff` includes all endpoint conditions: both band bounds,
the exact total A+B+t(w−m), and the cumulative allocation bounds on the
first counter. `total_stays_in_band` correctly deduces intermediate total
feasibility from the two endpoints for either sign of w−m. The predecessor
construction preserves integrality and both quotas. Time-varying rates
are permitted precisely when each rate and its complement lie in [0,m].

`odd_middle_interval_iff` specializes the first rate to b+(t+z mod2),
with z<=1, and proves the accumulated total bt+floor((t+z)/2). This
agrees at both starting phases, including t=0,z=1. Its hypotheses match
the ordinary safe-band lemma's algebraic assumptions.

The file explicitly stops at an algebraic interval theorem. It does not
silently import the odd-rectangle isoperimetric theorem, supply geometric
safe-band bounds, or assert full-game capture. This proof boundary is
accurate. No changes or additional compilation were requested by this
review; the parent had already reported a clean source compilation.

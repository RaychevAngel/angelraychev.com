# A shorter arbitrary-strategy lower proof for paths

This reconstructs the lower bound in Angel Raychev's October 2019–March 2020
path work. The matching, history-bit, and ammunition-potential organization below
was developed during the present investigation. It does not change the original
result or claim that the reconstructed proof preceded the original work.

The entire argument, including the actual-room interpretation, is now checked
in Lean: `PathClassification.exact_minimum` and `can_capture_iff`.

## The formula and semantics

Let n≥1 be the number of rooms and m≥1 the daily inspection budget. Inspect
before the princess makes one compulsory edge move. The minimum days are:

- 1 when n≤m;
- 2 when n=2 and m=1;
- 2n−4 when n≥3 and m=1;
- for n>m≥2, ceil((2n−4)/(2m−1)), plus 1 exactly when
  n−m−1 is divisible by 2m−1 and n,m are not both even.

The formal statement quantifies over every physical region-valued inspection
schedule with the global budget on every day. Its capture predicate quantifies
over every actual avoiding walk. The isolated n=1 board is inspected directly;
no impossible movement is mistaken for capture.

## Separate cohorts, retain the common daily budget

The two possible initial color classes evolve separately under any schedule.
On each day they occupy opposite classes. Assign to each cohort exactly the
inspections in its current class. Their two assigned inspection counts add to
the total daily count. This decomposition does not restrict the strategy.

Write B for a cohort's current possible rooms, S for its assigned inspection
set, R=B minus S, and N(R) for the open neighborhood. Always
|R|≥|B|−|S|.

## Neighborhood geometry without enumerating components

For n even, the adjacent pairs (0,1),(2,3),... form a perfect matching.
Consequently |N(R)|≥|R| for every set R. At equality, membership propagates
along the alternating matching chain: if N(R) contains an endpoint, R contains
that endpoint's entire opposite color class. Thus an equality neighborhood
with |R|<n/2 has no endpoint. A nonempty endpointless set expands strictly:
equality would propagate one of its vertices to an endpoint, a contradiction.

For n odd, every even-indexed room g can be exposed by a matching covering all
other rooms. If an even-indexed room is absent from R, this matching again
injects R into N(R). If all even-indexed rooms lie in R, their neighbors cover
the smaller class. Hence |N(R)|≥min(|R|,floor(n/2)). A nonempty set in the
smaller class satisfies |N(R)|≥|R|+1: equality closure under the matching
exposing room 0 would send its least occupied room to a strictly smaller one.

All these statements are about arbitrary supports, without an interval or
monotonicity assumption.

## A one-dimensional lower counter

For even n, put u=2|B|+z. Here z is 1 exactly after a nonempty proper
zero-growth neighborhood, and otherwise 0. The geometry just proved ensures
that z=1 forces endpointless support and strict expansion next time it survives.
For odd n use u=2|B| in the larger class, u=2|B|+1 in the nonempty smaller
class, and u=0 for an empty support.

Every physical step dominates

    F_C(u,p) = 0                      if floor(u/2)≤p,
               min(C,u−2p+1)         otherwise.

On even paths C=n and both counters start at n. On odd paths the exact cap
alternates between n+1 in the larger class and n in the smaller class; the
initial values are n+1 and n. Replacing both caps and initial values by n gives
a weaker lower game, sufficient except in one equality case.

## A potential that replaces long round-by-round case analysis

For m≥1 put D=2m−1 and

    Φ_m(u) = floor((u + floor(max(u−3,0)/D))/2).

Whenever p≤m and u≤C,

    Φ_m(u) ≤ p + Φ_m(F_C(u,p)).

For p=0 the rank cannot decrease. For a surviving positive allocation, the rank
drops by 2p−1≤D, so its quotient term drops by at most one. For a final
allocation the quotient term vanishes and Φ_m(u)=floor(u/2)≤p.
Summing over both counters therefore gives 2Φ_m(n)≤mt at capture.

Write n=qD+r+2 with 1≤r≤D. Direct arithmetic gives

    Φ_m(n)=qm+floor((r+2)/2).

The resulting integer lower bound is 2q+1 if r≤m−2, or if r=m−1 and m is
even; otherwise it is 2q+2. This already matches the construction unless n is
odd, m is even, and r=m−1. The same potential gives 2n−4 for m=1,n≥3, and 2
for the two-room path.

## The sole equality obstruction

In the remaining case n=qD+m+1 with m,q even, suppose both exact alternating
counters finish by T=2q+1. For each counter choose its first zero and the last
full state before that zero. Let a be that full state's time and l the number
of allocations from it to the first zero. In the intervening states no cap is
hit, so the rank telescopes exactly. If P counts the allocated inspections,

    C(a)+l ≤ 2P+2,       P≤lm.

These inequalities force l≥q+1 and P≥qm+m/2. The common T-day budget forces
equality for both cohorts. Equality further forces l=q+1 and C(a)=n, so both
intervals start in their smaller color class.

The two starting times have opposite parity. Because q is even and both
intervals fit in the T-day horizon, either both intervals fit in its first
2q days or both fit in its last 2q days. Their combined inspections equal
(2q+1)m, contradicting the budget of that shorter window. Thus T is impossible
and one further day is necessary.

The interval proof does not assume that the intervals are disjoint, that all
shots were useful, or that either physical cohort remains a prefix.

## Verification and proof boundary

The complete dependency closure consists of 18 Lean modules and was freshly
compiled sequentially in about 17 seconds. The exact-source receipt is
`research/path-full-lean-verification.json`. Final theorem axiom reports contain
only Lean's standard propositional extensionality, classical choice, and quotient
soundness. No admitted theorem, additional axiom, computational classification
assumption, or geometric hypothesis remains in the complete path statement.

# Lean verification: exact current scope

The development uses **Lean 4.33.1 and Std**. Fresh checks compile sequentially
with one compiler worker. The exact module count, elapsed time, compiler
outputs and source hashes are in `research/lean-verification.json`.

## Complete physical-game classifications

| Final module | Verified conclusion |
|---|---|
| `PathClassification.lean` | Every positive path length and daily budget: exact minimum days, an attaining room schedule, and impossibility of faster capture against arbitrary actual avoiding walks. Includes the one-room case, one probe, and the parity/residue correction. |
| `LadderGame.lean` | Every positive two-row length and budget, including the single edge: exact minimum days, finite/infinite feasibility, and physical attaining schedules with the global daily budget. |
| `ThreeCubeTimeClassification.lean` | Every natural budget on the 3×3×3 grid: feasibility exactly from five probes onward and the complete minimum-time table 18,10,6,4,3,2,1 over the stated budget ranges. |

The path and cube final modules expose `can_capture_iff` and `exact_minimum`.
Round zero is the first inspection day: a last-round index t means t+1 days.
The semantics quantify over arbitrary region-valued inspection sequences and
all legal avoiding walks. They do not assume that an opponent or searcher uses
one of the displayed patterns. Independent reviews check that those definitions
match the physical room game.

## Reusable theorems and partial formalizations

| Modules | Scope |
|---|---|
| `BeliefSemantics`, `CaptureRecurrence` | Exact possible-position/walk semantics, winning recurrences, downward closure, erosion predecessors, and losing-state trap certificates. |
| `StrategyCompression` | A monotone, cardinality-preserving, neighborhood-subcommuting operator compares complete strategies with arbitrary daily budgets and actual-walk semantics. Concrete geometric operators remain ordinary proofs. |
| `ProfileInverse`, `BipartiteProfileDuality` | Actual minimum-neighborhood profiles for any finite bipartite relation, exact complement/inverse duality, and the one-unit maximum-surplus difference for no-isolate parts of sizes M+1,M. The graph minima are defined and attained, not assumed oracles. |
| `PathGeometry`, `PathSweep`, `PathUpper`, `PathUpperArithmetic` | Actual-room indexed sweeps and arithmetic equality with the path formula. |
| `PathLowerGeometry`, `PathCohorts`, `PathRankLower`, `PathEvenRank`, `PathOddGeometry`, `PathOddRank`, `PathOddRankLower`, `PathOddBridge` | Arbitrary-support matching geometry, history ranks, the probe-count potential, and the odd equality obstruction, assembled into the complete path theorem. |
| `PathOEIS` | Arithmetic specialization to Kamenetsky's 2018 two- and three-probe formulas, alongside the separately proved physical path result. |
| `LadderCounters`, `LadderGeometry`, `LadderCardinality` | Complete counter optimum, exact physical projection, finite room cardinality and suffix attainment. |
| `ThreeCubeTrap`, `ThreeCubeLower` | Every same-color triple has at least seven neighbors; the arbitrary-strategy four-probe trap and five-probe feasibility. |
| `FiniteSubsetProfiles`, `ThreeCubeTimeProfiles`, `ThreeCubeTimeIsoperimetry` | A sound include/exclude finite-subset checker, kernel verification of all cube neighborhood profiles, and their interpretation for arbitrary Prop-valued supports. |
| `ThreeCubeTimeCounter`, `ThreeCubeTimeColors`, `ThreeCubeTimeUpper` | Finite lower potentials, parity/cardinality bridge, and physical upper schedules for the full cube table. |
| `FiveRowRankArithmetic`, `FiveRowOddRankArithmetic` | Universal scalar potential inequalities for the five-row three-probe proof. Its physical geometry and complete classification are not yet Lean theorems. |
| `FiveRowDeficitArithmetic` | Three universal implications from five row deficits: an exposed endpoint forces at most six missing cells; three consecutive exposed endpoint rows force at most five; alternating exposed rows force at most two. Their interpretation for physical neighborhoods, including the separate empty-row cases, remains an ordinary proof. |
| `FiveRowFourProbeArithmetic` | The four-probe potential inequality for every `h≥15`, valid cardinality/history mark, allocation up to four, and target allowed by the explicit historical transition relation. It includes every larger target in the surplus-at-least-three branch and has no finite cutoff on `h`. Geometry supplying the relation is not formalized. |
| `FiveRowFourProbeEquality` | For `h mod 3=0`, every positive tight transition from a full cohort allocates exactly two probes and reaches `h−1`; every tight transition from `h−1` allocates four. These are the universal local arithmetic facts used in the ordinary extra-day argument. |
| `FiveRowHighBudgetArithmetic` | Exhaustive allocation inequalities for `(h,m)=(15,8),(15,11),(20,14)`, giving the three exceptional high-budget lower checks. Kernel checked with no axioms; the physical cardinality lower profile is supplied by the ordinary geometry. |
| `UniformOddRank` | Uniform minimum-budget scalar potential inequalities and the two-cohort shared-budget bound. The geometric profile hypotheses remain explicit. |

The three-row and four-row all-budget theorems, the five-row classification
(closed formulas for all even lengths and budgets, and an exact recurrence
for odd lengths),
all-odd-box isoperimetry, side-two box application, and unbounded cylinder
construction have ordinary proofs and independent reviews. **They are not
fully formalized.** Checking these modules must not be described as checking
every result in the manuscript.

## Reproduction and trust

Run `python3 src/check_lean.py --lean /path/to/lean` from the archive root.
The script uses the pinned compiler, builds local dependencies first with `-j1`,
and stores outputs under `.build/lean`. It records exact source hashes, exit
codes, elapsed time, and printed axiom dependencies in the verification receipt.
No mathlib or other package is required.

Finite calculations use kernel reduction, including `decide +kernel` where
useful. There is no `native_decide`, admitted proof, external solver axiom, or
project-specific mathematical axiom in the completed result dependencies.
The printed dependency reports contain only Lean's standard `propext`,
`Classical.choice`, and `Quot.sound`, where applicable. Packed finite numeric
certificates are checked for their defining inequalities; their generating
search programs are not part of the trusted proof.

The fresh build and semantic reviews are separate evidence. Relevant reviews
are `research/path-matching-rank-proof.md`,
`research/ladder-game-independent-review.md`, and
`research/three-cube-time-independent-review.md`. The new five-row all-budget
ordinary proof is independently attacked in
`research/five-row-all-budget-independent-review.md`. Its arbitrary-budget
ammunition potential for `m≥5`, the actual attaining schedules, and the
geometric-to-scalar bridge remain ordinary proofs; the four new scalar
modules above do not imply full Lean verification of that theorem.

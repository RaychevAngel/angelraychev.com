EXPLICIT VERSUS LEARNED SEARCH
Neural-guided tree search and search-trace learning

Angel Raychev, 23 October 2026
Technical retrospective on joint 2025 work with Yalcin Tur and Mihajlo Stojkovic.

This is the source of the single current methods-and-results report.
The original course reports retain their original authorship and identity.
The empirical PNGs are unmodified assets recovered from their Overleaf projects.
The architecture diagrams are vector figures in the TeX source.
No model training or evaluation is needed to build this document.

Build from the extracted directory with a recent TeX Live installation:

    latexmk -pdf -interaction=nonstopmode -halt-on-error explicit-versus-learned-search.tex

Keep the figures/ directory beside the TeX file. All nonstandard packages are
available in TeX Live: lmodern, geometry, microtype, amsmath, amsfonts,
mathtools, booktabs, tools, graphics, xcolor, caption, float, placeins, pgf,
enumitem, fancyhdr, lastpage, titlesec, xurl and hyperref.

Article and canonical PDF:
https://angelraychev.com/explicit-versus-learned-search/

Code, historical evidence archive and run instructions:
https://github.com/RaychevAngel/classical_vs_contextual_search

Historical results are reproduced as historical, not newly replicated.
The refreshed verifier has not retrospectively rescored them. The earlier
developmental arrays and summary records in the repository are not the raw
run mapping for the final CS224R figures; the report preserves that distinction.

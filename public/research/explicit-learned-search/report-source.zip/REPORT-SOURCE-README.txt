Explicit versus learned search
Neural-guided tree search and search-trace learning
Angel Raychev, 23 October 2026

This is Angel's technical retrospective on joint 2025 work with Yalcin Tur
and Mihajlo Stojkovic. It is not a newly coauthored paper or a new experiment.
The original Stanford reports retain their original authorship and identity.

Source: explicit-versus-learned-search.tex
All three diagrams are vector figures defined in the TeX source. No external
image assets, model weights or experimental runs are needed to build this PDF.

Build with a recent TeX Live installation:
  latexmk -pdf -interaction=nonstopmode -halt-on-error \
    -outdir=output/pdf explicit-versus-learned-search.tex

Packages beyond the LaTeX base used by the report:
  lmodern, geometry, microtype, amsmath, amsfonts, mathtools, booktabs,
  tools (tabularx/array), graphics, xcolor, pgf (TikZ), enumitem,
  fancyhdr, lastpage, titlesec, xurl and hyperref.

Primary historical implementation snapshot:
  https://github.com/RaychevAngel/classical_vs_contextual_search/tree/1a7fda10617d34ccd3a87c825cba71e4429de91a

Companion article and current resources:
  https://angelraychev.com/explicit-versus-learned-search/

Historical measurements have not been rerun or rescored for this report.
Worked examples and architecture diagrams are explanatory illustrations,
not newly sampled trajectories or new empirical results.
